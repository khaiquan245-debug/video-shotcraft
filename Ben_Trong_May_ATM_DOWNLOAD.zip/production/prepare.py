from pathlib import Path
import json,wave,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;OFFSET=.04
m=json.loads((B/'audio/narration-native.json').read_text());assert m['inference_offline']
with wave.open(str(B/'audio/narration-native.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy();assert w.getframerate()==R
parts=[];cursor=0;spans=[];trims=[]
for i,q in enumerate(m['captions']):
 x=raw[round(q['start']*R):round(q['end']*R)];k=len(x)//480;v=x[:k*480].astype(float)/32768;energy=np.sqrt(np.mean(v.reshape(-1,480)**2,axis=1));active=np.where(energy>max(.004,float(np.max(np.abs(v)))*.013))[0];assert len(active)
 a=max(0,int(active[0])*480-round(.04*R));z=min(len(x),(int(active[-1])+1)*480+round(.045*R));start=cursor/R;parts.append(x[a:z]);cursor+=z-a;spans.append({'text':q['text'],'start':start,'end':cursor/R});trims.append({'sentence':i,'leading_removed':a/R,'trailing_removed':(len(x)-z)/R})
 if i<len(m['captions'])-1:parts.append(np.zeros(round(.045*R),dtype='<i2'));cursor+=round(.045*R)
compact=np.concatenate(parts);tempo=max(1.,len(compact)/R/37.8)
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-final.wav')],check=True)
with wave.open(str(B/'audio/narration-final.wav'))as w:vo_d=w.getnframes()/R
factor=len(compact)/R/vo_d
for s in spans:s.update(start=OFFSET+s['start']/factor,end=OFFSET+s['end']/factor)
D=math.ceil((OFFSET+vo_d+.35)*10)/10
phrases=[['Bạn đưa thẻ','vào máy ATM','và yêu cầu rút','một triệu đồng.'],['Nhưng bạn có biết','điều gì đang xảy ra','phía sau','màn hình không?'],['Đầu tiên,','máy đọc thông tin','cần thiết từ thẻ','và gửi','yêu cầu giao dịch','qua hệ thống','ngân hàng.'],['Sau khi bạn xác thực','và nhập số tiền,','hệ thống kiểm tra','tài khoản cùng','các điều kiện','giao dịch.'],['Nếu được chấp thuận,','bộ phận nhả tiền','bắt đầu hoạt động.'],['Bên trong máy','có những khay chứa','các mệnh giá tiền.'],['Các bánh lăn','tách từng tờ','và đưa chúng qua','hệ thống cảm biến.'],['Máy kiểm tra','quá trình lấy tiền,','đếm và chuẩn bị','đúng số lượng cần trả.'],['Nếu phát hiện tờ tiền','bị kẹt','hoặc không đạt yêu cầu,','máy có thể chuyển nó','sang ngăn riêng.'],['Cuối cùng,','tiền được đưa đến','khe nhận.'],['Bạn cầm tiền','và rời đi.'],['Toàn bộ quá trình','chỉ mất một khoảng','thời gian ngắn.'],['Nhưng phía sau đó','là sự phối hợp','giữa ngân hàng,','hệ thống bảo mật,','cảm biến','và hàng loạt','bộ phận cơ khí.']]
assert len(phrases)==len(spans);caps=[]
for s,ps in zip(spans,phrases):
 assert ' '.join(ps)==s['text']
 total=sum(len(p.split())for p in ps);a=s['start']
 for j,p in enumerate(ps):
  z=s['end']if j==len(ps)-1 else a+(s['end']-s['start'])*len(p.split())/total
  caps.append({'text':p,'start':a,'end':z,'emphasis':any(k in p for k in ['một triệu','chấp thuận','không đạt','ngăn riêng','cảm biến'])});a=z
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
keys=['insert','hook','read','verify','approve','cassettes','rollers','count','reject','present','take','fast','recap'];S={k:s['start']for k,s in zip(keys,spans)};S['insert']=0.;S['end']=D
# Four suitable notes first, an explicit conditional example, then a suitable replacement.
starts=np.linspace(S['rollers']+.1,S['reject']-1.2,4);notes=[{'id':f'accepted-{i+1}','start':float(t),'duration':1.05,'accepted':True,'value':200000}for i,t in enumerate(starts)]
notes += [{'id':'conditional-reject','start':S['reject']+.12,'duration':1.8,'accepted':False,'value':200000},{'id':'replacement-5','start':S['reject']+2.15,'duration':1.25,'accepted':True,'value':200000}]
assert notes[-1]['start']+notes[-1]['duration']<S['present'];assert sum(n['value']for n in notes if n['accepted'])==1000000
(B/'manifests/notes.json').write_text(json.dumps({'notes':notes,'payout_count':5,'denomination':200000,'payout_amount':1000000,'note':'Simplified illustrative transaction; conditional unsuitable-note case, not a claim that every withdrawal rejects a note.'},indent=2));(B/'manifests/story-times.json').write_text(json.dumps(S,indent=2));(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
meta={'duration':D,'vo_duration':vo_d,'native_duration':m['duration'],'compacted_duration':len(compact)/R,'offset':OFFSET,'pitch_preserving_tempo':tempo,'native_sha256':m['wav_sha256'],'voice_sha256':hashlib.sha256((B/'audio/narration-final.wav').read_bytes()).hexdigest(),'trim_log':trims,'sentence_spans':spans,'space_units':191,'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'offline':True}
(B/'manifests/voice.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(B/'manifests/project.json').write_text(json.dumps({'title':'Điều gì xảy ra bên trong máy ATM?','duration':D,'resolution':[1080,1920],'fps':30,'aspect':'9:16','style':'Original2D character and mechanical cutaway explainer','script':'Exact user narration, no additions','pacing_reference_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','schematic':'Simplified, illustrative; ATM hardware and card/cash order vary','illustrated_payout':'5 x200.000đ =1.000.000đ; abstract banknote artwork','paid_apis':False},ensure_ascii=False,indent=2))
print('VOICE',json.dumps({k:meta[k]for k in ['native_duration','compacted_duration','vo_duration','duration','pitch_preserving_tempo','space_units']}));print('STORY',S)
