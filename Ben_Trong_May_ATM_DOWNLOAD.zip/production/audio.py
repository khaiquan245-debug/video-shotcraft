from pathlib import Path
import json,wave,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000
S=json.loads((B/'manifests/story-times.json').read_text());vm=json.loads((B/'manifests/voice.json').read_text());notes=json.loads((B/'manifests/notes.json').read_text())['notes'];D=S['end'];N=round(D*R);T=np.arange(N)/R;rng=np.random.default_rng(20261121)
with wave.open(str(B/'audio/narration-final.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768;assert w.getframerate()==R
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==vm['native_sha256']
V=np.zeros(N,np.float32);i=round(vm['offset']*R);V[i:i+len(raw)]=raw
F=np.zeros((N,2),np.float32);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;n=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='key':a=(np.sin(2*np.pi*880*t)+.2*np.sin(2*np.pi*1320*t))*env
 elif kind=='chip':a=(np.sin(2*np.pi*1760*t)+.3*np.sin(2*np.pi*2350*t))*env
 elif kind=='motor':a=(.4*np.sin(2*np.pi*110*t)+.2*np.sin(2*np.pi*220*t)+.4*np.convolve(n,np.ones(21)/21,'same'))*env
 elif kind=='paper':a=(n-np.convolve(n,np.ones(22)/22,'same'))*.25*env
 elif kind=='click':a=(np.sin(2*np.pi*620*t)+.35*n)*np.exp(-t/.014)
 elif kind=='tray':a=(.7*np.sin(2*np.pi*185*t)+.2*np.sin(2*np.pi*390*t)+.1*n)*np.exp(-t/.04)
 elif kind=='confirm':a=(np.sin(2*np.pi*(659.25+220*(t>d*.45))*t)+.3*np.sin(2*np.pi*1318.5*t))*env
 elif kind=='whoosh':a=np.convolve(n,np.ones(19)/19,'same')*env
 elif kind=='step':a=(np.sin(2*np.pi*120*t)+.2*np.convolve(n,np.ones(9)/9,'same'))*np.exp(-t/.027)
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 i=round(at*R);assert 0<=i<N
 x=fx(kind,d)[:N-i]*gain;F[i:i+len(x),0]+=x*np.sqrt((1-pan)/2);F[i:i+len(x),1]+=x*np.sqrt((1+pan)/2)
 events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,6),'duration':d,'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'source':'Original local oscillator/noise Foley in production/audio.py','rights':'Self-created'})
add(.43,'motor',.055,.49,.15,'Card feeds through the visible reader slot')
add(.76,'click',.04,.07,.15,'Card clears reader entrance')
add(S['hook'],'whoosh',.07,.25,0,'Front panel cuts to mechanical schematic')
add(S['read']+.22,'chip',.027,.11,-.3,'Protected transaction packet leaves mini ATM')
for at in np.arange(S['verify']+.12,S['verify']+.7,.16):add(float(at),'key',.025,.065,.08,'Masked authentication dots appear while fingers tap keypad')
add(S['approve']+.75,'confirm',.045,.24,.25,'Bank approves the illustrated withdrawal')
add(S['cassettes'],'click',.027,.08,-.2,'Cut to banknote cassettes')
add(S['rollers']+.03,'motor',.028,S['present']-S['rollers']-.03,.05,'Transport rollers run during banknote feeding; not before authorization')
for n in notes:
 add(n['start'],'paper',.045,.16,-.18,'Pickup from active 200000 dong cassette: '+n['id'])
 add(n['start']+n['duration']*(.63 if n['accepted']else .58),'chip',.019,.07,.12,'Sensor passage: '+n['id'])
 if n['accepted']:add(n['start']+n['duration'],'paper',.038,.12,.35,'Suitable note settles in payout stack; count increments: '+n['id'])
 else:
  add(n['start']+n['duration']*.58,'click',.045,.065,-.2,'Diverter selects separate bin in the explicit conditional example')
  add(n['start']+n['duration'],'tray',.05,.14,-.4,'Unsuitable note arrives in separate bin and is excluded from payout')
add(notes[-1]['start']+notes[-1]['duration']+.06,'confirm',.028,.21,.3,'Five suitable 200000 dong notes complete one million dong')
add(S['present']+.1,'motor',.05,.55,.3,'Presenter moves counted cash into public cash slot')
add(S['present']+.2,'click',.03,.09,-.15,'Card returns through reader to left hand')
add(S['take']+.35,'paper',.055,.24,.2,'Five-note bundle transfers from slot to right hand')
for at in np.arange(S['fast']+.09,S['recap']-.03,.2):add(float(at),'step',.045,.09,-.1,'Shoes contact lobby floor while customer leaves holding cash and card')
add(S['recap'],'whoosh',.055,.25,0,'Four-part recap diagram replaces lobby')
# Original light technical score at 128 BPM. No sampled recordings or external music.
M=np.zeros(N,np.float32);scale=[293.665,440,349.228,523.251,391.995,349.228,440,261.626]
for k,at in enumerate(np.arange(.03,D-.25,60/128)):
 i=round(at*R);d=min(.62,(N-i)/R);tt=np.arange(round(d*R))/R;f=scale[k%8]
 z=(np.sin(2*np.pi*f*tt)+.24*np.sin(2*np.pi*f*2*tt)+.07*np.sin(2*np.pi*f*3*tt))*np.exp(-tt/.13)
 M[i:i+len(z)]+=.018*z
 if k%4==0:M[i:i+len(z)]+=.009*np.sin(2*np.pi*f/2*tt)*np.exp(-tt/.2)
noise=rng.normal(0,1,N).astype(np.float32);A=.005*np.convolve(noise,np.ones(37)/37,'same');A*=np.where((T<S['hook'])|((T>=S['verify'])&(T<S['approve']))|((T>=S['present'])&(T<S['recap'])),1,.5)
rms=np.sqrt(np.mean(V.reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(15)/15,'same');M*=np.interp(np.arange(N),np.arange(len(gate))*480,1-.66*gate)
fade=np.minimum(1,np.minimum(T/.035,(D-T)/.24));M*=fade;A*=fade;F*=fade[:,None]
stereo=np.column_stack((V+M+A,V+M+.97*A))+F;pre=min(1.,.98/float(np.max(np.abs(stereo))));stereo*=pre

def save(name,a):
 with wave.open(str(B/'audio'/name),'wb')as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',A),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
caps=json.loads((B/'manifests/captions.json').read_text())
def ts(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Ben_Trong_May_ATM.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}'for i,q in enumerate(caps)),encoding='utf-8')
(B/'manifests/sound-events.json').write_text(json.dumps({'events':events,'music':'Original light technical plucked composition,128 BPM','source':'All music, ambience and SFX generated locally with oscillators and noise','pre_master_gain':pre,'paid_apis':False},ensure_ascii=False,indent=2));print('AUDIO',D,'seconds,',len(events),'original SFX cues; gain',pre)
