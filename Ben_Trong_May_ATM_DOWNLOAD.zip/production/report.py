from pathlib import Path
import json,hashlib,csv,shutil
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';q=json.loads((B/'qa/final.json').read_text());vm=json.loads((B/'manifests/voice.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());nm=json.loads((B/'manifests/notes.json').read_text());notes=nm['notes'];sound=json.loads((B/'manifests/sound-events.json').read_text())
script=(B/'audio/script-approved.txt').read_text();assert len(script.split())==191
assert ' '.join(c['text']for c in caps)==' '.join(script.split())
accepted=[n for n in notes if n['accepted']];rejected=[n for n in notes if not n['accepted']]
assert len(accepted)==5 and len(rejected)==1 and sum(n['value']for n in accepted)==1000000
assert min(n['start']for n in notes)>S['approve']+.75
assert max(n['start']+n['duration']for n in accepted)<S['present']
account={'suitable_count':5,'denomination_dong':200000,'payout_dong':1000000,'conditional_unsuitable_count':1,'picked_total':6,'unsuitable_included_in_payout':False,'all_authorized_before_cash_feeds':True,'all_suitable_notes_arrive_before_presenter':True,'cash_hand_transfer_time':S['take']+.35,'single_payout':True,'card_return_before_departure':True,'illustration_only':True,'disclaimer':'Simplified transport; construction and card/cash order vary. Conditional unsuitable-note example is not a claim that all transactions reject a note or that jams can always be diverted. No specific counterfeit-detection claim.','notes':notes}
(B/'qa/money-accounting.json').write_text(json.dumps(account,ensure_ascii=False,indent=2))
pacing={'space_units':191,'film_seconds':q['duration'],'units_per_film_second':191/q['duration'],'reference_seconds':38.220045,'reference_units':191,'reference_units_per_second':191/38.220045,'native_voice_seconds':vm['native_duration'],'compacted_seconds':vm['compacted_duration'],'edited_voice_seconds':vm['vo_duration'],'pitch_preserving_tempo':vm['pitch_preserving_tempo'],'narration_max_quiet_seconds':q['narration_max_quiet_seconds'],'measurement':'Personal reference pacing measured as Vietnamese whitespace units / entire film duration, not a universal YouTube rule.'}
(B/'qa/pacing-comparison.json').write_text(json.dumps(pacing,ensure_ascii=False,indent=2))
origin={'characters':'Original procedural chibi character inherited from the previous original project; fixed identity and two-bone arms/legs','environments':'New original ATM lobby, front panel, schematic transport and transaction/recap diagrams in production/film.mjs','banknotes':'Abstract stylized denomination rectangles, not reproductions of banknotes','reference_video':'Pacing study only, no reference video/image/audio redistributed or composited','music_and_sfx':'Self-created oscillator/noise synthesis in production/audio.py','font':'Nunito, SIL Open Font License, included','tts':'VieNeu-TTS v3 Turbo, Apache-2.0 model, local ONNX CPU, stock preset','paid_apis':False,'previous_projects_modified':False,'installed_skill_modified':False,'model_weights_outside_git':True}
(B/'qa/asset-origin.json').write_text(json.dumps(origin,ensure_ascii=False,indent=2))
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));sheet=Image.new('RGB',(180*8,348*((len(files)+7)//8)),'#253a31');d=ImageDraw.Draw(sheet)
for i,f in enumerate(files):
 im=Image.open(f);im.thumbnail((178,318));x=i%8*180;y=i//8*348;sheet.paste(im,(x,y+25));d.text((x+5,y+4),f'{i:02d}s',fill='white')
sheet.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
with (O/'Shot_Timeline.csv').open('w',newline='',encoding='utf-8-sig')as f:
 w=csv.writer(f);w.writerow(['stage','start_seconds','end_seconds','approved_narration']);spans=vm['sentence_spans'];keys=[k for k in S if k!='end']
 for i,(k,s)in enumerate(zip(keys,spans)):w.writerow([k,round(S[k],3),round(S[keys[i+1]]if i+1<len(keys)else S['end'],3),s['text']])
shutil.copy2('/workspace/outputs/production_rules/SHORTS_NHIP_KE_NHANH.md',O/'SHORTS_NHIP_KE_NHANH.md')
(O/'README.md').write_text(f'''# Điều gì xảy ra bên trong máy ATM?

Video hoàn chỉnh: **{q['duration']:.1f} giây · 1080×1920 · 9:16 · 30fps · H.264/AAC**.

- [{Path(q['file']).name}]({Path(q['file']).name}) — mở để xem hoặc tải.
- [Gói video, phụ đề và mã nguồn](Ben_Trong_May_ATM_DOWNLOAD.zip).
- [Phụ đề tiếng Việt](Ben_Trong_May_ATM.vi.srt).
- [Báo cáo thực tế](Production_Report.md).

Giữ nguyên toàn bộ lời kể người dùng: 191 tiếng theo cách đếm khoảng trắng. Nhịp khoảng 5 tiếng/giây. Có hoạt hình nhân vật và cơ cấu nhả tiền, nhạc nền, SFX và phụ đề cháy vào hình.

**Hình cắt lớp là mô hình minh họa giản lược. Cấu tạo máy, thứ tự trả thẻ/tiền và quy trình xử lý lỗi có thể khác nhau.** Minh họa giao dịch bằng 5 tờ 200.000đ; ví dụ một tờ không phù hợp được tách riêng và thay bằng tờ hợp lệ, không tính thêm vào số tiền trao ra.

Giọng yêu cầu trong adapter: Minh Quân. Preset thực tế: Hải Đăng, nam Bắc tự nhiên; model VieNeu-TTS v3 Turbo, ONNX CPU ngoại tuyến. Không dùng API trả phí. Trọng số không có trong Git hoặc ZIP.

Mở MP4 bằng trình duyệt/VLC, hoặc chạy `python production/serve.py` sau khi giải nén rồi mở http://127.0.0.1:8831/.

Tái dựng trong môi trường Video Shotcraft đã cài: Python + NumPy + Pillow, Node.js + @napi-rs/canvas, FFmpeg. Bộ mã hiện tìm canvas trong `/workspace/video-shotcraft/workbench/package.json`; sửa đường dẫn này nếu vị trí cài đặt khác. Giữ thư mục `audio`, `assets`, `manifests`, `production`, `qa`, `logs`, `output` trong cùng gốc. WAV gốc được lưu nguyên, không cần chạy lại TTS.

```bash
mkdir -p output qa logs
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
```

Trước khi chạy, chép MP4/SRT và các tài liệu ở gốc ZIP vào `output/` nếu muốn dùng trang preview. Xem CREDITS.md cho nguồn và giấy phép.
''',encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn và giấy phép

- Hình nhân vật, ATM, môi trường, sơ đồ, chuyển động và tiền minh họa: mã vẽ gốc của dự án; không dùng cảnh hoặc âm thanh từ video tham khảo. Nhân vật giữ thiết kế gốc của các Shorts trước.
- Kịch bản: toàn bộ lời kể tiếng Việt người dùng cung cấp, không thêm lời hoặc đổi cốt ý.
- Nhạc nền 128 BPM, âm môi trường và 45 SFX: tự tổng hợp tại máy bằng dao động/sóng và nhiễu trong `production/audio.py`, không có bản ghi của bên thứ ba.
- Font Nunito: SIL Open Font License 1.1, bản font và giấy phép kèm `assets/`.
- VieNeu-TTS v3 Turbo: https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo — Apache-2.0 model, ONNX CPU offline. Preset thực tế Hải Đăng, alias adapter Minh Quân. Không giả giọng cá nhân mới.
- Phần mềm: FFmpeg, @napi-rs/canvas, NumPy, Pillow và trình duyệt Chromium/Remotion cho kiểm tra kỹ thuật.
- Không dùng dịch vụ/API trả phí. Không đưa trọng số mô hình hoặc video tham khảo vào gói tải.
''',encoding='utf-8')
(O/'Production_Report.md').write_text(f'''# Báo cáo thực tế — Bên trong máy ATM

## Sản phẩm

- Tệp đã xuất: `{Path(q['file']).name}`.
- {q['duration']} giây, {q['frames']} khung hình, 1080×1920, 30fps, H.264 yuv420p, AAC stereo 48kHz.
- Dung lượng: {q['bytes']:,} byte.
- SHA-256: `{q['sha256']}`.
- MP4 có lời kể, nhạc tự sáng tác, {len(sound['events'])} cue SFX và phụ đề tiếng Việt. Có hoạt hình khớp nhân vật, di chuyển thẻ, tiền theo đường dẫn, bánh lăn quay, cảm biến/gạt và bộ đếm; không phải slideshow ảnh.

## Giọng kể và nhịp

Toàn bộ 191 tiếng theo cách đếm khoảng trắng được giữ nguyên. File TTS gốc {vm['native_duration']} giây được bảo toàn; chỉ cắt im lặng đầu/cuối câu, nối khoảng nghỉ 45ms rồi dùng `atempo={vm['pitch_preserving_tempo']:.6f}` giữ cao độ. Bản voice sau xử lý dài {vm['vo_duration']} giây; phim 38,2 giây ≈5,00 tiếng/giây, gần video tham khảo 38,220045 giây với191tiếng. Đây là chuẩn nhịp tham khảo riêng của dự án.

Model thực tế: **{q['voice']['model']}**; backend **{q['voice']['backend']}**, CPU, ngoại tuyến. Voice adapter yêu cầu **Minh Quân**, preset thực tế **Hải Đăng** (nam Bắc tự nhiên). Không dùng model khác thay thế. WAV gốc và metadata/hashes kèm gói.

Phụ đề chia cụm nghĩa một dòng, canh từ thời lượng từng câu đã đo. Chưa thực hiện forced alignment từng từ; không tuyên bố độ chính xác từng âm tiết.

## Hình và tính nhất quán

Nhân vật áo cam, tóc đen, quần xanh và giày vàng giữ thiết kế. Hai xương trên mỗi tay/chân; kiểm tra tất cả khung hình có nhân vật: {q['rig']['samples']} phép giải, {q['rig']['unreachable']} mục tiêu ngoài tầm; sai số chiều dài xương tối đa {q['rig']['maxBoneError']:.3g}. Đã kiểm tra contact sheet bản mã hóa và các thời điểm đưa thẻ, nhập mã, tiền qua cảm biến, tách vào ngăn riêng, trả thẻ và nhận tiền.

Thẻ chỉ có chip/dấu chấm giả lập, mã xác thực được che. Số tiền minh họa: **5×200.000đ =1.000.000đ**. Có một ví dụ tờ không đạt; nó không được tính vào 5 tờ trả ra, sau đó một tờ hợp lệ thay thế. `qa/money-accounting.json` ghi lịch từng tờ. Mọi tờ bắt đầu di chuyển sau chấp thuận.

**Sơ đồ cơ khí giản lược; không đại diện một mẫu ATM/ngân hàng cụ thể.** Xử lý kẹt, điều kiện giao dịch, thứ tự trả thẻ/tiền và khả năng cảm biến có thể khác nhau. Cảnh loại tờ không phù hợp không khẳng định mọi lỗi kẹt đều có thể tự chuyển ngăn, không đưa ra tuyên bố phát hiện tiền giả.

## Kiểm tra kỹ thuật

- FFprobe: đúng kích thước, tốc độ hình, codec và {q['frames']} khung hình.
- FFmpeg giải mã toàn bộ tệp: qua, không báo lỗi.
- Loudness đo từ MP4 AAC: **{q['lufs']} LUFS**, true peak **{q['true_peak_dbfs']} dBFS**.
- Khoảng yên lời kể dài nhất theo ngưỡng RMS0,003 trên cửa sổ10ms: **{q['narration_max_quiet_seconds']} giây**. Đây là chỉ báo năng lượng, không phân tích âm vị.
- Phụ đề nối lại khớp chính xác kịch bản; đo bề rộng raster trước render, không tràn vùng650px thiết kế.
- Có ảnh lấy từ MP4 cuối cùng, log rig, loudness và báo cáo phát kỹ thuật Chromium1× đi kèm gói.

## Giới hạn kiểm tra

Đã xem các khung hình thực tế và kiểm tra kỹ thuật phát trọn tệp. Trình duyệt được chạy ở chế độ tắt tiếng cho kiểm tra tự động; không có nghe thẩm âm bởi người và không tuyên bố người dùng đã duyệt thẩm mỹ. Hoạt hình2D sơ đồ gốc, không phải ảnh quay cơ khí thực hay mô phỏng một ATM thương mại cụ thể.

## Bảo toàn

Không thay đổi Video Shotcraft, skill đã cài hoặc dự án cũ. Tất cả tệp mới trong thư mục ATM riêng. Trọng số ở runtime ngoài Git; ZIP không chứa mô hình, secrets hay video tham khảo. Không dùng API, thuê bao hay GPU trả phí.
''',encoding='utf-8')
print('REPORTS',q['sha256'],len(files),'encoded frame samples')
