from pathlib import Path
import json,wave,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;OFFSET=.04
m=json.loads((B/'audio/narration-native.json').read_text());assert m['inference_offline']
with wave.open(str(B/'audio/narration-native.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy();assert w.getframerate()==R
parts=[];cursor=0;spans=[];trims=[]
for i,q in enumerate(m['captions']):
 x=raw[round(q['start']*R):round(q['end']*R)];ws=480;k=len(x)//ws;v=x[:k*ws].astype(float)/32768;energy=np.sqrt(np.mean(v.reshape(-1,ws)**2,axis=1));active=np.where(energy>max(.004,float(np.max(np.abs(v)))*.013))[0];assert len(active)
 a=max(0,int(active[0])*ws-round(.04*R));z=min(len(x),(int(active[-1])+1)*ws+round(.045*R));start=cursor/R;parts.append(x[a:z]);cursor+=z-a;spans.append({'text':q['text'],'start':start,'end':cursor/R});trims.append({'sentence':i,'leading_removed':a/R,'trailing_removed':(len(x)-z)/R})
 if i<len(m['captions'])-1:
  gap=.15 if i==len(m['captions'])-2 else .045
  parts.append(np.zeros(round(gap*R),dtype='<i2'));cursor+=round(gap*R)
compact=np.concatenate(parts);tempo=max(1.,len(compact)/R/33.6)
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-final.wav')],check=True)
with wave.open(str(B/'audio/narration-final.wav'))as w:vo_d=w.getnframes()/R
factor=len(compact)/R/vo_d
for s in spans:s.update(start=OFFSET+s['start']/factor,end=OFFSET+s['end']/factor)
D=math.ceil((OFFSET+vo_d+.35)*10)/10
phrases=[['Một người đàn ông','mua được','chiếc điện thoại cũ','ở chợ đồ điện tử.'],['Nhưng khi gọi thử,','anh phát hiện','nó có thể liên lạc','với chính mình','trong quá khứ.'],['Anh lập tức gọi về','sáng hôm qua.'],['Anh nhắc bản thân','đừng làm đổ cà phê','lên máy tính.'],['Ngay lập tức,','chiếc máy tính trước mặt','trở lại như mới.'],['Anh vô cùng kinh ngạc.'],['Anh tiếp tục gọi về','tuần trước,','nhắc mình đừng mua','đôi giày quá đắt.'],['Một hộp giày','lập tức biến mất','khỏi phòng.'],['Nhưng anh bắt đầu','tham lam.'],['Anh gọi về','một năm trước','để bảo bản thân','mua thật nhiều vé số.'],['Ngay khi cuộc gọi','kết thúc,','căn phòng biến thành','một biệt thự sang trọng.'],['Anh vui mừng','chạy khắp nhà.'],['Nhưng chiếc điện thoại','bất ngờ đổ chuông.'],['Người gọi đến','là chính anh','của tương lai.'],['Và câu đầu tiên','anh nghe được là...'],['Đừng bao giờ gọi','cuộc điện thoại','tiếp theo!']]
assert len(phrases)==len(spans)
caps=[]
for s,ps in zip(spans,phrases):
 assert ' '.join(ps)==s['text']
 total=sum(len(p.split())for p in ps);a=s['start']
 for j,p in enumerate(ps):
  z=s['end']if j==len(ps)-1 else a+(s['end']-s['start'])*len(p.split())/total
  caps.append({'text':p,'start':a,'end':z,'emphasis':any(k in p for k in ['quá khứ','biến mất','tham lam','tương lai','Đừng bao giờ','tiếp theo'])});a=z
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
keys=['market','test','yesterday','coffee','healed','shock','shoes_call','box_gone','greed','lottery','villa','run','ring','future','lead_in','warning'];S={k:s['start']for k,s in zip(keys,spans)};S['market']=0.;S['end']=D
S['villa_change']=next(q['start']for q in caps if q['text']=='căn phòng biến thành');S['ring_hit']=next(q['start']for q in caps if q['text']=='bất ngờ đổ chuông.')+.01
(B/'manifests/story-times.json').write_text(json.dumps(S,indent=2));(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
meta={'duration':D,'vo_duration':vo_d,'native_duration':m['duration'],'compacted_duration':len(compact)/R,'offset':OFFSET,'pitch_preserving_tempo':tempo,'native_sha256':m['wav_sha256'],'voice_sha256':hashlib.sha256((B/'audio/narration-final.wav').read_bytes()).hexdigest(),'trim_log':trims,'sentence_spans':spans,'space_units':170,'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'offline':True,'final_warning_join_before_tempo':.15}
(B/'manifests/voice.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(B/'manifests/project.json').write_text(json.dumps({'title':'Chiếc điện thoại gọi về quá khứ','duration':D,'resolution':[1080,1920],'fps':30,'aspect':'9:16','style':'Original full-color2D narrative cartoon; preceding Shorts character continuity','script':'Exact user narration, no additions','pacing_reference_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','paid_apis':False},ensure_ascii=False,indent=2))
print('VOICE',json.dumps({k:meta[k]for k in ['native_duration','compacted_duration','vo_duration','duration','pitch_preserving_tempo','space_units']}));print('STORY',S)
