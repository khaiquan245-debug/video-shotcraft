"""Local-only media preview with byte-range requests for accurate browser seeking."""
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,re
ROOT=Path(__file__).resolve().parents[1]/'output'
class Media(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def send_head(self):
  p=Path(self.translate_path(self.path));self.slice=None
  try:p.resolve().relative_to(ROOT)
  except ValueError:self.send_error(403);return None
  h=self.headers.get('Range')
  if not h or not p.is_file():return super().send_head()
  m=re.fullmatch(r'bytes=(\d*)-(\d*)',h)
  if not m:self.send_error(416);return None
  size=p.stat().st_size
  start=int(m[1]) if m[1] else max(0,size-int(m[2]));end=min(size-1,int(m[2]) if m[2]and m[1]else size-1)
  if start>=size or end<start:self.send_error(416);return None
  f=p.open('rb');f.seek(start);self.slice=end-start+1
  self.send_response(206);self.send_header('Content-Type',self.guess_type(str(p)));self.send_header('Accept-Ranges','bytes');self.send_header('Content-Range',f'bytes {start}-{end}/{size}');self.send_header('Content-Length',str(self.slice));self.end_headers();return f
 def end_headers(self):self.send_header('Accept-Ranges','bytes');super().end_headers()
 def copyfile(self,src,dst):
  remaining=self.slice
  try:
   while remaining is None or remaining>0:
    data=src.read(65536 if remaining is None else min(65536,remaining))
    if not data:break
    dst.write(data)
    if remaining is not None:remaining-=len(data)
  except (BrokenPipeError,ConnectionResetError):pass
print('Local media player: http://127.0.0.1:8825/',flush=True)
ThreadingHTTPServer(('127.0.0.1',8825),Media).serve_forever()
