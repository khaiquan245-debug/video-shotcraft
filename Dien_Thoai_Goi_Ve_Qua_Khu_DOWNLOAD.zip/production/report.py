from pathlib import Path
import json,wave,hashlib,csv,subprocess
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';r=json.loads((B/'qa/final.json').read_text());v=json.loads((B/'manifests/voice.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());sounds=json.loads((B/'manifests/sound-events.json').read_text())
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split());assert len((B/'audio/script-approved.txt').read_text().split())==170
with wave.open(str(B/'audio/voice-timeline.wav'))as w:x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
n=len(x)//480;rms=np.sqrt(np.mean(x[:n*480].reshape(-1,480)**2,axis=1));times=np.arange(n)/100;active=np.where(rms>.003)[0];inside=rms[active[0]:active[-1]+1];best=run=0
for quiet in inside<.003:run=run+1 if quiet else 0;best=max(best,run)
before=np.where((times>=S['lead_in'])&(times<S['warning'])&(rms>.003))[0];after=np.where((times>=S['warning'])&(rms>.003))[0];gap=max(0,(int(after[0])-int(before[-1])-1)/100)
summary={'reference_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','reference_duration':38.220045,'reference_transcript_units':191,'reference_units_per_video_second':191/38.220045,'script_units':170,'duration':r['duration'],'units_per_video_second':170/r['duration'],'max_internal_quiet_seconds':best/100,'warning_gap_rms_seconds':gap,'warning_sentence_envelope_gap':S['warning']-v['sentence_spans'][-2]['end'],'caption_cues':len(caps),'sfx_events':len(sounds['events']),'mp4_sha256':r['sha256'],'note':'Vietnamese space-delimited units are approximate. Reference ASR boundaries and isolated-stem RMS silence are not equivalent measurements.'};(B/'qa/pacing-comparison.json').write_text(json.dumps(summary,indent=2))
(O/'README.md').write_text('''# Chiếc điện thoại gọi về quá khứ

Video 34 giây, 1080×1920, 30 fps, hoạt hình 2D có nhân vật và đồ vật chuyển động. Mở `Dien_Thoai_Goi_Ve_Qua_Khu_34s_1080x1920.mp4` hoặc `index.html`.

Giữ nguyên 170 tiếng của kịch bản; nhịp toàn phim 5 tiếng/giây theo mẫu người dùng. Có phụ đề tiếng Việt, nhạc và SFX. Nhịp trước câu cảnh báo cuối ngắn, không thêm khoảng đứng hình dài.

Giọng thực tế: VieNeu-TTS v3 Turbo, ONNX CPU offline, preset Hải Đăng; Minh Quân là alias trong adapter hiện tại. Giọng native được giữ nguyên; bản dựng chỉ thu gọn khoảng yên và xử lý tốc độ khoảng 1,043×, giữ cao độ. Câu cuối dùng cùng giọng qua EQ điện thoại, không đổi model hoặc recast người kể.

Các khung hiện tại/quá khứ dùng cùng nhân vật với bối cảnh và hành động tương ứng. Điện thoại cũ giữ nguyên thiết kế qua toàn phim. Máy tính được sửa tại chỗ, hộp giày không trở lại sau khi biến mất, và căn phòng đổi quanh nhân vật thành biệt thự. Cuối phim nhân vật chưa bấm cuộc gọi tiếp theo.

ZIP có MP4, SRT, source Canvas/FFmpeg, các WAV, metadata, font/giấy phép và QA; không có model weights hoặc video tham khảo. Không API trả phí.

Muốn dựng lại, tạo bản sao ở thư mục mới và giữ các WAV đã duyệt. Cần Canvas hiện có trong `/workspace/video-shotcraft/workbench/package.json`:

```bash
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
```

Đọc `Production_Report.md` để xem kiểm tra và giới hạn. Biên phụ đề trong câu ước lượng theo cụm nghĩa, chưa forced-align từng từ; không tự nhận đã duyệt phát âm bằng tai người.
''',encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn

Lời kể do người dùng cung cấp, giữ nguyên. Nhân vật chính kế thừa thiết kế của các Shorts trước; tranh nền chợ điện tử, căn phòng, quầy giày/vé số, biệt thự, người bán, điện thoại và các biến đổi được vẽ/diễn hoạt riêng bằng vector trong production/film.mjs. Không ghép khung hình hoặc soundtrack từ video mẫu.

Giọng: VieNeu-TTS v3 Turbo, Apache-2.0, ONNX CPU local; preset thực tế Hải Đăng, alias Minh Quân trong adapter. Nguồn model: https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo . Native WAV và checksum được bảo toàn; trọng số model không ở trong Git/ZIP.

Nhạc, Foley và nhạc chuông được tổng hợp bằng oscillator/noise trong production/audio.py. Nhạc chuông là chuỗi nốt tự viết, không lấy bản thu thương mại. Các tiếng phím dùng tần số chức năng DTMF. Câu cảnh báo cuối là cùng voice native qua EQ, không thêm lời nói mới.

Font Nunito theo SIL OFL, kèm assets/OFL-Nunito.txt. Không API trả phí, cloud inference hoặc subscription mới.
''',encoding='utf-8')
report=f'''# Kết quả thực tế — Điện thoại gọi về quá khứ

Tệp MP4 thật dài **{r['duration']:.3f} giây**, **1080×1920**, **30 fps**, **{r['frames']} frame**, có H.264 yuv420p và AAC stereo 48 kHz. Giữ nguyên 170 tiếng theo khoảng trắng và toàn bộ thứ tự lời kể người dùng. Đây là hoạt hình vector 2D có khớp tay/chân, động tác cầm/bấm điện thoại, cốc cà phê, chuyển đồ vật và chạy; không phải slideshow ảnh tĩnh.

## Nhịp kể và dừng

| Chỉ số | Video mẫu | Phim mới |
|---|---|---|
| Thời lượng | 38,22 giây | 34 giây |
| Tiếng tách theo khoảng trắng | 191, lời dựng lại | 170, nguyên văn |
| Mật độ lời toàn phim | ≈5,00/giây | 5,00/giây |

Video vừa tải được xác nhận trùng mẫu đã phân tích bằng SHA-256. Mốc ASR của mẫu không đồng nhất với phép đo RMS trên track giọng riêng; không tuyên bố mọi khoảng nghỉ giống hệt hay cùng giọng/model với mẫu.

Giọng native {v['native_duration']} giây được giữ file gốc. Thu gọn biên câu với đệm 40/45 ms và khoảng nối 45 ms, riêng trước câu cảnh báo cuối là 150 ms trước tempo. Bản ghép {v['compacted_duration']:.3f} giây được xử lý FFmpeg atempo={v['pitch_preserving_tempo']:.6f}, giữ cao độ, cho giọng {v['vo_duration']:.3f} giây. Không xóa hoặc thêm từ. Khoảng yên lớn nhất giữa phần có lời theo RMS<0,003 là **{best/100:.2f} giây**; quanh lần đổi sang câu cảnh báo đo được khoảng **{gap:.2f} giây**. Đây là phép đo trên stem giọng trước master mix.

## Hình, đạo cụ và âm thanh

Nhân vật ở hiện tại/quá khứ/tương lai dùng cùng hình và rig; vai tương lai thêm tóc xám, người bán có áo/mũ/râu riêng. Khung hiện tại/quá khứ giúp đọc hệ quả của lời nhắc. Điện thoại giữ cùng hình, luôn bám cổ tay khi được cầm; không nhân đôi cùng một chiếc trên quầy và trong tay sau khi nhặt. Cốc đặt trên bàn sau khi máy tính hồi phục; hộp giày biến mất và không xuất hiện lại khi biệt thự hình thành. Cảnh chạy có chu kỳ chân và quay đầu; cuối phim ngón tay dừng trước phím gọi.

Biến đổi diễn ra bằng thay đổi trạng thái vật thể/nền vẽ và động tác, không dựa vào cập nhật chữ. Đã sửa cao độ quầy/mặt sàn, chân ghế biệt thự, giữ cốc cà phê, chuyển điện thoại từ bàn tay lên tai, và tránh vẽ ngón tay bấm điện thoại khi tay đang cầm cốc. Những kiểm tra rig không chứng minh mọi che khuất hoặc chuyển động đều hoàn hảo.

Giọng thực tế **VieNeu-TTS v3 Turbo**, **ONNX CPU offline**, **Hải Đăng** (alias **Minh Quân**). Câu cảnh báo dùng cùng voice qua highpass/lowpass/EQ kiểu điện thoại; không tạo giọng mới hoặc thêm thoại. Nhạc và {len(sounds['events'])} sự kiện SFX tự tổng hợp; nhạc chuông nguyên tác, nhạc nền nhường chỗ cho cuộc gọi cuối. {len(caps)} cụm phụ đề một dòng, theo biên câu đã đo và biên cụm nghĩa ước lượng; chưa forced alignment từng từ.

## QA

- Giải mã toàn bộ MP4 thành công; âm lượng **{r['lufs']} LUFS**, true peak **{r['true_peak_dbfs']} dBTP**.
- Khoảng yên lớn nhất trên toàn track giọng: **{r['narration_max_quiet_seconds']:.2f} giây**, gồm đuôi kết.
- Rig solver kiểm tra **{r['rig']['samples']} mẫu**, **{r['rig']['unreachable']} đích ngoài tầm**; sai số chiều dài xương tối đa **{r['rig']['maxBoneError']:.3g}**.
- SHA-256: `{r['sha256']}`.

Đã xem ảnh trích từ MP4 thật ở các nhịp chính, kiểm tra browser playback 1× để xác nhận tệp chạy hết. Phiên kiểm tra phát tắt tiếng, không thay cho người dùng nghe đánh giá chất giọng/nhạc/SFX. Không tự chứng nhận tương đương thẩm mỹ với mẫu hoặc sự duyệt của người dùng.

Các dự án cũ, narration đã có và installed skills được giữ nguyên. Model weights nằm ngoài Git. Toàn bộ TTS/render/mix chạy local, không paid API. Dự án: `{B}`.
'''
(O/'Production_Report.md').write_text(report,encoding='utf-8')
with(O/'Shot_Timeline.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['action','start_seconds','next_event_seconds']);keys=sorted(S,key=S.get)
 for i,k in enumerate(keys[:-1]):w.writerow([k,S[k],S[keys[i+1]]])
(B/'qa/asset-origin.json').write_text(json.dumps({'film_source_sha256':hashlib.sha256((B/'production/film.mjs').read_bytes()).hexdigest(),'origin':'Original project vector artwork and own preceding character design','reference_video_pixels_or_audio_in_final':False,'weights_in_project':False,'paid_apis':False},indent=2))
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));w,h=180,320;board=Image.new('RGB',(6*w,6*(h+24)),'#173e39');d=ImageDraw.Draw(board)
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((w,h));xx=i%6*w;yy=i//6*(h+24);board.paste(im,(xx,yy));d.text((xx+5,yy+h+5),f'{i+.5:.1f}s',fill='#fff2cb')
board.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
print('REPORT',r['sha256'],summary)
