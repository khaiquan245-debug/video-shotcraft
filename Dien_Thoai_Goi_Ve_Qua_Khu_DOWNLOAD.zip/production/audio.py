from pathlib import Path
import json,wave,hashlib,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;S=json.loads((B/'manifests/story-times.json').read_text());vmeta=json.loads((B/'manifests/voice.json').read_text());D=S['end'];N=round(D*R);T=np.arange(N)/R;rng=np.random.default_rng(20261120)
with wave.open(str(B/'audio/narration-final.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768;assert w.getframerate()==R
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==vmeta['native_sha256']
V=np.zeros(N,np.float32);offset=round(vmeta['offset']*R);V[offset:offset+len(raw)]=raw
# Same voice; only the final warning is heard through an original telephone-style EQ treatment.
a=round(S['warning']*R);b=round((S['warning']+vmeta['sentence_spans'][-1]['end']-vmeta['sentence_spans'][-1]['start'])*R);b=min(b,N)
segment=V[a:b].copy();flt='highpass=f=260,lowpass=f=3500,equalizer=f=1500:t=q:w=1:g=2'
p=subprocess.run(['ffmpeg','-v','error','-f','f32le','-ar',str(R),'-ac','1','-i','pipe:0','-af',flt,'-f','f32le','pipe:1'],input=segment.astype('<f4').tobytes(),capture_output=True,check=True);filtered=np.frombuffer(p.stdout,dtype='<f4').copy()[:len(segment)];normal=max(.01,float(np.sqrt(np.mean(segment**2))))/max(.01,float(np.sqrt(np.mean(filtered**2))));filtered*=min(1.8,normal);fade=np.minimum(1,np.minimum(np.arange(len(filtered))/(R*.015),(len(filtered)-np.arange(len(filtered)))/(R*.015)));V[a:a+len(filtered)]=filtered*fade
F=np.zeros((N,2),np.float32);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;n=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='key':a=(np.sin(2*np.pi*697*t)+np.sin(2*np.pi*1209*t))*.5*env
 elif kind=='connect':a=np.sin(2*np.pi*440*t)*env
 elif kind=='coin':a=(np.sin(2*np.pi*1500*t)+.4*np.sin(2*np.pi*2300*t))*np.exp(-t/.025)
 elif kind=='wood':a=(np.sin(2*np.pi*270*t)+.3*n)*np.exp(-t/.032)
 elif kind=='cup':a=(np.sin(2*np.pi*830*t)+.3*np.sin(2*np.pi*1410*t))*np.exp(-t/.045)
 elif kind=='time':a=(np.sin(2*np.pi*(170*t+650*t*t))+.3*np.convolve(n,np.ones(15)/15,'same'))*env
 elif kind=='whoosh':a=np.convolve(n,np.ones(17)/17,'same')*env
 elif kind=='paper':a=(n-np.convolve(n,np.ones(25)/25,'same'))*.3*env
 elif kind=='step':a=(np.sin(2*np.pi*145*t)+.25*np.convolve(n,np.ones(12)/12,'same'))*np.exp(-t/.03)
 elif kind=='chime':a=(np.sin(2*np.pi*659.25*t)+.35*np.sin(2*np.pi*987.77*t))*np.exp(-t/.23)
 elif kind=='buzz':a=np.sin(2*np.pi*130*t)*(.5+.5*np.sin(2*np.pi*17*t))*env
 elif kind=='ring':
  notes=[659.25,523.25,783.99,523.25,659.25,523.25,783.99,523.25];idx=np.minimum(7,(t/d*8).astype(int));f=np.array(notes)[idx];phase=np.cumsum(2*np.pi*f/R);pulse=np.sin(np.pi*((t/d*8)%1))**2;a=(np.sin(phase)+.25*np.sin(phase*2))*pulse*env
 elif kind=='hiss':a=np.convolve(n,np.ones(9)/9,'same')*env
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 i=round(at*R);assert 0<=i<N
 sound=fx(kind,d)[:N-i]*gain;F[i:i+len(sound),0]+=sound*np.sqrt((1-pan)/2);F[i:i+len(sound),1]+=sound*np.sqrt((1+pan)/2);events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,5),'duration':d,'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'source':'Original locally synthesized oscillator/noise Foley in production/audio.py','rights':'Self-created, no third-party recording'})
for at in[.75,.87,.99]:add(at,'coin',.055,.14,-.18,'Coins drop from the buyers hand into market tray')
for at in[S['test']+.12,S['yesterday']+.22,S['shoes_call']+.06,S['lottery']+.05]:add(at,'key',.045,.075,0,'Finger touches the old phone call key while it is held in front')
for at in[S['test']+.7,S['yesterday']+.7,S['shoes_call']+.55,S['lottery']+.55]:add(at,'connect',.025,.17,0,'Past-self call connects after raising phone to ear')
add(S['coffee']+1.1,'cup',.055,.17,.25,'Past self returns cup upright and places it away from laptop')
add(S['healed']+.14,'time',.055,.35,.3,'Coffee damage and cracked laptop screen reverse at the same location')
add(S['healed']+.37,'chime',.025,.4,.3,'Restored laptop screen completes its visible change')
add(S['shoes_call']+1.2,'paper',.035,.3,.05,'Past self withdraws from buying expensive shoes')
add(S['box_gone']+.13,'whoosh',.08,.24,-.3,'Shoe box disappears from the present room')
add(S['lottery']+.75,'paper',.055,.6,.05,'Past self receives stack of lottery tickets')
add(S['villa']+.85,'connect',.025,.12,0,'Call ends; handset lowers before room transformation')
add(S['villa_change']+.02,'whoosh',.11,.45,0,'Room changes into a villa around the unchanged phone and character')
add(S['villa_change']+.25,'chime',.045,.7,.3,'Gold chandelier and villa interior finish appearing')
for at in np.arange(S['run']+.12,S['ring_hit']-.04,1/5.8):add(float(at),'step',.05,.11,.05,'Running shoes contact the villa marble floor')
add(S['ring_hit'],'ring',.10,.86,.05,'Old phone suddenly rings in the characters hand')
add(S['ring_hit'],'buzz',.025,.7,.05,'Phone hand vibrates with the incoming call')
add(S['future']+.05,'connect',.025,.12,0,'Future caller is identified; ringtone stops')
add(S['warning']-.065,'connect',.023,.07,0,'Short line click immediately before the future-self warning')
# Original evolving score: curious plucked notes, warm villa payoff, then restrained suspense.
M=np.zeros(N,np.float32);notes=[293.665,349.228,440,523.251,440,391.995,349.228,261.626]
for k,at in enumerate(np.arange(.04,S['ring_hit']-.1,.46)):
 i=round(at*R);d=min(.65,(N-i)/R);tt=np.arange(round(d*R))/R;f=notes[k%8];amp=.017 if at<S['villa_change']else .021;z=(np.sin(2*np.pi*f*tt)+.30*np.sin(2*np.pi*f*2*tt)+.10*np.sin(2*np.pi*f*3*tt))*np.exp(-tt/.17);M[i:i+len(z)]+=amp*z
 if k%4==0:M[i:i+len(z)]+=.008*np.sin(2*np.pi*f/2*tt)*np.exp(-tt/.28)
# Background drops at the incoming call; sparse low tone stays under the identification, then leaves the warning clear.
for at in[S['future'],S['lead_in']]:
 i=round(at*R);d=min(1.1,(N-i)/R);tt=np.arange(round(d*R))/R;M[i:i+len(tt)]+=.005*np.sin(2*np.pi*146.83*tt)*np.sin(np.pi*tt/d)**2
M*=np.where(T<S['warning']-.12,1,np.maximum(0,1-(T-(S['warning']-.12))/.1))
noise=rng.normal(0,1,N).astype(np.float32);A=.004*np.convolve(noise,np.ones(33)/33,'same');A*=np.where(T<S['test'],1.6,.6)
rms=np.sqrt(np.mean(V[:N//480*480].reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(17)/17,'same');M*=np.interp(np.arange(N),np.arange(len(gate))*480,1-.7*gate)
fade=np.minimum(1,np.minimum(T/.04,(D-T)/.23));M*=fade;A*=fade;F*=fade[:,None]
stereo=np.column_stack((V+M+A,V+M+A*.97))+F;pre=min(1.,.98/float(np.max(np.abs(stereo))));stereo*=pre

def save(name,a):
 with wave.open(str(B/'audio'/name),'wb')as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',A),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
caps=json.loads((B/'manifests/captions.json').read_text())
def ts(s):
 ms=round(s*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Dien_Thoai_Goi_Ve_Qua_Khu.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}'for i,q in enumerate(caps)),encoding='utf-8')
(B/'manifests/sound-events.json').write_text(json.dumps({'events':events,'music':'Original curious plucked composition,130BPM; warm villa payoff then sparse suspense','ringtone':'Original 8-note synthesized pattern, not a sampled commercial ringtone','voice_phone_filter':{'start':S['warning'],'end':b/R,'ffmpeg_filter':flt,'same_native_voice':True},'pre_master_gain':pre,'paid_apis':False},ensure_ascii=False,indent=2));print('AUDIO',D,'s',len(events),'events','warning_gap',S['warning']-vmeta['sentence_spans'][-2]['end'],'preGain',pre)
