from pathlib import Path
import json,csv,hashlib
from PIL import Image,ImageDraw,ImageFont
B=Path(__file__).resolve().parents[1];O=B/'output';S=json.loads((B/'manifests/story-times.json').read_text());r=json.loads((B/'qa/final.json').read_text());v=json.loads((B/'audio/narration-native.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());sound=json.loads((B/'manifests/sound-events.json').read_text())
plans=[('float','Ngôi lên khỏi sữa; thìa khổng lồ lao tới','Track-in theo nhân vật; thìa vào từ phải'),('hug','Ôm vòng ngũ cốc','Cận hơn vào hai tay và vòng ngũ cốc'),('scoop','Thìa hất nhân vật và ngũ cốc lên mép tô','Camera bám đường bay; rơi xuống bám thành'),('cat_arrives','Mèo nhảy lên bàn, nhân vật bám mép tô','Mở rộng để đọc được tỉ lệ mèo/tô/nhân vật'),('paw','Chân mèo thò vào tô','Cận chân mèo và hai bàn tay bám mép'),('escape','Nhảy sang miệng hộp đang mở','Track chéo lên theo quỹ đạo nhảy'),('slide','Trượt xuống đáy hộp ngũ cốc','Cutaway; camera đi xuống theo cơ thể'),('tip','Mèo húc hộp đổ','Xoay toàn hộp quanh cạnh đáy, giữ nhân vật bên trong'),('spill','Ngũ cốc tràn; nhân vật lăn về mép','Track ngang; cơ thể cuộn lăn, ngũ cốc chuyển động riêng'),('catch','Chộp lấy dây rèm','Cận cú chộp; chuyển tay từ tư thế lăn sang giữ dây'),('cereal_falls','Ngũ cốc rơi khỏi bàn và chạm sàn','Camera hạ theo dòng ngũ cốc; giữ dây và mép bàn làm mốc'),('cat_falls','Mèo nhảy xuống theo ngũ cốc','Góc rộng cho đường nhảy, bốn chân tiếp sàn'),('swing','Đu lên bệ cửa sổ','Camera theo cung đu; dây giữ chiều dài cố định'),('house','Thấy căn nhà nhỏ','Dây kéo rèm tách ra, lộ nhà; bước trên bệ cửa'),('door','Mở cửa nhà','Cận tay nắm; cửa xoay hé, ánh sáng ấm bên trong'),('room','Giường, ghế và bàn ăn','Cắt vào nội thất cùng bảng màu; nhân vật đi vào'),('mini_bowl','Thấy tô ngũ cốc trên bàn','Dolly vào tô; tô đặt trên mặt bàn'),('knock','Có người gõ dưới mặt sữa','Cutaway dưới sữa, tay gõ vào thành ở36.72/37.22/37.72s; giữ phản ứng đến40s')]
shots=[]
for key,action,camera in plans:
 ordered=sorted(S.values());a=S[key];end=min((z for z in ordered if z>a),default=40)
 shots.append({'id':key,'start':a,'end':end,'action':action,'camera':camera})
(B/'manifests/shot-manifest.json').write_text(json.dumps({'note':'18 timed story/action blocks; not a claim of18 measured hard cuts','ratio':'9:16','shots':shots},ensure_ascii=False,indent=2))
with (O/'Shot_Timeline.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','start','end','action','camera']);w.writeheader();w.writerows(shots)
# Board comes from the actual final encoded MP4, not source-only renders.
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));tw,th=180,320;board=Image.new('RGB',(8*tw,5*(th+24)),'#183e40');d=ImageDraw.Draw(board)
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((tw,th));x=i%8*tw;y=i//8*(th+24);board.paste(im,(x,y));d.text((x+5,y+th+5),f'{i+.5:.1f}s',fill='#fff6dc')
board.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
(O/'README.md').write_text('''# Bạn tỉnh dậy trong tô ngũ cốc

Bản phim 40 giây, 1080×1920, 30 fps, hoạt hình 2D có chuyển động nhân vật và đồ vật. Giữ nguyên toàn bộ lời kể tiếng Việt được gửi trong cuộc trò chuyện. Không thêm câu thoại, không dùng API trả phí.

Mở `Ban_Tinh_Day_Trong_To_Ngu_Coc_40s_1080x1920.mp4` hoặc `index.html`. Nếu trình duyệt chỉ phát mà không tải, dùng tùy chọn tải của trình phát hoặc giải nén gói ZIP rồi mở MP4 bằng VLC/QuickTime.

Giọng: VieNeu-TTS v3 Turbo, ONNX CPU offline, preset Hải Đăng; adapter hiện tại dùng Minh Quân làm alias. Giọng native dài37,6giây, không tăng/giảm tốc, đặt tại0,06giây trên timeline. Hơn2giây cuối dành cho tiếng gõ và cú hé lộ.

Trong gói có MP4, phụ đề SRT, lời kể, shot manifest, source renderer/audio, font/giấy phép, WAV native và kết quả kiểm tra. Trọng số model không được đóng gói hoặc đưa vào Git. Các dự án cũ được giữ nguyên.

`Production_Report.md` nêu các kiểm tra thật và giới hạn. Source trong `production/` sử dụng các công cụ đã cài của Cloud hiện tại. Các lệnh dựng lại trong môi trường đó:

```bash
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
```

Không chạy lại TTS vào đường dẫn WAV đã có. Adapter từ chối ghi đè; chọn tên mới nếu sau này đổi lời. Renderer dùng @napi-rs/canvas qua `/workspace/video-shotcraft/workbench/package.json`; model local và môi trường TTS nằm ngoài gói tải.
'''.replace('dài37,6giây','dài 37,6 giây').replace('tại0,06giây','tại 0,06 giây').replace('Hơn2giây','Hơn 2 giây'),encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn và quyền sử dụng

Kịch bản lời kể: người dùng cung cấp, giữ nguyên trong bản phim này. Nhân vật chính kế thừa bản FAST V2 của dự án; hình vẽ nhà bếp, tô sữa, thìa, mèo, hộp ngũ cốc, rèm và căn nhà nhỏ được vẽ mới bằng vector cho câu chuyện này. Không lấy khung hình hoặc soundtrack của video tham khảo để ghép vào phim.

Narration: VieNeu-TTS v3 Turbo, local ONNX CPU; model Apache-2.0 từ https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo . Preset Hải Đăng là giọng thực tế; Minh Quân là alias trong adapter hiện có. Metadata và SHA-256 của WAV ở `audio/narration-native.json`. Không dùng trả phí hoặc cloud inference.

Nhạc và SFX: tự tổng hợp local bằng oscillator/noise trong `production/audio.py`, không dùng bản thu bên thứ ba. Nhạc phiêu lưu chuyển sang hợp âm ấm ở căn nhà; nhạc tắt dần trước ba tiếng gõ cuối. Foley gồm nước/sữa, thìa kim loại, chân mèo, giấy hộp, ngũ cốc, dây, rèm và cửa.

Font Nunito: SIL Open Font License, giấy phép kèm `assets/OFL-Nunito.txt`. Trọng số model nằm ngoài Git và gói tải.
''',encoding='utf-8')
report=f'''# Kết quả sản xuất thực tế

**Bạn tỉnh dậy trong tô ngũ cốc — 40 giây, 9:16.** Toàn bộ 154đơn vị lời tách theo khoảng trắng của kịch bản được giữ đúng thứ tự trong nguồn TTS và chuỗi phụ đề. Tệp MP4 thật tồn tại, có hình và tiếng. Đây là hoạt hình vector2D với khớp nhân vật và vật thể chuyển động, không phải slideshow ảnh tĩnh.

## Hình và dựng

18khối hành động theo lời kể: ngoi lên → ôm ngũ cốc → thìa hất lên → mèo tới/thò chân → nhảy/trượt hộp → hộp đổ/ngũ cốc cuốn đi → chộp dây → ngũ cốc và mèo xuống sàn → đu lên cửa sổ → nhà nhỏ → mở cửa/nội thất → tô ngũ cốc → người dưới mặt sữa gõ. Đây là số khối kể, không phải đếm hard cut.

Nhân vật áo cam, tóc nâu đen, quần xanh và giày vàng được giữ từ FASTV2. Tay/chân dùng chuỗi hai xương có chiều dài cố định. Tô, thìa, mèo, hộp, rèm, nhà và căn phòng là hình vẽ mới; camera bám hành động, có các lớp nền/tiền cảnh riêng.

Đã sửa sau khi xem bản nháp: phụ đề quá dài được tách cụm nghĩa; tăng độ với tay hợp lý ở dây; hạ tư thế đi trong nhà để không duỗi chân quá tầm; sửa tô đặt đúng trên bàn; chỉnh tay gõ chạm thành; giữ ngũ cốc và mèo trên mặt sàn khi rơi xong; chỉnh hộp nằm xuống đúng mặt bàn và tư thế lăn không xuyên bàn; dời cú mèo nhảy lên bàn 1,3 giây để sát câu kể. Căn nhà được rèm che trước cảnh hé lộ.

## Giọng, phụ đề và âm thanh

Model thực tế: **{v['engine']}**, backend **{v['actual_backend']}**, CPU offline. Giọng thực tế **{v['canonical_voice']}**; tên Minh Quân trong adapter là alias của preset này. Native **{v['duration']:.2f}giây**, tốc độ giữ1,0×, không cắt hoặc kéo dài lời. Các WAV đã được duyệt ở dự án cũ không bị ghi đè.

{len(caps)}cụm phụ đề một dòng. Mốc câu được đo từ từng đoạn TTS; mốc cụm bên trong câu được ước lượng theo số tiếng, chưa forced-align từng từ. ASR local được chạy như chẩn đoán bổ sung; bản nhận dạng có nhiều sai khác chính tả, không dùng nó thay lời gốc hoặc phụ đề. Chưa xác nhận phát âm từng từ bằng tai người.

{len(sound['events'])}sự kiện Foley trong spotting list, gồm các va chạm nhỏ của từng viên ngũ cốc. Âm thanh tự tổng hợp, không lấy soundtrack của mẫu. Nhạc nguyên tác nhanh ở phần thoát hiểm, ấm tại căn nhà; chủ đích bỏ nhạc từ35,55 giây để ba tiếng gõ có không gian. Ba nhịp gõ hình/tiếng đặt tại36,72/37,22/37,72 giây.

## Kiểm tra tệp

- Thời lượng **{r['duration']:.3f}giây**; **{r['width']}×{r['height']}**, **{r['fps']}fps**, **{r['frames']} khung hình**.
- H.264 yuv420p và AAC stereo48kHz; giải mã toàn bộ thành công.
- Âm lượng **{r['lufs']}LUFS**, true peak **{r['true_peak_dbfs']}dBTP**.
- Khoảng yên dài nhất trên track giọng theo RMS<0,003: **{r['narration_max_quiet_seconds']:.2f}giây**, gồm đoạn kết chủ đích.
- Kiểm tra rig trong bản render: **{r['rig']['samples']}mẫu**, **{r['rig']['unreachable']}đích ngoài tầm**, sai số chiều dài xương tối đa **{r['rig']['maxBoneError']:.3g}**.
- Dung lượng **{r['bytes']}bytes**; SHA-256`{r['sha256']}`.

Ảnh kiểm tra được trích lại từ MP4 đã encode; log giải mã, loudness và phát trình duyệt được giữ trong QA. Phát trình duyệt 1× là kiểm tra kỹ thuật, tắt tiếng; không thay cho người xem duyệt cảm xúc/độ dễ nghe. Các phép đo khớp không bảo đảm mọi kiểu che khuất hay diễn xuất đều hoàn hảo. Mẫu mới chưa được người dùng duyệt.

Các nguồn và công cụ có sẵn đều chạy local: VieNeu-TTS/ONNX, Canvas, FFmpeg và ASR CPU. Không cần tải model mới, không phát sinh API trả phí. Trọng số model nằm ngoài Git. Thư mục dự án mới: `{B}`.
'''
# Improve technical prose spacing without modifying any narration.
for a,z in [('154đơn','154 đơn'),('vector2D','vector 2D'),('18khối','18 khối'),('FASTV2','FAST V2'),('giây**, tốc',' giây**, tốc'),('giữ1,0','giữ 1,0'),('cụm phụ đề',' cụm phụ đề'),('sự kiện Foley',' sự kiện Foley'),('từ35,55','từ 35,55'),('tại36,72','tại 36,72'),('giây**;',' giây**;'),('**30fps','**30 fps'),('AAC stereo48kHz','AAC stereo 48 kHz'),('LUFS**',' LUFS**'),('dBTP**',' dBTP**'),('giây**, gồm',' giây**, gồm'),('mẫu**,',' mẫu**,'),('đích ngoài',' đích ngoài'),('bytes**',' bytes**'),('SHA-256`','SHA-256 `'),('duyệt.\n','duyệt.\n'),('duyệt.','duyệt.'),('duyệt','duyệt')]:report=report.replace(a,z)
(O/'Production_Report.md').write_text(report,encoding='utf-8')
(B/'qa/asset-origin.json').write_text(json.dumps({'drawing_source':str(B/'production/film.mjs'),'sha256':hashlib.sha256((B/'production/film.mjs').read_bytes()).hexdigest(),'identity_reused_from':'tree-hollow-fast-v2-20261120; own project character','new_story_art':'Procedural authored vector kitchen, bowl, milk, spoon, original ginger cat, cereal carton, window/curtains, house, furnished room','external_reference_media_in_final':False,'model_weights_in_project':False,'paid_apis':False},ensure_ascii=False,indent=2))
print('REPORT',r['sha256'], 'shots',len(shots), 'caps',len(caps),'SFX',len(sound['events']))
