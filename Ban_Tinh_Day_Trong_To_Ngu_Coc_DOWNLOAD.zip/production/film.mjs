import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import{createRequire}from'node:module';import{spawn}from'node:child_process';import{once}from'node:events';
const require=createRequire('/workspace/video-shotcraft/workbench/package.json');const{createCanvas,GlobalFonts}=require('@napi-rs/canvas');
export const B=path.resolve(fileURLToPath(new URL('..',import.meta.url)));GlobalFonts.registerFromPath(B+'/assets/Nunito.ttf','Nunito');
export const W=720,H=1280,D=40;export const QA={samples:0,unreachable:0,maxBoneError:0};
const K='#40383a',C=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),E=x=>{x=C(x);return x*x*(3-2*x)},L=(a,b,u)=>a+(b-a)*u,U=(t,a,d)=>E((t-a)/d),mix=(a,b,u)=>a.map((v,i)=>L(v,b[i],u));
const stages=[0,4,7.6,10.2,14.2,18,23,26.4,30];
export function at(t){let n=0;while(n<7&&t>=stages[n+1])n++;return{n,t:t-stages[n],d:stages[n+1]-stages[n]}}
function stroke(c,col=K,w=4){c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.stroke()}
function line(c,pts,col=K,w=4){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));stroke(c,col,w)}
function poly(c,pts,col,edge=K,w=4){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.fillStyle=col;c.fill();if(edge)stroke(c,edge,w)}
function ellipse(c,x,y,rx,ry,col,edge=null,w=3){c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);if(col){c.fillStyle=col;c.fill()}if(edge)stroke(c,edge,w)}
function box(c,x,y,w,h,r,col,edge=null,lw=4){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=col;c.fill();if(edge)stroke(c,edge,lw)}
function grad(c,x,y,xx,yy,colors){let g=c.createLinearGradient(x,y,xx,yy);colors.forEach((s,i)=>g.addColorStop(i/(colors.length-1),s));return g}
function txt(c,s,x,y,size=44,col='#fff',align='center'){c.font=`900 ${size}px Nunito`;c.textAlign=align;c.textBaseline='middle';c.fillStyle=col;c.fillText(s,x,y)}
function shape(c,draw,col,edge=K,w=4){c.beginPath();draw(c);c.fillStyle=col;c.fill();if(edge)stroke(c,edge,w)}
function ik(a,b,l1,l2,sign){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>l1+l2+.01||d<Math.abs(l1-l2)-.01){QA.unreachable++;throw Error('IK '+JSON.stringify({a,b,d,l1,l2}))}let ang=Math.atan2(dy,dx)+sign*Math.acos(C((l1*l1+d*d-l2*l2)/(2*l1*Math.max(.001,d)),-1,1));let q=[a[0]+l1*Math.cos(ang),a[1]+l1*Math.sin(ang)];QA.samples++;QA.maxBoneError=Math.max(QA.maxBoneError,Math.abs(Math.hypot(q[0]-a[0],q[1]-a[1])-l1),Math.abs(Math.hypot(b[0]-q[0],b[1]-q[1])-l2));return q}
function hand(c,q,angle=0){c.save();c.translate(...q);c.rotate(angle);ellipse(c,0,0,7,8,'#f8bd83',K,2.5);ellipse(c,5,-3,3,4,'#ffd3a0',K,1.5);c.restore()}
function project(p,q){let r=p.lean||0,x=q[0],y=q[1]-125;return[p.x+x*Math.cos(r)-y*Math.sin(r),p.y+125+x*Math.sin(r)+y*Math.cos(r)]}
function gait(t,speed=100,cadence=2.6,ground=215){let period=2/cadence;return[0,1].map(i=>{let phase=(t/period+i*.5)%1;if(phase<.5)return[speed*period*(.25-phase),ground];let u=(phase-.5)*2;return[L(-speed*period*.25,speed*period*.25,E(u)),ground-25*Math.sin(Math.PI*u)]})}
function actor(c,p){let t=p.time||0,breath=Math.sin(t*2.7)*.7,p0={...p,y:p.y+breath},arms=p.hands||[project(p0,[-29,132]),project(p0,[29,132])],feet=p.feet||[[p.x-15,p.y+220],[p.x+18,p.y+220]],hips=[project(p0,[-11,123]),project(p0,[11,123])];
 for(let i=0;i<2;i++){let q=ik(hips[i],feet[i],50,52,i?-1:1);line(c,[hips[i],q,feet[i]],K,19);line(c,[hips[i],q,feet[i]],i?'#3d6479':'#325569',13);let f=feet[i];box(c,f[0]-10,f[1]-9,30,12,5,'#d9a747',K,3);line(c,[[f[0]-8,f[1]+3],[f[0]+19,f[1]+3]],'#f7d877',3)}
 const P=q=>project(p0,q);shape(c,ctx=>{ctx.moveTo(...P([-24,43]));ctx.quadraticCurveTo(...P([-35,55]),...P([-30,112]));ctx.quadraticCurveTo(...P([0,132]),...P([31,112]));ctx.lineTo(...P([31,56]));ctx.lineTo(...P([24,43]));ctx.closePath()},grad(c,p.x-35,p.y,p.x+40,p.y,['#ffcb63','#ed9c40','#da7e31']),K,4);
 line(c,[P([0,49]),P([0,119])],'#ba7439',2);line(c,[P([-17,90]),P([-10,102]),P([10,102]),P([17,90])],'#b37438',2);line(c,[P([-8,51]),P([-8,70])],'#fff0ba',2);line(c,[P([8,51]),P([8,70])],'#fff0ba',2);
 let elbows=[];for(let i=0;i<2;i++){let a=P([i?25:-25,55]),b=arms[i],q=ik(a,b,40,39,i?-1:1);elbows.push(q);line(c,[a,q,b],K,20);line(c,[a,q,b],i?'#eea241':'#ffc45b',14);let cuff=mix(q,b,.82);line(c,[cuff,b],'#f5c99b',13);hand(c,b)}
 let hd=P([0,0]);c.save();c.translate(...hd);c.rotate(p.head||0);ellipse(c,-33,4,8,10,'#f0b480',K,3);ellipse(c,33,4,8,10,'#f0b480',K,3);
 shape(c,ctx=>{ctx.moveTo(-33,-15);ctx.bezierCurveTo(-40,24,-18,42,2,39);ctx.bezierCurveTo(28,37,41,14,33,-17);ctx.bezierCurveTo(19,-40,-20,-40,-33,-15)},'#ffd3a1',K,4);
 shape(c,ctx=>{ctx.moveTo(-35,4);ctx.bezierCurveTo(-46,-22,-28,-43,-7,-40);ctx.lineTo(4,-51);ctx.lineTo(9,-38);ctx.bezierCurveTo(29,-38,44,-25,34,0);ctx.lineTo(24,-14);ctx.lineTo(16,-8);ctx.lineTo(7,-20);ctx.lineTo(-4,-11);ctx.lineTo(-11,-18);ctx.bezierCurveTo(-22,-6,-26,-6,-35,4)},'#413238',K,3);
 let blink=Math.exp(-(((t%3.7-3.25)/.055)**2)),smile=p.mood==='happy',worried=p.mood==='worried',sleep=p.mood==='sleep';
 for(let i=0;i<2;i++){let xx=i?14:-13;if(p.profile&&i===0)continue;let yy=4,rx=worried?6:5,ry=worried?8:6;if(blink>.75||sleep)line(c,[[xx-5,yy],[xx,yy+2],[xx+5,yy]],K,2.5);else{ellipse(c,xx,yy,rx,ry,'#fff8e7',K,2);ellipse(c,xx+(p.look||0)*2,yy,2.5,3.8,'#443339');ellipse(c,xx+1,yy-2,1,1,'#fff')}
  line(c,[[xx-6,-10+(worried?(i?-3:3):0)],[xx+5,-10+(worried?(i?3:-3):0)]],'#49363b',2.2)}
 ellipse(c,0,15,3,2,'#e7a677');ellipse(c,-23,18,7,3,'#eea58d');ellipse(c,23,18,7,3,'#eea58d');if(worried)ellipse(c,3,27,5,6,'#683b3b',K,1.7);else if(smile){shape(c,ctx=>{ctx.moveTo(-9,23);ctx.quadraticCurveTo(1,32,11,22);ctx.quadraticCurveTo(3,39,-9,23)},'#814b4e',K,1.5);line(c,[[-5,25],[7,25]],'#fff2d9',2)}else line(c,[[-6,26],[2,28],[8,25]],'#754d43',2.2);
 c.restore();for(let i of(p.frontHands||[])){line(c,[elbows[i],arms[i]],K,20);line(c,[elbows[i],arms[i]],'#f1aa48',14);hand(c,arms[i]);}return{wrists:arms,feet,head:hd,elbows};}
const S=JSON.parse(fs.readFileSync(B+'/manifests/story-times.json'));const caps=JSON.parse(fs.readFileSync(B+'/manifests/captions.json'));
const point=(a,b,u)=>[L(a[0],b[0],u),L(a[1],b[1],u)];
function hero(c,x,y,t,opt={}){c.save();c.translate(x,y);c.scale(opt.scale||1,opt.scale||1);if(opt.angle){c.translate(0,110);c.rotate(opt.angle);c.translate(0,-110)}let hands=opt.hands||[[-35,124],[35,124]],feet=opt.feet||[[-17,220],[22,220]];actor(c,{x:0,y:0,time:t,lean:opt.lean||0,mood:opt.mood||'worried',head:opt.head||0,look:opt.look||0,hands,feet});c.restore()}
function grain(c,x,y,r=42,a=0){c.save();c.translate(x,y);c.rotate(a);ellipse(c,0,3,r,r*.63,'#aa6837',K,3);ellipse(c,0,-3,r,r*.63,grad(c,0,-r,0,r,['#f6d58c','#e1a94f']),K,3);ellipse(c,0,-3,r*.40,r*.24,'#8b633c',K,2);ellipse(c,0,-6,r*.28,r*.13,'#c9a471');for(let i=0;i<9;i++){let q=i*2.399;ellipse(c,Math.cos(q)*r*.74,Math.sin(q)*r*.46-3,2.3,1.5,'#c08b46')}c.restore()}
function splash(c,x,y,t,amount=1){for(let i=0;i<9;i++){let u=C(t/(.45+i*.017)),a=-Math.PI+(i/8)*Math.PI,sp=120+i%3*50;ellipse(c,x+Math.cos(a)*sp*u,y+Math.sin(a)*sp*u+110*u*u,4*(1-u)+1,9*(1-u)+1,`rgba(255,252,231,${(1-u)*amount})`)}for(let i=0;i<2;i++)ellipse(c,x,y+8,35+t*150+i*15,7+t*22,null,`rgba(255,253,234,${C(1-t*1.5)})`,3)}
function window(c,t){box(c,2030,-620,1620,1270,32,'#bfa582',K,8);box(c,2070,-578,1540,1170,12,grad(c,0,-580,0,600,['#9fc9d5','#d6e9d8','#fcdfa9']),K,5);for(let i=0;i<6;i++){let x=2080+i*290;ellipse(c,x,330,220,200,'#b7cc99');ellipse(c,x+100,360,170,220,'#a6bd8e')}line(c,[[2850,-570],[2850,595]],'#e6d5ae',30);line(c,[[2075,-60],[3600,-60]],'#e6d5ae',28);box(c,1980,590,1740,55,15,'#e5c99c',K,6);line(c,[[2010,606],[3685,606]],'#fff0c6',6);
 // Curtain is a separate foreground/background layer, with a fixed cord anchor.
 for(let side of[2070,3550]){shape(c,q=>{q.moveTo(side-100,-700);q.lineTo(side+90,-700);q.bezierCurveTo(side+40,-330,side+75,130,side+120,490);q.lineTo(side-120,470);q.bezierCurveTo(side-90,150,side-110,-350,side-100,-700)},'#c5b5bc',K,4);for(let i=0;i<4;i++)line(c,[[side-70+i*45,-600],[side-35+i*34,430]],'#a997a9',4)}
}
function kitchen(c,t){c.fillStyle=grad(c,0,-1500,0,2600,['#e8e7cf','#f5e5bf','#cfaa83']);c.fillRect(-5000,-5000,12000,12000);
 // Broad original kitchen, not a cropped still: cabinetry, tile, plant and window parallax.
 for(let i=-4;i<6;i++){box(c,-1800+i*620,-1100,590,770,28,'#8faeac',K,6);box(c,-1768+i*620,-1068,526,704,20,'#a8c2b9','#72908c',4);line(c,[[-1540+i*620,-990],[-1540+i*620,-910]],'#e6d6a8',12)}
 c.fillStyle='#ebdfbc';c.fillRect(-5000,-240,7000,980);for(let y=-220;y<760;y+=170)for(let x=-2200;x<2000;x+=210){box(c,x,y,200,160,10,'#f0e6c8','#d9c9a8',3);if((x+y)%3===0)ellipse(c,x+100,y+70,18,21,'#d2d7b7')}
 box(c,-2300,730,4200,80,18,'#cfb28b',K,5);c.fillStyle='#91aaa2';c.fillRect(-2500,810,4400,1700);for(let x=-2300;x<1800;x+=530){box(c,x,850,490,900,20,'#a7bcb0','#627e79',5);line(c,[[x+150,900],[x+300,900]],'#e1d0a3',13)}
 // A kettle and plant establish full-size scale behind the tiny adventure.
 ellipse(c,-1300,680,240,28,'rgba(69,66,57,.14)');ellipse(c,-1300,450,190,240,'#b9c4bb',K,7);box(c,-1440,185,280,40,18,'#698d89',K,6);shape(c,q=>{q.moveTo(-1125,425);q.lineTo(-940,315);q.lineTo(-900,340);q.lineTo(-1100,540)},'#a6b9b3',K,6);c.beginPath();c.ellipse(-1510,430,80,180,0,-Math.PI*.6,Math.PI*.6);stroke(c,'#596d67',25);
 box(c,1640,600,230,170,25,'#dba284',K,5);for(let i=0;i<7;i++){let x=1755+Math.sin(i*2)*120;line(c,[[1755,610],[x,250+i*25]],'#7f9567',7);ellipse(c,x,265+i*25,65,28,i%2?'#95ad74':'#789c78',K,3)}window(c,t);
 // Table edge remains at world x2700 throughout the pursuit.
 c.fillStyle='#bd916c';c.fillRect(-5000,1000,7700,2000);for(let y=1060;y<3200;y+=150)line(c,[[-5000,y],[2700,y]],'#a47b5d',3);
 box(c,-5000,982,7700,80,14,grad(c,0,980,0,1060,['#d3aa7d','#b78d63']),K,7);line(c,[[-5000,991],[2690,991]],'#f0cfa0',5);
 // Beyond the edge the floor drops away; this is the cereal/cat fall destination.
 c.fillStyle='#d7b696';c.fillRect(2705,1750,5000,5000);for(let i=0;i<14;i++)line(c,[[2705+i*200,1750],[2205+i*400,3500]],'#bd9b7f',4);
 for(let i=0;i<90;i++){let x=-1500+(i*197)%4200,y=1080+(i*47)%500;if(x<2700)ellipse(c,x,y,2.5,1,'#a77a56')}
 let sun=c.createLinearGradient(500,-800,2700,1500);sun.addColorStop(0,'rgba(255,244,204,0)');sun.addColorStop(.6,'rgba(255,242,190,.10)');sun.addColorStop(1,'rgba(255,246,203,.02)');c.fillStyle=sun;c.fillRect(-3000,-2000,9000,6000);
}
function bowlBack(c,t){ellipse(c,0,1001,680,45,'rgba(70,57,54,.19)');shape(c,q=>{q.moveTo(-700,650);q.bezierCurveTo(-620,1040,600,1040,700,650);q.lineTo(-700,650)},grad(c,-600,700,650,950,['#b9d2bd','#82b5ac','#66999b']),K,7);ellipse(c,0,650,700,140,'#d7e8ce',K,6);ellipse(c,0,650,655,110,'#fcf3da','#a0b7a5',4);
 for(let i=0;i<13;i++){let x=-540+(i*173)%1040,y=585+(i*37)%100;grain(c,x+Math.sin(t*1.6+i)*9,y+Math.sin(t*2+i)*4,28+(i%3)*5,i*.3)}
}
function milkFront(c,t){shape(c,q=>{q.moveTo(-645,650);for(let x=-645;x<=650;x+=35)q.lineTo(x,650+Math.sin(x*.04+t*4)*3);q.quadraticCurveTo(0,790,-645,650)},'rgba(254,247,222,.68)',null);c.beginPath();c.moveTo(-700,650);c.quadraticCurveTo(0,915,700,650);stroke(c,'#455e5b',11);c.beginPath();c.moveTo(-699,646);c.quadraticCurveTo(0,908,699,646);stroke(c,'#cde0c5',7)}
function spoon(c,t){let x,y,a;if(t< S.scoop){x=L(850,-150,U(t,0,3.8));y=L(120,680,U(t,.1,3.7));a=L(-.25,-.04,U(t,2,3.5))}else{let u=U(t,S.scoop,1.1);x=L(-150,290,u);y=L(680,180,u);a=L(-.04,-.55,u)}c.save();c.translate(x,y);c.rotate(a);shape(c,q=>{q.moveTo(310,-40);q.lineTo(1700,-100);q.quadraticCurveTo(1840,-60,1700,10);q.lineTo(310,50)},grad(c,0,-80,0,80,['#eff0dc','#a6b4ac','#8b9a94']),K,7);ellipse(c,0,20,420,130,'#829991',K,7);ellipse(c,0,-5,425,122,grad(c,-240,-80,180,70,['#edf3e0','#bccdc3','#9eb7b0']),K,6);ellipse(c,-45,0,330,70,null,'#f1f4e4',7);c.restore()}
function cat(c,x,y,t,{paw=0,angle=0,run=0}={}){c.save();c.translate(x,y);c.rotate(angle);let wag=Math.sin(t*2.7)*35;
 c.beginPath();c.moveTo(-280,30);c.bezierCurveTo(-660,-90,-700,-390+wag,-500,-350+wag);stroke(c,K,75);stroke(c,'#c4814d',62);for(let j=0;j<3;j++){c.beginPath();c.moveTo(-525-j*19,-310+j*60);c.lineTo(-555-j*15,-295+j*61);stroke(c,'#9b5f40',18)}
 // Exactly four complete feline limbs. Paw reach is limited by actual two-bone lengths.
 for(let i=0;i<4;i++){let fore=i>1,a=[fore?230:-210,i%2?25:-15],b=[(fore?310:-240)+(i%2?45:-35),420-Math.max(0,Math.sin(t*8+i*Math.PI))*45*run];if(i===3)b=point(b,[680,80],paw);let knee=ik(a,b,230,245,i%2?-1:1);line(c,[a,knee,b],K,85);line(c,[a,knee,b],i%2?'#d8985d':'#b97d4f',72);ellipse(c,b[0]+17,b[1]-10,68,40,'#e2aa70',K,5);for(let j=0;j<3;j++)line(c,[[b[0]+j*22-8,b[1]+8],[b[0]+j*22-9,b[1]+22]],'#a36e4c',3)}
 ellipse(c,0,0,355,270,grad(c,-250,-170,300,230,['#e6b77c','#cf8b51','#b87547']),K,7);ellipse(c,190,100,100,165,'#eed2a0',null);for(let i=0;i<4;i++)shape(c,q=>{let x=-250+i*115;q.moveTo(x,-230);q.quadraticCurveTo(x+70,-250,x+80,-150);q.lineTo(x+55,-125);q.closePath()},'#a76a44',null);
 c.save();c.translate(330,-180);c.rotate(Math.sin(t*2)*.025);poly(c,[[-145,-70],[-162,-215],[-44,-120]],'#d69962',K,7);poly(c,[[63,-120],[173,-205],[159,-25]],'#d69962',K,7);poly(c,[[-130,-90],[-140,-177],[-73,-117]],'#d2a193',null);poly(c,[[92,-115],[151,-170],[140,-63]],'#d2a193',null);ellipse(c,0,0,175,145,'#e6ae71',K,7);
 for(let j=-1;j<=1;j++)poly(c,[[j*48-15,-136],[j*48+22,-130],[j*31+10,-70]],'#a76b45',null);
 for(let side of[-1,1]){let xx=side*67;ellipse(c,xx,-4,43,48,'#d5dfac',K,5);ellipse(c,xx+12,-4,8,35,'#394740');ellipse(c,xx+17,-17,5,9,'#fff2cf');line(c,[[xx-39,-55],[xx+32,-50]],'#7c583f',6)}
 ellipse(c,-42,75,58,40,'#f6dcb0');ellipse(c,47,75,58,40,'#f6dcb0');poly(c,[[-20,53],[24,53],[3,74]],'#be8076',K,3);line(c,[[3,73],[3,94],[-22,104]],K,3);line(c,[[3,94],[30,104]],K,3);for(let side of[-1,1])for(let j=0;j<3;j++)line(c,[[side*75,60+j*15],[side*(204+j*12),33+j*40]],'#655d4e',3);c.restore();c.restore()}
function carton(c,t){let tipped=U(t,S.tip+.18,1.13)*Math.PI/2;c.save();c.beginPath();c.rect(-5000,-5000,12000,6000);c.clip();c.translate(1500,1000);c.rotate(tipped);c.translate(-1500,-1000);let cut=t>=S.slide&&t<S.spill;poly(c,[[1000,70],[1500,70],[1500,1000],[1000,1000]],'#e8b876',K,7);poly(c,[[1500,70],[1590,10],[1590,945],[1500,1000]],'#bf875f',K,6);box(c,1030,100,440,860,10,cut?'#a97548':'#edc98f',K,4);if(!cut){box(c,1070,220,360,510,42,'#de8d61',K,5);ellipse(c,1245,450,143,130,'#f3dca5',K,5);grain(c,1245,450,92,-.1);line(c,[[1140,645],[1350,645]],'#f5db9e',15);line(c,[[1165,684],[1325,684]],'#f5db9e',9)}else{for(let i=0;i<13;i++)grain(c,1070+(i*97)%340,855+(i*23)%90,35,i*.8)}
 poly(c,[[1000,70],[960,-80],[1430,-90],[1500,70]],'#e2b77c',K,5);poly(c,[[1500,70],[1590,10],[1620,-110],[1515,-65]],'#d6a36c',K,4);line(c,[[1020,70],[1480,70]],'#604a3a',10);
 if(t>=S.slide&&t<S.spill){let u=U(t,S.slide,1.56),y=L(-125,748,u);c.save();c.beginPath();c.rect(1010,-250,480,1245);c.clip();hero(c,1250+175*U(t,S.tip+.2,.9),y,t,{angle:.1*Math.sin(t*9)*(1-U(t,S.tip,.5)),hands:[[-66,72],[66,72]],feet:[[-42,190],[46,185]]});c.restore();if(u>.88)for(let i=0;i<5;i++)ellipse(c,1180+i*35,965-(1-u)*200,8,5,'#e7c787')}
 c.restore();}
function crumbFlow(c,t){if(t<S.spill)return;for(let i=0;i<22;i++){let u=Math.max(0,t-S.spill-i*.045),speed=250+(i%5)*15,start=1530+(i%4)*55,x=start+speed*u,r=32+(i%3)*9,fallx=2700+r;let y=991-r-Math.abs(Math.sin(u*6+i))*20;
 if(x>fallx){let f=(x-fallx)/speed;x=fallx+speed*f*.68;y=991-r+420*f*f;let hit=Math.sqrt((1750-991)/420);if(f>hit)y=1750-r-Math.abs(Math.sin((f-hit)*7))*10*Math.exp(-(f-hit)*2)}if(y<2600)grain(c,x,y,r,u*4+i*.2)}}
function house(c,t){let left=2570,top=120,w=650;ellipse(c,2895,610,350,25,'rgba(74,61,50,.16)');box(c,left,180,w,420,14,grad(c,left,200,left+w,600,['#ead3a2','#cbb187']),K,6);for(let y=200;y<600;y+=65)line(c,[[left+8,y],[left+w-8,y]],'#b79b75',3);poly(c,[[2500,190],[2895,-90],[3290,190]],'#779a8b',K,8);poly(c,[[2545,190],[2895,-55],[3240,190]],'#92b09b',K,3);for(let k=0;k<5;k++)line(c,[[2655+k*49,90-k*35],[2895+k*49,-55+k*35]],'#709181',2);
 box(c,2970,320,160,170,20,'#d9dfbb',K,5);box(c,2986,337,128,136,10,'#a1c5c5',K,3);line(c,[[3050,340],[3050,468]],'#f2dbb0',9);line(c,[[2990,401],[3110,401]],'#f2dbb0',9);
 box(c,2625,325,170,275,22,'#665c48',K,6);let open=U(t,S.door+.08,.73),width=L(150,24,open);box(c,2635,337,width,261,10,'#bc8f60',K,4);box(c,2645,352,Math.max(4,width-22),220,8,'#cca577','#91714f',2);ellipse(c,2635+width*.78,475,8,8,'#eac97b',K,2);if(open>0){c.save();c.globalAlpha=open*.2;let g=c.createRadialGradient(2730,470,10,2730,470,360);g.addColorStop(0,'#ffdfa1');g.addColorStop(1,'rgba(255,223,161,0)');c.fillStyle=g;c.fillRect(2370,110,720,720);c.restore()}
 box(c,2940,-55,70,130,8,'#b58b68',K,5);for(let i=0;i<3;i++){let u=(t*.18+i*.3)%1;ellipse(c,2975+u*36,-90-u*150,18+u*24,13+u*17,`rgba(236,223,196,${.3*(1-u)})`)}
}
function drape(c,t){let open=U(t,S.house,.95);for(let side of[-1,1]){let left=side<0?2470-420*open:2895+420*open,right=left+425;shape(c,q=>{q.moveTo(left,-700);q.lineTo(right,-700);q.bezierCurveTo(right-10,-250,right+10,200,right,590);q.quadraticCurveTo((left+right)/2,616,left,590);q.bezierCurveTo(left+20,200,left-10,-250,left,-700)},grad(c,left,-300,right,500,['#c5b5bc','#ddcbd0','#a994ad']),K,4);for(let i=0;i<7;i++)line(c,[[left+35+i*56,-640],[left+43+i*54,587]],i%2?'#b49db7':'#e3d2d5',4)}}
function ropeEnd(t){let a=t<S.swing?-.25:L(-.25,-.837,U(t,S.swing,S.house-S.swing));return[3060+1000*Math.sin(a),-300+1000*Math.cos(a)]}
function rope(c,t){let q=ropeEnd(t);line(c,[[3060,-300],q],'#766c54',9);line(c,[[3060,-300],q],'#e0c99e',5);box(c,q[0]-7,q[1]-8,14,24,6,'#bfa579',K,2)}
function roomBack(c,t){c.fillStyle=grad(c,0,-1500,0,1500,['#e8d9ac','#f7e6b5','#cead84']);c.fillRect(-4000,-4000,10000,10000);for(let x=-1000;x<3000;x+=130)line(c,[[x,-500],[x,800]],'#dcc59a',2);c.fillStyle='#c7a27c';c.fillRect(-4000,800,10000,5000);for(let y=810;y<1900;y+=105)line(c,[[-4000,y],[6000,y]],'#ae8969',3);for(let i=-5;i<20;i++)line(c,[[i*230,800],[i*330-500,2000]],'#b78f6d',2);
 box(c,-180,250,280,550,20,'#8b7456',K,5);box(c,-150,280,220,500,12,'#d1ad7d',K,4);ellipse(c,20,535,9,9,'#ecd49c',K,2);box(c,170,620,430,140,20,'#a77e5b',K,5);box(c,155,610,460,60,20,'#9bbeb0',K,5);for(let x of[180,550])line(c,[[x,730],[x,800]],'#82634c',21);box(c,190,592,140,48,20,'#f0dfb3',K,3);shape(c,q=>{q.moveTo(340,620);q.lineTo(602,620);q.lineTo(602,745);q.bezierCurveTo(490,725,400,750,340,710)},'#9cb2bb',K,4);for(let x=370;x<600;x+=40)line(c,[[x,629],[x,724]],'#c2d1cb',4);
 box(c,500,100,300,310,22,'#baa47f',K,6);box(c,519,120,262,270,15,'#b8d4cf',K,3);line(c,[[649,125],[649,389]],'#f4dfb8',12);line(c,[[520,250],[780,250]],'#f4dfb8',12);ellipse(c,704,164,32,32,'#f3dba5');
 // Chair and table retain their positions across room, bowl and reveal shots.
 line(c,[[925,630],[925,800]],'#98734f',16);line(c,[[1050,630],[1050,800]],'#98734f',16);box(c,900,610,180,35,10,'#c19a6e',K,5);box(c,900,425,40,200,12,'#bb946a',K,4);line(c,[[920,450],[1035,450]],'#ac865c',15);line(c,[[1035,450],[1035,619]],'#ac865c',15);
 for(let x of[1090,1430])line(c,[[x,663],[x,800]],'#976f4e',23);box(c,1050,645,440,50,14,'#d2ac7e',K,6);line(c,[[1065,654],[1470,654]],'#efd5a3',4);ellipse(c,1260,632,140,17,'rgba(75,70,57,.18)');
 box(c,1390,390,85,40,10,'#cca06f',K,4);line(c,[[1430,410],[1430,640]],'#b38c60',8);ellipse(c,1430,435,110,52,'#f4d99d',K,4);let g=c.createRadialGradient(1380,530,10,1380,530,400);g.addColorStop(0,'rgba(255,229,162,.17)');g.addColorStop(1,'rgba(255,229,162,0)');c.fillStyle=g;c.fillRect(980,130,800,800);
}
function miniBowl(c,t){let k=0;for(let a of[36.72,37.22,37.72])k+=Math.exp(-(((t-a)/.065)**2));c.save();c.translate(k*1.5,-72.5);shape(c,q=>{q.moveTo(1100,590);q.bezierCurveTo(1110,760,1390,760,1400,590);q.lineTo(1100,590)},grad(c,1100,590,1400,745,['#bfd8c1','#87b8ae','#669a9c']),K,4);ellipse(c,1250,590,150,38,'#d4e6ce',K,4);ellipse(c,1250,590,138,31,'#fcf2d7','#a1bca9',2);for(let i=0;i<7;i++)grain(c,1135+i*35,586+Math.sin(i*2)*13,10+(i%2)*3,i);
 // A deliberate cutaway opens below the milk surface only on the final revelation.
 let reveal=U(t,S.knock+.75,.9);if(reveal>0){c.save();c.globalAlpha=reveal;shape(c,q=>{q.moveTo(1123,615);q.quadraticCurveTo(1250,655,1377,615);q.bezierCurveTo(1368,739,1134,739,1123,615)},'#a9c9c1','#7baba5',2);c.save();c.beginPath();c.rect(1120,620,260,113);c.clip();hero(c,1344.1,640,t,{scale:.25,angle:.6,mood:'worried',hands:[[-42,96],[L(60,85,C(k)),L(73,50,C(k))]],feet:[[-30,200],[34,199]]});c.fillStyle='rgba(160,205,203,.21)';c.fillRect(1120,620,260,113);c.restore();for(let i=0;i<4;i++){let u=(t*.9+i*.21)%1;ellipse(c,1280+i*13,706-u*85,2+u*2,3+u*2,null,'rgba(235,250,233,.9)',1)}if(k>.04){for(let i=0;i<3;i++)ellipse(c,1370+i*9,667,4+i*6,8+i*7,null,`rgba(255,241,178,${k*(1-i*.26)})`,2)}c.restore()}
 c.beginPath();c.moveTo(1100,590);c.quadraticCurveTo(1250,664,1400,590);stroke(c,'#45615b',5);c.beginPath();c.moveTo(1102,587);c.quadraticCurveTo(1250,655,1398,587);stroke(c,'#dbe7cd',3);c.restore()}
export function world(c,t){if(t>=S.room){roomBack(c,t);if(t<S.knock+.35){let u=C((t-S.room)/2.4),x=L(200,880,u),feet=t<S.room+2.4?gait(t-S.room,680/2.4,4.1,211):[[-17,211],[22,211]];hero(c,x,589,t,{mood:t<S.mini_bowl?'happy':'worried',head:t>S.mini_bowl?.08:0,hands:[[-35,124],[35,124]],feet:feet.map(q=>[q[0],q[1]])})}miniBowl(c,t);return}
 kitchen(c,t);house(c,t);drape(c,t);let catOn=t>=S.cat_arrives&&t<S.house;
 if(catOn){let u=U(t,S.cat_arrives+1.3,.72),x=L(-900,-80,u),y=L(1180,580,u)-Math.sin(u*Math.PI)*400;
 if(t>=S.tip){x=L(-80,510,U(t,S.tip-.2,.65));y=580}if(t>S.spill+.7){x=L(510,2120,U(t,S.spill+.7,S.cat_falls-S.spill-.7));y=580}
 let a=0;if(t>=S.cat_falls){let f=U(t,S.cat_falls,1.3);x=L(2120,3030,f);y=L(580,1330,f)-240*Math.sin(f*Math.PI);a=.25*Math.sin(f*Math.PI)}
 let paw=U(t,S.paw,.42)*(1-U(t,S.escape,.45));c.save();if(t<S.paw){c.beginPath();c.rect(-5000,-5000,12000,6000);c.clip()}cat(c,x,y,t,{paw,angle:a,run:t>S.spill&&t<S.cat_falls});c.restore();}
 bowlBack(c,t);if(t< S.cat_arrives+.1&&t>S.scoop+.85){}else if(t<S.scoop+1.1)spoon(c,t);
 if(t<S.hug){let u=U(t,0,.6),hx=-140+Math.sin(t*2.5)*15,hy=L(650,510,u)+Math.sin(t*3)*6;hero(c,hx,hy,t,{hands:[[-68,80+Math.sin(t*7)*13],[68,80-Math.sin(t*7)*13]],feet:[[-35,192],[40,190]],mood:'worried'});if(t<.7)splash(c,hx,650,t,.8)}
 if(t>=S.hug&&t<S.scoop){hero(c,-120,520,t,{hands:[[-46,103],[46,103]],feet:[[-35,192],[40,190]]});grain(c,-120,620,65,-.05+Math.sin(t*2)*.04);hand(c,[-166,623]);hand(c,[-74,623]);}
 if(t>=S.scoop&&t<S.cat_arrives){let u=U(t,S.scoop+.25,2.1),hx=L(-120,740,u),hy=L(520,660,u)-450*Math.sin(Math.PI*u);hero(c,hx,hy,t,{angle:(1-U(t,S.scoop+1.55,.45))*.22,hands:pointHands([[-46,103],[46,103]],[[-65,-5],[-30,10]],U(t,S.scoop+1.3,.7)),feet:[[-35,192],[40,190]]});let rel=U(t,S.scoop+1.5,.5);grain(c,L(hx,630,rel),L(hy+100,653,rel)-80*Math.sin(Math.PI*rel),65,t*.2);if(t<S.scoop+.9)splash(c,-100,650,t-S.scoop,.8)}
 milkFront(c,t);
 if(t>=S.paw&&t<S.escape+.45){let u=U(t,S.paw,.42)*(1-U(t,S.escape,.45)),x=-80,y=580,a=[x+230,y+25],b=point([x+355,y+420],[x+680,y+80],u),j=ik(a,b,230,245,-1);line(c,[a,j,b],K,85);line(c,[a,j,b],'#d8985d',72);ellipse(c,b[0]+17,b[1]-10,68,40,'#e2aa70',K,5);for(let k=0;k<3;k++)line(c,[[b[0]+k*22-8,b[1]+8],[b[0]+k*22-9,b[1]+22]],'#a36e4c',3)}
 if(t>=S.cat_arrives&&t<S.escape)hero(c,740,660,t,{hands:[[-65,-5],[-30,10]],feet:[[-30,198],[38,194]],head:-.08});
 carton(c,t);crumbFlow(c,t);
 if(t>=S.escape&&t<S.slide){let u=U(t,S.escape,S.slide-S.escape);hero(c,L(740,1250,u),L(660,-125,u)-190*Math.sin(u*Math.PI),t,{angle:.12,hands:[[-55,-2],[55,-2]],feet:[[-39,190],[44,186]]});}
 if(t>=S.spill&&t<S.catch){let u=U(t,S.spill,S.catch-S.spill);hero(c,L(1642,2690,u),rollY(Math.PI/2+Math.PI*3.5*u),t,{angle:Math.PI/2+Math.PI*3.5*u,hands:[[-48,105],[48,105]],feet:[[-40,188],[43,185]]});}
 if(t>=S.catch&&t<S.house){let end=ropeEnd(t),u=U(t,S.catch,.47),hx=L(2690,end[0]-10,u),hy=L(rollY(Math.PI*4),end[1]+10,u),bend=U(t,S.swing,S.house-S.swing);rope(c,t);hero(c,hx,hy,t,{hands:pointHands([[-48,105],[48,105]],[[10,-10],[15,-8]],u),feet:pointHands([[-40,188],[43,185]],[[-30-14*bend,198],[38+5*bend,194]],u),head:-.06,angle:0});}
 else if(t<S.catch&&t>S.spill-1)rope(c,t);
 // Cord pull parts the curtain at the landing, revealing the miniature house.
 if(t>=S.house&&t<S.room){let u=C((t-S.house-.25)/(S.door-S.house-.25)),x=L(2307,2690,u),walk=t>=S.house+.25&&t<S.door?gait(t-S.house-.25,383/(S.door-S.house-.25),3.8,218):[[-17,218],[22,218]],hands=[[-35,124],[35,124]];if(t>=S.door){let width=L(150,24,U(t,S.door+.08,.73));hands[1]=[2635+width*.78-x,93]}
 hero(c,x,382,t,{mood:'happy',feet:walk,hands,head:.03});}
}
function rollY(a){let bounds=[[-42,-48],[5,-51],[42,35],[-58,105],[58,105],[-50,190],[65,190]];return 990-Math.max(...bounds.map(q=>110+q[0]*Math.sin(a)+(q[1]-110)*Math.cos(a)))}
function pointHands(a,b,u){return a.map((q,i)=>point(q,b[i],u))}
export function camera(t){let cx=0,cy=600,width=1220;
 if(t<S.hug){cx=L(-120,-10,U(t,.1,3.5));cy=570;width=L(1320,1090,U(t,.2,3));}
 else if(t<S.scoop){cx=-100;cy=575;width=L(1050,870,U(t,S.hug,1.7))}
 else if(t<S.cat_arrives){let u=U(t,S.scoop+.2,2.2);cx=L(-100,700,u);cy=L(420,620,u)-130*Math.sin(u*Math.PI);width=L(1120,1250,u)}
 else if(t<S.paw){cx=L(560,700,U(t,S.cat_arrives,2.3));cy=590;width=L(1610,1410,U(t,S.cat_arrives,2.3))}
 else if(t<S.escape){cx=710;cy=570;width=L(1110,930,U(t,S.paw,1.2))}
 else if(t<S.slide){let u=U(t,S.escape,S.slide-S.escape);cx=L(740,1250,u);cy=L(530,100,u);width=1200}
 else if(t<S.tip){cx=1250;cy=L(100,710,U(t,S.slide,1.55));width=850}
 else if(t<S.spill){cx=L(1210,1690,U(t,S.tip,1.3));cy=650;width=1550}
 else if(t<S.catch){let u=U(t,S.spill,S.catch-S.spill);cx=L(1770,2670,u);cy=870;width=1350}
 else if(t<S.cereal_falls){cx=2790;cy=900;width=L(800,980,U(t,S.catch,1.3))}
 else if(t<S.cat_falls){cx=2830;cy=L(980,1250,U(t,S.cereal_falls,1.6));width=1460}
 else if(t<S.swing){cx=2900;cy=1100;width=1600}
 else if(t<S.house){let q=ropeEnd(t);cx=q[0]-50;cy=q[1]+100;width=1200}
 else if(t<S.door){cx=L(2620,2830,U(t,S.house,2.6));cy=430;width=L(1360,1160,U(t,S.house,2.6))}
 else if(t<S.room){cx=2680;cy=460;width=L(800,640,U(t,S.door,.8))}
 else if(t<S.mini_bowl){cx=L(740,900,U(t,S.room,2.5));cy=560;width=L(1530,1280,U(t,S.room,2.5))}
 else if(t<S.knock){cx=L(1150,1245,U(t,S.mini_bowl,1.6));cy=547.5;width=L(830,490,U(t,S.mini_bowl,1.6))}
 else{cx=L(1250,1280,U(t,S.knock,4.3));cy=577.5;width=L(450,355,U(t,S.knock,4.3))}
 return{cx,cy,width};}
const cv=createCanvas(1080,1920),ctx=cv.getContext('2d');
export function draw(t,{caption=true}={}){let c=ctx,cam=camera(t);c.resetTransform();c.clearRect(0,0,1080,1920);c.scale(1.5,1.5);c.save();let z=720/cam.width;c.translate(360,620);c.scale(z,z);c.translate(-cam.cx,-cam.cy);world(c,t);c.restore();
 // Gentle edge shade belongs to the composed shot; it never replaces animated artwork.
 let vign=c.createRadialGradient(360,560,200,360,600,950);vign.addColorStop(0,'rgba(48,37,34,0)');vign.addColorStop(1,'rgba(48,37,34,.13)');c.fillStyle=vign;c.fillRect(0,0,720,1280);
 if(caption){let q=caps.find(q=>t>=q.start&&t<q.end);if(q){let text=q.text.toLocaleUpperCase('vi-VN');c.font='900 44px Nunito';let m=c.measureText(text);if(m.width>650||m.actualBoundingBoxAscent>80)throw Error('Caption bounds '+text+' '+m.width);c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';c.strokeStyle='#343436';c.lineWidth=8;c.strokeText(text,360,975);c.fillStyle=q.emphasis?'#ffe48b':'#fff8e9';c.fillText(text,360,975)}}
 return cv;}
export async function render({draft=false,start=0,duration=40,out=null}={}){let ow=draft?540:1080,oh=draft?960:1920,dc=draft?createCanvas(ow,oh):cv,dctx=draft?dc.getContext('2d'):null;out=out||B+'/output/'+(draft?'draft-cereal.mp4':'Cereal_Wakeup_Picture.mp4');let total=Math.round(duration*30);let ff=spawn('ffmpeg',['-v','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',`${ow}x${oh}`,'-framerate','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf',draft?'22':'17','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',out+'.part.mp4'],{stdio:['pipe','inherit','inherit']}),done=once(ff,'close');for(let f=0;f<total;f++){let im;try{im=draw(start+f/30);if(draft){dctx.drawImage(im,0,0,ow,oh);im=dc}}catch(e){ff.kill();throw Error(`Frame${f} time${start+f/30} ${e.message}`)}if(!ff.stdin.write(im.data()))await once(ff.stdin,'drain');if(f%150===0)console.log('FRAME',f,total)}ff.stdin.end();let[code]=await done;if(code)throw Error('encode'+code);fs.renameSync(out+'.part.mp4',out);fs.writeFileSync(B+'/qa/'+(draft?'draft':'final')+'-rig.json',JSON.stringify(QA,null,2));console.log('RENDERED',out)}
if(process.argv.includes('--preflight')){let events=Object.entries(S).filter(q=>q[0]!=='end').sort((a,b)=>a[1]-b[1]);for(let i=0;i<events.length;i++){let[name,t]=events[i],next=events[i+1]?.[1]||40;for(let u of[.02,.2,.45,.7,.95]){let tt=t+(next-t)*u;try{let im=draw(tt);if(u===.45)fs.writeFileSync(B+`/qa/scene-${String(i).padStart(2,'0')}-${name}.jpg`,im.toBuffer('image/jpeg',{quality:90}))}catch(e){throw Error('Scene '+name+' at '+tt+' '+e.message)}}}fs.writeFileSync(B+'/qa/preflight.json',JSON.stringify(QA,null,2));console.log('PREFLIGHT',QA)}
if(process.argv.includes('--draft'))await render({draft:true});if(process.argv.includes('--full'))await render();
