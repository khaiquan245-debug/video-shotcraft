from pathlib import Path
import json, wave, hashlib
B=Path(__file__).resolve().parents[1]
m=json.loads((B/'audio/narration-native.json').read_text())
assert m['canonical_voice']=='Hải Đăng' and m['inference_offline']
phrases=[['Bạn vừa ngoi lên','khỏi mặt sữa','thì một cái thìa','to bằng chiếc xe buýt','lao tới.'],['Bạn ôm lấy','một viên ngũ cốc.'],['Cái thìa lướt qua,','hất cả bạn','lẫn viên ngũ cốc','lên mép tô.'],['Bạn vừa bám được','vào thành thì con mèo','nhảy lên bàn.'],['Nó thò chân vào.'],['Bạn nhảy sang','hộp ngũ cốc đang mở,','trượt một mạch','xuống đáy.'],['Con mèo','húc đổ cái hộp.'],['Ngũ cốc tràn ra bàn,','kéo bạn lăn thẳng','về phía mép.'],['Bạn chộp được','sợi dây rèm.'],['Cả đống ngũ cốc','rơi xuống sàn.'],['Con mèo nhảy theo.'],['Bạn đu lên','bệ cửa sổ.'],['Vừa đặt chân xuống,','bạn thấy một căn nhà','bé bằng bàn tay.'],['Bạn mở cửa.'],['Bên trong có','giường, ghế,','cả một cái bàn ăn.'],['Trên bàn là','một tô ngũ cốc.'],['Và dưới mặt sữa,','có ai đó','đang gõ vào thành tô.']]
caps=[]
for q,ps in zip(m['captions'],phrases):
 assert ' '.join(ps)==q['text']
 total=sum(len(p.split()) for p in ps); cursor=q['start']+.06
 for j,p in enumerate(ps):
  end=q['end']+.06 if j==len(ps)-1 else cursor+(q['end']-q['start'])*len(p.split())/total
  caps.append({'text':p,'start':cursor,'end':end,'emphasis':any(s in p for s in ['lao tới','húc đổ','dây rèm','gõ vào'])});cursor=end
assert ' '.join(q['text'] for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
# Shot changes and physical events are keyed to the actually generated sentence spans.
S={k:m['captions'][i]['start']+.06 for k,i in [('float',0),('hug',1),('scoop',2),('cat_arrives',3),('paw',4),('escape',5),('tip',6),('spill',7),('catch',8),('cereal_falls',9),('cat_falls',10),('swing',11),('house',12),('door',13),('room',14),('mini_bowl',15),('knock',16)]}
S.update(float=0,slide=S['escape']+1.25,end=40)
(B/'manifests/story-times.json').write_text(json.dumps(S,indent=2))
with wave.open(str(B/'audio/narration-native.wav')) as w:assert w.getnframes()/w.getframerate()==m['duration']
(B/'manifests/project.json').write_text(json.dumps({'title':'Bạn tỉnh dậy trong tô ngũ cốc','duration':40,'ratio':'9:16','resolution':[1080,1920],'fps':30,'style':'Original colorful2D cutaway physical-comedy cartoon, prior FAST V2 character continuity','script':'exact user narration; no additions','voice':{'engine':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'backend':m['actual_backend'],'native_duration':m['duration'],'tempo':1.0,'offset':.06},'models_outside_git':True,'paid_apis':False,'caption_alignment':'Measured sentence spans; within-sentence semantic phrase boundaries are estimated, not forced word alignment'},ensure_ascii=False,indent=2))
print('NATIVE VO',m['duration'],'CAPS',len(caps),'STORY',json.dumps(S))
