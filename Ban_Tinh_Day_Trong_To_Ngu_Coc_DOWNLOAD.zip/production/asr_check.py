import os
os.environ['HF_HUB_OFFLINE']='1'
from pathlib import Path
from faster_whisper import WhisperModel
import json,subprocess,numpy as np,difflib,re
B=Path(__file__).resolve().parents[1]
a=subprocess.check_output(['ffmpeg','-v','error','-i',str(B/'audio/narration-native.wav'),'-ar','16000','-ac','1','-f','f32le','-'])
x=np.frombuffer(a,dtype='<f4').copy()
model=WhisperModel('/workspace/local-models/whisper/models--Systran--faster-whisper-small/snapshots/536b0662742c02347bc0e980a01041f333bce120',device='cpu',compute_type='int8',cpu_threads=4)
segments,info=model.transcribe(x,language='vi',beam_size=5,word_timestamps=True,condition_on_previous_text=False)
segs=[s._asdict() for s in segments]
text=' '.join(s['text'].strip() for s in segs)
(B/'qa/narration-asr.json').write_text(json.dumps({'model':'faster-whisper-small local CPU, diagnostic ASR only','language':info.language,'segments':segs,'transcript':text,'note':'ASR is fallible, not forced alignment or human listening approval.'},ensure_ascii=False,indent=2,default=lambda v:v._asdict() if hasattr(v,'_asdict') else str(v)))
(B/'qa/narration-asr.txt').write_text(text,encoding='utf-8')
print(text)
