# B4 Bunker Character Pack

Sáu pose từ The Bunker Knocked Back. PNG RGBA, nền trong suốt.

- `poses/firefighter-knocking.png` — 230×466
- `poses/firefighter-reaching.png` — 315×447
- `poses/protagonist-falling.png` — 326×392
- `poses/protagonist-kneeling.png` — 320×312
- `poses/protagonist-relieved.png` — 155×459
- `poses/protagonist-wary.png` — 135×459

Đây là các pose PNG riêng để dựng từng cảnh.
