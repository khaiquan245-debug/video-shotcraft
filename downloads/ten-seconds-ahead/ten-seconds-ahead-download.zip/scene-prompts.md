# Director Mode A2B — production package

## Global continuity

30 seconds total; three connected ten-second scenes; native 9:16; 1080 by 1920 local output target at 24 FPS. One consistent minimalist 2D cartoon stickman protagonist with a round white face, solid black oval eyes, a small simple mouth, a fixed silhouette of short black spiky hair, a navy hoodie with two white drawstrings, slim black pants, and gray-white sneakers. Preserve the same face proportions, hair spikes, clothing details, limb proportions and outline weight throughout. No red beanie and no yellow shirt. Expressions and body language may change; identity and wardrobe may not.

Rich full-color illustrated city street at blue hour, rain-darkened stone, softly glowing amber cafe windows, cool teal street depth, drifting steam and elongated wet reflections. Keep the protagonist in clean expressive 2D vector animation, with painterly architectural depth, soft distant focus, warm edge lighting and restrained volumetric light. Violet reflected light marks a brief prediction; present time returns to teal and amber. Compose natively for portrait: faces in the upper-middle, physical hand contact in the central action area, layered foreground and background paths, and full necessary action visible.

One off-screen adult female narrator throughout. Natural General American accent, clear warm mid-range timbre, gentle forward resonance, no raspiness, restrained conversational inflection, a steady conversational pace, and close, dry studio recording. Keep the same voice identity, register, texture, accent and recording treatment throughout. Convey tension and relief through the images, editing, music and sound effects rather than changing narrator identity or adding character dialogue.

The approved treatment is implemented here with original local 2D drawing/animation and a local neural voice. These prompts are also retained as standalone scene specifications. No text-to-video API was invoked and no paid service was used.

## Scene 1 — 0–10 seconds

Output: approximately ten seconds, vertical 9:16, 1080 by 1920 target, 24 FPS, synchronized audio.

Rich full-color illustrated city street at blue hour, rain-darkened stone, softly glowing amber cafe windows, cool teal street depth, drifting steam and elongated wet reflections. Keep the protagonist in clean expressive 2D vector animation, with painterly architectural depth, soft distant focus, warm edge lighting and restrained volumetric light. Violet reflected light marks a brief prediction; present time returns to teal and amber. Compose natively for portrait: faces in the upper-middle, physical hand contact in the central action area, layered foreground and background paths, and full necessary action visible.

Character lock: One consistent minimalist 2D cartoon stickman protagonist with a round white face, solid black oval eyes, a small simple mouth, a fixed silhouette of short black spiky hair, a navy hoodie with two white drawstrings, slim black pants, and gray-white sneakers. Preserve the same face proportions, hair spikes, clothing details, limb proportions and outline weight throughout. No red beanie and no yellow shirt. Expressions and body language may change; identity and wardrobe may not.

[0–3s] Begin with a falling coffee cup seen extremely close against wet paving, the predicted spill approaching the ground. A brief violet reflection and a restrained light flash lead back to the actual untouched cup. Preserve cup design and spatial geometry through the match cut.
[3–7s] The protagonist catches the real falling cup with a visibly supporting palm, then steps back as a ridden bicycle passes through the lower foreground. Track the planted sneaker before rising to the face. The smile emerges only after the physical danger clears.
[7–10s] The smile fades. Transfer focus into the cafe glass, where the predicted image of a mustard-yellow-raincoat child and approaching headlights becomes visible. End with the protagonist looking toward that same curb. Use local acting, the falling prop, layered reflections, a foreground pass and motivated camera changes; no decorative morphs.

Exact audio-only English narration: “What if you could see ten seconds ahead? You’d catch the spill, dodge the accident, and think you’d finally beaten life.”

Audio voiceover only, strictly no speech bubbles, no dialogue boxes. Do not add, omit, repeat, reorder, paraphrase or visually transcribe the narration.

One off-screen adult female narrator throughout. Natural General American accent, clear warm mid-range timbre, gentle forward resonance, no raspiness, restrained conversational inflection, a steady conversational pace, and close, dry studio recording. Keep the same voice identity, register, texture, accent and recording treatment throughout. Convey tension and relief through the images, editing, music and sound effects rather than changing narrator identity or adding character dialogue.

Audio: quiet thoughtful piano and subtle soft ambient synth continue seamlessly with identical instrumentation through all scenes. Keep the voice clear above rain, cup contact, bicycle movement, footsteps and the passing bus. Duck the score during the warning and restore it gently after the rescue.

Negative constraints: no photorealistic human skin, no 3D humanoid CGI, no detailed pupils or irises, no changed hair or clothing, no extra limbs, no disconnected hands, no floating held props, no chaotic line glitches, no unrelated spectacle, no visible words, letters, numbers, captions, logos, interfaces, watermarks or dialogue balloons.

## Scene 2 — 10–20 seconds

Output: approximately ten seconds, vertical 9:16, 1080 by 1920 target, 24 FPS, synchronized audio.

Rich full-color illustrated city street at blue hour, rain-darkened stone, softly glowing amber cafe windows, cool teal street depth, drifting steam and elongated wet reflections. Keep the protagonist in clean expressive 2D vector animation, with painterly architectural depth, soft distant focus, warm edge lighting and restrained volumetric light. Violet reflected light marks a brief prediction; present time returns to teal and amber. Compose natively for portrait: faces in the upper-middle, physical hand contact in the central action area, layered foreground and background paths, and full necessary action visible.

Character lock: One consistent minimalist 2D cartoon stickman protagonist with a round white face, solid black oval eyes, a small simple mouth, a fixed silhouette of short black spiky hair, a navy hoodie with two white drawstrings, slim black pants, and gray-white sneakers. Preserve the same face proportions, hair spikes, clothing details, limb proportions and outline weight throughout. No red beanie and no yellow shirt. Expressions and body language may change; identity and wardrobe may not.

Supporting cast: the same small child in a mustard-yellow raincoat with a blue backpack; a single paper airplane motivates the curb action. Keep the child visually secondary to the protagonist.

[0–3s] In the same street geometry, show the predicted danger: the child in a mustard-yellow raincoat with a small blue backpack reaches toward a paper airplane beyond the curb; approaching headlights brighten through rain. Cut away before impact; no graphic injury.
[3–7s] Return to the present. The child is still beside the curb. Push slowly toward the protagonist's white face: alarm becomes understanding, then resolve. Keep the black spiky hair and navy hoodie unchanged. The cup remains physically in the supporting hand until it is set down.
[7–10s] Place the cup securely on the stone cafe ledge, release it visibly, pivot on a planted sneaker, and accelerate toward the child. Lower the camera into a moving follow shot. Keep the cup on that ledge after departure and maintain left-to-right travel into the next scene. Use practical light, real prop ownership, a reaction close-up and a running camera move.

Exact audio-only English narration: “But then you see someone else get hurt. Suddenly, knowing the future doesn’t make you powerful. It makes you responsible.”

Audio voiceover only, strictly no speech bubbles, no dialogue boxes. Do not add, omit, repeat, reorder, paraphrase or visually transcribe the narration.

One off-screen adult female narrator throughout. Natural General American accent, clear warm mid-range timbre, gentle forward resonance, no raspiness, restrained conversational inflection, a steady conversational pace, and close, dry studio recording. Keep the same voice identity, register, texture, accent and recording treatment throughout. Convey tension and relief through the images, editing, music and sound effects rather than changing narrator identity or adding character dialogue.

Audio: quiet thoughtful piano and subtle soft ambient synth continue seamlessly with identical instrumentation through all scenes. Keep the voice clear above rain, cup contact, bicycle movement, footsteps and the passing bus. Duck the score during the warning and restore it gently after the rescue.

Negative constraints: no photorealistic human skin, no 3D humanoid CGI, no detailed pupils or irises, no changed hair or clothing, no extra limbs, no disconnected hands, no floating held props, no chaotic line glitches, no unrelated spectacle, no visible words, letters, numbers, captions, logos, interfaces, watermarks or dialogue balloons.

## Scene 3 — 20–30 seconds

Output: approximately ten seconds, vertical 9:16, 1080 by 1920 target, 24 FPS, synchronized audio.

Rich full-color illustrated city street at blue hour, rain-darkened stone, softly glowing amber cafe windows, cool teal street depth, drifting steam and elongated wet reflections. Keep the protagonist in clean expressive 2D vector animation, with painterly architectural depth, soft distant focus, warm edge lighting and restrained volumetric light. Violet reflected light marks a brief prediction; present time returns to teal and amber. Compose natively for portrait: faces in the upper-middle, physical hand contact in the central action area, layered foreground and background paths, and full necessary action visible.

Character lock: One consistent minimalist 2D cartoon stickman protagonist with a round white face, solid black oval eyes, a small simple mouth, a fixed silhouette of short black spiky hair, a navy hoodie with two white drawstrings, slim black pants, and gray-white sneakers. Preserve the same face proportions, hair spikes, clothing details, limb proportions and outline weight throughout. No red beanie and no yellow shirt. Expressions and body language may change; identity and wardrobe may not.

Supporting cast: the same small child in a mustard-yellow raincoat with a blue backpack; a single paper airplane motivates the curb action. Keep the child visually secondary to the protagonist.

[0–3s] Continue the existing run in the same direction. The protagonist reaches the child at the curb and visibly establishes a safe hand-to-forearm contact before guiding the child away from the roadway. Show approach, contact, weight transfer and the safe result; no unexplained teleport or pull by the neck.
[3–7s] A bus passes across the foreground only after the rescue is readable, forming a motivated wipe. Reveal both characters safe beside the cafe. The original cup stays on the stone ledge; the paper airplane remains where it fell rather than flying into a hand without a pickup action.
[7–10s] The protagonist lowers toward the child's eye level, shoulders relaxing. Hold a small reassuring expression and grounded contact while the camera gently retreats into the warm light and cool city depth. Keep meaningful movement and the existing clothing/face lock. No on-screen question card; the final question is spoken only.

Exact audio-only English narration: “You move before anyone understands why. One small choice changes everything. If you saw what came next, would you save yourself—or someone else?”

Audio voiceover only, strictly no speech bubbles, no dialogue boxes. Do not add, omit, repeat, reorder, paraphrase or visually transcribe the narration.

One off-screen adult female narrator throughout. Natural General American accent, clear warm mid-range timbre, gentle forward resonance, no raspiness, restrained conversational inflection, a steady conversational pace, and close, dry studio recording. Keep the same voice identity, register, texture, accent and recording treatment throughout. Convey tension and relief through the images, editing, music and sound effects rather than changing narrator identity or adding character dialogue.

Audio: quiet thoughtful piano and subtle soft ambient synth continue seamlessly with identical instrumentation through all scenes. Keep the voice clear above rain, cup contact, bicycle movement, footsteps and the passing bus. Duck the score during the warning and restore it gently after the rescue.

Negative constraints: no photorealistic human skin, no 3D humanoid CGI, no detailed pupils or irises, no changed hair or clothing, no extra limbs, no disconnected hands, no floating held props, no chaotic line glitches, no unrelated spectacle, no visible words, letters, numbers, captions, logos, interfaces, watermarks or dialogue balloons.

## Stitching guide

Scene 1 ends on the warning in the cafe reflection; Scene 2 begins within the predicted curb geometry. Scene 2 ends in the protagonist’s run; Scene 3 continues the same direction and momentum. The bus supplies a physical foreground wipe after visible hand contact. Keep one narrator and continuous piano/ambient mix; inspect actual encoded joins rather than treating prompt wording as a quality pass.

## Voice and music continuity

The local film uses Kokoro af_heart en-us at its native default rate for all three narration blocks; no speaker substitution or tempo stretch. The soundtrack uses a licensed piano recording and an original soft synthesized pad; required attribution and actual modifications are in output/CREDITS.md.
