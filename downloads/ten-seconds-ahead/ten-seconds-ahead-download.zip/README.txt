TEN SECONDS AHEAD — CINEMATIC STORY

Finished 30-second encoded sample: ten-seconds-ahead-cinematic.mp4
1080x1920, 9:16 vertical, 24fps, H.264/AAC stereo.
Original locally drawn 2D animation: rain, layered city/cafe, moving cameras, fixed spiky-haired navy-hoodie character, coffee catch, bicycle dodge, child rescue, foreground bus wipe and ending reaction.
Natural American English local neural narration. No paid APIs.

Open the MP4 in the Codex file viewer or download it into a video player. preview.html supplies a portable player. Managed Chromium may block file:// URLs; a local HTTP preview is provided on port 8766 while the process runs.

Include the attribution in CREDITS.md in the video description if publishing. No upload/publication was performed.

Original drawing/animation source, narration clips, sound plan, shot ledger and three standalone scene prompts remain in the parent project folder. Existing Video Shotcraft files and installed skill files are unchanged.

Technical decode and sampled-frame checks passed; full continuous audiovisual and real-device review remain unperformed. See QA.json for exact scope.
