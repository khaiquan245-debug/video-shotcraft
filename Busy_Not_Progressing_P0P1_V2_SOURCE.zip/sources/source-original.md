# CODEX ALL-IN-ONE — NGƯỜI BẬN RỘN NHƯNG KHÔNG TIẾN BỘ

> **ĐÂY LÀ FILE DUY NHẤT ĐỂ ĐƯA VÀO CODEX.** Nội dung đã gộp đầy đủ: master prompt, 24 phân đoạn lời kể, storyboard 120 shot, bảng timing 120 shot dạng JSON và CSV, nguồn nghiên cứu, 2 ảnh tham chiếu phong cách **nhúng trực tiếp vào cuối file dưới dạng base64 JPEG**. Không cần upload các file rời.
>
> **BẮT ĐẦU NGAY:** Đọc phần 'LỆNH KHỞI ĐỘNG' dưới đây, tự trích xuất tài nguyên nhúng theo hướng dẫn. Không cần hỏi lại người dùng. Đầu ra phải là video đã render hoặc báo cáo trung thực điểm chưa thực hiện được.

## LỆNH KHỞI ĐỘNG DÀNH CHO CODEX

Bạn là đạo diễn hình ảnh, animator 2D/2.5D, technical artist, và kỹ sư render. Hãy **THỰC THI** dự án ngay từ file Markdown này, không chỉ tạo kế hoạch.

1. Đọc các phần theo thứ tự: **PROMPT SẢN XUẤT**, **KỊCH BẢN LỜI KỂ**, **STORYBOARD**, **SHOTLIST JSON**, **NGUỒN**, **ẢNH THAM CHIẾU NHÚNG**. Tất cả ở chính file này; mọi chỗ trong bản prompt gốc ghi 'đọc file 01/02/03/04' đều được hiểu là 'đọc các phần tương ứng trong file này'.
2. Trích xuất **2 ảnh phong cách nhúng** ở cuối file, lưu vào `references/`, trước khi tạo nhân vật, màu sắc, bối cảnh. Không cần làm mới ảnh. Ảnh được nén JPEG từ chính ảnh tham chiếu gốc, chỉ dùng hướng dẫn phong cách, không copy-paste làm cả video.
3. Lấy JSON trong phần **SHOTLIST JSON** làm dữ liệu điều hành chính (24 scene, 120 shot). Phần storyboard hỗ trợ hướng máy quay, SFX và chuyển cảnh. CSV chỉ để đối chiếu.
4. Kể chuyện hoàn toàn bằng **một voice-over tiếng Việt**, không đối thoại giữa nhân vật. Bắt buộc giữ Minh nhất quán, tốc độ nhân vật nhanh hơn bản cũ với các mốc động tác ở master prompt; không tạo slideshow ảnh tĩnh.
5. Chỉ dùng pipeline local miễn phí, phù hợp PC i5-6500, GTX 1060 3GB, RAM 16GB, Windows. Nếu không có narration phù hợp, render bản hình + SFX, ghi rõ còn thiếu voice, đừng mạo nhận là bản đầy đủ.
6. Xuất `output/demo_12s.mp4`, `output/Busy_Not_Progressing_1080p.mp4` (nếu đủ dữ liệu), và `output/QA_report.md`. Kiểm tra file thật bằng ffprobe trước khi báo thành công.

### Trích xuất 2 ảnh đã nhúng (chạy bằng Python, chỉ dùng thư viện chuẩn)

Trong workspace, đổi tên hoặc giữ nguyên file .md này. Lưu đoạn script dưới tên `extract_refs.py` và chạy `python extract_refs.py <tên-file-md>`; hoặc Codex tự thực thi logic tương đương. Đừng đưa chuỗi base64 vào prompt đầu vào model; đọc xử lý bằng code.

```python
import base64, pathlib, re, sys
source = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
pattern = r"<!-- BEGIN_EMBEDDED_ASSET: ([A-Za-z0-9_.-]+); encoding=base64; mime=image/jpeg\n([A-Za-z0-9+/=\n]+)\nEND_EMBEDDED_ASSET -->"
found = re.findall(pattern, source)
assert len(found) == 2, f"Cần 2 ảnh, thấy {len(found)}"
dest = pathlib.Path("references")
dest.mkdir(exist_ok=True)
for name, data in found:
    content = base64.b64decode(''.join(data.split()))
    (dest / name).write_bytes(content)
    print('Extracted:', dest / name, len(content), 'bytes')
```

**Quan trọng:** Trên Windows: `python extract_refs.py CODEX_TAT_CA_TRONG_1_FILE_BAN_RON_KHONG_TIEN_BO.md`. Nếu file có tên khác, thay đối số tương ứng.

---

## PHẦN A. PROMPT SẢN XUẤT CHI TIẾT

# MASTER PROMPT CHO CODEX — DỰNG VIDEO 8 PHÚT, NHỊP NHANH HƠN, NHÂN VẬT CỬ ĐỘNG RÕ

Bạn là đạo diễn hình ảnh, đạo diễn hoạt hình, technical artist và kỹ sư render video. Hãy làm một VIDEO HOÀN CHỈNH, không chỉ lên kế hoạch, với bộ tài liệu trong thư mục hiện tại:

- `01_KICH_BAN_LOI_KE.md`: Kịch bản 24 đoạn S01–S24, một giọng người kể.
- `02_KICH_BAN_HINH_ANH_GOC_MAY.md`: Storyboard 120 shot, camera, chuyển cảnh, âm thanh.
- `03_DANH_SACH_120_SHOTS.json`: Shotlist có start/end và hành động cụ thể.
- `references/thumbnail_style_mac_ket.jpg`, `references/thumbnail_style_tinh_di.jpg`: HAI ẢNH THAM CHIẾU CỦA NGƯỜI DÙNG. Quan sát kỹ phong cách; giữ nhân vật và gam màu tối giản, không chuyển sang anime/hình người thật/3D chân thực.

## A. Mục tiêu & giới hạn

1. Video dài khoảng **8 phút**, 16:9, 1920×1080, 30 fps, MP4 H.264 + AAC, tiếng Việt. Đầu ra cuối: `output/Busy_Not_Progressing_1080p.mp4`. Đồng thời xuất `output/demo_12s.mp4` và `output/QA_report.md`.
2. Đây là video **KỂ CHUYỆN 100% VOICE-OVER**, không có một cuộc đối thoại nào giữa các nhân vật. Không dựng miệng nhân vật nói/đồng bộ lip-sync nếu không có lý do. Minh 27 tuổi, nhân vật chính xuyên suốt.
3. Bám đúng mạch truyện và 24 cảnh S01–S24, đặc biệt các cao trào S14–S18 và sự thay đổi S19–S24.
4. Sử dụng **100% công cụ miễn phí chạy local**, KHÔNG gọi API trả phí, KHÔNG yêu cầu credit, token của dịch vụ bên thứ ba, KHÔNG dùng model sinh video nặng. Bạn có thể dùng Godot Engine (MIT), Python/Pillow/SVG, FFmpeg (theo giấy phép của chúng), các thư viện và tài nguyên miễn phí hợp lệ.
5. Cấu hình mục tiêu: Windows, Core i5-6500, GTX 1060 3GB, RAM 16GB. Ưu tiên 2D/2.5D sprite vector có rig khớp và background phân lớp. Không dùng render 3D nặng, particles quá mức, video diffusion.
6. Nếu có phần mềm/skill dựng video phù hợp đã cài sẵn, hãy phát hiện và tận dụng; nếu không, dùng **Godot 4 (2D) + FFmpeg** làm stack mặc định. Cấu trúc dự án sao cho có thể chạy lại bằng một script PowerShell.

## B. Thiết kế hình ảnh BẮT BUỘC

- Chất liệu hình như 2 thumbnail tham chiếu: tối giản, cinematic, xanh navy/xanh xám đậm, viền mềm, đầu TRÒN ĐEN, đôi mắt TRẮNG, áo sơ mi trắng có điểm nhấn xám, quần tối màu; ánh sáng vàng ấm ở cảnh giấc mơ/thành công.
- Nhân vật chính nhất quán về tỷ lệ: kích thước đầu so với thân, màu mắt, áo, quần. Không tự động đổi màu tóc/quần áo hay hình dạng đầu giữa cảnh.
- Bối cảnh chính lặp lại: căn phòng ban đêm (bàn, laptop, cốc, đèn, cửa sổ, kệ sách) và văn phòng. Lưu file character master/rig/background để tái sử dụng.
- Không biến reference thumbnail thành ảnh nền tĩnh phóng to 8 phút. Không dựng một loạt slide tĩnh. Vẽ tách nhân vật/bàn/đèn/laptop/cửa sổ thành các lớp có thể animate. Hai ảnh là style guide.
- Chỉ dùng rất ít chữ trên hình: 'HỒ SƠ NĂNG LỰC', '45 PHÚT', '0%', 'MỤC TIÊU', '1 KẾT QUẢ HÔM NAY', các câu nhỏ có trong shotlist. Chữ là tiếng Việt đúng dấu, không in prompt/ký hiệu sản xuất, không tiếng Anh thừa.

## C. SỬA LỖI QUAN TRỌNG NHẤT: NHÂN VẬT QUÁ CHẬM

Tôi đã chê phiên bản trước vì nhân vật động tác quá chậm. Bản mới phải có NHỊP HÀNH ĐỘNG THẬT, không giải quyết bằng zoom camera.

- Tốc độ cử động ở các cảnh công việc từ S01–S16: **nhanh hơn phiên bản chậm khoảng 1.35–1.6 lần**, nhưng vẫn tự nhiên. Không cho tất cả animation chạy cùng một tốc độ máy móc.
- Phản ứng mắt/đầu khi có thông báo: bắt đầu trong 0.12–0.25s. Quay đầu dứt khoát trong khoảng 0.25–0.45s, với 0.1s follow-through.
- Bấm chuột / chạm điện thoại / lật trang: động tác chính 0.2–0.5s; dừng ở đỉnh động tác 0.06–0.15s rồi trở về. Phải có nhịp ra/về rõ.
- Đi bộ nhanh: nhịp khoảng 1.8–2.2 bước mỗi giây khi gấp. Thân có bob nhẹ, đối xứng tay/chân luân phiên, chân chống không trượt trên mặt đất.
- Ngồi xuống/đứng dậy: diễn trọn động tác trong 0.6–1.1s, chân/tay tương tác ghế và bàn. Chuyển tư thế kiểu người thật giản lược, không teleport.
- Gõ phím: hai cẳng tay, bàn tay và cổ vai cùng có chuyển động; các nhịp gõ 3–5 nhịp/giây theo cụm, kèm micro-pauses.
- Ngạc nhiên, thất vọng, bối rối: biểu hiện qua đôi mắt, góc đầu, vai và nhịp thở; tránh nhân vật cứ cúi đầu đứng yên 15 giây.
- Phải tạo rig 2D với các pivot: neck, shoulders L/R, elbows L/R, wrists L/R, hip, knees L/R, feet. Tách đốt tay/chân nếu phù hợp. Mỗi chuyển động có pose start/anticipation/action/recovery và easing tinh tế.
- Mỗi shot trong JSON phải có hành động diễn ra **trên thân nhân vật hoặc vật thể thật**, camera di chuyển chỉ là phụ. Ít nhất **70% shot** có chuyển động chủ thể, không chỉ pan/zoom/scale.
- GIỮ CHẬM CÓ CHỦ ĐÍCH ở S17–S18 (sốc mất cơ hội) và hai câu kết S24. Đoạn này không slow-motion cả cảnh; cho cử động hít thở, buông tay, hướng nhìn để duy trì sức sống.

## D. Tốc độ cắt dựng và góc máy

- Thực hiện đủ 24 scene và **120 shot** theo `03_DANH_SACH_120_SHOTS.json`. Mốc cut tham chiếu 3–5 giây/shot (tốc độ trung bình ~4 giây/shot), có microcut 0.7–1.2 giây bên trong montage.
- 0–10 giây đầu: cảnh phải có ngay đồng hồ 23:48, ngón tay gõ máy, checkbox hiện, đôi mắt mệt, và đối lập folder còn 0%. Không intro logo, không mở đầu dài dòng.
- Dùng góc máy OTS, ECU, CU, MS, WS, POV, top-down, 3/4, tracking profile. Xen kẽ khoảng cách máy để có năng lượng hình ảnh.
- Ưu tiên hard cut, match cut, whip-pan ngắn, L-cut/J-cut âm thanh, montage dạng action-to-action. Hạn chế dissolve/blur dài và chuyển cảnh màu mè.
- Parallax 2.5D phải xuất phát từ các lớp đồ vật/nhân vật khác nhau; không giả 2.5D bằng cách scale cùng một hình.
- Với các shot trong storyboard, triển khai hành động vật lý theo mô tả; nếu cảnh không thể có đầy đủ vector chi tiết, thay bằng động tác chủ thể tương đương, không được thay bằng ảnh tĩnh.
- Thời lượng mỗi scene có thể lệch ±3 giây để ăn khớp voice-over; tổng thể mục tiêu 07:45–08:30. Tuyệt đối không cắt lời kể ngang câu hoặc tăng tốc voice bất tự nhiên.

## E. Âm thanh & giọng kể

- Duy nhất một giọng dẫn chuyện tiếng Việt, tự nhiên, trầm vừa phải, nhấn hook và cao trào, không có lời thoại giữa nhân vật.
- Ưu tiên nạp `assets/narration.wav`, `assets/narration.mp3` hoặc `assets/narration.m4a` nếu người dùng đã có bản thu. Căn S01–S24 theo đoạn lời kể thực tế bằng timing hoặc marker.
- Nếu CHƯA có file giọng đọc, hãy kiểm tra có hệ TTS tiếng Việt miễn phí chạy local hợp lệ hay không; chỉ dùng khi thực sự hỗ trợ tiếng Việt dễ nghe. Không được ngầm gọi dịch vụ online hay API trả phí, không tạo giọng đọc tiếng khác giả làm tiếng Việt. Nếu không thể có narration hợp lệ, vẫn render demo và bản hình + nhạc/hiệu ứng, xuất `output/NEED_VOICEOVER.txt` ghi chính xác file cần người dùng bổ sung. Không tuyên bố bản cuối đã có voice nếu không có.
- Tạo SFX local bằng oscillator/noise/one-shot tự sinh hoặc dùng thư viện local có giấy phép rõ: click chuột, bàn phím, thông báo, lật sách, kéo ghế, đồng hồ, cửa mở, bước chân, quạt máy.
- Nhạc nền instrumental nhẹ, hạn chế nhạc lớn. SFX đúng lúc tiếp xúc đồ vật. Voice luôn rõ ràng, không bị nhạc che. Dùng ducking: nhạc giảm khoảng 12–18dB khi voice hoạt động, tùy kiểm tra tai nghe.
- S17–S18: nhạc giảm gần như im lặng, 1–2 tiếng piano thưa. Kết thúc S24 fade âm 2 giây.
- Nếu render phụ đề, dùng tiếng Việt chuẩn, chia từng câu ngắn; đặt vùng an toàn phía dưới, không che tay, đồ vật và cảm xúc nhân vật.

## F. Quy trình phải THỰC THI, không hỏi lại

1. Đọc tất cả file kịch bản và hai ảnh reference. Tạo thư mục project `busy_not_progressing/` và lưu `assets/`, `characters/`, `backgrounds/`, `scenes/`, `audio/`, `output/` rõ ràng.
2. Kiểm tra hệ điều hành, Godot/Node/Python/FFmpeg hiện có. Chọn stack không tốn phí và ghi lại quyết định kỹ thuật.
3. Dựng **character master** có rig khớp, các action reusable: `idle`, `fast_walk`, `sit`, `stand`, `type`, `mouse`, `phone_reach`, `page_flip`, `head_turn`, `hand_to_forehead`, `reaction_surprise`, `reaction_regret`, `open_door`.
4. Dựng background master cho bedroom/desk, office, street, abstract achievement bubble, café-project graphic, door. Dùng palette nhất quán.
5. Dựng thử **12 giây đầu** (không chỉ ảnh demo), xuất `output/demo_12s.mp4`. Xem/kiểm tra chuyển động (tốc độ tay/đầu, đủ hành động, không giật/chuyển frame lỗi), sau đó TỰ SỬA các vấn đề phát hiện.
6. Thực hiện toàn bộ 24 scene/120 shot từ JSON theo thứ tự. Tạo transitions có chủ đích và âm thanh đồng bộ, không để shot bị lặp lại quá lâu.
7. Có narration thì đồng bộ theo voice; không có thì làm bản video hình + nhạc/SFX và ghi thiếu giọng rõ ràng. Không cắt bớt một nửa câu chuyện để giả có video 8 phút.
8. Render thử 30 giây bất kỳ gồm cảnh tương tác tay/chân và cảnh căng thẳng; kiểm tra không có bàn tay xuyên vật thể, đầu bị giật, foot sliding, layer lỗi.
9. Render toàn bộ bằng cấu hình phù hợp 3GB VRAM (render 1080p, concurrency thấp, ưu tiên reuse vector/sprites), xuất MP4 H.264 yuv420p, AAC, 30fps. Nếu cần render sequence theo scene rồi nối bằng FFmpeg để tránh RAM tăng.
10. Chạy `ffprobe` kiểm tra duration, fps, kích thước video, stream audio. Tự kiểm tra thumbnail frame tại 00:05, 01:35, 03:30, 05:30, 06:30 và 07:50 để phát hiện cảnh quá tĩnh, text sai hoặc biến dạng.
11. Ghi `output/QA_report.md`: đã xuất đủ 24 scene chưa, tổng shot thực tế, 5 khung kiểm tra, độ dài, fps, âm thanh và lỗi chưa xử lý. Cho đường dẫn cuối cùng **ngay sau khi render thành công**. Không báo thành công khi file chưa tồn tại.

## G. Tiêu chí nghiệm thu

- [ ] Không đối thoại; một voice-over xuyên suốt (nếu có file voice hoặc TTS local hợp lệ).
- [ ] Nhân vật Minh đúng template xanh đen tối giản, không biến đổi hình dáng giữa cảnh.
- [ ] Tốc độ hành động tay/chân/đầu nhanh, dứt khoát, có phản ứng trong 0.12–0.45s nơi phù hợp.
- [ ] Ít nhất 70% shot có motion chủ thể; tổng 120 shot không phải slideshow.
- [ ] 0–10 giây đầu có hook mạnh, ít nhất 3 thay đổi góc/quy mô cảnh.
- [ ] S17–S18 chậm lại để tạo nỗi đau, S19–S22 nhịp tăng trở lại, S24 kết lắng.
- [ ] Không lỗi chữ tiếng Việt/khớp tay/chân/biến hình; SFX khớp hành động; voice rõ.
- [ ] Có file MP4 thật, chất lượng 1080p/30fps, dài khoảng 8 phút hoặc báo đúng trạng thái chưa hoàn thành.

**BẮT ĐẦU THỰC HIỆN NGAY. Không dừng ở kế hoạch hoặc chỉ tạo khung hình tĩnh. Không yêu cầu người dùng mua dịch vụ. Không đợi xác nhận sau demo; tự chuyển sang dựng bản đầy đủ.**


---

## PHẦN B. KỊCH BẢN LỜI KỂ (ĐẦY ĐỦ)

# KỊCH BẢN LỜI KỂ — BẬN RỘN NHƯNG KHÔNG TIẾN BỘ

- Video: 16:9, 1920×1080, 30 fps, khoảng 8 phút.
- Hình thức: 100% voice-over, **KHÔNG có hội thoại giữa nhân vật**, không nhân vật nào nói với nhau.
- Nhân vật: Minh, 27 tuổi, nhân viên văn phòng, muốn làm thiết kế tự do.
- Nhịp lời dẫn: tự nhiên, có nhấn và khoảng ngắt ở 05:20–05:50, không đọc như một danh sách mẹo.
- Các mốc là chỉ dẫn dựng, cần căn lại theo độ dài bản thu thực tế; không tua giọng quá nhanh để khớp mốc.

## S01 — 00:00–00:20 | HOOK: Mười bốn tiếng

Hôm nay, Minh đã làm việc gần mười bốn tiếng. Điện thoại vẫn sáng. Hộp thư vẫn đầy. Danh sách công việc gần như đã được gạch hết. Nhưng có một điều Minh chưa dám nhìn thẳng: sáu tháng qua, cuộc sống mà cậu muốn xây dựng vẫn chưa tiến thêm được bao nhiêu. Một ngày rất bận. Một tương lai đứng yên.

## S02 — 00:20–00:40 | Đồng hồ lúc nửa đêm

Mười một giờ bốn mươi tám phút đêm. Minh ngồi trước laptop, tay vẫn di chuyển trên bàn phím. Một cốc cà phê nguội ngắt. Cổ vai căng cứng. Cậu kiểm tra hết cửa sổ này đến cửa sổ khác, rồi thở phào vì hôm nay không bỏ sót việc gì. Cảm giác ấy giống như chiến thắng. Chỉ tiếc, nó biến mất ngay khi màn hình tắt.

## S03 — 00:40–01:00 | Sáng hôm sau

Sáu giờ ba mươi, chuông báo thức vang lên. Minh bật dậy, xem lịch, kiểm tra tin nhắn rồi vội vã ra khỏi nhà. Trên đường đi làm, cậu vẫn nghe một bài học mới về cách phát triển bản thân. Minh tin rằng chỉ cần chăm hơn một chút nữa, mọi thứ sẽ khác. Và đó cũng là điều cậu đã tự nhủ suốt nhiều tháng.

## S04 — 01:00–01:20 | Lịch kín mít

Ở văn phòng, Minh xử lý báo cáo, sửa bảng số liệu, trả lời email, tham gia họp rồi tiếp tục xử lý những việc phát sinh. Cứ hoàn thành một việc, một việc khác lại xuất hiện. Minh không hề giả vờ bận. Công việc của cậu thực sự nhiều. Nhưng giữa nhịp quay ấy, có một câu hỏi chưa từng xuất hiện trong lịch: hôm nay mình đã đi gần hơn mục tiêu nào?

## S05 — 01:20–01:40 | Giấc mơ thầm kín

Minh không muốn làm công việc hiện tại mãi mãi. Cậu từng ước có thể sống bằng nghề thiết kế tự do, được chọn dự án mình thích và có thời gian chủ động hơn. Trong máy tính đã có sẵn một thư mục tên là Hồ sơ năng lực. Minh dự định sẽ điền đầy nó bằng những sản phẩm tốt nhất. Chỉ cần chuẩn bị thêm một thời gian nữa thôi.

## S06 — 01:40–02:00 | Học mãi không xong

Buổi tối, Minh mở khóa học thiết kế. Nhưng chỉ ít phút sau, cậu tìm thấy một hướng dẫn khác được giới thiệu là tốt hơn. Rồi thêm một video, một bộ tài liệu, một danh sách công cụ nên thử. Từ một bài học, màn hình mở ra mười hai tab. Minh lưu tất cả để xem sau. Và tự thấy mình đang đầu tư nghiêm túc cho tương lai.

## S07 — 02:00–02:20 | Chuẩn bị thay cho bắt đầu

Cuối tuần, Minh dành cả buổi sắp xếp tài liệu. Đổi tên từng thư mục. Chọn màu cho bảng kế hoạch. Vẽ một lộ trình rất đẹp. Những ô nhỏ lần lượt được đánh dấu hoàn thành. Nhưng khi mở phần mềm thiết kế để bắt tay vào sản phẩm đầu tiên, cậu lại đứng hình. Minh chưa biết nên chọn ý tưởng nào. Thế là cậu quay về nghiên cứu tiếp.

## S08 — 02:20–02:40 | Cảm giác hoàn thành

Đó là cái bẫy khó nhận ra nhất. Những việc nhỏ thường cho Minh một cảm giác tiến bộ rất nhanh. Xóa email: xong. Dọn bàn: xong. Viết kế hoạch: xong. Còn làm ra một thiết kế thực sự? Có thể mất hàng giờ và vẫn chưa đẹp. Thế nên Minh cứ chọn những việc dễ có dấu tích, để tránh đối diện một bản nháp chưa hoàn hảo.

## S09 — 02:40–03:00 | Việc quan trọng bị đẩy đi

Mỗi ngày, Minh đều tự hứa sẽ dành một giờ cho hồ sơ năng lực. Nhưng rồi điện thoại báo có việc gấp. Đồng nghiệp cần hỗ trợ. Một biểu mẫu phải cập nhật. Đến lúc mọi thứ tạm yên, cậu đã không còn sức. Một giờ quan trọng ấy được chuyển sang ngày mai. Và ngày mai lại có những thứ khẩn cấp mới chờ sẵn.

## S10 — 03:00–03:20 | Bận vì khẩn cấp

Nghiên cứu về hiệu ứng khẩn cấp cho thấy con người đôi khi chọn việc có hạn chót sát hơn, dù phần thưởng của nó ít giá trị hơn. Với Minh, điều đó xuất hiện dưới một hình thức rất bình thường: phản ứng ngay với mọi yêu cầu mới, rồi để việc dài hạn nằm yên. Không phải mọi việc gấp đều vô nghĩa. Nhưng điều quan trọng nhất không phải lúc nào cũng biết gửi thông báo.

## S11 — 03:20–03:40 | Đầu óc bị chia nhỏ

Ngay cả khi Minh ngồi xuống thiết kế, cậu cũng liên tục bị kéo đi. Vừa đặt được vài hình khối, điện thoại sáng lên. Trả lời xong, cậu kiểm tra email. Quay lại màn hình, Minh mất một lúc để nhớ mình đang làm dở điều gì. Nhà nghiên cứu Sophie Leroy gọi phần chú ý còn mắc lại ở việc trước là sự tồn dư chú ý. Đổi việc không phải lúc nào cũng miễn phí.

## S12 — 03:40–04:00 | Sáu tháng trôi qua

Ngày nối ngày. Những ô lịch bị xé đi. Các dự án ở công ty đến rồi kết thúc. Minh vẫn dậy sớm, vẫn về muộn, vẫn ghi thêm ý tưởng vào điện thoại. Có hôm cậu tự hào vì mình chẳng có phút nào rảnh. Nhưng tháng thứ nhất trôi qua. Rồi tháng thứ ba. Và đến tháng thứ sáu, thư mục hồ sơ năng lực vẫn gần như trống rỗng.

## S13 — 04:00–04:20 | Cuốn sổ cũ

Một tối, trong lúc dọn bàn, Minh tìm thấy cuốn sổ ghi mục tiêu đầu năm. Ở trang đầu tiên có một dòng được gạch chân: hoàn thành năm thiết kế và tìm khách hàng đầu tiên. Bên dưới là những việc nhỏ đã được đánh dấu kín trang. Minh lật tiếp. Lật thêm. Rồi dừng lại. Mục tiêu lớn nhất vẫn nằm đó, không có một ngày hoàn thành.

## S14 — 04:20–04:40 | Một cơ hội đến

Đúng lúc ấy, một người quen đang mở quán cà phê cần bộ hình ảnh quảng bá. Một dự án nhỏ, nhưng rất hợp với điều Minh muốn theo đuổi. Cậu lập tức nghĩ ra ý tưởng về màu sắc, phông chữ, cách bố trí hình ảnh. Lần đầu sau nhiều tháng, giấc mơ có vẻ đã ở đủ gần để chạm tay vào. Chỉ cần gửi vài sản phẩm từng làm.

## S15 — 04:40–05:00 | Thư mục trống

Minh mở máy tính, tìm đến thư mục hồ sơ năng lực và nhấp đúp. Bên trong có hàng chục ảnh tham khảo, vài file chưa đặt tên và một bản phác thảo dang dở. Không có bộ sản phẩm nào hoàn chỉnh. Cậu mở lại các folder cũ, hy vọng mình đã bỏ quên thứ gì đó. Nhưng màn hình chỉ trả về những tài liệu đã lưu, không phải thứ cậu tự tạo ra.

## S16 — 05:00–05:20 | Cơ hội đi qua

Minh quyết định sẽ làm gấp một bộ mẫu để gửi. Nhưng cả buổi tối trôi qua trong việc chọn bố cục, chỉnh màu rồi xóa đi làm lại. Hôm sau, người quen đã tìm được một nhà thiết kế khác. Minh không trách ai. Cậu hiểu cơ hội ấy không đợi mình được. Và điều khiến cậu hụt hẫng nhất không phải vì mất một việc nhỏ, mà vì mình đã có quá nhiều thời gian trước đó.

## S17 — 05:20–05:40 | Cao trào: Tất cả những ngày đã qua

Minh ngồi yên nhìn màn hình. Sáu tháng. Bao nhiêu tối thức khuya. Bao nhiêu lần nói rằng mình đang cố gắng. Cậu không hoàn toàn đứng yên; cậu đã học được nhiều điều. Nhưng tất cả hiểu biết ấy vẫn nằm rải rác trong các tab, ghi chú và kế hoạch. Minh đã dùng sự bận rộn để tự trấn an, thay vì nhìn vào điều mình thật sự tạo ra.

## S18 — 05:40–06:00 | Nhận ra điều khó chịu

Lần đầu tiên, Minh hiểu rằng cậu không chỉ thiếu thời gian. Cậu đang tránh một nỗi sợ khác: nỗi sợ làm ra thứ chưa đủ tốt. Lên kế hoạch cho một tương lai rực rỡ rất dễ chịu. Bắt đầu bằng một sản phẩm vụng về thì không. Và chính khoảng cách ấy đã nuốt mất nhiều tháng của cậu. Điều đau nhất không phải thất bại. Là chưa từng cho mình cơ hội thử thật sự.

## S19 — 06:00–06:20 | Một quy tắc khác đi

Sáng hôm sau, Minh không quyết định thay đổi toàn bộ cuộc đời. Cậu cũng không đặt ra ba mươi thói quen mới. Minh chỉ viết một câu lên tờ giấy nhỏ: hôm nay phải có một kết quả nhìn thấy được. Không phải số giờ ngồi trước máy. Không phải số video đã xem. Một sản phẩm có thể mở lên, chỉ ra chỗ tốt, chỗ dở, rồi sửa tiếp.

## S20 — 06:20–06:40 | Bốn mươi lăm phút thật

Tối đó, Minh đặt đồng hồ bốn mươi lăm phút. Cậu tắt thông báo, mở phần mềm và bắt đầu ngay bằng một bố cục đơn giản. Có lúc bí ý tưởng. Có lúc muốn tìm thêm hướng dẫn. Nhưng lần này, Minh không bỏ chạy sang việc khác. Cậu chỉnh từng khoảng cách, chọn ảnh, thử phông chữ, rồi xuất bản đầu tiên. Nó chưa đẹp. Nhưng cuối cùng, nó tồn tại.

## S21 — 06:40–07:00 | Sửa thay vì mơ

Những ngày sau không phải lúc nào cũng thuận lợi. Có hôm Minh tăng ca đến tối. Có hôm mệt đến mức chỉ sửa được vài chi tiết. Nhưng khi không thể làm nhiều, cậu vẫn biết mình đang sửa phần nào. Cậu gửi sản phẩm cho vài người xem, nhận góp ý và sửa lại. Sự tiến bộ không còn là một cảm giác mơ hồ. Nó có phiên bản cũ, phiên bản mới và những lỗi cụ thể được khắc phục.

## S22 — 07:00–07:20 | Bốn tuần sau

Một tháng trôi qua. Minh chưa trở thành nhà thiết kế tự do. Tài khoản ngân hàng cũng chưa thay đổi đáng kể. Nhưng trong thư mục hồ sơ năng lực đã có ba sản phẩm hoàn chỉnh. Cậu vẫn đi làm mỗi ngày, vẫn có trách nhiệm phải lo. Chỉ khác là khi mở máy tính vào buổi tối, cậu không còn phải tưởng tượng mình có thể làm gì. Cậu có thể nhìn thấy điều mình đã làm.

## S23 — 07:20–07:40 | Sự thật cần công bằng

Không phải người bận rộn nào cũng đang đi sai đường. Có người phải dành phần lớn thời gian để kiếm sống, chăm sóc gia đình hoặc vượt qua những giai đoạn quá sức. Nghỉ ngơi không phải lười biếng. Và không thể đo giá trị của một con người chỉ bằng năng suất. Nhưng nếu bạn vẫn còn một khoảng nhỏ có thể tự lựa chọn, hãy tự hỏi: mình đang làm điều quan trọng, hay chỉ đang làm điều dễ gạch đi?

## S24 — 07:40–08:00 | Kết: Cánh cửa

Chúng ta có thể đi rất nhanh trên một chiếc máy chạy bộ, mồ hôi ướt áo, chân không ngừng chuyển động. Nhưng khi bước xuống, vị trí vẫn như cũ. Bận rộn cũng có thể như vậy. Đôi khi, điều thay đổi cuộc đời không phải thêm một giờ làm việc. Mà là dừng lại, xác định đúng cánh cửa, rồi đặt tay lên nắm cửa ấy. Và thật sự mở nó ra.

---

## Chỉ đạo đọc
- Một giọng kể duy nhất; không lời thoại trực tiếp của bất cứ nhân vật nào.
- 00:00–00:20: rõ, gọn, nhấn “một tương lai đứng yên”.
- 01:40–03:40: hơi nhanh và dồn dập, không lướt qua từ khóa chính.
- 04:20–05:20: nhịp căng, khoảng nghỉ ngắn ở mỗi bước vỡ mộng.
- 05:20–06:00: đọc thấp giọng, có khoảng lặng sau câu “Sáu tháng.”
- 06:00–07:20: dần sáng hơn, không lên gân như diễn thuyết.
- 07:40–08:00: chậm lại có chủ đích, 1–2 giây im lặng cuối phim.

## Ghi chú nguồn cho hai ý nghiên cứu
- *Mere urgency effect*: Zhu, Yang & Hsee (2018), *Journal of Consumer Research*. Nên hiển thị nguồn nhỏ ở cuối video hoặc phần mô tả.
- *Attention residue*: Sophie Leroy (2009), *Organizational Behavior and Human Decision Processes*.
- Hai ý khoa học mang tính giải thích chung; không phải chẩn đoán tâm lý nhân vật hư cấu Minh.


---

## PHẦN C. KỊCH BẢN HÌNH ẢNH, GÓC MÁY, ÂM THANH (120 SHOT)

# KỊCH BẢN HÌNH ẢNH — 120 SHOT CHO VIDEO 8 PHÚT

**Lưu ý:** đây là shotlist để Codex dựng hoạt hình, không phải 120 hình tĩnh. Mỗi shot cần cử động thật của nhân vật hoặc vật thể, khác biệt bắt đầu–đỉnh–kết thúc. Mốc 20s/cảnh mang tính định hướng; kéo giãn/thu lại theo độ dài voice-over thực tế.

- Góc máy: ECU (cận cực gần), CU (cận), MS (trung), WS (toàn), OTS (qua vai), POV (góc nhìn nhân vật).
- Nhịp thông thường 3–5s/shot; 0.7–1.2s/cut đối với các montage trong một shot. Cao trào S17 được chậm có chủ đích.
- Không slow motion toàn bộ, không ảnh tĩnh chỉ zoom, không nhân vật đứng như tượng.
- Giữ đúng thiết kế nhân vật và màu xanh đen tối giản của hai ảnh tham chiếu trong thư mục `references/`.

## S01 · 00:00–00:20 · HOOK: Mười bốn tiếng
- **Nhịp dựng:** Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
- **Âm thanh:** Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.
- **00:00–00:03 / Shot 01.01:** ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng.
- **00:03–00:07 / Shot 01.02:** OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp.
- **00:07–00:11 / Shot 01.03:** CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở.
- **00:11–00:15 / Shot 01.04:** Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ.
- **00:15–00:20 / Shot 01.05:** Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'.

## S02 · 00:20–00:40 · Đồng hồ lúc nửa đêm
- **Nhịp dựng:** Match-on-action qua các cử động tay.
- **Âm thanh:** Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.
- **00:20–00:23 / Shot 02.01:** CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm.
- **00:23–00:27 / Shot 02.02:** ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên.
- **00:27–00:31 / Shot 02.03:** MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc.
- **00:31–00:35 / Shot 02.04:** POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu.
- **00:35–00:40 / Shot 02.05:** Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt.

## S03 · 00:40–01:00 · Sáng hôm sau
- **Nhịp dựng:** Whip pan từ đồng hồ đêm sang báo thức sáng.
- **Âm thanh:** Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.
- **00:40–00:43 / Shot 03.01:** ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây.
- **00:43–00:47 / Shot 03.02:** MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through.
- **00:47–00:51 / Shot 03.03:** CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa.
- **00:51–00:55 / Shot 03.04:** Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax.
- **00:55–01:00 / Shot 03.05:** OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học.

## S04 · 01:00–01:20 · Lịch kín mít
- **Nhịp dựng:** L-cut âm thanh giữa các khu vực văn phòng.
- **Âm thanh:** Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.
- **01:00–01:03 / Shot 04.01:** WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác.
- **01:03–01:07 / Shot 04.02:** OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt.
- **01:07–01:11 / Shot 04.03:** CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ.
- **01:11–01:15 / Shot 04.04:** Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi.
- **01:15–01:20 / Shot 04.05:** Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp.

## S05 · 01:20–01:40 · Giấc mơ thầm kín
- **Nhịp dựng:** Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style.
- **Âm thanh:** Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.
- **01:20–01:23 / Shot 05.01:** MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim.
- **01:23–01:27 / Shot 05.02:** ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát.
- **01:27–01:31 / Shot 05.03:** Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp.
- **01:31–01:35 / Shot 05.04:** Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng.
- **01:35–01:40 / Shot 05.05:** Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày.

## S06 · 01:40–02:00 · Học mãi không xong
- **Nhịp dựng:** Montage 0.7-1.2 giây/cut bên trong shot #4.
- **Âm thanh:** Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.
- **01:40–01:43 / Shot 06.01:** OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi.
- **01:43–01:47 / Shot 06.02:** ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác.
- **01:47–01:51 / Shot 06.03:** CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson.
- **01:51–01:55 / Shot 06.04:** POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp.
- **01:55–02:00 / Shot 06.05:** MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng.

## S07 · 02:00–02:20 · Chuẩn bị thay cho bắt đầu
- **Nhịp dựng:** Smash cut bảng kế hoạch đầy đủ -> canvas trống.
- **Âm thanh:** Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.
- **02:00–02:03 / Shot 07.01:** Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh.
- **02:03–02:07 / Shot 07.02:** ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động.
- **02:07–02:11 / Shot 07.03:** MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống.
- **02:11–02:15 / Shot 07.04:** OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn.
- **02:15–02:20 / Shot 07.05:** CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác.

## S08 · 02:20–02:40 · Cảm giác hoàn thành
- **Nhịp dựng:** Graphic match tick -> ô bản nháp trống.
- **Âm thanh:** Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.
- **02:20–02:23 / Shot 08.01:** ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát.
- **02:23–02:27 / Shot 08.02:** CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây.
- **02:27–02:31 / Shot 08.03:** MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống.
- **02:31–02:35 / Shot 08.04:** Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự.
- **02:35–02:40 / Shot 08.05:** ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ.

## S09 · 02:40–03:00 · Việc quan trọng bị đẩy đi
- **Nhịp dựng:** 5 inserts động; giảm nhạc ở cuối.
- **Âm thanh:** Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.
- **02:40–02:43 / Shot 09.01:** CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch.
- **02:43–02:47 / Shot 09.02:** ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay.
- **02:47–02:51 / Shot 09.03:** OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục.
- **02:51–02:55 / Shot 09.04:** WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc.
- **02:55–03:00 / Shot 09.05:** CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài.

## S10 · 03:00–03:20 · Bận vì khẩn cấp
- **Nhịp dựng:** Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
- **Âm thanh:** Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.
- **03:00–03:03 / Shot 10.01:** Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên.
- **03:03–03:07 / Shot 10.02:** POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu.
- **03:07–03:11 / Shot 10.03:** MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ.
- **03:11–03:15 / Shot 10.04:** Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%.
- **03:15–03:20 / Shot 10.05:** Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống.

## S11 · 03:20–03:40 · Đầu óc bị chia nhỏ
- **Nhịp dựng:** Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
- **Âm thanh:** Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.
- **03:20–03:23 / Shot 11.01:** OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas.
- **03:23–03:27 / Shot 11.02:** Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay.
- **03:27–03:31 / Shot 11.03:** Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi.
- **03:31–03:35 / Shot 11.04:** Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây.
- **03:35–03:40 / Shot 11.05:** Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa.

## S12 · 03:40–04:00 · Sáu tháng trôi qua
- **Nhịp dựng:** Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im.
- **Âm thanh:** Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.
- **03:40–03:43 / Shot 12.01:** Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm.
- **03:43–03:47 / Shot 12.02:** Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối.
- **03:47–03:51 / Shot 12.03:** Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt.
- **03:51–03:55 / Shot 12.04:** Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi.
- **03:55–04:00 / Shot 12.05:** CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng.

## S13 · 04:00–04:20 · Cuốn sổ cũ
- **Nhịp dựng:** Match cut trang sổ -> màn hình folder.
- **Âm thanh:** Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.
- **04:00–04:03 / Shot 13.01:** Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống.
- **04:03–04:07 / Shot 13.02:** OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế.
- **04:07–04:11 / Shot 13.03:** ECU lật trang nhanh: các checkbox nhỏ đều được tích.
- **04:11–04:15 / Shot 13.04:** CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích.
- **04:15–04:20 / Shot 13.05:** Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành.

## S14 · 04:20–04:40 · Một cơ hội đến
- **Nhịp dựng:** Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn.
- **Âm thanh:** Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.
- **04:20–04:23 / Shot 14.01:** ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình.
- **04:23–04:27 / Shot 14.02:** CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng.
- **04:27–04:31 / Shot 14.03:** Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D.
- **04:31–04:35 / Shot 14.04:** MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình.
- **04:35–04:40 / Shot 14.05:** Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở.

## S15 · 04:40–05:00 · Thư mục trống
- **Nhịp dựng:** Cut vào ánh sáng màn hình lạnh hơn.
- **Âm thanh:** Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.
- **04:40–04:43 / Shot 15.01:** POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành.
- **04:43–04:47 / Shot 15.02:** OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng.
- **04:47–04:51 / Shot 15.03:** CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống.
- **04:51–04:55 / Shot 15.04:** Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại.
- **04:55–05:00 / Shot 15.05:** ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt.

## S16 · 05:00–05:20 · Cơ hội đi qua
- **Nhịp dựng:** Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành.
- **Âm thanh:** Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.
- **05:00–05:03 / Shot 16.01:** Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật.
- **05:03–05:07 / Shot 16.02:** OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh.
- **05:07–05:11 / Shot 16.03:** CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt.
- **05:11–05:15 / Shot 16.04:** POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại.
- **05:15–05:20 / Shot 16.05:** MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây.

## S17 · 05:20–05:40 · Tất cả những ngày đã qua
- **Nhịp dựng:** Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào.
- **Âm thanh:** Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.
- **05:20–05:23 / Shot 17.01:** Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn.
- **05:23–05:27 / Shot 17.02:** ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s.
- **05:27–05:31 / Shot 17.03:** CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích.
- **05:31–05:35 / Shot 17.04:** OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay.
- **05:35–05:40 / Shot 17.05:** Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở.

## S18 · 05:40–06:00 · Nhận ra điều khó chịu
- **Nhịp dựng:** Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
- **Âm thanh:** Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.
- **05:40–05:43 / Shot 18.01:** CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm.
- **05:43–05:47 / Shot 18.02:** Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật.
- **05:47–05:51 / Shot 18.03:** MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop.
- **05:51–05:55 / Shot 18.04:** ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở.
- **05:55–06:00 / Shot 18.05:** Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe.

## S19 · 06:00–06:20 · Một quy tắc khác đi
- **Nhịp dựng:** Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
- **Âm thanh:** Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.
- **06:00–06:03 / Shot 19.01:** Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác.
- **06:03–06:07 / Shot 19.02:** CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét.
- **06:07–06:11 / Shot 19.03:** MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế.
- **06:11–06:15 / Shot 19.04:** POV mở file thiết kế duy nhất, bỏ các tab không cần.
- **06:15–06:20 / Shot 19.05:** CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối.

## S20 · 06:20–06:40 · Bốn mươi lăm phút thật
- **Nhịp dựng:** Các chuyển động rig nhanh, không zoom kéo dài 10 giây.
- **Âm thanh:** Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.
- **06:20–06:23 / Shot 20.01:** ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát.
- **06:23–06:27 / Shot 20.02:** OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây.
- **06:27–06:31 / Shot 20.03:** CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách.
- **06:31–06:35 / Shot 20.04:** Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật.
- **06:35–06:40 / Shot 20.05:** POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu.

## S21 · 06:40–07:00 · Sửa thay vì mơ
- **Nhịp dựng:** Match cut trên hành động kéo layer của Minh.
- **Âm thanh:** Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.
- **06:40–06:43 / Shot 21.01:** Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây.
- **06:43–06:47 / Shot 21.02:** OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột.
- **06:47–06:51 / Shot 21.03:** ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble.
- **06:51–06:55 / Shot 21.04:** CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra.
- **06:55–07:00 / Shot 21.05:** MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất.

## S22 · 07:00–07:20 · Bốn tuần sau
- **Nhịp dựng:** Montage ngắn nhiều cut, end một frame rõ portfolio.
- **Âm thanh:** Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.
- **07:00–07:03 / Shot 22.01:** Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay.
- **07:03–07:07 / Shot 22.02:** POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng.
- **07:07–07:11 / Shot 22.03:** OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột.
- **07:11–07:15 / Shot 22.04:** CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung.
- **07:15–07:20 / Shot 22.05:** Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật.

## S23 · 07:20–07:40 · Sự thật cần công bằng
- **Nhịp dựng:** Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động.
- **Âm thanh:** Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.
- **07:20–07:23 / Shot 23.01:** WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa.
- **07:23–07:27 / Shot 23.02:** MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại.
- **07:27–07:31 / Shot 23.03:** MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên.
- **07:31–07:35 / Shot 23.04:** OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động.
- **07:35–07:40 / Shot 23.05:** CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút.

## S24 · 07:40–08:00 · Kết: Cánh cửa
- **Nhịp dựng:** Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
- **Âm thanh:** Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.
- **07:40–07:43 / Shot 24.01:** Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây.
- **07:43–07:47 / Shot 24.02:** Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ.
- **07:47–07:51 / Shot 24.03:** Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm.
- **07:51–07:55 / Shot 24.04:** ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào.
- **07:55–08:00 / Shot 24.05:** Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s.

## Kiểm tra shot trước khi nhận bàn giao
1. Nhân vật không thoại: chỉ voice-over; không tạo miệng lip-sync vô cớ.
2. Ở các cảnh gấp (S03–S12, S14–S16, S19–S22), ít nhất 70% shot có hành động tay/chân/đầu/thân hoặc tương tác vật thể, không tính zoom camera.
3. Minh có ít nhất 8 loại hành động tái sử dụng: đi nhanh, ngồi xuống, đứng dậy, gõ phím, rê chuột, mở folder, lật sách, cầm điện thoại, chống trán, quay người, kéo ghế, viết bút.
4. Bàn, đèn, laptop, cốc và cửa sổ giữ vị trí nhất quán giữa các cảnh; không đổi quần áo tùy tiện.
5. Chữ trên màn hình đọc được, tối giản, dùng tiếng Việt; không tự xuất hiện nhãn tiến trình sản xuất.
6. Nhạc và SFX không át voice; S17–S18 có khoảng lặng chủ ý; S24 fade out 2 giây.

---

## PHẦN D. SHOTLIST JSON (DỮ LIỆU THỜI GIAN ĐỂ DỰNG)

Để lấy dữ liệu: đọc chính phần code block JSON này rồi lưu nội dung thành `shotlist.json`. Dùng các trường `start_seconds`, `end_seconds`, `camera_action`, `scene_edit`, `scene_sound`.

```json
{
  "project": "Người bận rộn nhưng không tiến bộ",
  "target_duration_seconds": 480,
  "fps": 30,
  "width": 1920,
  "height": 1080,
  "total_scenes": 24,
  "total_shots": 120,
  "note": "Thời điểm shot là bố cục tham chiếu; trong quá trình dựng phải ưu tiên căn chính xác với file lời dẫn đã thu. Cho phép 7:45–8:30, không tăng tốc giọng quá mức.",
  "shots": [
    {
      "scene": "S01",
      "shot": "S01-01",
      "start_seconds": 0,
      "end_seconds": 3,
      "duration_seconds": 3,
      "camera_action": "ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-02",
      "start_seconds": 3,
      "end_seconds": 7,
      "duration_seconds": 4,
      "camera_action": "OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-03",
      "start_seconds": 7,
      "end_seconds": 11,
      "duration_seconds": 4,
      "camera_action": "CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-04",
      "start_seconds": 11,
      "end_seconds": 15,
      "duration_seconds": 4,
      "camera_action": "Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-05",
      "start_seconds": 15,
      "end_seconds": 20,
      "duration_seconds": 5,
      "camera_action": "Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S02",
      "shot": "S02-01",
      "start_seconds": 20,
      "end_seconds": 23,
      "duration_seconds": 3,
      "camera_action": "CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-02",
      "start_seconds": 23,
      "end_seconds": 27,
      "duration_seconds": 4,
      "camera_action": "ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-03",
      "start_seconds": 27,
      "end_seconds": 31,
      "duration_seconds": 4,
      "camera_action": "MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-04",
      "start_seconds": 31,
      "end_seconds": 35,
      "duration_seconds": 4,
      "camera_action": "POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-05",
      "start_seconds": 35,
      "end_seconds": 40,
      "duration_seconds": 5,
      "camera_action": "Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S03",
      "shot": "S03-01",
      "start_seconds": 40,
      "end_seconds": 43,
      "duration_seconds": 3,
      "camera_action": "ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-02",
      "start_seconds": 43,
      "end_seconds": 47,
      "duration_seconds": 4,
      "camera_action": "MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-03",
      "start_seconds": 47,
      "end_seconds": 51,
      "duration_seconds": 4,
      "camera_action": "CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-04",
      "start_seconds": 51,
      "end_seconds": 55,
      "duration_seconds": 4,
      "camera_action": "Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-05",
      "start_seconds": 55,
      "end_seconds": 60,
      "duration_seconds": 5,
      "camera_action": "OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S04",
      "shot": "S04-01",
      "start_seconds": 60,
      "end_seconds": 63,
      "duration_seconds": 3,
      "camera_action": "WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-02",
      "start_seconds": 63,
      "end_seconds": 67,
      "duration_seconds": 4,
      "camera_action": "OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-03",
      "start_seconds": 67,
      "end_seconds": 71,
      "duration_seconds": 4,
      "camera_action": "CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-04",
      "start_seconds": 71,
      "end_seconds": 75,
      "duration_seconds": 4,
      "camera_action": "Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-05",
      "start_seconds": 75,
      "end_seconds": 80,
      "duration_seconds": 5,
      "camera_action": "Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S05",
      "shot": "S05-01",
      "start_seconds": 80,
      "end_seconds": 83,
      "duration_seconds": 3,
      "camera_action": "MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-02",
      "start_seconds": 83,
      "end_seconds": 87,
      "duration_seconds": 4,
      "camera_action": "ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-03",
      "start_seconds": 87,
      "end_seconds": 91,
      "duration_seconds": 4,
      "camera_action": "Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-04",
      "start_seconds": 91,
      "end_seconds": 95,
      "duration_seconds": 4,
      "camera_action": "Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-05",
      "start_seconds": 95,
      "end_seconds": 100,
      "duration_seconds": 5,
      "camera_action": "Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S06",
      "shot": "S06-01",
      "start_seconds": 100,
      "end_seconds": 103,
      "duration_seconds": 3,
      "camera_action": "OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-02",
      "start_seconds": 103,
      "end_seconds": 107,
      "duration_seconds": 4,
      "camera_action": "ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-03",
      "start_seconds": 107,
      "end_seconds": 111,
      "duration_seconds": 4,
      "camera_action": "CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-04",
      "start_seconds": 111,
      "end_seconds": 115,
      "duration_seconds": 4,
      "camera_action": "POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-05",
      "start_seconds": 115,
      "end_seconds": 120,
      "duration_seconds": 5,
      "camera_action": "MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S07",
      "shot": "S07-01",
      "start_seconds": 120,
      "end_seconds": 123,
      "duration_seconds": 3,
      "camera_action": "Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-02",
      "start_seconds": 123,
      "end_seconds": 127,
      "duration_seconds": 4,
      "camera_action": "ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-03",
      "start_seconds": 127,
      "end_seconds": 131,
      "duration_seconds": 4,
      "camera_action": "MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-04",
      "start_seconds": 131,
      "end_seconds": 135,
      "duration_seconds": 4,
      "camera_action": "OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-05",
      "start_seconds": 135,
      "end_seconds": 140,
      "duration_seconds": 5,
      "camera_action": "CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S08",
      "shot": "S08-01",
      "start_seconds": 140,
      "end_seconds": 143,
      "duration_seconds": 3,
      "camera_action": "ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-02",
      "start_seconds": 143,
      "end_seconds": 147,
      "duration_seconds": 4,
      "camera_action": "CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-03",
      "start_seconds": 147,
      "end_seconds": 151,
      "duration_seconds": 4,
      "camera_action": "MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-04",
      "start_seconds": 151,
      "end_seconds": 155,
      "duration_seconds": 4,
      "camera_action": "Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-05",
      "start_seconds": 155,
      "end_seconds": 160,
      "duration_seconds": 5,
      "camera_action": "ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S09",
      "shot": "S09-01",
      "start_seconds": 160,
      "end_seconds": 163,
      "duration_seconds": 3,
      "camera_action": "CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-02",
      "start_seconds": 163,
      "end_seconds": 167,
      "duration_seconds": 4,
      "camera_action": "ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-03",
      "start_seconds": 167,
      "end_seconds": 171,
      "duration_seconds": 4,
      "camera_action": "OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-04",
      "start_seconds": 171,
      "end_seconds": 175,
      "duration_seconds": 4,
      "camera_action": "WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-05",
      "start_seconds": 175,
      "end_seconds": 180,
      "duration_seconds": 5,
      "camera_action": "CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S10",
      "shot": "S10-01",
      "start_seconds": 180,
      "end_seconds": 183,
      "duration_seconds": 3,
      "camera_action": "Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-02",
      "start_seconds": 183,
      "end_seconds": 187,
      "duration_seconds": 4,
      "camera_action": "POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-03",
      "start_seconds": 187,
      "end_seconds": 191,
      "duration_seconds": 4,
      "camera_action": "MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-04",
      "start_seconds": 191,
      "end_seconds": 195,
      "duration_seconds": 4,
      "camera_action": "Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-05",
      "start_seconds": 195,
      "end_seconds": 200,
      "duration_seconds": 5,
      "camera_action": "Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S11",
      "shot": "S11-01",
      "start_seconds": 200,
      "end_seconds": 203,
      "duration_seconds": 3,
      "camera_action": "OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-02",
      "start_seconds": 203,
      "end_seconds": 207,
      "duration_seconds": 4,
      "camera_action": "Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-03",
      "start_seconds": 207,
      "end_seconds": 211,
      "duration_seconds": 4,
      "camera_action": "Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-04",
      "start_seconds": 211,
      "end_seconds": 215,
      "duration_seconds": 4,
      "camera_action": "Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-05",
      "start_seconds": 215,
      "end_seconds": 220,
      "duration_seconds": 5,
      "camera_action": "Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S12",
      "shot": "S12-01",
      "start_seconds": 220,
      "end_seconds": 223,
      "duration_seconds": 3,
      "camera_action": "Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-02",
      "start_seconds": 223,
      "end_seconds": 227,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-03",
      "start_seconds": 227,
      "end_seconds": 231,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-04",
      "start_seconds": 231,
      "end_seconds": 235,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-05",
      "start_seconds": 235,
      "end_seconds": 240,
      "duration_seconds": 5,
      "camera_action": "CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S13",
      "shot": "S13-01",
      "start_seconds": 240,
      "end_seconds": 243,
      "duration_seconds": 3,
      "camera_action": "Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-02",
      "start_seconds": 243,
      "end_seconds": 247,
      "duration_seconds": 4,
      "camera_action": "OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-03",
      "start_seconds": 247,
      "end_seconds": 251,
      "duration_seconds": 4,
      "camera_action": "ECU lật trang nhanh: các checkbox nhỏ đều được tích",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-04",
      "start_seconds": 251,
      "end_seconds": 255,
      "duration_seconds": 4,
      "camera_action": "CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-05",
      "start_seconds": 255,
      "end_seconds": 260,
      "duration_seconds": 5,
      "camera_action": "Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S14",
      "shot": "S14-01",
      "start_seconds": 260,
      "end_seconds": 263,
      "duration_seconds": 3,
      "camera_action": "ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-02",
      "start_seconds": 263,
      "end_seconds": 267,
      "duration_seconds": 4,
      "camera_action": "CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-03",
      "start_seconds": 267,
      "end_seconds": 271,
      "duration_seconds": 4,
      "camera_action": "Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-04",
      "start_seconds": 271,
      "end_seconds": 275,
      "duration_seconds": 4,
      "camera_action": "MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-05",
      "start_seconds": 275,
      "end_seconds": 280,
      "duration_seconds": 5,
      "camera_action": "Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S15",
      "shot": "S15-01",
      "start_seconds": 280,
      "end_seconds": 283,
      "duration_seconds": 3,
      "camera_action": "POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-02",
      "start_seconds": 283,
      "end_seconds": 287,
      "duration_seconds": 4,
      "camera_action": "OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-03",
      "start_seconds": 287,
      "end_seconds": 291,
      "duration_seconds": 4,
      "camera_action": "CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-04",
      "start_seconds": 291,
      "end_seconds": 295,
      "duration_seconds": 4,
      "camera_action": "Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-05",
      "start_seconds": 295,
      "end_seconds": 300,
      "duration_seconds": 5,
      "camera_action": "ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S16",
      "shot": "S16-01",
      "start_seconds": 300,
      "end_seconds": 303,
      "duration_seconds": 3,
      "camera_action": "Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-02",
      "start_seconds": 303,
      "end_seconds": 307,
      "duration_seconds": 4,
      "camera_action": "OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-03",
      "start_seconds": 307,
      "end_seconds": 311,
      "duration_seconds": 4,
      "camera_action": "CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-04",
      "start_seconds": 311,
      "end_seconds": 315,
      "duration_seconds": 4,
      "camera_action": "POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-05",
      "start_seconds": 315,
      "end_seconds": 320,
      "duration_seconds": 5,
      "camera_action": "MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S17",
      "shot": "S17-01",
      "start_seconds": 320,
      "end_seconds": 323,
      "duration_seconds": 3,
      "camera_action": "Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-02",
      "start_seconds": 323,
      "end_seconds": 327,
      "duration_seconds": 4,
      "camera_action": "ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-03",
      "start_seconds": 327,
      "end_seconds": 331,
      "duration_seconds": 4,
      "camera_action": "CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-04",
      "start_seconds": 331,
      "end_seconds": 335,
      "duration_seconds": 4,
      "camera_action": "OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-05",
      "start_seconds": 335,
      "end_seconds": 340,
      "duration_seconds": 5,
      "camera_action": "Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S18",
      "shot": "S18-01",
      "start_seconds": 340,
      "end_seconds": 343,
      "duration_seconds": 3,
      "camera_action": "CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-02",
      "start_seconds": 343,
      "end_seconds": 347,
      "duration_seconds": 4,
      "camera_action": "Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-03",
      "start_seconds": 347,
      "end_seconds": 351,
      "duration_seconds": 4,
      "camera_action": "MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-04",
      "start_seconds": 351,
      "end_seconds": 355,
      "duration_seconds": 4,
      "camera_action": "ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-05",
      "start_seconds": 355,
      "end_seconds": 360,
      "duration_seconds": 5,
      "camera_action": "Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S19",
      "shot": "S19-01",
      "start_seconds": 360,
      "end_seconds": 363,
      "duration_seconds": 3,
      "camera_action": "Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-02",
      "start_seconds": 363,
      "end_seconds": 367,
      "duration_seconds": 4,
      "camera_action": "CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-03",
      "start_seconds": 367,
      "end_seconds": 371,
      "duration_seconds": 4,
      "camera_action": "MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-04",
      "start_seconds": 371,
      "end_seconds": 375,
      "duration_seconds": 4,
      "camera_action": "POV mở file thiết kế duy nhất, bỏ các tab không cần",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-05",
      "start_seconds": 375,
      "end_seconds": 380,
      "duration_seconds": 5,
      "camera_action": "CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S20",
      "shot": "S20-01",
      "start_seconds": 380,
      "end_seconds": 383,
      "duration_seconds": 3,
      "camera_action": "ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-02",
      "start_seconds": 383,
      "end_seconds": 387,
      "duration_seconds": 4,
      "camera_action": "OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-03",
      "start_seconds": 387,
      "end_seconds": 391,
      "duration_seconds": 4,
      "camera_action": "CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-04",
      "start_seconds": 391,
      "end_seconds": 395,
      "duration_seconds": 4,
      "camera_action": "Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-05",
      "start_seconds": 395,
      "end_seconds": 400,
      "duration_seconds": 5,
      "camera_action": "POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S21",
      "shot": "S21-01",
      "start_seconds": 400,
      "end_seconds": 403,
      "duration_seconds": 3,
      "camera_action": "Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-02",
      "start_seconds": 403,
      "end_seconds": 407,
      "duration_seconds": 4,
      "camera_action": "OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-03",
      "start_seconds": 407,
      "end_seconds": 411,
      "duration_seconds": 4,
      "camera_action": "ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-04",
      "start_seconds": 411,
      "end_seconds": 415,
      "duration_seconds": 4,
      "camera_action": "CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-05",
      "start_seconds": 415,
      "end_seconds": 420,
      "duration_seconds": 5,
      "camera_action": "MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S22",
      "shot": "S22-01",
      "start_seconds": 420,
      "end_seconds": 423,
      "duration_seconds": 3,
      "camera_action": "Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-02",
      "start_seconds": 423,
      "end_seconds": 427,
      "duration_seconds": 4,
      "camera_action": "POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-03",
      "start_seconds": 427,
      "end_seconds": 431,
      "duration_seconds": 4,
      "camera_action": "OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-04",
      "start_seconds": 431,
      "end_seconds": 435,
      "duration_seconds": 4,
      "camera_action": "CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-05",
      "start_seconds": 435,
      "end_seconds": 440,
      "duration_seconds": 5,
      "camera_action": "Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S23",
      "shot": "S23-01",
      "start_seconds": 440,
      "end_seconds": 443,
      "duration_seconds": 3,
      "camera_action": "WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-02",
      "start_seconds": 443,
      "end_seconds": 447,
      "duration_seconds": 4,
      "camera_action": "MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-03",
      "start_seconds": 447,
      "end_seconds": 451,
      "duration_seconds": 4,
      "camera_action": "MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-04",
      "start_seconds": 451,
      "end_seconds": 455,
      "duration_seconds": 4,
      "camera_action": "OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-05",
      "start_seconds": 455,
      "end_seconds": 460,
      "duration_seconds": 5,
      "camera_action": "CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S24",
      "shot": "S24-01",
      "start_seconds": 460,
      "end_seconds": 463,
      "duration_seconds": 3,
      "camera_action": "Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-02",
      "start_seconds": 463,
      "end_seconds": 467,
      "duration_seconds": 4,
      "camera_action": "Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-03",
      "start_seconds": 467,
      "end_seconds": 471,
      "duration_seconds": 4,
      "camera_action": "Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-04",
      "start_seconds": 471,
      "end_seconds": 475,
      "duration_seconds": 4,
      "camera_action": "ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-05",
      "start_seconds": 475,
      "end_seconds": 480,
      "duration_seconds": 5,
      "camera_action": "Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    }
  ]
}
```

---

## PHẦN E. SHOTLIST CSV (BẢN ĐỐI CHIẾU)

```csv
scene,shot,start_seconds,end_seconds,duration_seconds,camera_action,scene_sound,scene_edit
S01,S01-01,0,3,3,ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng,"Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-02,3,7,4,"OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-03,7,11,4,"CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-04,11,15,4,"Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-05,15,20,5,"Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S02,S02-01,20,23,3,"CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-02,23,27,4,ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên,"Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-03,27,31,4,"MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-04,31,35,4,"POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-05,35,40,5,Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt,"Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S03,S03-01,40,43,3,ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây,"Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-02,43,47,4,"MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-03,47,51,4,"CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-04,51,55,4,"Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-05,55,60,5,"OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S04,S04-01,60,63,3,"WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-02,63,67,4,"OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-03,67,71,4,"CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-04,71,75,4,"Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-05,75,80,5,"Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S05,S05-01,80,83,3,"MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim","Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-02,83,87,4,ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-03,87,91,4,"Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp","Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-04,91,95,4,Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-05,95,100,5,Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S06,S06-01,100,103,3,"OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-02,103,107,4,"ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-03,107,111,4,"CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-04,111,115,4,"POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-05,115,120,5,MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng,"Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S07,S07-01,120,123,3,"Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-02,123,127,4,"ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-03,127,131,4,"MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-04,131,135,4,"OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-05,135,140,5,"CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S08,S08-01,140,143,3,"ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-02,143,147,4,"CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-03,147,151,4,"MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-04,151,155,4,"Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-05,155,160,5,"ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S09,S09-01,160,163,3,CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-02,163,167,4,ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-03,167,171,4,"OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục",Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-04,171,175,4,"WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc",Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-05,175,180,5,CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S10,S10-01,180,183,3,Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên,"Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-02,183,187,4,POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu,"Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-03,187,191,4,"MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-04,191,195,4,"Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-05,195,200,5,"Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S11,S11-01,200,203,3,"OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-02,203,207,4,"Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-03,207,211,4,Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi,Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-04,211,215,4,"Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-05,215,220,5,"Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S12,S12-01,220,223,3,"Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-02,223,227,4,"Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-03,227,231,4,"Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-04,231,235,4,"Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-05,235,240,5,"CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S13,S13-01,240,243,3,"Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống","Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-02,243,247,4,"OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế","Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-03,247,251,4,ECU lật trang nhanh: các checkbox nhỏ đều được tích,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-04,251,255,4,CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-05,255,260,5,Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S14,S14-01,260,263,3,ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-02,263,267,4,CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-03,267,271,4,Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-04,271,275,4,"MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình","Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-05,275,280,5,Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S15,S15-01,280,283,3,"POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-02,283,287,4,"OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-03,287,291,4,"CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-04,291,295,4,"Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-05,295,300,5,"ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S16,S16-01,300,303,3,Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật,"Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-02,303,307,4,"OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-03,307,311,4,"CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-04,311,315,4,POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại,"Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-05,315,320,5,"MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S17,S17-01,320,323,3,"Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-02,323,327,4,"ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-03,327,331,4,"CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-04,331,335,4,"OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-05,335,340,5,"Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S18,S18-01,340,343,3,"CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-02,343,347,4,"Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-03,347,351,4,"MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-04,351,355,4,ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở,"Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-05,355,360,5,"Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S19,S19-01,360,363,3,"Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-02,363,367,4,"CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-03,367,371,4,"MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-04,371,375,4,"POV mở file thiết kế duy nhất, bỏ các tab không cần","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-05,375,380,5,CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối,"Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S20,S20-01,380,383,3,"ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-02,383,387,4,"OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-03,387,391,4,CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách,"Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-04,391,395,4,"Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-05,395,400,5,"POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S21,S21-01,400,403,3,"Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-02,403,407,4,"OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-03,407,411,4,"ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-04,411,415,4,"CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-05,415,420,5,"MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S22,S22-01,420,423,3,"Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-02,423,427,4,"POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-03,427,431,4,"OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-04,431,435,4,"CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-05,435,440,5,"Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S23,S23-01,440,443,3,"WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-02,443,447,4,"MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-03,447,451,4,"MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-04,451,455,4,OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động,"Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-05,455,460,5,CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút,"Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S24,S24-01,460,463,3,"Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-02,463,467,4,"Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-03,467,471,4,"Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-04,471,475,4,"ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-05,475,480,5,"Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).

```

---

## PHẦN F. NGUỒN NGHIÊN CỨU

# Nguồn nghiên cứu dùng trong kịch bản

Các dẫn chứng liên quan thói quen phân bổ thời gian và chuyển đổi nhiệm vụ; chúng không thể chứng minh mọi người bận rộn đều không tiến bộ.

1. Zhu, Meng; Yang, Yang; Hsee, Christopher K. (2018). **The Mere Urgency Effect**. *Journal of Consumer Research*, 45(3), 673–690. DOI: https://doi.org/10.1093/jcr/ucy008. Minh họa việc đôi khi ưu tiên việc trông có vẻ khẩn cấp hơn việc quan trọng.
2. Mills et al. (2026). **Brief Commentary: An Independent Replication Study of the Mere Urgency Effect**. *Journal of Consumer Research*. DOI: https://doi.org/10.1093/jcr/ucag026. Một thử nghiệm độc lập trên 2.374 người ghi nhận hiệu ứng vẫn tồn tại trong các thiết kế được kiểm tra, dù yếu hơn khi bổ sung biện pháp kiểm soát một số yếu tố nhiễu.
3. Sophie Leroy (2009). **Why Is It So Hard to Do My Work? The Challenge of Attention Residue When Switching Between Work Tasks**. *Organizational Behavior and Human Decision Processes*, 109(2), 168–181. DOI: https://doi.org/10.1016/j.obhdp.2009.04.002. Liên quan sự chú ý còn lại ở nhiệm vụ trước khi chuyển việc.

**Lưu ý sản xuất:** không hiện số liệu bịa; không biến nghiên cứu thành lời khẳng định tuyệt đối về nhân vật hư cấu Minh. Có thể ghi các nguồn này trong phần mô tả YouTube.

---

## PHẦN G. HAI ẢNH GỐC THAM CHIẾU — DỮ LIỆU NHÚNG

Đây là hai ảnh tham chiếu **đúng phong cách người dùng đã chốt**, được nén kích thước để dễ chuyển giao trong một file văn bản. Codex phải trích xuất bằng Python ở phần đầu, KHÔNG cho model đọc chuỗi base64 và KHÔNG coi ảnh gốc như các frame sẵn.

### thumbnail_style_mac_ket.jpg

SHA-256: `9ed0dd90e38a83e26323db4b8f30c173d0df7bdeaac27fde09fc6abb6bf6a3ef` — 84471 bytes

<!-- BEGIN_EMBEDDED_ASSET: thumbnail_style_mac_ket.jpg; encoding=base64; mime=image/jpeg
/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAcFBgYGBQcGBgYICAcJCxIMCwoKCxcQEQ0SGxccHBoXGhkdISokHR8oIBkaJTIlKCwtLzAvHSM0ODQuNyouLy7/2wBDAQgI
CAsKCxYMDBYuHhoeLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/wAARCAKjBK8DAREAAhEBAxEB/8QAHAAAAgIDAQEAAAAA
AAAAAAAAAAECAwQFBgcI/8QAXBAAAQMDAQQGBQcHBgoIBAcBAQACAwQFEQYSITFBBxNRYXGRFCIygaEVQlJyscHRFiMzU2KCkkOTorLS4RckJTRFY4OElPAIREZUZHN0
wjVVhZUmNoajw+LxVv/EABsBAQEBAQEBAQEAAAAAAAAAAAABAgMEBQYH/8QAPBEBAAICAAQDBQYFBAIDAQADAAECAxEEEiExE0FRBRQiYZEGMlJxgaEVI0JTsTPB0fBi
4UNykvEWJGP/2gAMAwEAAhEDEQA/APDl6HA0CQCAQNAIEgEDQCAQCBoBA0AgSBoBA0AiEqGgFFNENUCAQCAQNAIBAIBAkAgaAwgYQSQCAQCIEDQCAQCAQCKEDCBoGgED
QCBIGgSBoBAkDQAQNAIBAkDQCigIBAIBAIBAKKEAgeEDQPeoowgYCCWFFPCi6SAU2qWEBs5U2aTDU2ukwxTa6SDFNrpMRFZ2uljYT2KTZrlWCnceSzzLyrG0zuxTna5V
8VK5xw0ZPYN6zN2uRsafT10qADBbauTP0IHH7lnxIXlbKHQ2ppsdXZKvH7bQ37Sp4sJywzYujbVT+Ntaz687B96niwvLDNi6LNSP9sUUfjPn7ApOWDUMuPomvh9qst7f
3nH7lnxV1C3/AATXbncaD+F/4J4pqD/wS3T/AOZUP8D/AME8U1CLuia8fNuFAfc8fcr4pqGPJ0T38ezUW93+0cP/AGp4sJqGLJ0W6mZnEVI/6tQPvCviwahgTdHeq48/
5Ie//wAuRjvvWoywahrajR2ooM9bY69uOYhLvsV8WE5WrntNXCSJqWePHHbjc37Qr4kJyMM0x4LXOnIg6mcOS1zJyoGAjkrzM8qBiPYrtOVWYz2K7TSBjK1tNIlibNIF
iu2dKy1XZpEtVRAtVREhVESiIkKiKIRVCKBIEUEUAgEQKhIDcgEAgSoFAIhFAkUsIBAkAgaAQJA0AgSBoEgEAgEDQCAQNAIBA0CQAQNAIGgSAVDCIaAQCBoBAIGgEAgE
DQGEQYRQgEDQNAIBAIgQNA0AgEAgMIEinhENFCBhA0AgSAQNAIBAIBAIGEDUCVAgECQNRQgEDQCAUUIDCB4QPCimAgeFFMNU2aS2U2ujDVNrpMNUmV0kGqbXSYjPYptd
LGxZ5Kcy8qxsJ7Fnmaiq1sBzvGPFZm6xRuLbpy73DHoVsqpx2siOPPgsTlhvkdVbujHUlTgyU0NMO2aUZHubkrnOVeWIbyPowpKRodd9R00A5tjaPtcfuWJytRG+0L47
J0cUHq1Fxqa1447LnY/ogfaseJMt8lvRu7PS6JnD32/TzHtYQOsnZnJ7tolccufl6OlMFrebooJqaDApbfTQgcNhgH2BeaeJn0dfdo85ZPp85G4gJ7xc93pA9LmPF/wU
8a/qvg09C6+Y/wAo5PEv6nh19EhLIeMjvNOe3qnJX0PbcfnHzV3Jywe0fpHzTcpqBtH6R81dyagi9w+cfNTmk5YRMjxwe7zU5p9WuWPRAzyjhK/zU57eq8lfQjVTj+UK
eLf1PCp6F6fUt+eD4hXx7x5r4FJRdd5QCJImPHYcrUcRbzhmeFr5S5W6ajsjKt9NctMwy4+cGsOR7wF6qX5o24WxTWdba18nRtWHEtqmpHHmxjm4/hJ+xa5rM8kqjo/R
FxP+T9QvhceDZHNOP4gCtRlmEms+jFq+iase3rLbd6OpZy2gW/EZC6xkc9Q5uv6O9T0mSbY6do+dTvEnwG/4K+LByRLmay11NI/YqaeWB45SsLT8VuMkSk42C+nI5LcX
Zmil8JHJaizE1Y74j2LfMzNVZYrtnSBYtbTStzVdppWQrtNIkKoiQqiKCJRCVCKBIEqgQIoBAkAgEAiBAlQKKSAQCBIBAIEgEDQCAQCAQCAQCAQAQNAIBAIGgEAgEAgE
AiGqGgEAgEAgaAQCAQNAIGiBA0AihAIGgEQ0UkQIGgEDQCAQNAIBAIBFNA0AgSBoBAIAIGgSBoBAIBRQgEAgEAgEDQCKageEAAopgIJAKLowFNrpINU2qYaptdJhimzS
YjU21pY2I9izNliq6OnJ5LM2birYUForK6URUdLNUP8AoxMLj8FznJDfI7mz9Ft/q2iSqZDQx8SZ3Zd/C37ysTknyXUQ279J6FshHy3qE1Mw4wwOA+Dcn4rnzWnsuvkY
1fouzbrFpdssg4SzNDficuTltPdevq1td0oaiqMspW0dIzkGR7ZHvd+C1yQnRrpdQXysZmtutVITvLes2QPcMLnMRt1r0YYmcTtElx7TvU03zLWbUrmsaMuccAd6k9De
3pllpBQ0UVOOIGXHtPNfNyW5rbe2kajTcMO5c1WtVSVg4LTKQVZTBVRMFVNHlXaaGUNIkqLpAlRVblGkHFZWFLyo2xZVVcnqyi6yJtUwetHud4L04LanTjmruNuOK9bz
G1+O8IbQdUVFPIJKaaWInnG8t+xWEs6O06p1HT0VTKLjLL1WxsicB4GSRzWLdLRpqKxMTuGzj6RKt7BHdrRSVkXPHqnydkLbnNI8idVdGl2BNZbJLZKeL2NLAPezI+C1
EyxMWUy9HFmukZl05qOGYcmS4f8AFu8e8KxeYT84cleOj3UluDnPtrp4x/KUx6weQ3jyXSMjOolx81I+N5Y5ha8cWuGCPcusXZmjFfCRyW4sxNVL4itRLEwocxa2zpWW
LW00rc3uV2mkCFURIVRHCBFVCQIoBVCQIoEgEAgEQIoVQlFJAIEgECQNAIEgEDQCAQCAQCBoBAkDQCAQCBoEgaAQCAQNECoMqBqgQCAQCBoGgEAgaAQNECAQCBooRAgE
AgEDQCAQCBoGgaAQCARQgEDCB4QCAQGEAgEAgaAQCBIGgFFJA0AgSBhRUsIDCBgKLpIBQMBRrSQaoqxrMqbXSxsaztYha2InkpMtRC5kB7FibNRVsbfa6qumENLTSzyn
gyNhcfgudr6dIo76zdF12qGCe5Sw26Ab3dYdp4HgNw95XOckr0htzSdGum91RO+8VbOLWnrBnwGGj3krO5lerDruk+ohiNPYbTSUEA3AuAcf4Rhv2qxjJ15uLu+p73dc
iuudTKw/MD9ln8IwFuKQnNrs0fWkcN3gt8rPMXWHtTRtl0LS9+272W/asXnUN06y2rXZXHTqmEHR6RojPVmqeMxw8O9y8/EX1GnfDXc7egQncvBL1MphUFzUSVhOMBVD
BVZlMFVEgVUPKBEoaRJRUS5RVTnKKROQo0qeorGk4KjX1bGyxvjcMtcMLdZ1KT1h5xW0z6aqkhcPZO7wX0K23G3jtXU6VBiu0MxgjBU2umxpMCzXFoG8GH+sVzn70Nx2
lppQ4ggrrDnLBcxzXEZK6RLmInGKQSNJa8cHNOD5hWR09u11f7W1rWV7qhg4R1A6wAePEeazy77JMV827OvdP3pgh1Pp2OTO4zRAPI79+HD3Fa5bQzr0Uu0TpHULTJpe
/iKY7/RpztY7sHDh8U5pr3SXIX7QWorQHPntzpoG8ZqY9Y3343j3hda5IZ5duQkpyM4HBdYsxNWK+I9i3FnOYY72LcSzpU5qu0mFbgtMoEKoiQgRCqEgSBKoCgigMoAI
BA0QkUkCQIoEgEAgYCAVAoBAIEgaAQCAQCAQCAQNAIBAIGgSARAqGEDQCAQMIBAIBAwgaAQCAREkUigEQIGgEAgaBoBAkAgEDQNAKhqAQMIBAIoRAihAwgaA3oBAIGgE
AgCgEAgEAgEAooQCAwoqWEDwoqQCBhqiphqm10mGLO2tLGsU2sQvjizyWJs1EMmOA9ixNm4q6jTuj7zfCDRUbupzvmk9SMe88fdlcrZHSKxHd235GaV001s2qLwJ5sZ9
EgyNr3D1j8Fzm0y1HXtCus6Raa3U5pNLWaCihG4SSNGT37I+8lOWZNR5uDvGo7vdnE3C4Tzj6Bdhg8GjcukUhJt6NM+YnwW4qxNlZkPatRDO0C9XSbRLldG0ow57w0cS
pPQhu4GCNgYOS89usvRHSF4WWl0Yc9zWNBLicAKSQ9Js1KKOiigA9YDLj2lfMyW5rbe+leWNN3FuC5NslhUF8YyiSCclUSBRJTBVTR5KqaGUBtIIkqLpAuUXStxRdIhw
zhRUXoMd6oxJVqElzeoKSJ7WznLcHDnAZIHavRitMdHLJXfVzk8EtPL1creIDmuG8OHIg8wu8WiXHWlkUJeRuUmViHUW3T1VPp+51UceWDq/F2ycux4AqxjtaOePJOet
bRWfNylVThnBSstWhqqlmBkDeutZcrQJaT0WjZV1e6WYZp4DxLf1juxvYPneCu+adQzrXWWneTklxJJ4ld4cpVOfha0zsmSlrg4H1hwI4j3pMbIs7CxdIGoLTsM9L9Lg
G7qqnLt3c72h5rE44Xmie7pzfdBas9W+UBtdc7d6SzcM/XA/rBZ1ao1N86LK5sXplgq4bpSuGWgENfju37LvcVqMiah5xX2yopJ3wVEEkUzDh0cjS1w8QV2rdiaNZLAR
yXSLOc1Yz4+5biWdKnNwtbZ0rIVREhVESgiVUJAlUJAIEgaoFEJFCqEoowgECQCBoEgSBoBAIAIGgSAQCAQAQNAIGgEAgECQCBohqgQCAQNAigAgkEDwgEQIBFCCQRCQ
CAQNA0AgEAgEAgaAQCoe9AIGoGgEUIgQCKaAQNAIBA0AgEAgEAUAEDQCBIBRTQGEAop4QSAUUwN6ipgKbXSYaptdLGtWZldLmRrMy3EMyGnLuS52s6Vq63Tehr3fC19L
TdVTHjUTZaz3c3e5cZu3yxHd2rbfobRozcZflm6M39UAHNafq+yP3iT3LnuZa6tBfeke91+YaJzbbS4w1kHt473fhhaih0hw89VJI9z3vc57jlznHJPiV0iiTdjulytR
DEyrc7K3EM7VlyumdoEqoWVQ1BsbfDst6xw3nh4LlefJ1pHm2DVydFjSoroNL0vXVRqHj1IuHe5efPbUad8Ndzt3MB4LwS9kNjEdwWFZDMqDJD9mMjtREAUVMFESBVTR
5Q0NpVNEXIukSVBFxRVTyoqvOCirHOy0FVGNIVRiSnKsDAq4xKxzHDIIwVuJ0zMbaeiZF69tuGepa4mKUDJhJ5jtaeY9/Fd9+cOM1ZdDaJ5biyhaG9Y4+0Dlob9PPZhK
zzTqEn4Y3L1OmijpaOKjpxsxsbsjPE957yd69E3mI5YeXW55peYatsbqSs9IhZilnJLQPmO+c37x3eC4dur1VnfRpoLfS0cPp9fG2VxGaeldwkP03/sDs+d4K820msuU
us01RVS1FRI6SZ5y5x5/gO7kvRTWujjeNNNKd69EOEsdxW4YQLldJsuswrpNpNlIPFTS7biy6jutll6y2V0tP2sacsd4tO4rE0iW+Z6HR6507qSBlFrK1xNkxhtXE04b
37vWb7sjuWJrMdj8muv/AEaSS0/yjpWsjulE/e1geOsA7AeDvge5Wt9dyYie7zCuoJqaZ8E8T4pWHDmPaWuae8Fdq3252o18kRHJdYlzmFDmLUSzMKnNWtppAhVlAhEI
hURQCqFhAkAqgUUKhKBIgRQgECQCACAQCAQCBoEgaAQGECQNAIGgEAiBFCAVQKKaqBQCAVAoBUPCgFQwiGimgECKIEDygYQCAQNAIBAIBAIpogwgaAVAgagEDQCKEAga
AQCBoBA0AEDQCAQJAFABA0AooQMIBFCgFFSAQSAUVNrVJldLWtWdtaWtYszLUQvjiyeCxNm4q6HTumbpfanqLdSuk2fbkPqsj73O5fauNrukV13elQWLSGiWNmv1Q25X
QDabTMbkNP1fvd5LlMzLe58nOaq6Qbvdg6npn+gUOMCGF3rOH7TuPuGAtRVOkOFkqCd2V0irM2UOeTzW9MTKsuV0myygCqIFWEJVAgyKWEyyb/ZHFZtOoarG5bZo8lwd
ljVFWxtc9zWNBLicALM9Fh6BaKQUdLHAPa4uPaV87Jbmnb3UryxpuoGrjLrDNjOFlWdSmLOZHjwUSd+SVQYw8CM5CJG/NWCo0mCgkCgeUQ8oESgiSioOcgrcVRU4oLY8
vGByQY82QSEhWK5ahJVPA5kKstXcYgXNkjGXcDhdK2iISazMuy0pa30dKJ5Wn0moA4/MZxA9/E+5dqVmP1ebLbc/KHStbl20eHJeiI3O5eeZ6aYN2pIauGSmmaOrl9YE
jOy4cD/zyJXPJrep7S6Y5nvHeHkV8gqqetnhrN07HYdk8ezHdjh3LnEcs6l6dxaNw5S4sA9fd3716KS892lm2d5yPNeirhLEeR2hdIc5UuK3DMqyVWUdpXRsw9TRtY2U
jmppqJbixajutjqfSLZWPgcfaZxY/wCs07isWpEtRZ6PBqnSutIWUWrKNlDXY2Y66I4aD9bi3wdkLjyzXrDUfJzGr+jm62ZjqykxcLbjaE8I3tb2uaOXeMhdK5PVJrEv
PpoC1dos5TVivZ3LpEsTChzcLUSzMKyFplEhERIVCwgRQJVAgSBKoFFCAQJAIEgEAgEAgEDQJA0AgEAgEAgEDQCqGgEAoBFCAVQIGgEAgAgYCB4QCIaKEAiEgaAQNAIB
A0AgEAgEAgYQNAKgQCgaoaBqBIoQPCBoDCISKaBoBAIGgEAgCgEAgEAooQNRQgAFFSAQSAUVY1qy1pa1izMrpcyMlZmW4hn01I+RwDWkknAAHFcbX061o9N090fRU9L8
rarqBQULRtdSXbL3fWPzfAet4LlNplvp5LL7r5tPS/JWlaZtuoWbhK1uHu7wPm+JyVIrtderzioqXyPc973Oe45c5xyXHtJ5rpWrM2YUshK6RDEyqLlrTO0cogyqMqho
5a2rp6WEZkmkawDxKxe0VrMy1Ws2mIh6RqLo7jkLp7JK2J2N9PIfVJ/Zdy8CvmYfaGumR9DLwUT1o80raSakqpaWobsTROLHtyDgjvC+pS0WrFo83zrVms6lj4W2Umty
QBvJUG3p4hHGG8+a4Wncu9Y1C8BZaTCg3mm6TrKk1Dx6sfDvcuGe+o07Yq7nbtIBvC8MvXDYRbgsS3DIaVlVjSoJh29Ba0qCQQSCKkoGgRKqIlFVlEVuVFTiqE1+DuKa
EXuQUOme05a4hVDFdVAYExH7o/BXqnLCL6+sYxzhNvA3eq38EiZJrX0dZHXPeaWpZM4MlYyQtzu37iPPK9lssxeJiek6eSuKJpMTHWNsd11nZK+J73Nc1xBBAXKc146b
dIw0mN6WU9xkmhmdtl5Dg1uRwOMlPGty9UnDXmiIcDrS7VceoKmOnmLepayPOyDvDRniO0rvaNz1Yp91zE16upaR6a8H6rfwVilSZlzlZebq5zmy1shx3N/BemuKno4T
kt6tPUVlTL+kmc7xwu1aVjtDla9p82E9xPErpEOcyqJWmUcqoW0gYcpo2kHKaXa2OUjmszDUWdnpDXd3045sMb/SaHO+llO4duyfmn4dy5Wx+jpFt93X1undM68pZLjp
maOguwG1NRSeq1x7wOH1m7u0Bc4tas6ldPJr1Z661VslFX0z4KiPix45doPMd4XorfbFqNNJHgldYlymGO5q3EsTCBCqIEKoiVURKBFAlUCAQCAVQIEVFJAIABBEIDKA
QNAIBAIGgSBoGgSAQAQNA0AiBAIBVQoBENUCA4IBA0DRDQCAQCKEQIDCKaIaAQGEAgEAgEDCKeEQIBUPCgEAFRJAKBIpoGgaAQJA0AgSBhBJAkDQJAIBAKKaBqKeEBhR
TAUEgEWIWBqztrSxjVmZaiGTFHnksTLcQ31isddd6yOkoKd00z+Q4AdpPId64Wu7RXXWXqsNLp/o7pmzVexcb+5uWMbwj8Poj9o7zyXLuvWe3Z51qPUdyvtWaivnLgD+
bibuZGO4ffxW61N6aCSUnmukVYmzHc5biGJlU5y0iOUQIABB6J0WWaSWrfep2fmYcsgz85/M+4fEr5ntDPFY8OO8vocHhmZ55ei324i02mquEgGIWZaD853Bo88L5uLH
OW8Ve7JeMdZs+e5ZJJZXyyu2pHuLnHtJOSv0kRERqHwpmZnco4yqM+hhH6Vw8FzvbybpXzZ4C5OqYCgmxhc4NAyScBSZWIdvbaYU1NHCOIGXHtK8OS3NO3spXUabiAYA
XGXWGYwrCrmlRpa07lBY1QWtKgmEVYAoHhAIEUESggVRU5UUOKqKiVRFzkRS4qiGQrpGQyLbgc95DIuG0eZ7AOZU0b8mZaZhUWhoY0tNLM6LBOTsn1hn35XW0TNIn0c4
nV5+bZXyASsdNG3843fu+cMZVvrmlnHvUI2BrX0rCR7Ux8twViInUJeZjc/J51cp6a83CsfTgR1r5nlse16s+842SeDscuB5LrbcTvyZjtEOWqHEOc1wLXA4IIwQV2q5
2ae4x5b1jeI4r0Y58nC8ebTvK7w4yocVqGJVkrSIkoI5VQ8oAFBNpU0qxr8LMw1Es6irqijqI6mlnkhnjOWSRu2XNPcVia7biz1e1aosetKCOx6vijhrfZgrmAN9bx+a
7u9k9y89qzWdw3EuC1roq56ZqcVLeupJHYhqmD1X9x+i7u8srrTJtma7cbJFjku8S4zDHezC6RLEwqcO5VFZC0iJCIiUCVQIEgEAgEAgSoFAIIoBA0CQCACCSAQCAQCo
FAIBAIGgEAgaqBRTRCVDQMIBAIgRTCIEU0QIGgEAgEDQCAQNAkAgEDwgaAQCB4QCBqgwgagEUIGEDQCAQCBoBAkDQNAKACoECQCimgYUUwgYRUsKBgKKm0LMy1ELmNWZ
lqIZEUWTwXOZbiHYaO0lX6irOqp29XAwjrqhw9WMdneewLha7tEREbl3901BaNG0L7JpdjJK7hUVjsO2XfY53dwHeucQut9ZeVV9bNUzSTTSvlle4ue95yXHtJXStS1m
ve8ldYhzmVTnLWmVZKukRJVQkQBBLKivRdL6/wDRY4aG60sYp2ANZLTM2dgd7Bux4L5fEcBzTNqT1+b6GDjOWOW0dFHSJqeK5zw22hlbJRw4kfIw7pHkbvcAfM9y68Fg
mlea3eWOLzReeWvZwpOSvc8ayCMyPDRw5qTOoWI3LbNaGgADcFwmXZY0KKmAitxYqXrJzO4erHw7yuOa2o064q7nbq4gvHL0wzotyxLbJaVlVrSoq5pWVWtKguaMqDLp
aWaodiNuQOLjuAW6YrZPusXy1p3QuVz09ZARc7k0zD+Ri3u8hvXqrw1I+91/J55z3t92NR83OT9JNihJFJZJpgODpXhuftXorhpH9Lla9572ayfpUi2sDTMBb/6jf/VX
ScFJ/phjntH9Ur6PpJsFQ7ZrbRW0f7cL2yge7cVytwdJbrxF483UW6stl5iMtmuMNZgZdEPVlb4sO9eTLwtq9ur0U4mJ+90/wk4YJBG9eXT07UvKox3lagUPKqKy5VEH
FWEEYib68vrdjM8fHsCqCaV8p2nngMADcAOwBZ0sdGRYHFlRXwcpohK36zTv+BK7061mHHJ3iXR9aHRQuPzo2/h9y5ZJ1LWOO7Hc9lFbZahvqiGGabA7d+PjhdsUbmrn
knUWj8oeIOZgDLt+F6nNl1ErLjGBUPDa5ow2Z3CYfRefpdjufA9qkRNe3ZO7SysIJa4HPAgrtVyloqyMxSFvI7wvTWdw89o1LDcV0hhWVURKoSIMqgBUEgUEg5RU2uwp
pV8cpCxMNxL0zRut4vQ/yf1QwVlolb1YfINp0I5A8y0dvEclwvTXWHSJ21GvtDy2Ii5W55q7LNgxzg7RjzwDiOIPJ3PxWqZN9JZmrz2aPBO5eiJcphiPbhdIlzmFLgtM
oFURKISAVQkAgSAQCAwgRQJAIBAIEgEDQCBoBAIBECoFFNABAIGiBUNAIBAkDQCBogRTQCIaKEQ0CQNFCIaAQCoFA0AgEAgEDQNAIHhA8IBAIBUCgEU0DQCAQNQCoEAg
aB4UCVAgFFCBoBRTQARUgFBMBRUgFmWoWsbvWZlpkxRkrnMtxDttC6RqtRVuyMxUcRHXz49n9kdrj/euF7ejtEREbl2OrdU0dqoPya0tiGmjBZNURne48w08yebufALn
HVqK+cvLZZeQXWISZYj3ErpEOcypcVqGVZKrO0cqoFQIGoAIqYUVJQMNyUGzpYurZ+0eK42nbrWNMkBZbWNCirGNJIaBkncFJkddb4RT07IhxG8ntK8d7c07eusajTaQ
hcZdIZbFmWlwKyqxpUVewqC9iyrYwMpaajkuVznbT0MQy57jjP8Az8eS9GDBz9bdnnzZuX4a93nequkOpry6js5fQ0A9UOG6SQd5+aO4b+0r6PJ015PJE6nc9ZeezTl7
i4nJPEnmtxVmb7Y7pT2rcVZmysyZ5q6Z2Rero2UVRNBMyeCV8crDlr2OLXA9xCvLs5tPSdL9Iomcyg1PIDnDY7iBvb3SgcR+0N455Xlz8LXJG47uuLPNJ+TvZgWnBIOQ
CC05BB4EHmD2r5FqzWdS+nW0WjcMZ5RpQ4rUMqiVUQcVRWSiIlxVGZZZmR3alc/2S/Zd4EYP2rpimItG3LJG6zp1LoAyCIBwIaXMyDkbis58etfqYr73+jRaudPHpysh
p2OkmljZEGM3uwXZccceAXXDWYnc+jOW0T0j1ePukLuK9UQ4TKpzitRCbQe/aHrHJ7VYhmZYFdD1sRA9obwutZ1LnaNtG7sXohwQIVREoEqiJVAiGFFSCCQUVJp3qKyo
XlpWJhuJehaE1mLYx1ouzPSbLPlr43ja6oHiQObTzb7xvXC9POHSJ2wukTRTbLsXa0u9JsdVh0UjTtdSTwaTzaeR9x3rWO/lLNo284mjIyvREuUwxHtXSJc5hWQtMokK
oigRCqEgEAgFUCihBEoEgEAgSBoAoBAIGgEAgEQIGihAIGiBUNAIEgaAQCAQNAIGEQIGEUwiBAIBAIGgEDQCAQCoFAKhoDKgaBoGqBQCACBoBUCigIGgEDCAwoGgEAga
oEAgSinhA0AgFFJBIKKkFFWAZUldJtGVmZahkRsyVzmW4h1mjdN1WobnHR042WD1ppSMiNnb48gOZXnvZ3rGusu/1jf6Sy28aU04eqhiBZUzNO8nm0HmT84+4LlEbbiP
OXl80udy6xDM2YcjsrpEOcyocVtlWSqygVpAgEDQCgkAopgIqQCgy6OEuO2RuHBYtbybrDYtC5OiwBRpY0blBsrRBtzmVw3M4eK5ZbajTrjjc7dJEMryy7wzohgLEtwy
GLLS5qgsaoq5hUlWyt0Ucr3yTvEdNC0vleTgNaFvFj57deznlyclend5TrrVr9RV+zATHbIDs08XDP7ZHaeXYF9atXzplxr3Heummdq9sq6ZmUS7PNa0my34ymjbZx6e
1BLSirislwfTkZEjadxBHapzR6jSyPLXFpBDgcEEYIPYtIpdJ3q6Tb0To21S9ssOnLhNmB52aGR5/RPP8mT9F3LsPcV5OL4bxK81e8PRw+fktqe0vSH9hyD2FfGfVUvW
oRS4qoqJWkQKIQ3oNBrm5Otem9iCR0dRcJzBttOCImtDngHlkuaPDK+jwGOJmbS8PG3mNVc1pG7Xmg0ZqiejldDHF1ToJJDgB5OH7Gd21s44c8L0cRWtstIlxwWtXHaY
cJ8oVxqW1XXyekteHtmLyXhwOQc8cr1csa083NO9u39KbXNFaCSJ8vJIwc537vHK+fy8s8r3RaLRuFT1UUuWkQcMqo1Vwg2Xda3gePiu1J8nG8ebXkLo5lhURIVCIRCA
QPCBoGEEgoqxpWViWRFJg8ViYbiXo3R/quGka6w3sNmstWCxzZN4hJ4n6p59nELhennDpE7aDpD0fLpq44iLpbbUZdTTHfu+gT2j4jBXTHfbNquCmjwSvRWXGYYzgujn
MKyFURVQkCVQIEgSAQCBIBAkAgMIBAIBA0AgEAgaqDCAUAgEDVDCBoEgEAgaBIBA0DQCIEAgaBoBAIGgRQCBoGgEDQCAwgEAgYVDQCAUDQCBqgUU0CQMIJIDCAQNAkDQ
CAUUIBA0AgFFGEDAUUwEVNoWZVa1qzMtQujasTLUQ29ot1RX1cNJSxGWeZwYxg5krje2natXrl4qafQWnWWC1yNdd6pu3VVDeLMjiOzsb2DfzXnnrLrWN9fJ5ZNMXZyV
0rVLWYUjsrrEOUyocVqGVRO5aRAqoSqDCBhA8KCQCimAipAb1BdDEZHhoHFSZ1DURttWRhjQ1o3BcJnbrEaWAKKsaFFWMYXEAcSkysQ6WhgEMLWc+J8V5L23O3orGobC
IYXOW4ZsW9YluG5FuIpGzvOyANpy48076N9GATv3cFtFrCki9mFlWi6VLq61aforBTP2aivHX1RHHqxwb7z9i+pw2LVYl87Nk5ry8cEjsgbyTyC9enDb1Ch0bp6z26Cs
1xdzSVE7dplFE7DmjvwCSe3G4dq5c8zOqrpg3LSumLtBNNoy+OnqoWGR1vqSQ+RoGTsZAJOOW9WLWjvCaeeOwBucu2mHT6LrLRaTVX+8Qsq3UhayjoiR+emdk7RH0WgZ
z2kc1Jjyghs6zpX1bPUGWKelp2Z3RMgDgB2ZdklZnFE92t6YmpLvaNW2Oa7VLKa36koy0SNYdllfGd2Wj6bePhz7LSs0nXkkztwDyOS7RDG1YcQchxBHAg7x3q6Tb3/T
N5+XtP0lykcDUkGKpx+tbgE/vAh3vK+FxmLw8vTtL6/C5OfHr0bB5Xmh6JUlaQ4YzLK1gIGThJnSMipt8sTXOONkc1ItC6ap7scFtlxPSix8lgtswziCuew+D4xj4sK+
l7PnrMPBx1e0t9depuPQtRVMjXO6q2wPbsnGy+N+xnw45W+teKc468PLxVzmA/NJXveN3ljppJNNUkhj2S3aLcc27R3r52W382X0MVf5UIORFbgtQiBVRXIwPaWuGQVq
J0zMbaOeIxyFh5LvE7hxmNKiFWSwqEQqhYQGEAgYCipYQMKCxpU01DJhkLSFiYaiXrGirnR6qscui74/L9jNFOd7mkcAO9vEdoyF57xNZ3DrHV5VqKz1VnuVRb6xmzPA
7ZOODhycO4jeF6KW25Wq5+RmCu8S4zClwWmECFpEUEVUCBIEgEDQJAuaARCRQgEDQCAVDUAgEQKhoBAkAoBUNQNUCAQCBoBAIBENAIBAIGgYQNAKgQCgEDQJA0DCBqgU
AqAKA5qhoBAIGgYUDVDUAijCBhA8IDCIEUKAQCoMKB4RRhAIBRTQGEDCBgKKkAosJtCzLUL2NysTLcQzKeIuI3LlazpWHsWg6Cl0vpyfV9yjBqJmFlHE7iQeGO9x/ojv
XmtbcuutzpwN3rpq+rnrKqQyTzOL3uPM/grWG7THZp5OJXWHKZYznb8Z3rcMSqcVqEQKrJEKhYRDwgYCKkAoGAiphqiphqm102VLDsMyfaK42tuXWsaZQasNJhqKmGqb
NNhbYduXrCNzPtXPJbUadKRuW8iXnl3ZcYWJWGbDJ1bmvAacHOCMhZmNtRLOnudTURmJ5aGHiGhYisQrHacqi1pUVlUbDNUwxDi97W+ZSI3MQWnUTLx/pCvBumsrtPtZ
iimNPF3MZ6o+IJ96+7Suqw+NMtZp64UNuvdDcK2mdUwU0olMLSBtkDLRv5Zx5LU13Gk2xr3dqu83WpudbK6Sed5ccn2RyaO4DclaajULNmJHUSxSMlikdHIw7TXscQWn
tB5LWmdq3PJJJOSrpNo7aaCL1dG1TnppFTnLSIFyqPS+h+uJku9scfVcyOpYOwg7Dvg4eS+b7Sp8MWe7gLfHNXpLwvkw+mpduWoSVW2WPDgd4OVdbRsaq7NdHsRMySN5
cucY+rXM07Wy1FRHDE3akkcGtA5krtEb6Q5zOustT0n2eb8mKYW+40c9P6UHVRLsbbgC1gYd+0AdvIG/yX0+DrFLzvu+dxNpvEei/R94tNr0zSWOplmuDqdsoeaaie9h
Y95djB5DJG8b1eIxWvfmjomC8Urru8zv1kskl0LrFcJKeidsDqamF5e0/OO1vHeAvVWbxX4u7z2is26dneUVJDQ0UNHDnqom7Ddo5JHevkzabWm0vpxWK1isNBcIOoqH
NHsneF6KTuHG0alhFbhlAhVlAhUYldT9YzaaPWb8QulLac7V21JauzkjhEGECwqFhAYQW08Mk8rIYmF8r3BrGN4uJ3ABSZiI3KxEzOoegXPo2q47fTy2+oEta2MdfA84
Dn89h3wwezivmU9pVm8xaOnlL334G0Viaz1cDVU1RR1D6aqhkhmYcOjkbghfSraLRus7h4LVms6lAFUWNKzKwz6Golp5454JHRyxuD2Pad7XDeCudodKy9R1ZTQ640ZF
qWjjaLtb27FZEwb3NG8+XtDuJHJcaTyzpqYeKTx7zheysuFoYT2rpDnMKnBaZQIVRFUJEJAkAiBFJAIBAIBAkDQCAQCBoGiEqGgECUUIBENAKgQCBoBA0AgEQIGgYQNA
IBA1QKAVDUAqBQCBhAIHlAlQ0AgkAgEAgEAgagaBoBA8IpoGgEAgFAYRQgaBoEgFFCBoBFMBQSAQSAWWoWNG9ZlpkxNXOW4h1+hrE6/X6modk9RnrJ3DlGOPnw968+Sz
vXpG3V9Jl7ZW3RtspCG0VvHVNa32S/gSO4Y2R4Fco6ulY1Dz6Uk5XWGJYzicrpDEvSdFT224WCWilhgbNEwxz4YA5zDweT4c+0L5XFVvTLzRPSX0eGtS+Plnu8wrYW09
XNTsmZM2N5aJGHLXgHiCvr0nmiJfMvGpmGOtMGqDCgeEDARdJBqm1SDVNmljWqbXTKpYdt+0RuCxa2m6xtsg1cduulgam10m1qgsDM4GFNq3dLEIoms58T4rz2ncu1Y1
DNjCxLbKYsysLWqNLGlQWtKyq5mVJabSzEC5Uzj81215Alaxffhzzf6cvmuqmMtTPKTkvke4nxcSvvxHR8eZ6qdta0g20QbSA2kCLlRAuV0iBciKy5URyiOz6KXubq3Z
B3PpJQfgfuXh9of6P6w9fBf6v6S9neviPsMd61DMqHArbKshVGJfbo3Tunqq7tIFbLmloQf1jh6z/wB1uT4kL28Hi5rbl4+Ly8teWHlFDV0tLp50VRcw0mrdIyl9Z7sb
ABdgDAye078L6cx8XSHz4np1ZmnekAWA1ApqV03XFu1t+rjZzjge9cs3Dxl1uXXFn8PtDUzXqCsnllEUgfK8uLQBuJOdy7xXUacptudvQrHUzV9rjnlhkieCWESNIJxz
39q+TmrFbzEPpYbTakTJXSn6yEuHtM3+5Sk6lbxtoXBehxVkKoRCIiQqjV1sGxJtNHquXattw5WjUsMtW2dIkJtBhUGyER0dv0XqGvYySO3OZE8BzZJXta0g8DxXlvxm
KnSZeinDZLdYh6Fo7REVjl9PrpI6ivG6PY9iLtxni7v5cl83iuMnLHLXpD38PwsY55rdZdRdLhS2u3z11Y7Zhhbk9p7AO8ncvHjxzktFK95em94pWbS+eLrWz3O41Nwq
TmWd5cRn2RyA7gMBfpsdIpWKx5Pg3vN7TafNihaZWNKiwvjdhZmG4d10bah+RL9GJ3D0GrxDUNPAA+y73E+RK4ZK+bpE76NX0laa/J7UM8ELMUU+ZqY8g0ne3907vDC3
ivuGLQ4KVq9MS4zDHcFtiVZC0iBRCVCRAgEQlQlFNBFA0AgEAgECQNABA8qoFAKgUAihA1UJA0AgEDQNAIBAIgQNA0DQCoagEAgEAgAgaAQNAIBAwgaoAgYQNAKAVAoB
FMIGge9AIGEDUAihVAimgFAIGgEAooQCBqKYCCQUVMLMtQsYN6zLUM6nZkjcuNpdaw9j0hH+S2gq3UDwBW1/qU2eON4b8cu9wXlvO5d4jc6eazOJcS4kk7yTzWqwtpYj
3LrEOUyoccrUMyiHvZthj3ND2lrgDjaHYe0K6iWdyoK0iOFQwEEgEDAUEw1RYhINU21pMNU2qyNhc4NaN5UmdLENtDDsMDQFwm23aI0vaxTarAxTZpIMU2umdQQ7T9tw
3N+1Yvbo1WOraNauLqvYFmVXsUlqFrVlU2qC1qir2LMtM23vEdbTvd7IkAPgTg/arSdWiWbxusw+c7nA6kuFZSPGHwTyRkeDiF+ir2fElh5WkLaVQbSaBtJo2iXK6TaJ
ciIFyoiSgSI73oipnSaiqqnHqwUrhnvc4AfYV8/2lbWOI9Ze7gI3kmfSHsD18V9ZQ5aRS5VlOmhkqaiKnibmSRwa1brEzOoZtMRG5eR9Kd+iu2ofQ6CXattsaaaAg7pH
Z/OSe93wAX3eHxxjpp8XLeb23Lh3ZeMEr0OTbaOspueoKdrwH00OZZg9uQWjkfEkBefisnh45nzl24enPkiHr9NR0lGMUtJBD/5cYC+PN7W7zt9WKVjtC6RxcN5ykDDl
bnIW4ZlzlZAYZnNxuO8L0VncOExpilq2yjhERIyqiqaISRlh9y1E6SY20z2Fri1w3hdtuOkCFQYVQtlB6r0bX6n+SJbdX1UcRo/WjfK8NBjJ4ZPYfgQvj8dw888XrHd9
Lg88cnLaezc3LXOn6FrhFUurJB8ynbkfxHcuWPgct+8a/N1vxeOvbq8v1Zqas1DUN2x1NHGcxU7XZAP0nHmfsX1eH4auGOnf1fOz8RbLPXs5sr0vOSok1RYXMWWmXC7B
HYsTDdZeq3Np1l0Ytq/0l0spw/tewDf5twfFpXCvw203LxOoZhxXrrLz2hhPG9dYc5UuWmUCqhIEqhIEgEAgECVQKARQgECygaAQCARDVAgEDQCAwoBUNAIBAIGgEAga
IEAEEggEAqBQNAKgQCgeEAgEDQCoaBhA8IBAKBoBUCBqBIphA0DQMIBA1AIoQNAIDCBoBA8IHhRQgFFGEU1BIKKsAWZahcwbwsS1DoNO0D7jcqWhjHr1EjYx3ZPHyXny
T0eikeb03pTrIopqGxUvq09DCDsjtIwPJo+K8/m607beYzHeu1WLMV5XSGJVErTEoFVESFULCB4RTAUEgFNrpY1qkyukw1TbSwN3KbNNhQQbI6xw3nguV7eTpSvmz2tX
PbppNrFNrpY1qbVMMzyU2abWnjEcYbz5rjady6xGmS0LKrWhRVoGFlVgUVNqirWqKvYVmRc3eMKLDyDpTtzqTVMla1mIbiwVAI4bfsyD+IZ/eX3uEyRkxRL4/EU5LzDi
iV6XBElVCyiFlUIlERJVESUAgAg9r6KrW6h066tlbiWvf1gz+rG5vnvPvXwfaGXny8seT7PA4uXHzT5u0evC9aly0iotyqjV6tup05peeqifs3K4h1LR44sZj85J7huH
eV9DgsPNPNLwcZl18EPAnDZGBwC+w+Yr3qo9a6PbWaKyCrlbietIk38QweyPtPvXxuNy8+TljtD63CY+WnNPm6dwXlh6ZUuWoZUSLcMy1lyh6yLaA9Zv2LpS3VztDSuC
7OSJCqaRIV2iBCowqyDa/OAbxxW6z5MWhgOYum3NAtVQsKhYRASqIFVECgWEQwFFWNUVkR7lmWoej9Ed0bS6gdbp8GmuMZic08C4AkeYyPeuGSPN1jrDg9YWl1mv1wtp
BxBM5rO9nFp8iF2xzuHO8OXlGF6IcJY7gtsIFVESgSqBAkCQCARCQCKSBoEgEDVQYQGFFCAVQIGgaAUDVAgEAiBAIBA0UIgygEEggaAQCBoBAIHhABUPCgSoaAQNAIJB
AIDCgEDVDwgMIBQPCAwimgEDQCBqKEDwgEDQPCAwooQNUNQCimgFFCCQCjS1oWZWGRGN4XOW4en9DVtFTqY1bx+booXSZPJx9UfaV5rzt37VazVFb8o3qurc5Eszi36o
3D4ALlV2mNRpzsu9doc5YzgtwwrIVZRIVQsK7AGps0eyoaSDVNqm1im10sa1TbWlrWZWdrpkU8HWPAxu5rNrahqI22jI8bgFxmXWIXtYptrSxsamzSwMU2aZFLDtSbRG
4LNp6NRDYNauTota1BbG0kgAKDdUFoklc2SoaY4hvweLvwXK99dm4qV0txpnmWFpMJ/od3gpW21mNNe1bRNvFRVzVFXxrMrDS63sTr7YXwwM2qynd11P3uxgt/eG7xAX
p4TP4V+vaXn4nD4leneHgsgLXFrgQQcEEYIPYvvQ+PKolaZJEIlULKBFAkAg6HRun5tRXdtNhzaSLD6mQfNZ2DvPAe88l5eK4iMNN+fk78PhnLfXl5voJkbIo2RRMDI2
NDWtbwaAMAL85MzM7l96I1GoItyqKzGVUSipHSYe9zYqfaDXzyENY3JxxPPuXXHjtedRDlky1pHWXhOvdTO1HqGaqhDm0EA9Ho4z82JvA+Ljlx8V+hxY4pWIh8TJebW3
Lly48V1c2001a/lm9U9EQepJ25iOTBx8+HvXHPl8LHNnTDj8S8Ve47LGtDWtDWgAADgByC+B3fb7K3BahJUPC1CKHhahlQ8ZBC1DMtFUwmOUtxu5LtWdw5TDHLe5b2zp
EtVTSBaiaVubxBWk0108Ww8jkukTtzmGO5q1tnSJCu00gQrtNIEKoiQqI7KIMILIIZZ5WxQxvkkecNYwZJPgpMxEblYiZnULqqjqqKd1PV08kEzeLHtwVmtotG6y1NZr
OpDEkhsrXVSUVZBVxHEkEjZG+IOVztG4dKu26a6KOSttl9gA6qvpgCRzc3eP6Lh5LOG3kloePTt3leurhLEcusOcoFGUCqIqoaBIEgOaAQCqEgFFCAQCARDQCAVAgFAI
GqGgEAgSAQCIaARTQCIEAgkEDQCAQCBoGgEDQNAlQIGgEDQSCAQCgFQIJIBABQNAIpoBAKBoowgaAQPCBoBA0AopoAIpqBoowoAKKm0KSq1gWZahlwNy4LlaXSsPZujG
M0Gjr/dAMPfmNp+qz8XLx5LPRWNzEOHqack4zwWa2drQwZKQ/SC6xZymrGkpZAMgZ8FuLQxNZYzmdo3rcSzMKy1XbJbJTZow1NmkwxTasilpKiqmbDTQSTSHg1jclZte
KxuZarWbTqIdBV6SudFan3GpEbdgjaiB2nAHmSNy81eKpe/LDvbBateaWj6ojku+3LSbWKbXTbUsGxGN288Vxtbcuta6ZTY1jbelrWKbNLAzuTa6SDFNrpsIYthgHPmu
UztuIXBqm10tDVNmk2jB3Js06O23NjoiyqeA5g3PPzh+K4Xp16OkSxLncTU/mocth59rv7lqtdMzO2tAWhY0Iq5gUVexZlYZDVlXnvSBoaS4ySXmyxg1Z31FMN3XftN/
a7Rz8V9Lg+N5f5eTt5S8PFcLzfHTu8hfG9jnNe1zXNOC1wwQewjkvsRO+z5cwqKqIlVAgEBhEbnTWnblqKtFNQx4jaR11Q8epEO88z2DiVwz8RTDXdnbDgvltqr3/T1j
oLDbY6ChYdkes+R3tSv5ud3/AGcF+czZ7Zr81n3cOGuKvLVsXNwuTqQh/MvqZZIqekZ7dRO8Mjb7zx9y74sN8n3YcMmamP7zkb30hadtYMdpideasfysmY6Zp7vnP+AX
0sXs+I63eDJxtp6V6PLdT6tvuo3j5UrnPp2O2o6aMbEMZ5YaOfeclfRpjrSOjw2tM93Mk711YRO9EeqdHdoNDanV8rMT1mHDPFsY9nz4+S+RxuXmvyx2h9Tg8fLTmnvL
sw0leF7EZGuA3hWJNMdy1DKl60jHeFqGWFXQ7bNscWrdZYtDWFi6uaBaqistV2IFqu00onh2mHA3hWsszDXPYuu3PSotV2iJCu00rLVURLVdposKoWEHSaMu1DZauoqK
yOZzpGBjDG0HZGck7z4LycXitlrEVenhslcdpmzB1DeKi83F9RKSIW5bDH9BmftPErrhxRipqGMuWclty17MrpLnDNp2OJHqkrnaXSsPStRN+U+h+31DxmW3VDYyeYGS
37C1ccc/G1eHidSMEr3VeazBdxXWHKVZVRAqoSqBAkCQCIEAqEoGgEUkAiGqGoEgFQZQCBKBhUSQJAIBABA0AgEAiBA0DCBhA0AgEAgaBoBAwgaoEAgaAQNAwgYQCAQC
AQNAKBoGEU0AoBFNA8IBAIHhA8Ip4UAgEAgAoqSAUUIJAKKm0LMtLWDesy1DNpx6wXKzrV7bp0CDoncRuM0rs++QD7l4csvTjj+ZDi6obzuWKu1mA9q6xLlKGwrtNMOv
jaA14G8nC6Uli0MAtXTbnobKbNGGptdJtaps06LR9xZarsySY4gmHVyHsB4H3FeTisfiU6d4ejh78luvm9XmEc0L4XtD45Glrm8iCvjxaYncPpzETHV57cdH19PM40TT
U05OW4I22jsI5+K+nj4uto+LpLw34eYn4Wr+S6inkHpNPJFjgHtxldfFiY6Sx4cx3ZbY1iZaiFrY1NrpY1im10nsKbXS+ni2nZPAKTKxDNDFzbTDFNiQYmxNowmzSYCg
A1BINRVjQoq1oUFrFlqF7AsqyGqDnNUaPtGogZZ4zT1uN1VCAHH6w4OHjv716cHGZMPSOsejhl4amXrPd5beOjbUdC5zqWOO4wDg6A4fjvYd/llfVxe0MV/vdJfOycFk
r26uSrbdXURLayjqKcjj1sTm/aF7K3rb7s7eW1LV7wwj4hbYQEse0G7YLicADeSqPQdOaNtj44q3Ut3io4SR/i211bjngHPO4eA3968XE581OmOm/m9fD4MduuS2vk9X
NfpbTtHHRuuVst8DBlsLJQ52/nstyST2lfKjhs+a3NaOvzfQnPhxRqrnLn0nafpNptsoay5SDg+X/F4s+G9xHkvVj9mR3vLz34+0/dhq67pbnkjcKCwUUE3BskjnSBu7
edjgTnPH4rvXgccW3pxni8kxrbz++367Xyo9IutwmqnD2Wvd6jO5rRuHuC9laxXs802me7UGQ9q3pjaBdlXSIEKo22mbSbzeKei39UTtTOHzWDj58PeuWfJ4dJs64cfi
Xir3ERtY1rWNDWtAAA5AcAvgTO5faiFkGOtAe7ZaeJUnssMy41VK+Hq4mhzhuBxwWK1ne5amYaZwwuzmoeN6sIqLVUVvaCCDwK0kw1U0Ow8t5cl1iducwoLFrbOkCxXZ
pAsV2itzUiUa+qhw7IG4rrWXO0MQsWts6RLFdogWK7RAtV2mkS1XaaLZTZowEEms2nADiVNrpsIoGM5ZPauc2dIhlRjesS1DvrGBW9Guq6E7zEzrmjs3A/8AtXKOl2r+
TxKqHrFfQo8lmA/iu0OMqnKogVUCqEgECKBIBECoEAgFFCIEAqGgSAUAihEJA0DQCAQCoEAgaAQCBoBEAQNA0AgEDQCBoGEDVAgEDQNA0DQAQNAIBAIBQNAIGEU0AgEE
goGimgaAQCBqKaAQCACBgKKEU1AYQSCjULGrMqtYN6xLUM2mHrBcrO1Xt9sAPRRRgfrN/wDOFeHK9OL77i6hu8rFXazEe1dIlzlU5u5aZYdc3823xW6yxZg7C3tnR7Cb
NGI02aWNYptdLWx5Wdrp1mntQz2+NtPUtdPTjc3f6zB3HmO5ePNw1bzuOkvVjzTWNS66C/WypaOrqmtcfmyeqQvHbBevk9NclZ83N3eqfW1hdn80z1WDu7V6cdeWunG8
80sRrFvbOljY1NrpYI1NmkxGm1ZsMWywDG9c5nq1ELgxTa6SDE2qQYiGGqbUw1NokGptUg1TZpINU2uljQptdLmNUVc0KC1oWVSwEVRdqqC1W2W5VzjHTxjI3es85wA0
HiSfcu+Lh75JiIhwyZ6Y4nbzTUmo6O72GNl2kmpaK4BzBFGS/Z2XZ3kDjuBzhfc4fhaYY6dZ9Xys3E2y9+zzK46bhZCau3XOjrKTaDSTII3sJ4bTT9oXqebTLpXWjTEg
LWsuN0Ay57XDqoSeTTzPeiNzqaq9OsFql2MPqnCTZByB6pSIWZcxUUPo/Vy7vW3O2e3kiKy7ciqyUTaJcroQKIjneqO301oO4XNrKq47VDRneAR+dkHc08B3nyXhz8dS
nSnWXrw8Ha/W3SHpdttFBaaf0e30zYmfOPFzz2uPEr5V818k7tL6VMVaRqsMohZ20rIQRwqEYyQm0Y72LUIqIWkQLURiVcWW7QG8LdZZmGCWdy3tnSBYrtEDGVdog6I4
BIIBGRkcVYlJhjzQ7TS1aiyTDXPiwSCF0iXOYVGNaiWdIFiu00rc1XaaVlqu00js702aGyhpkUrPXJPJZtLUQzWhYaWxhZlqHoGgB1to1PTYyH0JOP3XBc/6mr9niFSN
w8B9i99Hku18nErtDjKl3FaZRKqEqgQJECBIBAlQIBAIEopqoEAoBFCIFQkAopohoBUJQNAIGGPdvDHEdwKCYhlPCJ/8JQHUzcoZP4SgmKapJ3U8p/dKCogjceKoEAiG
geUAgEAgaBhAwgaBqgQACCQQNAIGgEAoBUCgYQMBAIGihA0AgYUDRUkDCARQoGgEAgEUwFA0AooQMKKkFFTaoq5ixLUM2nOHBcrO1XtWlSajoumYN5hnd7vXB+9eHNHS
Xpxf6kOYqWYK41l6LQwXt4rrEucwqLVrbLErm+o3xW6yxaGDsLe2dJhibNJhncptrSbY1nZpc1im10tY0rO2tM+ihyesI8FzvbybrDYtZlc9uml7WDsU2ulgZ3KbNJhn
cptdLYIsu38ApMrEMwMXPbSYZ3JsMM7k2qQYpsPZQGyqHsqCQCipNaoJhqirWhBexuVBXc7habNSR1d3r20zJNrqo2tL5Zccdlo+0r1YeFnJHNPSHny8RFJ1EdXnd76U
ZwXQ6ftzKRvD0mqxLKe8N9lvxX0cXCUp108OTiL283ITVVfdWGruFZNUzzu23STPLiQNwHcM5OAvVWIiXGZnl0lqi1FnR7ZK9r3B4r54H9g3EjC6Vnq5WjowdM9HmpNR
0xqaWFsEIIDJarLQ/txuytTeISKTLZah6MdRWVolp4vTafAy6MAOaee5SLxJNJhutSW11DpjRtBVQmKrgoXySMcMOaXOwAfckT3JcBcp374Opc1ufaeMZ8FrTO2tcqKy
d6qETk4Cg3Fg07db9NsW+mJiBw+d/qxs8XdvcN645uIx4Y3aXXFgvln4Yes6Z0Ra7IW1EoFbXt39dI31WH9hvLxO9fGz8bky9I6Q+rh4SmPrPWXTuHE815YelU8LSKXB
VFZCqI4VQigqc1ahFLmK7RHZVFbmAggqxKaa+SPZJatxLEwqLFrbOm007RUdXX9VWFx9XLGcA8jiCuWa9q13V0x1ibal0t/tEdyo2sha2OeEfmcDAx9HwXkw5ppbr2d8
mKLR0cBPRzQPMc8bo3ji1wwV9GLxPWHkmsx3YFVAPaHvXStnO0MJ8a6RLGlLmK7TStzFraTCssV2zpAsTYNhVF9M3e5ZtLVWSAsbaXRhZlqHf9Hx6uh1JJybQH7HLnv4
lv2h4ZUncPqhfQo8l2A/iu0OMqitMoqoFUJAkQKhKARSVQIBAKBKhoBAKAVAoEgSoagaAVAgEDQIqDorHIDQhud7XkfeitkHE8yoDZQI+rvQcrWgNq5m9jyqihUNAb0D
QNEBOEAMHgcoLmU879zIJXfVYT9ym1V8DgjeFUMIJBAKgQNA0DQCBogUUIBUCCQUDQCBooQCBhA1A0UwgaihA0DQPCAQCimEAgFFCBhRTCirGqSq1izLUMyDGQuVnWr2
XoplFXp++2knLsdY0eLSPtaF48kdJh3idWrLT1TCvHWXutDAexdolylU5q1EssOtZlrfFbrLNoYojWtsaTEfcptdJiNTa6WNjU2uljY1NrEMiKEucGgcVmZaiG3hhDWh
oHBcZl1iGQ1iztdLGsU2ulrY1NqmI1NmmVFFstHaszLUQua1ZXSWwmzR7KA2VAbKoeygNlQPZ7kHF6r1pDay6lthjqKsHDpDvji/tHu4Be/h+Cm/xX6Q8ebi4rPLTrLI
6O7/AF99bWw3DZkfThrmzNaG5DiRggbs7ljjOHpi1NfNrhc9sm4t5O5DF4HsSAcMBoyTuA70PzeP9KF7FbqmejidmC3tbSsI4Eje8/xE+S/RYactIh8PJfmtMuFkdtZX
fTltuLdVTTNa18DBGxoaHjdw7uanKvM9c6MDR3Kx19praaOeOGpEzWvaDjabxHYcjipadSsRt6Q9phpgykhjywERxk7LScHAJ5DvWO7SxxHVDbaMlvrNG8ZxvHeg8I6T
KqSs1dURtPqU0ccAHZgZPxcu1Ozlfu4e7ydRRODiNp52WgrcMy0VRT1cFPFVT0s0dPK4tjkewta8jiATx4qxaJnSTExGxb6SpuVXFR0EDp6qU4ZG3id2TxWb3rSvNaei
1rNp1Xu9S0v0ZQU2xVagkbUy8fRYj+bH1ncXeAwF8niPaMz8OLp830sPAxHXJ9Ho8cUUMTIYYmRRMGGxsaGtaO4BfMmZmdy+hEREahFzVRW4Kil7VUVFqqIFqqIFqofU
vMZk2TsA4JTZpS5qu0Vlqu0QLVdppAtV2jHqIs4dhaiWZhiub3LW2dINMjJGyRuLXtOQRxBVnUxqR2lqvVNUsayocIajGCHbmuPaD9y8N8M16x2emuWJ7tpOxkwAkiZI
3ltNBXKJmHXUS88v74amvkFPFHHAz1G7DQNrtK+jhia1693iyTEz0c7LCWuIK9MS4TCh0a1tNKXRrUSzpW5iu00gWK7TSOwrs0vp2b3LFpWsMgMWdtrmN7lJIdxpceja
M1ZWk4xSlgP7h/FYr1suTtDwyq4+Awvo0eGzBfxXWHOVRWmSVQlUJECoECQCCKgFQIBAKAQCAQCAVAVAkUIDKIaKEQ0BhUQc4Ddkeait3pwbTJ2ZBwQ5BvA1w5E+5QWN
Y88GO8kA6nmO7YTZprZ9MXOtqnz04gEZwMvkxvx2LM3iGorMro9F15/SVdMzw2nKeJB4csqPRJ/lLkP3IfxKeL8l8P5sqPRNCP0lbUu8A1qniyvhwyotIWdvtCok+tLj
7As+JZfDhlxaasjD/mDHfXc4/epN7LFKsyO0WuP9HbqUf7MH7VOafVeWGXHTQR/o4ImfVYB9ym5XUL4wdoAk4yptXjVdGI62pj+jK8f0ivZHZ5Z7qAqiQQNQCoEDCBoG
EQ0UIEgeFABBJAIDCBoBFNAIJKKEEkAopoGEDQMKBopIBAKBooQMKKYUVMKKtYsy1DJhO8LnLcPS+iOvbSanjge7DKuJ0W/6Q9YfZ8V57x1du9W81DSeiXOqgxhrXkt8
DvH2r50xy2mH0KzzUiWhkatxLMwx3NW4ZUVDctAIHHitQzLG2MLW2dLGx9yzMrpYI1NtaTbEmzSxsam1bGjp8DbI3nguV7OlYZ7I1z23pa2NTa6WtjU2aWNYptV0UeXc
NwUmV0yhGs7VMRhNosZGCptUHMwcII7KqDZQGygeFBz2rLnDFSSWinbPUXOsjLIqemOJAD84n5o+1erhsczPiT0iPOXDPeIjkjrM+jgbb0f36rqjFWxNoYGHDpXuDs/U
AO/7F9DJx2KsbrO3hpwl5nU9HqlgstDY6P0Sgi2Wk5e9290ju0n/AJwvk5s1stt2fSxYq441DbtXF1QrKyO2W+tusuNiigfNv5uAw0e9xC9PC4+fJHyefib8mP8AN8yz
SySSvmmcXSSOLnuPNxOSfMr9BEPjTKG0qjeUM4mgbvALfVICqO+6K7i2k1QylccMrI3RfvD1m/YR71m8dGqy9rfv2T+0FzbNrMnLj6o3k9yD5qvVY+ruVbWnjPO+QeBc
cfDC7xDjM9WHatYNsL6jqLNR1lYXANqKr1hEMcGtxxzxOVi+Ln826ZOXyYWpNZXzUlMKW5zwmmDw8QxQta0EcDnefirjw1p1hL5LW7sjopp2v1tTOAyI4Jn/ANHH3rze
0J1gn9Hfgo3mh7zhfnn20XBahFZCqIFhKonLRytiEmMnm0cQEiUYRatIgWKjJoqaOaQh7tw37Pas2tpYhtZIGPgdCAA0jA7lzieu2nOSRlri04yDhd4ljSlzVdsoFqux
EsTaaVvZkEHgrEpphviIJBC3EszCvq1raaRLcJtNJMnqI2kRzyMb2NcQFNRPddzHZjOat7Z0xamDLcjiFqJZmGC+PAW9s6Y7mdy3Es6VOYrtnStzFdmkdnertNL4Gbys
zKxDJDFnbWlsbN6kysQ666O+TeiGudwfX1Ajb3guA+xpTFG7sZZ8nhlQckr6NXjsw3LrDlKsqoiVUIqoSBIgVAgaCCBIBA0AgECQNQNAkCVF9HSy1tVFSwBvWynZbtHA
z4rMzpYjbfR6Oujt75aVn75P2BZ8SGuSWTHouo/la+IfVjJU8ReRkR6MhB/OV8h+rGAp4i8jJj0hbW+3LUv/AHwPsCc8ryQyotL2ZnGme/68pKnPJyQymWGzs9m2wH6w
J+0qc0rywy4rbb497KGmb4RN/BTcrqCr4omwMLI2Nw75rQPsWq92bdmsO8rbBYRFjQitpbHANkZ4Fc7t0Zqw2MIJAIHhAAKCYQSARUsY3qDyLUUXU324x9k7j57/AL17
Kfdh5rfelrgqyaoaAQNAIGEEkAgFAYVDUAgaAQNA8IAIpoBQMIphA1FCBoGEDwoGEU0AoBFCAQPCKYCgYUVIKKsYpKwyIyuctw3VmrJKKtp6uJxEkEjZG+IOVxvHR2pL
2zVrYa2loL1Tb4aqIbx4ZH3j3L52aOsWezhp6TSXFzNAKxEu0wxntwF0iWJhjyMyVqJZ0iIu5NppfGwNadyzMtRBtYmzSbY+5Ta6ZMEG28DHiszbSxDaMiwBuXKZdYhc
1iztdLGs7lNqtDERMMRWXFFhoWJlVwYoGGIL2saBnKgqlDSchUV7KoA1EBZhBzVbdayvrH2vToY+VhxUVzxmGm7h9J/cvTXFWlefL28o85/9OFslrTy4/r6NpZbJSWls
joi+armOZ6qU5kmPeeQ7guWXNbJ8ojybx4op+fq2wb2rk6pbKgk1pQ24rpduIotMUtsY7Etxn23j/VR/i4jyX2PZ+PVeb1fM4zJu3L6PD6h2GE53jevpQ8KGVpGTQzdT
MCT6jtzvxRHR0VRNRVcFZAfzsEjZWEdoOUnqr6Up6tlXRw1kJzFMxkrPA4IXB1a7Ud1lt2k6+tqGMiqG0rssY/aa17hsgA895Vr1nSW7bfOFbViKnc76Iw3vPJehxcuT
nJJyTxKqEg9C6Gafb1HWzEfoqIj+J7R9y+b7UnWKI+b3ez43lmfk9pIXwn2EHBUQIVRHgcqjPiqGOADjh3eszCMOqpcZkjOW8T3LUWNMEsWtocZcx4c04ISRkz1kj49l
o2SRvKzFdLMteR3LaKyxVECxXaIFioiWIimaPnhaiUmGM5i1tnSpzFdmkCzuV2mkNjem00g9qu0011RHhx3bl0iWZhiuYtbZ0qcxa2zpWY8q7TSDoyN+Fdml0LfWWZIh
ktaptrS+KNxcA0bzuHisTLdYbrpjqGW+xaf08w+sxhnkHgNkfEuXp4evm8mS25mXicx3le6sPLMsVy3DEoFaZIoIqoSARCVAgaCpAwgaAQCAUAgFQIBRSQZ9kkEV4oJC
cATs+Jx96luyx3etYxu7F53ZEoFhAIHhUAUEkFVRF10RYDg8cqxOpSY3DGbb+2Xyatc6cqQt8f6x3knPJyJihiHFzypzyvJC6GBkJLmbWSMHJUmZlYjS8LKphAwglhAw
FBLCKkAoJYRXluto+r1HVHHttY/zb/cvVin4XmyR8TRBdGDQNAkDQCBhBIIGgEDQCgFQ1AIGgaARQoGimgEU1AwgEUwoJBA0AopoBAYQNRQgeEAipBQTasy0uYVmWoZk
D8ELlaHSsvZOjmuZedO1mnJ3Dr4B1tOT9EnPwd8HLx5abiYeiluW0WYVRT7JcHDDgcEHkvDEvoTDBfHldIlzlWYt61tnSTIVJldJGHHLcps0BHvQRMtPGcS1MEZ/bkaP
vVitp7QbiO8tlQSUkgxDVQSOPJkjSftXO9bR3hus1ntLYtaOBXLbppaGZU2qYYmxYGKbFsceTwSZGS1iwqzZQSDCiJOicG7WENqi1ULYQMNwqjmr5LV3a7N05QzOp4Wx
iavqGe01h4Rt7C5enFFcdPFtG/SP93nvM3t4df1b+hoKWgpI6SjgbDBGMNY0fHvPevNe9r25rT1d61isahkbKjRgIJNagta0kgNGXHcFaxudQzM66vCuli7NuOsKqGJ+
1T29oo48cMt3vP8AET5L9HhpyUiHw8lua0y4Kfex3gu0OaLDljT3KokCqNtbKzLRA8+s32T2jsTQ926L7y2s0y+hkdmWhfsgf6txy37wuV46ulOyrpdr2R6dp6Jpw6qq
QSO1rBn7cJjjqZOzwC6yh8whYctj497v7l2hxa8hUAQes9CUHrXqpxvDYYx5uP3BfH9qz92PzfS9nR1tL1chfIfUQIQQLVURLVRHZVCO0BgE4QVFqbES1VESEEOryVRk
Q0e3hztzftWZsaUVNOI5MA5B3rVZ2kwxyxXaIliuzSt0eRhXaaYj48ErW00rLFdppW5iu00rcxXaaVuZuVRjVUTWR9ZK5kTOTpHBg+K3WZmdQzbUd2nkrLcHbPyhSE9g
mau0Uv6S5TevqnGGSjajc17e1pBHwUnp3WOvZPqRlNmkJ4hgdiRJMIQx+thWZSIZTY94WZlrTpdI20V17pWFuY43da/wb/fhc+8tWnlrMvP+lG8C76uuE0b9qCBwp4j2
hm4n3uyvpYa6q+feXByHJXphwlQ5bYQKqIkqoECKIECKoEAoKwqGgYQCAQCAQCAQCgEDa/qnslHzHB3kQiw9mDg71hwO9ed3CgFQkDUAgAgaBoJAIoUCQSCCQQTCCYUD
CKkAgYCipgKDzjpDj2b1DJj26cfAkL04fuuGXu5YLs5BA0AgaB4UAgaoaISCQUDQNFJA0AgEEkUKARTCBhQPCKeEDwopgIHhQNAIoUDQCARQgaARTCgmFJVY0rMtQyIn
YWJhuJdLpS8vs14pbgzJETvXaPnMO5w8lwvXcOtZer6upWkw3ahcH0lY0PDm8NojOfeN/mvn5aatt7cGTdeWe8OKqDLne4+atdNTtQyolY72todhWuWJZ5phuaF0dRHt
N3EbiOxcbxNZdazEwxL9cqW0U3XVByXbmRt9p57B+K1hx2yTqGMt4xxuXnF0v9xuDiDKYITwiiJA954lfUx4KU+cvnXz2s1AODnGe9dtOW0trfnge0Jo26Cx6putrka3
r3VNPzhmcSMdx4hebNwuPJ5al6MXEXp84et2K6Ud5om1dI84zh8bvajd2H8ea+NlxWx25bPqY8kZI3Dahq5tptYgvjZgKC5rUFgaiJN3HKEpPcSMBE0q2FF2NkIGGZIH
aqS5TRpNVX6kuJ39bcDC0/sxjAHxXq4rpWlfk8/D9bWt83VBq8j0jZQMNVRMBBRcq+O02uuu0mNmigdMB2uAw0fxEL1cJj58n5PNxN+WmvV8uTOlle+WVxdI9xc9x5uJ
yT5r78PkyxZnARuyVqGUNmWKCCR8ZayZpdG4/OaDgke8EJExPYmJhHaJWmTaXBwc1xBByCiPRujO7tpr7CHPDY6ppp5m53Ane0+Y+KzeNw3WdS2vTJc2MusNPG8F1PTh
rW/tv9Y+Qws446Lknq8jzjnnv7V1cyQMKbHtHQrEBY7lKOL6sN8mD8V8T2nO8lY+T6vs+NVmXpOF8x9Ei1BEtVESxEItQQLUESxBAsVESxXYjsFUXxSFjdkjI5LMwKJc
veXEKwSqLFdppWWq7NIFibRRLFzwtRKTDHcxa2mlTmK7QurzxwB2nkrtNOC1HrIRyPpLJsnZ3Oq3DOT+wD/WPuX0MPCbjmyfT/l4c3Fa6Y/q4WpqJ6qUzVM0k0h4ukcX
H4r31rFY1EaeKbTM7lVlaRZBUzU7w+CR8bhzYcJNYmNSRaY7OosuqDLKymuRaCThs4GB+9+K8eXh9Ruj1Ys++lnYtgL2kncAMkrxbevTSVNQ8vIiOyzt5leitY83G1p8
kYpH59p2fFJiEiZeiWqqfpnQFw1BO7/GqodVSA8d+Q0+eXeAWK03YvaezwaqkJJySTzJ5r6FYeS0sB5XWHKVTlplFVCVQkQlQIEUCQCgiqAIGgEAoBUCAQMoIqAQQm/R
P8ElXsNrk6620cv04GH+iF557u8MpQJUGEDQCBE4BJ4DnyQaysv9rpSWvqRI8fMi9c/grFZlOaGJQajZX3CKlipHhkhxtF2SO8gclZpqNpF9zpsrjd6K2uDKiRxkIyGM
G07Hb3LMVmVm0QupLlQ1jg2mqopHkZ2Q71vJSYmFiYlnBmd/JFcjWXW4XStdQ2YubG3jI04Lh2k8gukVisbs5zaZ6Qt9PvtodE66RsmpXHYL24JHvHPx4qctbdl3Md3W
ROZJGyWN20x7Q5pHMFc21gCipBBIBQMBRUwEVw3SRDh1un7Q+P7Cu+Ce7hm8nDLu4hUMIGgaBoBQCqHhFCIaBoBRQgEDCB4RQoBFMIJKKAgkFA0VIIHhRQgaihAIGgEA
gSBqAVUwoJAqKk0qSq5pWZahkxPIIXOYdIl7B0Y3qC42+bSlxfuc0upXHiOZaO8H1h715clN9HWLTExaGDeKSSjrJqSduJIzg9h7CO4rx9p090TFo3DTyMPJdIliYX22
ZlJJNJM7ZiEZc49mN6ZK80REFJ5Z3Lzm9XSa7XGSsmJDTujZyYzkPx719LFjjHXlh8/LknJbmlgkro5IqgQSBUlYb3S97lslyjqmkmE+rNGPns/EcQvNxGGMtNebvhyz
jtt7xAWSxMljcHRvaHNcOYO8FfCmNTqX2N+bIZH2hQXBqCYaiJAIh4VEtlEIhF2Wx3KaNmMN9Y8t6sQlpch0aDb006bnNWTvP8S9XG/6mvlDz8L9z9XXhi8mnp2eyro2
WyhtNrMpEMzLhOl+vFLYKO0MdiSul66X/wAtnAe9x+C+twePkrzer5/EW57a9Hh0/HC+hEvJMMGeCWUbEbSXuIa0dpJwB5rW9M6ei9Ken4rDZ9KQsaPzFO+keRzcMPPx
Ll4+Dy89r/V6OJpy1rp5vlpXveQHKosppJ4ZmyxPLSOwoNhqK4TXm7TXCc+s/HHwAJ+CkdCerVEAKhFwQNo2jgKEPX+hGfZF2txdv9SoaPNrv/avke06bmtn0uBtrdXq
+yQvkvpDZQRLVRHZQLZRS2ECLERWWIIliCOwqAtQQLUECxURLEECzuTYg6PIwrtNMZ8WCQtbRSY+0K7TTgOka9ugYLLSvw+RofUuB3hp4M9/E92F9HgcO/5lv0eHjMuv
5cfq82JX1HzkSgFUCIAAiu807eTPp+ahkfmogLWtJO90Z/Dh5L5+bFrJFo7S92HLunLPeEg1zlNrpuNN2ea8XWnoYwQHuy9w+awcT5LnaWu0bWdL9/hqbpDYKAgUFqb1
eG8DLjB8hu8cr0YadNvPazymZ2SvXEPPMsdxW4c5QK0iJRCVAiEqBBFAigSAQCBoEgEAgEDUCQIoBFQk9goQ9U0nL1unLe47yI9jyJC4W7u0dm3UUKAQSAyg5O46jq+v
fTW+jIka4tJe0udn6o4e9dYpGtyxNvRrK6nvU1HLW3OVzY2DOxI/BO/GA0bh71qJrE6hmYnzbLTFit1bb/TKqEyPMjmtaXENwMch71m9piei1r0bu4vhsttlnhgjY1gw
1jG4DnHgFiI3LU9Ic/pmgdcjPcbozrmyOw3aJG0eZ8OS3a2ukJWN9ZZeo7VR0lKyvoWejyxPbnYJxv4HuIKlLbnUlo11hm3m6POl4p2O2ZKtrWbuWR632fFK1+ItPwr9
LUPodqje5uJaj84493zR5fas5J3LVI1BatkaLHMHYzts2fHa/wD9Snct2ZWli99ho3P+i4Dw2jhZv95a9m3Cw0kEVIBBJRUmqDlekSHas1PLjfHUD4ghd8E/E5Zo+F5s
vQ85qhoGgEDQNEAQNAIGgMIBAKKaBhA0UKARTUDCKlhRTwgkFAwimoHhFGFAYRTAQGEBhAYQCAQRKBhAwgkCo0saVmVhcx2FmYaiWwoKyamqIp4JHRzRuD2Pad7SOBXK
1dulZe1sfDrfT7LpTMa27Urdiohb87nu7jxHvC8WTHM9YenFkik6ntLkZGbPJcIs9VqtBqecw2uRo3GRwZ7jx+xerh43d5s86o4VwXveEsKskqBBIKKviGSsy1D27o4r
TV6bjiecvpXmL93iPgV8TjKcuWZ9X1uGtvHHydewbl5XZYAiJhiuk2bgGNLnENaN5JOAFYjaTKqOpp5J5aaOeN88QBkja4FzAeBI5ZSYmI3KRaJnS8DKKk1oyMq6ZmXJ
1OsDDNLELbE7YeWg9c7fg47F7Iw0mHDmt6tXWavmniki+TIw2RpaSJ3A4IxuONyRw1Ineycttaa6xX6OxUXoVBaGNg2y/D6p7zk4zvI7l1yYYyW5rSxS00jVW2bruYcb
RD/Pu/BZ92oTluf5dSH/AETF/Pu/BPdaHjXI66eP9Exf8Q78E90oeNdS/pBmbuFmiP8AvLvwWo4SiePdoL9erbf65tbc7G90rY2xNDK97WtaOAAwvTWsxGol55nbVvh0
uRv09Of/AKm/+ytxzerM6KlfpykrKeqi03MZIJGysD7m9zdoHIyNnfvVtFrRMTKRqJ3Db6m1DQ6npoKW7WIuihl61nVVzmHawRxDewrniw+HO6y3kyTeNS0TKDR7Rk6d
qz/9Vf8A2V33b1cuWEXU2keWmqn/AO6yf2Vea3qnLCHUaVHDTdT/APdZP7Kbt6moQMOlz/2bqf8A7tJ/ZTdvU1CHoulTx01U/wD3eT+ym7+qagxS6Sz/APlmp/8Au8n9
lN29TULGwaRbw01Uj/6tJ/ZV3b1XUNnZLxZrBXGutdgkZMYzGesuUj2lpweGz3BccuLxI1aW8eSaTuHQ/wCEl542OL/infgvNPAY3o98yF/hIfyscf8AxTvwU9wx+p75
kS/wjPP+g4v+Kd+CvuGP1Pe8g/wiPP8AoSL/AIp34Ke409V97yH/AIQnH/QsX/Eu/BT3GnqvvV0h0gPPCyxf8S78FJ4KnqvvVzbr15/0PF/xDvwU9zp6r7zdIa3kd/oi
L/iHfgs+509Wo4m6xusZHED5KiGT+vd+Ck8JT1WOIu67C+e9xFqgWxlVFcr44gDLIxgJ2QXOAyezfzViJnskzEd2BR3e1V4jNHcKeYylzWBr/WcW+1gHfuW74slPvQzX
JS3aWZ1eeS5ug6vCqKJmDiArEpphy7LQXO9kDJ8FqB8+3atkuFzq655yZpXOHcM7h5YX6PHSKUiseT4OS/PebT5sIrowiqgRAipAKDZ2EllyiA4Py0rlmjdJdcU6vDt4
WjO8L58y90Q7xtRHofR8t2lDW3i4jYpY3cWjG4+72j7gtY680uWS3k8GrJXSSOc55c4kkuPEnmV76w8tp2wHneusOUqitMolVESqiKAVQIBAkESgEAgEAgECQNAkAoBU
JQBQQf7BRYej6Dk29PsZn9HM9vxB+9cb93WvZ0iy0aBIBQJoAJIABPEgYJQaTV5a2yubzkkY345+5bp3Zt2ZOl43QWOjafnNL/MkqW7rXswdcTkUdJAOD5HOPuG77VvG
zdvqOnZTUUEDOEcYHvxv+K5z1lqOznNb1QioYqRpy+Z+0R2Nb/etY467S89GLqCCWn0zbGEHMOA8dhc38dy1Wfilm0dIdlbpY6mhp5YSDGY24I4cFynu6R2clqSd94uE
Fqtx6xrHZc4cHO7fBo5rpWOWNyxM7nUOyooG0lJDSx+xEwMB7cc1xmdzt1iNQyQoqQCgmAipAKCQQaLWsXWaarO1hY/ycF0xT8UMZI+F5RwK9jyhAwgaACBhA0Q0AgED
QCARQgYUDRTUAgYRT8VBMMOM8lFSxhFACglsoowoqQCijCB4QPCijCB4QLCAwgigFUCAwgEDCipAqKsBWViV0bsLEw3Eun0nqWs0/c4q2mO032ZYid0jOYP3HkVytV1i
Ynu9Uu9DRXiij1DZ3B9LONqVgG9juZI5b+I9/NfPy01PND14cm/gl55rmh6u0xyDlOM+RXXhLfGnE1+B564L6MPBKBC0ySqDCBhRYXRnCzLUPWOh8ukgubM+q17D8Cvl
cfHxQ+hwk/DL00MwvBp6ttffbpBZrRVXKcbTYWZDM423HcG+8rpixze0VhjJflrtXpK+Mv8AZYriYBA8vcx8YdtAEHkexbzY4x35XPHeb125bpeu7YbZTWWI/nKx/WS9
0Te3xP2L18JTc83o4cRbyeVW64Tw3CKrfUTtaZmSyuY47TmtO7x3dq9tqRNdaeetpidvpOjljqaaGqi2urmY2Rm0MHDhkZ818Tk5ZmJfRi/NG1+MkYRXldwoZo6yoEjH
NcZHHDhjdkr2Vt0cZhgPYGe1uW4lJhS7Y+kFuJYmFTtj6Y81qJZ0pc+MfPb5rSKnTR/TatQyrL4j89vmrCK3SRD+UatMqzNF+sb5rTJGWL9Y3zVRWZoh/KN81URNREf5
RvmiI9dD+tb5q6CM0P61vmrpETNB+sb5oF10P61vmmguvh/WtV0iJmi/WNQLrY/ptUB1sZ/lGppUhLF+sb5qKmJYv1jfNBISR/Tb5rLSbXs+mFJWF7XMPzgsS3EL2Bp+
cFmZaiGTGzPDesTLUQy6eGSSVkcbHOe4jDWjJKxa0RHVuKy9Y2CvjvojZQMADirA8q6YLkDUUdqbAQY2iqbNtcSctIx3dq+pwFI1N/0fP4y87iv6vOrfXT2+4U9fDnbp
5WzNHbv3hfQvSL1ms+bxVtNbRaPJ9JUdRT1VLDVQuDoZmCRh7WkZC/OTE1nU+T7dZ5o3Dk7jrCGl1jFp91OwQEtjfOXHIe4ZGBwxvA969VeFm2HxYlwniNZfDdQ6PaGF
5Il6pam/MMNmuEreLad5H8JXXF1vH5sX6Vl83g7h4L9K/PhUJVAgaCTQoraWFhfdaVo+nn4LjmnVJdcUbvD2TSVkgmfJd7kWxWuiBkle/g4jfjwHE+4c182N2l7bzyw8
515qifUt7krXbTKVg6umiJ9hnf3nif7l9DHTUPFezj5HZK7xDjMqHFdIYlAqoiURFUIohKgQCAKCKAQJAkAgaAQCBZQCAUAgSohJ7BUWHddHMmaGth+jM13m3+5crutJ
dkubRFAKgQPCg5fW0mzS0sX0pHO8h/eumNi7paKMRUNNFj2Imt+AWJ7tw1WqbVNcqBppxmaF201o4uGN4HetUnUs2jbXRanjhpGtqIJTVRtDXN3AEjnk7wrydU5is1DU
Xi4C7XNmIQQY2EYDscAB9EfFLWisagiNzuXVVNNDUxSQysD43jDmnmuW23Lv0nOx7mUtwLKdx9h4dn4biukZPVjkdFZbXS2uEtiG3M4YfK4bz3DsHcsWvNm4rpswsNJg
IqYCgmFFMBBIBBgX+LrbHcI8ZzTv+Az9y1SdWhLRuJeM5zgr3PGaARDCKYQCBohoBAIGgEAgaKFA0U1FNAYUF1NNJTTxzxPLJI3BzXDkR4qTG41KxOur1LT1PorWNG70
mjba7uwfnhSSdUx/7bWnLcHs5FfNzZM2CenWHvwYseaPSWVL0PiU7VFfyGngJ6fPxaVMfH833oMnB8vaWHP0R3uL9DcLdKO8vZ9oXWeNpHdzjhrqGdE+pJHgGotrB9Iz
OP2NSONxyTw14bKDobuZGZ71RN+pC934KzxVfRIw2Wnocm539v7tIf7S4zx0ejpHDfMx0NT/ADb+0/WpD/aVjjd+STg15sefoguzM9TdqKT68UjPxWvfK+cJ4FvJp6zo
x1XTgmOmpqoD9RUDPk7C6RxOOWZxWhzFxsl2tji242yrpsc5IiB58F1i9bdpYmsx3hgbO7I3jtCqIkYVCIQLCoSBYRCVAiDKKkFBIFTSptcszCxLIifgrEw3Eu40Jqx+
nqsskBloJyBPDx/eb3j4jcvPkpt2rO3Z64sTLjp+ass7hUUczBLFsb9kjeMd3Ed3BeOkeFki3k9XN4lJrPd4c5i+nEvDMK3NWolnSBatMlhABBYwHKzLUPa+iCgdBYKi
te3Bqpzs97WjGfPK+Txtt3iPR7+GjVXX6kuDrTYbhcWBhkghLmB/Au4DPvK4YsfNaIdb35YmXkGtdWPv1DbaVrBGGxiapa3gZTuwO4Df7+5fRwYPDmZeXLl5oiG00tqa
Ow0lis0cMUnpbpKmtlc7HUMJOCO8BpJyuebh/Fm1/TstMvJqriNS3x99vdZcTkMlOxC0/NjG5o8t/vK9eLH4dIq89781plgRFrjg+ydx8AtykPpLTNU+4WG31jqX0brY
QRFtZ2WjcN/eACvjZact5h78dt1bZoWIhrauspKWth6qpiDxyPNvgVuLaZ08/wBTWJ1BsSRyCSF7iG53OBxzXSt9q5mSneOS7RLMwx3wu+itxLEwx3wO7FqJZmGNJTv7
FqJZmFDonjktxLEwqdE48lqJZlU6F3YrtJVOieOS1tlW6N55KpKJif2KhGJ/YqiJif2JtETE/sVEerf9FNpouqf2K7D6p/YoGIn9ibDEbuxFPq39iyqYid2JtVrYX9iz
MtRDIjhd2LEy1EMqOB3YsTLcQyYoXDkucy3EOl01anXKokiLxGxjQ5ziMnGeQXny5OSHbHTb0KgtlHb2bNLEA4j1pDvc73rw3va/d6a1irK2VhrYwi7QcwkblNLt4r0r
TVMmpBSzQxtjp4muge0Haexw357d4K+zwFKxj3Hn3fM4u0zfU+ThC7YwOzd7l9B4nZWHXFXa9IzUcLYZKyklb1Im3h0Lj6wA5kH4HPJeDNwdcmaLT2n/AC9mLippimI7
x/hZr6j9IuVBf6U4huNNHMxw+a8AZ+7yV4SdVnHPkcRG7RkjzdnZdYvuF9ttt6qLqqij6yR+/a64AkgcseqfNeHLwsY8dr+k/s9WPiJveK/J09yh9NpZ6QbhNG6PzGF4
6X1aJeua7rMPmN8L4XvhkBD43Fjh2EHB+xfqYncbh+dmNdEStISBgIGAgsa3KzMrEO56MNOVF8v5EYLYYI9qSTG5mdw9/HAXk4mZmvLHm9GDVZ5p8m/6T9V07426Vsbg
210h2ZnsP6Z45Z5gHnzPgphx66l7b6y8plfkleyIeeZY7iukOcq3KogVURKqEgFUJAkAgCgigSBIBAIBA0CQCAQCAQJBF/slRXWdHMuKyvhPzomPHudj71yu6UegLDZY
UBhUCBhBzmqaKorKig6qF8kYJa4tGcEkcfct0mI2xaJl0nAkDhyXNtLJQVupqeR/WSQRPf8AScwE+abkW7KipBES3IoHHcoqxu8blBr6u+2uhJE9WwvHzI/Xd8FqKTKT
aIU2jUdPdrgaSmpJgzZLuscRux2gcFbY+WNyVvudOgwuTZhFSAUBIwSRvjI3PaWn3jCsDwuRhje6M8WOLT7jhe94ZJVDRQgaIaBoBAIGgSBhA0AFFNFMKB4RQdygk3eV
Nq2Nss1zu7+rtlBUVThx6phIHieAWL5K062nTVaWt92HbWHov1IKiKrqK6ntjmHI2D1sg9w3e4leLNxuLWojb2YuFyRPNvTrrjfaDSkLWQ6phkqGDElMWbe0e5rc7Phl
eTHjtln7vR7L5a1jrLHpOlOnqQBJE0Htbu+C3fgreUs04nH5wnXa966Etpa19O4jc5mMhZpwtqzuW7ZsdoedXzUmpZJHY1BcJIzwxOR9mF78eOmusPDebR2lz5ut0ecy
XKscf2qh/wCK7eHT0c/Ev6pfK1xaPVuFWPCd/wCKeHX0PEt6rIdRX+B2YL5cWeFS/wC8rM4aT3gjJb1b6g6RNYUoA+WpZh9GoY2T7RlYnhsc+TUZbOkoOmC8R+pcbbR1
cZ49XmIn3bx8Fytwlf6Z06Rm9YZMmoejTUX/AMTtU9pqncZombO/xZkH3tWeTNTt1P5dvkwq7o5kqqd1dpS7015pgM9UHBso+4/ArcZ43q0ac5xTHZwtVSVFLO+nqYJI
ZmHDo5Glrm+IK7xMT1hzmFJbhXZpEhVESEESqhFVCygAUEgVFSBUVa1yzMLErWSEHiszDcS7/QGs5rBN6LU7U1sld+cj4mM/Sb945+K896ddw7RO2TrnRLI43ah08RVW
ifMrmR7zDniR2s+LealL+ST83nb4COS7RLMwoezC1EsTCkha2hBuVNjb6estbfLnFQUbd7t8khG6JnNx/wCd5XPLkileaXSlJtOofSFto6e30FPQ0zdmGCMRsHcOfjzX
xbWm07l9GteWNQ5Hpallj0g5kfszVMTH+G8/aAvTwkfzOrjxE/C8OJOd6+m8e1T3l53ndjHuWtMIgdio2un7XNeLvR2yLOaiQMJ+i3i4+4ArlktFYmW6xudPp2CKOGGO
GFobHG0MY0cmgYA8l8iZmZ3L3RGoWYUUbKaNuc1mzNFTbv5U/wBVar0WOrh5GZXWJJY0kWVuJZmGM+PC3EszDGezuWoliYY74+5biWZhS6PC1EszCpzVqJZ0pcxa2zpU
5qu00gWq7TRbPcqmiLVRAtTaaRLVUGygMIDZRTDVBINUWITa1Z21pexgWZlYhkMjWJluIZUbcLEy3EMyFoK5zLpEOy0LCfSaw/6tv2rycR1074+jtdlebTrsi1DaOEBh
NLt5v0wWoyW+kvMTfXpnGGXvY/h5O+1fQ4G+rTT1ePi69Is8YeMr60Pnyr2cHOFWW1+UqmajpaWSRxjpGGOJudwBJP3lcuSItMx5unPMxET5MrTVTJHqe1SsPripY3xB
OD8CuXEVi2K0T6OmG0xkrL6E6oN58F+f0+1zPFulHTclDcn3qmiJoqt+ZcD9FKeOe53Hxyvt8DxHPXw57x/h8njMPLbnjtLz8hfQeMYRDAQWtYpMrEN9pjT9fqC6RW+g
i2pH73PPsxt5uceQHx4Lje+nStXo2rb1btF2V2jtMy5rHj/KFYPayRvGfpHh+yN3Fcq1555pb3p4/NJkr1Vq42nbFccrpDnKslaZQKqSiVUQKARAqEUCQCBFAigSBIBA
IBAIGgSAQCAQCgi/2T4IrfaCk2L/ALB/lIHt8sH7lzv2dK93poXNsKAVAgFAZKCQQNFVVFVBSx9ZUTMiZnG092AkbnskzpYyVr2h7XBzXDIIOQQorWVuobVRktfUiSQf
MhG0fw+K1FJlmbRDTz6rqahwhttEA5xw0v8AXcT3NG5bjFEdZljnnyL5G1VcnB9VWSUzOI237JHg1v3pM0jssRaS1ka2KpoKUVT3RyRhpaDjaeDguIHblTHrUyt97bih
0nbYCDVF9U8cneqzyHFZnLM9mopDo6aGKBgjgiZEwfNY0NC5TO24hkBRTCKkFAcCD2IPGdQQej3y4QgbhO4jwJz9691J3WHjvGrS14W2TRAgEU0QIJIGgECQAUDQMIre
ae0zc9QicWv0aSWHBfC+cRvweDgDxGd3iuGbPXFrmdceK2T7rcno01iDvtkY7zUxj71znjcPq6e65fRl0nRhqiRwEzaGAdrqna/qgrlPtDDDccFlnydDRdEJIDrje2Mb
zFPCT8XEfYsW9oR/TDpXgbf1S29No7QViPW1LmVcredXNt/0RgfBeW/FcRf7v7PVThMVesrrhr+0W+m9GtccJ2RhrcbDG/uhZpw+S3W7pbJjp92XlmqdW3m77Uc11lFO
f5GH82zyHH3r6OHBSnaHhy5bW83H7WzkBerTygO5hXRtNtRKPnlTULuUxVSY3kpywc0omTa3nimjZZV0AFRUwVNCWU0ptcppdsygr6qgqG1NFUy087d4kieWu8ws2rFo
1LVbTHZ6FRa+ob3Tst2uLWytjA2WV9O3Znj793H3eRXntitXrSXTcT3Yd70a6KhdeNO1jbzZ+JkhH52Huezj7x5BWuXc6t0lm1NON47xwXVzRIVRAhURIVREhVCQMIGC
oqYKkqsYVmWoZMLy05XOYbrLuNF6wq9Pz7DgZ6GQ/nacn+k3sPwPNcbV84do6w6fUulLberW6/aRaJmvO1JSx8QeeG8j+z5LnFpiVj0l5LPC4OLXAgg4II4Fd4sxNWMY
1vbnp0Gk9IV2pZZnQVENPTQOa2aR+SRkZGGjid3cuWXPGOG6Y5vL2/TWn7fp+i9EoIj62DLM/e+U9pP2DgF8vJltkndnupStI1DeBqxprbjelPqfyMrOsIBbJEY+921w
8sr08L/qRpxzfdeCkgr6bxKSFpkAgcUV7f0UaWlt1Ib3XxltXVM2YGOG+OI78nsLt3u8V87icvN8MPThprrL0gNK8unfZhquk2lhNDQauaHUMPdL9xTbdO7iZYjgkbgO
Z3DzWoluYYT5KcO2TV0od2GoYD9q3ufSfozqPUOpZXsMjGbbOboyHj4ZSLx2TllgyRFdYliYY72LcSxMKHsWolmYUPYtRLGlLmrUSzMKXMWtppAsV2mi2O5XaaIsV2aQ
LE2mkS1XaaGygWyhoBqbNJBqm10mGKbVY1ikyulzGLEy1EM+npD6O+rnmjpqRntTzHDR3DtPcFxtfryx1l2rSZjc9Ia2s1PZaYmOipKiveP5WV3Ux+5o9Y+/C6V4fJbr
adfuxbNjr92N/swBq+qByy3UDB2bLz8S5b91r5zLHvU+UQ3li6Rau2yvc62U0jZAA7Ye5pwOzOVzycHFo6S3Xi584eoaY1laNQYhilMFX+ol3E+B5r52XhsmPv2eumWl
+zptlcdN7Gyml2RamjbEudvp7lQVFBVN2oJ4zG8Djg8x3jit0tNbRaEtEWjUvmzUVnqrFc57dWt/ORn1XjhI08HDuP25C+5iyRevND5N6TWdS05K7Oa+BvqknmVmWodL
oKlZNq+1h+MNlL9/MhpI+K83FTrDbTvw8byQ942TjevgvrqqmCGpp5KaohZLDI0tfG8ZDgeRC1W01ncJMRMal5Jqfo1nge6psUwlhJ/zaZ+Ht7muO5w8cHxX1MHtCJ6Z
Pq+dl4OY60ecBmOK+nt4VjGZUmTTpNJ6Zr9R3BtHQxZAwZZXD1Im9rj9g4lcr3061q9C1FqG0aEtcmmdKuElzcMVlcMbTHc9/wBLsHBviuVaTedy1M6eNzzF73Oc4lxO
SScklemtXK1mK5y6RDnMq3FbZQKrKKCJVQiiEqBEJAkUYRAQgSKWEEUCwgYQBQCBoBAkAgEAgT/ZKgz9Ky9TqK3uzudJsH3ghYt2dK93rY4Li6BFCqEgqq546WllqZc7
EbS444pEbJUWq4RXKl9IiY9gDi0tdxBCWjUpE7Z29RoDOUHG6jkkudzkpIcGOjjc53ZkDLj9y7UjUbnzcrTuW5086Ku03HTvzgNdA7ZOCB//AIQueTpZqvWqmj0lbYfW
l26kjgHnDfIJzyRSGvt0A/LlzYWNZFA5xDWDAGyzH2lat9xI+875hK4ujgtVXCnOoYJAOujo9lrm5xlwdkjPjhd6R8LlafiXsrdU3wn0SP0OmcfbHqD+I7z7ljVK92t2
t2dXY6CegoG09TVuqZdouLyTuzyGd+FyvMTO4daxqG0AWWjUDQNFeVa7iMWo53Y3SxskHlg/YvZhn4Hkzfec4F1cjQNFCiGqGgYQNAIEgFAIGCisugrp6CobUU5AeAQQ
4Za5p4tcOYPMLN6xaNS1S00ncOnivl2kjElkvVxiHz6F9S5z4vqE/pG/0hzB4rx2xUidXrH5/wDez20y2n7k/owZtS6kfkPvtw7x1xCsYMXlWCc2T1aye63GY5nr6qU/
tzOP2ldIx1jtDnN7T3ljPq5HbnPcfErcVZmyh0pPNa0ztS5+VdJMoEqoEDCBoBA8oqQKipAop5UDBRUgVFWNdhRdt9pjUly05cG1tum2Sd0kTvYlb2OH38QuWTHF46ul
baejz2axdINDNddOCO33tgzU0TyAx57e7PJw3HmF54vbHPLbss0iY3DzCupKmiqpaSrgfBURO2ZI5BhzT3r0RO+sOWmIQtbTSJVREqoiVURQSCCbVmWoXxsJ5LEy1EMl
kZ7FiZdIhewOHIrEy3EN9prUVwsFcKmjk9V2BJE72JB2EffxCxNdtd41L0Spt+nOkKB1Xb3NoL21uZI3fP8ArAe0P2hv7Vz6xJ27vL79Yq6z1jqSvp3RSDeOYeO1p5hd
K3JrvrDEttzulpe51ur6il2iC4RPwHeI4FWa1t3hmNx2dPQ9JeoqRzRU+j1rBxEkey4/vNx9i5W4ak9ujcZbQ9C0/ryzXeiqKiaT0GWmZ1k0UzgcN7Wn53hxXkvw96zr
u7Vy1mNvI9ZagqdS3MzyF0dJESKeDO5g7T+0efkvoYcUY66ju82S83lp7bb5a+vpqKFzRJUStiaXcAScb10tbUbYiN9G11pYYtOXt1sZVGoAhjkLy3Z3uBzu8Qpjvz12
WjUtVaJKSG7UM1VGJKdlRG6Rh4Fu0Mq33yzor3fVDXZzjeM8V8l7EwqABAOLWNLnEBoGSSdwCaTbxnXnSGKmV1vsjGOhjdvqnDO0eHqjs716sfC763Ytn5elXmNXXVdU
8vqqmWY/tuJHkvZWkV7Q81rzPeWG9wPIeS6QxMpU1TUUkolpZ5IJAch0Ti0/BS1ItGrRtYvNZ3Euzs2rm1OzS37ZBO5tcxuCP/MA4jvG9ePJws164/p/w9VOJ5umT6t/
UwuifsuA3gEFpyHA8CDzBXGttu0xpiPYtxLEwoexaiWZhS5i3EszCl0e9XbOkCxXZothXaaIsV2mkCxNppExq7NIlibTQ2E2ugGJs0mGKbXSYYptdLBGptdMmJtNTU01
wr3FtJBjIHtSOPBg7yudpmZite8t1iIibW7Q4q93irvNSJKhwbEzdDAz2Ih2AdvevXixVxxqHmy5bZJ3LW7l1chnCKkHFTQvhnkje18b3Ne05DmnBB7lma7WJ09y6MdZ
PvbDaLpIDcYmbUUh/l2Djn9ofEb18rieG5Pir2e7Fn30l6Lsrx6enZYQ2Mbk0PIOm+anMlop+rb6SGySF/MM3ADwzk+5fR4GJ6y8nFTHSHkpcxoJwvovFLtNTaabaLFZ
7vBIXQ1kMfWMdxZIWbR39hXlxZue9qT5PTfFy1izkhLLHI2SN7mPYQ5rmnBaRwI7131vo49ntWk9c0Fwsks12qI6eromA1Bd/KDgHtHPJ3YHNfHz8Lat9UjcS+nh4itq
7t3hoLv0oFxcyz25oHKWqOT/AAj7yvRj9nR3vP0cb8bP9MOMuOrtT15Ilu00bD8yACMfBeqnC4adqvPbiMtvNomM5Lvtx07bQ2h6zUsnXu2qW2xn85VOG444hmeJ7+A5
rlfJpuKuj1RrO22G3O0zogCGBuWz1zDl0h4HZdzPa/yWa0m07sszp5JK8kk5XoiHKZYziukQxMoErTKBKrKBKoRVQiUQlQkQIEgMIBAIIoEiolAIGgECQNAIBAkDUAqI
v9kqAoJOor6Wb6EzHfELM9m4e1bsnxXB1NFJEGEGl1ZJ1VllbnfK5rPjk/Yt0jqzbst0tCIrJTZG+TakPvP4BS/da9m3wstMW5V7bfQz1RAJjblo7XcAPNWI3OkmdQ5v
SsLfQqquqnAekks23nA2eZye0n4Ld566hisdNoaSr6egdLQzF7utmaIywZGeBPhwVyV31Sk66O6YGg7zzXF1cfpJ3pOoLlV8RsvIP1n/ANy65OlYhzp3doHELi6OHoOp
qde1Y6ljo43SO2SMjaAAzjxK7T0xucffdhXXS3UIzWVccbgPYzl3kN64xWZ7OnNEMC16kpLjchRU9POA4EiRwGN3aOSWxzWNkXiZ06Nc3QIGgeFB550lwbNbQVGPbicw
+Idn7168E9Jh588dYlxIXdwNFNA0QBBJA0AgSBoEoBFNAA71B2eidG1+pXipeTSWtjvXqnDe7HERjme/gPgvNn4muLp3l6MPD2y9fJdr246XgiFn07a4aiaL1ZLlI5zn
Z54OfXPed3YuPD48kzz3nW/J6M1qRHJWN683AGWX5wavbqHl2jtuPYrpNlkoDKIaoEDCAQCKageUU8qKYKKYKgkCipgqKm1yiw2llu1bZ7hDcLfO6KoiOQRwI5gjmD2L
F6RaNS3W0w9onpLT0naeFdTdXS32mbskk8D9B3aw8jy8144mcVtT2dbVi0bh43cKKpoKuajrIXw1MLiySN43tP8AzzXqiYnrDhMMNwWmZVlaZRVQkDCisiJuSsTLUQ7T
ROlKrUNS8RkQ0kW+eoePVZ3DtPd5rz5L6d6w7sUWhLWeojtct1kbudNK71Se7gPILx2zb7PTGG3n0Xw2/QN0/NPt0lrmduD2Pw0H4jzCtcseZOK8duridaaYm09UMORN
Sy74Z2jc7uPYf+Qu9bbcpjbmaaunpJ2TU8r4pYzlj2Ow5p7iuk12zFnpVm1na9Q0jbPrKnjcDujrAMYPaceyf2hu7QuU0mF/JqNVdHtfbmmstbjcLcRtB7MF7B3gcR3h
It6r0lwb6Zw4hdYszNVJaWHIC13Z0rmyRtN4cx2KxKTD0boesTqqumvtQzMNL+bp8jjKeJ/dHxK8vFZNRyw6Yq+bVdL8L/y0kdvwaWH7CuvDf6bGXrZxDY87jzXZh9Q6
PrBctL2usJy99O0P+s31T8QvnZKREy9NbbhusYXNoig8q6YNTyUzG6dopC18rA+qc07ww+yz38T3Y7V6uHx7+KXLJbXSHjD3L2w4KScrTMoFaQiUQtrCDttF3Z1TH8iV
LsuaC+jceI5uj8DxHfntXh4nFyz4kfr/AMvZw+Tm+Cf0dC5meC4RLvMKXs7luJZmFLmLUSzpU5iu00rLFds6RLO5XaaR2VdmkSxXaaIsTZour7k2aHVptNDq02ukgzuU
2uljWKbNJtjJ4DeptdOY1lX9bWstkLv8WostOOD5T7bvu9y78PTVeee8/wCHLiL9eSO0f5c5lel5wgEDyoJNKis62VtTb66nrqSQsqIHiSN3YR/zj3rF6xaNS1WdPqay
3CG72mjucG6OpibIB9E8x7jkL4uSnLMxL6NLbjbP2Vz03snAYV0bfOnShcRX6yrw05jpdmmZ+6PW+JK+tw1eXHDw5rbs41zWlju3BXphwl9M1lgp7vo+G1SgAuo4hG4/
MkDBsnz+BK+NFuTJNo9X0Nc1NS+dKincypfTvbsSxuLZA75hBwc+C+rFum3jmOumNMG46uLcwb883HtP4LUR5yzM+UINaURk08D5ZGRsY573HDWtGS49gHNZmzUQ9RsG
gqG1UgvmuJmUlI3eyjLvXeex2N/7o39uFxnJudQ3ENVrbXs91gNqtUfoFmYNhsLAGukaPpY4D9ke/KtMfnJNnnUr8lemIcZljPctxDEyqJWmUSqiJVRBVAiEqEgSARAg
ECQIlAkUIIoEgaBFAIGEAgEAgEAgT/ZPgoMYkgZHEb1GnttK/raaGXOduNrvMBcHZcoBAKjk9czfm6OmB3uc5+PgPtXTH6ud5dRRwCnpYIB/Jxtb5Bcpnq6Qvwg4zVlV
VT1zbV1IbGXtMeOMhO4HwySutIiI252mZnS6j0fNIG+n1oDWDDYojtY7sncPcFJyR5LFPVXbaf5N1i6jjaeqLS2Mv3nBbkb+3cUtO6bI6WdnK14gkf2McfguUOjkej2B
4bXTHmWN+0rpl8oYxu4a3eMri6PO3Wa/x3msFLDLGZ3vzMHhrSwuz7XLl3r0c9ddXLlttvLboumZ+cuNS6eQ7yyL1W+88Sudss+TUY/V1VFSU1HH1VLTxws7GNxnx7Vy
mZnu6xER2ZICypoGAopoOQ6R4Oss9PUAb4ZwD4OBH2gL0YJ+LTjmj4dvNV6nmNECBhAwgYQNAIBAIEoBAwEV6JoHQbLnCL7qAmnszBtsY47JqAOZPJnfz5LxcTxPJ8FO
71cPw/ifFbsu11rgV8Rs1jAprTGOrJjGx1rR80Aeyzu5rlg4eYnnv3enLljXJTs82mmbjDRuXtiHkmWI45OVtglUCBoGgEEwgEAgAihQNFARUgoGCoqQKKmCoqxrlFh0
Ok9QVenbtDX0riWg7Msed0jOYK5ZccXrp1x35Z+T2fV1goNd2CC9WfZNxbHmF3Drm84nd/YeR7ivHiyTWeWzeTHrrDwaWNzHuY9jmPaS1zXDBaRxBHavbEvPMKHBaZRV
QBVEmjepKwyqcDaGVytLrWHvNNE21aBs9DTeq6sj66Zw4uzvP2geAXzOJt5er3cNXdpmfJzFQwhxwFwrL02hUyJxdzW9suupaYXjRt2tVSdt1PF10DjxYRkj4g+a6YZ8
nDPGpizw6oIDty99Xlt0QZMWnIK1NWeZ12lNc3TT72xwvE9HnLqaQ+r4tPzT4bu5crU9G4mJ7u4ko9J67aZrdMLbeHDLonADbPe3g7xbv7lx61b3p55qPTV1scpbX0jm
xE4bMz1o3eDvuO9brcmIns5x4cx2QN/eundjWntPRbqC21FpprEI46Ssp2kNZn1Z+ZcCfndo8l482Kebm27VtGnHdLb4ptVl0MrJGiliaSxwcARtbshenB0ppxvHVwgw
DvXdh7F0VakttPYJrfX10VPJBUExiQ4y1wB3e/K8fEVne4dsfV6VSVtHWN2qWqhnH+qeHfYvN+bpLJBj+dw5+C6VmGZ3p8r6mubrtfLhcXHPXzucO5ucNHkAvo1jUaea
ZaRxW4ZVkrTKBKqEqEUF1LUS0lTFVQnEkLxI094OVm1YtExK1tNZiYeuvMcuJoh+blAkb4OGfvXyI6dJfVtqesKHtW4ljSosV2mlbo1dppW6Na2kwrcxXbOkdhXaaLq+
5XZodX3Js0NjuU2aGwrs0WwmzRiPuU2aTaxTa6Tc8UzH1LhuhaZPIZU79F7dXlr3ukc6R5y5xLnE8yd5X0u3R8+evWSVAgEAgkNyirGnsWZWH0B0KVTqnSMlM52fRat7
G9zXAOHxJXzOKp8e3rwW6ad9VVFNSRdbVVEUEf0pHho+K8vLM9nfmaifVGn4mPebtTOLGl2GuJzgZxwWoxWmSbdHzNWSOqaiWpkJMk0jpHZ7XEk/avsRGujwTO2I7AB3
clpl9RQXm2R2kVZrYPRYIWl8jXghoAA/5C/PzzWvy66y+rERWu5fP2q6+mu99rrhR05p4aiTa2Sd7jjG0ewnjhfZw1mlIiZfPyWi07hpmxEldNsaddpPRF51G9r6WDqq
TOHVUoIYPDm49wXO124iI7u7dXaP6O2PjtzG3e/gbLpSRiI97huaO5uT2lYiJssvLtR6huV+rnVlyqTLJwY0bmRjsaOQXatNMTZz8jyea6xDnMqHOW4hiZVOK1pnaBKq
IqoRQIqoSIRVCQJAIgRQiEgSKRQJAkAgAgEC5oGgEAgaBIBAn+yVBj8dyjT2DTcvXWG3SZ39Q1p8Ru+5cbd3WOzZrKkgRVHG34el6roqXk0xtPvO0V0r0rtzt1tp11ZW
UtGwy1U7ImnhtHefAcSuURM9m5mI7tPDquglr4aSOKdwleGCQtwATuG7it8kxG05o2w6IC6azmmdvipi4j931R8d6s9KJHWzsg3Z4Lk6NLcbVNUXujuUMzYxFs9YCN5w
eXuOFqLajTM13O28yXAtcAWkYI7lhpi2220tuZIyka5rZHbRBdn3eCtrTPciIjszmlZVMDKirG7lFTG8IKpqulg/S1MTPrPCkt1pa3aFdPcqKom6mGpY+TGQBz8FNt2w
3rG5hmhHM0Go1bT+kabuDAMlsfWDxaQV0xTq8MZI3WXjpXueIIBA0DCBoGgEAgMoEoGAg9H6PtFQ1UI1HqQCGzwjrI45Ts9eB853Yz+t4Lw8TxXLPh4+72cPw3N8duzG
19rmS+yGhoCYbVGcNaBs9bjgSOQ7As4OH5Pit3dsuaJjlr2efyylxXsiHlmWO4rTMo5VQIGEQwgaoaimEDQCBooQCgEU0UwoqQUVIFBIHCirGOUWJeo9D+pvk24m0Vcm
KSqPqZO5j/714uJx6+OHrwzzRyfRu+mHSYDjqagjAY8hta1o4O4CT38D7j2phyb6OF66ePyM2Tgr1Q5SpKqJNaTwTZpcInDiFmbNRVl0zN42hhc7S6Vh7lpt8eodFUUd
O8OrrYOqkj5lvI+8Y8iF8/icczG47w9fD5IrbU9pYb6HfvG9eCLvfNSbb+xa52eVsLjMNM6SudbOdmorGdRAw8SSCM/En3L18PWe8vHxFomdR5PB6qUOO5fSrDxWlibR
XTTG1kbyFmYaiWdT1DmOa4OIIOQQcEHuXOa7bi2nounekeqp4fQr5C250Thsu2wOsx353O9/muM49Om4ltp9JaV1TC6r0rcGU9RjLqWTOAfq+033ZCzNtHXzcFeLBdrF
Ns19HJCAfVlG9ju8OG5ai0S1EejTVUkk79p28gAZxxW69IZtuZY/VnmtbY02FpjxM5vJzfsXPJ2dMfdvadzqeUSQvfHI3eHMdske8LhPV3h6JpfVprYKi23J+avqJDBN
wMhDSdk/tdh5qVrES5ZInyfPofljcdgX0YeVArTMoEKoiVUJAYQCD1bT7+usVvc7iIWt8ty+VljV5fTxzukM10fcsba0olcyJjnvIa1oJJPIBajr0SeimjqKetgE9O8P
jJxnGN61aJrOpZrMWjcKbtVRUFBNVOAJaMNB5uPALWOs2tpm88tduRh1JP6RH6RGzqQ384GN3k9o7PBem2CNdHnjNO+rro2bbQ4cCMhebb0aT6tNmiMabNKpiyGN0kjg
1jRlzjwAVjr0hJ6NYb1bQ6RpqPYIGdkkHPMdoXTwr+jHiVbZrMgEcFz26HsdimzSQYptdMK+Bws1fs8epct4/vwzk+7LzMr6LwBVAgEDCBqKm1SR6l0b31th0pdJIw19
ZUVgbAx3AYjGXEdgz7yvDxFd3h6cPZgV9dXXCoNRXVD55T855zjwHAe5YiIjs7Nbc5zHRvbne/1V0xx8TF5+Fzbxkr0xLz6JsYcd/BJkiGxrZpKj83GSIhvIHziOZXGt
Yjq63tNujO07pq8X6oEVto3yMBw+Z3qxs8XHd7uKtrxDPK9Fj0xpDRrW1OqK1txrwNplDEPVz9XifF2B3LnzTbsrnNU9It2usbqKiAttuA2RBTnDnN7HOHLuGAt1x+qT
MQ4CWbIXaKuc2Ykj8rpEMTKlzlqIZ2rJWtMoFVEVUIoIqoEQigSoSISAQNAIEgSBFAuaCKKEAgECQNA0CQCAQCCL/ZKClZaeoaEl6zT0TM74pHs+OfvXK3d0r2dEVlok
CKDgLk6ubqeeSljk9JEn5vZZk4xgEe7mu0a5erlO+bo2NLperqJPSbrVOD3by1rtp58XcB7lmbxHZqKerpKG20VE0CmpmMcPn4y4+871zm0z3biIhkU9HTU8ss0MDGSS
nL3NG9ykzMkQygSoqfFBIDCgZc1oy4gAczuCi6YM93t8JINQHuHKMbSzNoeinDZLeTXzamY3dBSk98jsfALPO714Kf6pUtuN+rD/AItC5rTwMcX3lTdp7Ong4Kfen90z
ar1Vf5zVAZ5PlJ+AU5bT3Xx8FfuwyqXTDMh1RVOP1GBvxKvIzbjZ/phsYrfZ6CVk3WsEjODpJgce5XliHK2XNkjWun5NlHIyRjXxva9h3hzTkFHCYmJ1K0KIJ4mz08sD
t4kY5h94wrE6naTG4eDOaWEscPWadk+I3L6T54QCBhA0DCAQPKAQJQMbyg9E0Ro6mfS/lNqdzaezQjbZHKcdfjmf2O7i7wXi4jiZj4MfWXs4fh+b479IanX2t6rUc/ot
MHU9piP5uHgZMcHOA+A4BOH4eMcbnrLpmz8/w17OJc8nmvVp5tqyVULKqBAwgYRDQNUNAwooQNFCAygFA0U0UwoHlFGVBIIqxqis2kl6uRsjXFrmkEEcisWjcadKTqdw
+k9FXym1NpoQ1bWyuMZhnjd88YwfNfLtvHbley9YvHPHm8H1jY59PX+ptshLomnbgkPz4j7J8eR7wvfjvz128Vq6nTRALpthtbJb57lcKahpmbU1RI2NgPDJP2LF7ahu
sPZnWXSGmsUUlobdqxgAmmnO7a7AOA8Pivn5eJ1OoezFw83je9NbedL2K+26prNOUrqC5U7DI6kzlkrRx2ew+HkmLiOadJlwzTv2eeWO911krmVtBUOhlG48w4djhzC9
U124xOnplH0lWerjabzZyJsb5KdwIPuOCPMrzX4eLTuYda5bV+7YqrpGsFMC+12WWWYey6oeGtB8BkqV4WsTvS2zXmNTLzjU2p7hfqkz1822RkMjbuZGOwD7+K9dMenn
tf0cvI7Jyu8Q4zKG0taQw5NCwSd6zMNRK1kpzxWJhqLM2jrJqeZk0Er45WHLXscWub4ELFqxLpFnoti6Sa6KL0S9wR3OkcMO2wA/Hfyd7x71xnHrs1uJbgaf0PqoF9hr
Rbq52/0Z+4Z+oT/VJU7LuY79XJ3/AEXe7PtPmonTQN/loPXb7+Y94Tm9VjU9nO0gcKqPZ+lgpaejVY6tzsOwuW3XRxxvD2va4tcDkOBwQmzTiKqnME0kThgscWr31ncb
eG0anTHIWtsokKppEhXaEQgSBjHNB61YaV0FkoI3DDhC0keO/wC9fJy23eZfTxRqkQzJ3xQQySynDGNLnHuCzXrOoanpG3IX26issTXQMdG+pe6MtJyQ1vHz3L14sXLk
6+TzZMm6dPNHT9RDbrbTsqHuD6qchgAz2DJ7ky1m9p15JjtFKxvzYes6pr6qOga7LYfWkwfndnuH2rpw9dV5vVjPbc8rlw5oJJGSV6Xneo0BL6GmL3B7zE3acOZwvmXn
4p0+jWPhja/YPYs7XQ2O0K7NNdqImKy1JjY1xIAdkZ9UneuuHU3jbll3yzp5y9ozu4cF7njdvpisdVW4Ryb5YPUd3jkfu9y8WavLbfq9eG26i63iSgudLAWt6hwBkJG8
gnG7swrTHFqzJfJNbRDog1vLeF59u2kKmmbUU0sDuEjCzzGFqttTtJruNPHpGujkdE8EPYS0jsI3L6sTvq+bMa6EAiJYQPCAwimAoJAFQddZYHQ2+PaGHPy8+/gvHltu
z2Yq6q2GFz23pq72MiJvLeV1xebnkakRZXWZctOmsOh9QXrZdSULmQO/l5/UZ7s7z7gsTkhrldoyw6K0ewO1FX/KlwaM+iQjLQfqg/1iPBcua1p6L2aq/dJdwqIfQ7LD
HaaJo2WiHHWY8QMN9w963GP1Z3EPOqmpfLI6R73Oe45c5xySe0nmu8VZmzDfIe1biHOZUuflbiGdqnOWmVZKqIkqoiVUJAiqhIEqhFAkQkUkQIBAIEgSAQJBFAIoQCAQ
CAQCAQCAQRd7JQUrKvQOjiXNHXQZ9iVr/Nv9y53dKOyKw2SAQA3HON/DKgmEBhRUggUksUTdqWRsbe1xwpMrWs2nUQ1tRfqOHIi25j+yMDzKxN4eqnB5J79GvN6udY4s
o4dn/wAtu0fM7lOaZ7O8cNip1vKTbJdKwh9XUBueT3l58huU5Znus8Tip0pDKFotNEM11WXEci8NHkN6vLEd2PeM1/uQkLpY6Qf4rS7ZHNsePi5TmrB4Ge/35RdqKrnO
zR0QJ5cXn4Jzz5NxwlK9b2Nsepqw5LjA09pEf96nxSu+Gp8/3WDTtZLvqrhv5gbTvtU5Z85PfKV+5Vkw6YomnMks0h8Q1XkhiePyT2iG7pKaGkgbBAzZjbwGcq9nmveb
25rd2QCoykDwPYivF9TU3ol/uMIGAJnOb4O3j7V9Ck7rEvBkjVpatbYCBhA0DQNAIEoAAkgAEk7gAM5QdvZLBb7I2K7asimkkxt01nhjL5puwyAey3uOO/sXgy8RN/gw
/rPk92HBFfiyx+UNfq7UOodRziSvpXUdFEfzFKSGMjHbg4Lnd+PDC3gx48cdJ3K5rZLz1jUOTnBa0OcRvOAAvTDzz0Y5OSqgVQIgQMIqSIaBqhqKEDRQiBFNAKBoqTY3
HljxRVoiHNyirBCw8S73KKkKMu3slB7nDCm15d9kZKaaEAyRkA8HcQfekTEk1mO6GcIibCSVJah6N0UXd1uvAgc49VPuI714OLp05o8nu4W290nzej9K+mvlnTvypTtz
V28GQYG98R9se72vcVnh7an83HNDwF7Ng8V7XnbnSN5bZdQ265SML46eYOe0cS3gcd+CVzyRMx0bq9pvFpnuMrrtaC2uoas9Yx8JzjPIhfJy47c0zEPpYc1YrEW6Sst8
DdK0VTfry4QNZEWxQuPrSuPAALpgwW3zS58RnraOWr5/q5cyOcMAkk4HJfUiHgtZjdee1a5WeYdce1OU5kXSErUVZ2rLldJtDKqbMFNKkCpoTa5TS7WsfhYmGola2Ujm
szVrmXx1DgQQcEcD2LM1bizttO9IV/tYbE+pFbTjd1dSS4gdz+I+K42xQ1uJddFqLQeoXtdd6A2ytP8ALtG7P12j+sFznG3FrR2ZlToyKen9Jslyp62E8PWGfMbvsXK1
ddpda5d9LRpyVxt1dQOLamkli73N9U+/gsRZ179nH6ioJifTo2ktxiTHLsK9eDJH3ZebNjn70NB1ZXp28+iLFdppEsV2mkSwps0iWK7TTa6ctEl2uccGD1DPXmd2NHL3
8FyzZYx1264sc3tp67sjAAGANwA5L5G309NFq7Mdhqi3i7ZZ7iQu/D9ckOObpSXnHWPw1pJIbuaOxfReES10wmgdGR/i+6PIyAc5z5qxWNT80m07j5MB+297nvcXOcck
niStsJwU755WRRtzI8hrR3lSZ1G5WI3OoetUNFHRUcFKzeImBue08z5r5V781pl9KleWsQu2O5Z21otjKu000+qKOaWzyvhc4GMh7gD7TeYP2rtgtEX6uWaszXo86exr
HEDhyX0YeGWZark+3VBlYMtc0te3tH4hYvSLx1apeaztbVVUdfamOlcXVVPJsbTuLmO/vCzFeW/TtLU25q9e8N5o+qqqmqmgnlc8CFpYCeGzu+xefiKxERMO2C0zMxLs
OqJXm29Dg9bWR1NVfKcLfzExxLj5r+33/avdw2XccsvHxGPU80OS2RlerbzHsoaPZQSDCptdGGKbNNvYrPLcagu2T1EW957exoXDNmikfN2xYpvPydaITw2cY+C8XM9v
KyqK1Vtc8MpKSac/sNyB7+CcxMRHd0X+Doywx1N7ucFugZku9YE48Tho+K6UtMOF7RPZjm69HulXf5It77xWs4TyHLQfrOGP4WrfLazDm7/0j6iuwdEKkUVMd3U0uW7u
wu4n4LrXGxuIcVNUl5JzvPHvXWKsTZivlPatxDEyqc9aiE2qc5a0ztAlXSbQJVRElVESqgQJVCQJVCKBIEgRQJAIgQJUCgECQJBBFCBogQCARQgaIMIpIBBF3slBUsq6
/o5l2blWwHg+EO8nf3rF+zdHoZXN0JQGEAgZIaCTuARWsqL3RxEiMumd+xw81ibw9NOEyW79GC64XWuOzRwua3/VjJ/iKxNrT2eqMGHF9+TisFdM7rKucMJ479tyRSfN
m3F0r0pH+zLNLZbdg1LmvkHKQ7R/hCuq17uXiZ8v3VU+oWMHV0NLu4Av3D3NCk39HWnBTPW8q2s1Dchv6yKM9p6tv4qfFLe+GxfOfqy6bS7dzquqJPNsQ+8pysW43yrD
bU1lttPgspWvd9KT1j8VdQ4W4jJbvLYtaGjZYA0djRhVxmd90wEEwMqCWFFGEVIBQSUV5f0jUxivkc+PVqIGnPe0kH7l7cFt108meNW25Fd3E0Q0DQMIBQNAlQ2kgggk
EbwQcYUFhfO7P5+bf/rHfis8sejXNPq6ro10zHqDUbWVkZkoaZnWzjONvk1ue8/ALzcXl8PH07y9HDY/Ev17Q0uvKi2y6kqqe0QMht9IfR4gzftlvtOJ55dn3ALfD1tG
OJv3lc9om+q9oc5wXdxCBogHBBIIGEUwiGgaKEAgaKEDQNrS44AUVkMYG957UE/FRQN/BAbbQcF7fNFXwyYcDyKkrDPjle3I3Fh4tO8FYmu3WttI1FvhdH19McfSj448
FiLzE6s1OOJjdUaa1zzYLQAD2pbLEFcFrOnsdskoqiKd0zMsOcBeXLli0a09eLBNZ3t7rp+7Mr7cGPAdhuy5p5jmF4K5Zr8LtnwRM80eb5u1VbZLNqO4Wt2diGU9WTzj
O9p8iPJfWx25qxL5d41OmsYcLcwzturVqG6Wlrm264VNMHe0IpC0H3cFiccS1F5Y9zvVfcZOtrqyepkHB0shcR4Z4LVccQk321L5C48V0iHOZV7Suk2NpNGy2ldJssob
PKqAIqWVFMFTS7SDlNKmHLOl2sD8c1NLtY2QhSYWJWsmI5rE1bizPoLlV0Momo6qank+lE8tPw4rFscT3bi7trR0l3mmAir2U9wh4ESt2XH3jcfeFxnBXya59ukh1RoG
7t2a+gfbZnbnODfV827vMLFsXpDUXtHmwJuji0Xbbn03qGnlYd4ifh+O7LTke8LUZJjpLE6cvdejrVNAXf5MNSwfPpnB/wAOPwXSMsSmocnVUU9K8x1UMkLxxbI0tPkV
uL7SaqBFtHcFrmTlbS06ZuV2ePR4SyHPrTyDDG/ie4LlfiKU7ulMNrdnptos1NZ6MUtM0nJy+Rw9aR3afw5L5uTNOS25e/HiikahmOj7ljbemh1hHnT1X+zsu8nBejh7
fzIcM8fBLzDGSvp7fP0pdHxWtsobOCmzTr9D2d00zrpK383HlsOebuZ932rycVl1HJD1cNi3PNLuupxyXg29uh1Q7E2mh1au00i+MOa5jm5a4YI7QrFtJMPJ7zbJbdcJ
aZ4OyDljvpNPAr6uPJF67h83JSa2015j7l02xpONgBJwpMrEOo0RvvLv2YHfaF5uJn4Ho4eN3egYzyXz+Z7dKqilZUwvgmja+J42XNcMghWLTE7gmsT0lwN40RV08hmt
gNRAf5In84z+0Pivdj4us9L9Hivwsx1r1cyYdklpG8HBHYV6uZ5+UNgceDU5jlTbA4vDA0lx4NAyT7lJsvK7HTPR9eryWzSUctNS/TlGwX+AP2rz5M+ulesutMcT96dP
S6fR1JZ6Rgr7lS0FMwcNr73YyV5Jpe87tL0RlrWNUhrKrUugrO8mlppbvUj52z6mfF2B5ArrTDPm52y2lobv0pXioYYLZBT22HgOrbtvHvO4e4LtGGPNymzg7jc624Tm
euq5qmQ/OleXfbwXWKRDM2YL5iea3FWJsoe9biGZlU5y1pmZVlyuk2rLlrTMyiSrpNokoiJKoRVQkCKqEUAqhIEUCKBIgKKiiBAIBUJAFQRKBIIooQNAIhooRAihAIEg
ECd7JQVFZVv9ES9XqOBvKRj2fDP3LN+zde71LkuLoeEAgMIAtDgWkZB3FFhhUlmoIDtdV1ruRkOce5YisQ734nJbz0lX3ant+YQxzpAMhjRsgeJSbRHRcXDXy/F5NSaq
93PIhY6KE82+qP4jvKxu0vVyYMP3ussml05H7VXO57jxbHuHmd6RT1Yvxsz0pDdUlBSUn+b07GH6WMnzK1EaeW+W9/vSzR2lGEwipYUEgopgIJhRUkU1Awin4KDi+kqm
Mluo6oDfFMWE9zh+IXp4eesw4cRHSJebFet5AEDCBoGgEDQCAUBk8kHr+mpPyS6Kq6+uw2suALoe3J9SMfa5fMzfzuIjH5Q+lg/lYJv6vEjx457zzX0XiJUCIaBoAIGE
VMIBA0CQNA0UKC2OMu3nc1FXgADAGAgaKx6mqjgGD6z+TQoML0p0x9YlvdyQS4oq+CUxEH5vMIN22Rr2Nc07iMrLayOR0Z2gVmY21W0xLJbcNge0BjtK5Tjdoyyuivkb
XAGZvmsThbjP83qXR1UVbn7ZYX0sn8rG4PaPHBOPevncRSItuHux35scxLV9NltZHXWy6NaMzxOgee0sOR8HHyXt4Sek1fMzx128mecFezTzqttXSESrpNokppNllVBl
A1QIBAIJZUDyopgop5WVSDk0qYcpoSDlNLtMPPas6XaYkKmmtptlPapyrzLoah0TxJG9zHjg5pwfMLM121FnT2vXmprcAyC6yyRjgyoAlH9Lf8VznHDXNDp6XpRnqWiK
92WirYzxLdx8nZC5zinylYmGWLx0ZXEf43ZJKF54ujiIx72H7k5bQdW6o36anjigtWrIWsjaGshqdk4A5b9kry3wbmZ09NOItEamG5iss0zAYqmmnH0o3HB+1cPCnydf
eK+aieyV7TgQbX1XBScd48mozY583nGtaa+1ExpBaK6KjjOS8wOIlPbu5DkvZw9IpHNPd5s2Tn6R2chBaqyepjpYqeQzyHZa0tI3+9eqckVjcuEUmZ1CV5tDrXcZaOSV
ry0NcHDmCM/ipizRkrzQuXFNLalTbLYytuNNSySFjJXhpc0b1cmSa1mYSmOLWiJer0tNHTQRwQxiOKNoa1o5BfItebTuX1IpERqFxYSptdF1Su00XVq7TQ6k9ibNNZf7
FFdaTGQypjBMTz8WnuK74c3JPyccuHnh5bLEBlfTiz581ViJ2x1myQwu2drlnsTm66OXptsLJUz22ubUwgP3bL2Z9tvMLnlrF66lvHaaTuHrdBH6bTR1FNHI+OQZGGHP
ge9fLtE1nUvoxaJjbImt9zYMU1oqqiQjcA0MaPFziAFuuOZc75q1YEmm9c1h3C326Lvk23D3gFdopjjv1cZz2nt0aodHtjoQX33V1JEc5c2LZB+JJ+C7xkme0OGktros
tQ9UVl1kb27Raf6oT+ZJ2QPSPbbe0s0/pejpex8mAf6Iz8UjFM95SZho7n0ianrtofKRp2H5tMwM+PH4rcYoTmcnVV89TIZaiaSaQ8XSPLj5ldIppJuw3zEniunKxzKj
J3q6ZmUS9a0m0C9XSbVlyuk2g5yuk2gSrpNokqoiVUIoEqiJQJVAgSIFQigRQJEJFCISBIBAkCVAgSgEFaKYQNA0AgWUDygEQFAkUIEeBQVKK2On5eovlvl4ATtB8Du+
9ZtHRY7vYQMe5cHYIpoBAwoJeCCt1PBJKJnwsdI0YDnDJAU03F7RHLE9F2EYTbuUVYCEVMBRUmqCYRUgoJBRTCBg54KKnggZIIHadyDFqLhQU4zPXU0X1pmj71eWZ7Qn
NEebBl1PYIR610hd3Rhz/sC1GG8+TM5aR5ub1VqmzXKz1FBTmofK/ZLHdVstDgc7ySu2LFatty5ZMtbV08+3r1PMYQNA0DQCBoBAILKankq6mGlhGZJntjb4uOB9qzaY
iNysRudPTOm+qZQUVh0zTOxHDH1rmjsaNhn/ALivncDHNNsk+b6XFzy1rjh5AvoPCFQKoagEDVDCiphAIBAIGEVJrS44aMlQZEcIbvdvKKsPFAIrCqavGY4N7ubuQUGE
2BzjtO3k8SURcII+YOU0Jhuz3ppdg4O5Bm0U4ip3dY7AYVJhuJVS3CSoJYzMbO7iUiGZlU0BUWswiwz7dcKq31DaiiqZaaZvCSF5afhxXO1ItGpbraY7O+oekk1NK236
stVPdqT9YGBsre/HAnvGCvLbhdTvHOneuaJ6XhdUaEtmoqR9z0RdWyge1RVJw5h+jtHe09zt3es14i1J5csF8FbRzUl5u+KSKR8crCyRji1zXbi0g4IK90dXjnp0Vkqs
llUCIEDCAQCAQMFFMFQPKKeVFMFNCWVNKYKmg8ppUg5TS7SDlNG0g9TS7SD1NLtMSEc1NLtYJj2qcq7S67PE58VOVeZbT1k1M7ap5pYXdsby0/ArM021zt9Ra11LSYEV
7rMD5sj9sf0srE4oleaG/o+lLU0O6WalnH7cGD/RIU8LXY3EtrD0uVmP8as9HKe1kjmn45UnFtI1HZCfpHsFY7auGj45XHcXZjefi3Kx4Ex2lubesp02rOjt0jJXaUkg
kaQ4OZC3ce3c4JOO+tSkTqdxLdM1noSXe+GqiPfA77iuM8LHo7ePk9Vo1V0fnjUzt8YpAnuseh7xk9T/ACl6P3f6RmH7kn4LM8N8l94uY1D0fAZNzk/hf+CscNHoe8ZE
Xaq6PWbhXzHwjk/BWeG+Se8ZPVjS6s0Fv2ZKyT6sT1j3afRr3i3q0bbt0WxEkafqpT+3G4/a9emK5PV550sbrHQdLGYqXR+1Htbey5kYBdjGcEnfhXw7b3JzdNbA6Urf
SjFv0pSw44Eva3+q1a8KWdwxKrpbvT2kU9DQQ9mQ5/3hTwNkWiGkqukfVlQT/lNsLTyhha3HvwStxhqczRV2obrXZ9MuVXPnk+ZxHlnC3GOITnal0+/IAW4qzNkHTE8S
rypzIGRXScyJkV0ztAvV0bQLldJtHaKuk2iXJo2iXK6TZEqptAlVESVULKBKoSBFAiqhYQJAKoSAQJAkQkCQCBKgUCJQJAIEgEFaKYQNAIBAIhIpgohoEihAjwKCvCim
xxje2QcWODh7jlQe3MeHtDxwcA4e/evO7pIphQNAwEElAIJAoqQI5KCYDuOyceCKhLV00AzNUQx/XkaPvTUybhhTaisUP6S7Uuexr9o/BXktPknPHqwJtbWCPc2eeb/y
4T9+FYw2TxawwZukKgb+gt1TJ9d7WD71qME+cs+NHo103SJWH9BbKdn15HO+zCsYI9U8WfRgTa6v8mdh9NCP2IQftJWow1SctmBNqa/zZ27rUgdjCGD4BajHSPJmb29W
vnrKuoyZ6qeXP05HH71rUQzMyxwAN+B5KjJYXbI3qsyFUNAIGgaBoBAIBAIOr6M6T0zW9qaRlsT3Tu/caSPjhebi7cuGztw1ebLWGN0rV/p+uriQ7aZTbFO3u2Rv+JKx
wdOXDHzeji7byz8nHL1PMaIaBoBAwgYRUggaBIJMY9/stJRWTHTc3u9wUF4a1owAAO5VTOACVFYUtbA1+wwmV/Yz7zwUGNLNLUDYaMN5kICOEN471WVuEUkCQQlOywns
Qa6GQ5kaXe0QfJZVdFJsu3AuPcgyWunfwY1g7TxVFnVSj1hIHHs4IsBlSA7YkGy7vUaZLcuRXV6G1C/TV8griT6M/wDN1LB86M8feOI8FxzY4vXTrjvyy6Lphs8dLdIb
7RAOo7kMvcz2RLjOf3m4PiCuXC5OavLPeE4nHyzzR5vNSvY8oRAqGgEQIGgSKAoJIp5QGVAwimCoGEUwoqWUBlTQYcmlSBU0bMOU0p7SaNntJpdmHKaNpbSml2e2e1NG
xtntTRsxIe1TS7SEp7U0bPripyrzDrj2pynMl155EpynMiZ3HmU5TmLrT2pynMDMRzTlTmQMpV5TaJkParpNl1h7U0mx1hV0bRMhTSbRL1dG0S9XSbR2k0Ilyuk2C5NG
0S5XSbIuVNllNJtElNGyyqhEqoiSgSqEUBlEJUJAFAkQlQIEgSAQJEJAkAgRQJAIEgEBhAkFaKYQNA0CRCRTQHNA0CRAgDwRVSikd4I7VFexWKUz2agmO8ugZnxAx9y4
T3do7Ngdwydw79yyqiWuo4f0tZTs+tK0ferpNwwptRWSL27nTnuYS77Aryz6JzQw5dZWSPOxJPKf2ISPtwr4djnhgza7pB+ht87/AK72t/FXwp9Wedgy68qj+ht0Dfrv
c78FfCg55YUutL0/2HU8X1Yc/ar4dUm8sKXU1+l9q6TgdjMN+wLXJX0Tmn1a+atrZzmasqJPrSuP3q6iGdyxy0E5IBPeMqhgY4IJAHvRD2HdiGzEbu5NG0xH3q6NmGDt
TSbSDG9iaNpAAckQ1RJAIBAwgaAQMIBA0Ag9D6FoQ7VNTOeEFG4/xOaPuK8HtCf5WvWXt9n13l36Q83u1Say7V1W45M1RJJ5uK9dK8tYhxvbmtMsRaYCoYUVIIhooVQw
oqQQTbsfOLvcAgua+lbv2HE9+9FSdWRNHsux4IbUSXJg9iIk95wptWJLcah25jWM8BkqbFJhqqnfNI/Z7HH7kGRHTsY3Zxu7Bz8VTa8DAwOCIEAihAnENaXE4A5oMdrh
UtdjIZnGeZQNlJA3fsZP7W9NC8ADcAAO5AwEVIZUWDMbHjEjQQirGNdEMMO03sPEKLBufncPIrO2oev6Fmi1hoet0nWyD0ulYOoe7iG5zG791249xXz8seFljJHm9lf5
uPkl5NUQTU08tPPGY5onlj2H5rgcEea+lE7jcPmzGp1KlVkKhoGgEDQGEAFA0UIHhA1FCCQQCimgFFGUDyop5QGUDBQMFA9pQGU0HtJpRlTRsbSaNjaTRsbSaNltJo2N
pNGxtJpNjaV0bRLk0bIuTRstpXSbG0mgi5NGyyrpNo7SaCyqbLKIWVTZEogygWVUIlBElAKoSAQJVCQJAIBVCRQiIlAIEUAiEgSBFAIEgEAgSAQCBIK0CRTQNAFAkDRD
RQiEgEUHggqKihQZ8d4ukVMyliuFRHAwYaxj8AD3Jywu5Ycs88xzLPLJn6byftTQhgdg8kQ8oBVQERINJ5FNG0gwppNpdWeZV0bSEYTSbMMb2IbSAHIIBUNAwgaIaAwg
eEDCBoGgEAgaAQMIBAwgYQejdEbhC/UVRzjoM/Fx+5eDjusVj5vfwH3rT8nkzTlrT2jK9ryJIGqGFFNENAIpoJBAcUBstPJAjGwne1FAij+gEEmtA4NA8FBJAIBAkU0C
QY1btGncBy3pIhQOBg2ebXHKQMsFBLCAGMoqYUaSQGSorJo6kRO2J6dlTTuPrRPJHva4b2nvHkVi9N9Y6S6Uvy9J6w9A0fa5aK4U2otL1Lq6GE4q6CTDalkZ9puODxje
COJA3LxZb9OTJ0nynyevHT+rH1T6Y7UymucF9pWH0evGJTjGJQOJ7NpvxBXTg80WryT3h5+LwzSef1eaA53r2vEYVEsIBA0AgFAwimgeEDCijCKEDUAgaAQCihAIBFNA
ZRDygMoDKAyooygMogyqFlNBZTRsZTQMpoRLk0hEqmyJQ2WUTYyroIlNGyyiDKAygWVUGUCKIRKojlAIBAkCyqhIBAIhoAqhFAkCKBFAkAiEgSAQJAIEgSAQCBIBBWgE
UIBA0CQNAIgQCACKERWo0MZ5IGGHsQSDPBNJsbHemjZ7AV0bS2R2IbMBESQAQNENUNFCIEDRTRDQNAIBAwgaAQNAIGgeEAgEAgkEHd9GryKPVbAd5tbiPdtfivFxcdaf
m9vBT9/8nmLQAxvgPsXreaEkDVDCBoGopoBBJAIJBAIoQCgaARQgECQCCJAwc8EVr4tmnqXesdkjgBlQZJqmDgHOPcE2IdbVyezGI29ruKdRIQSO9qc58E0qYmng3Ss6
xn0m8kGVE9krdqNwIRVoCipAgIsMuhuVZb6llVRVD4J2cHsOD4d47lzvSt41aHSl7UndZevitGsujK51FdGyOeGN5c4cBJGA4OHZn7yvm0p4HEREPflvGbBMy8TDdwX1
3xTVDQNAKARQgkEU1AIpoGop4QGEAopoaCGiQ0ENHhF0WETQQCAQCAQCISAygMqoWUCyiFlAyVRElELKBIFlUGUQsobGUCygMqoMoBAiUCyqhIDKBZQCISAQCoaAQJAi
gSAQIoEiEgECQBQJAIEgEAgSBFAkEUUIEgaAQCAQCIEAihECAQNFCIaAQNA0AEDVDCBogUDVUIGiGEUYQNECBoGgEDQNAIGgEDQNAIEgkEHY9G0n+UbtSj/rFqqGjxAy
vJxf3Yn5vXwc/HMesPO2+w3wC9LgkEDygaKYQMIGEDQNFNECKaAQCimgECQCKECKCMnsnHJRWshcXTEuGSUhGfG3fkgKi4IJAb0WEgO1RpWYGbW3GTG/tb94UNLWOk4P
Az2jmgmipMG/eor1dv8AknoWcQdmS4PIHftvx/VaV4ojn4r8nqvbl4bXq8pJXvfNJUNAwFA0UYQNFAUU8IqQChoKKaLo0NGoaGEXQwhoIaCLoYQ0MIaBRNEhoIaJAIgV
CQCIEQlQiiaBVCRCKISoSBZRCQCoSISAQCIWVQZQCBIhFUCgEAgSoEAgaBIBAkCQJAFAIhFAkESgEAqEoBAlQKAQJAIIIoQJAIHlAkAgaAQCARAgEDRQEQ0DQNAIBA0D
QNUCiGFVCIaBooRDCBoBA0AgYQNA0AoBAwgaAKBIGFR0WhaptJqy2OecMlkNO/wkaWfaQvPxVd4rO/DW5c1XI1MLqeomgeMOikdGR3gkfcutZ3ESlo1aYVKsmgaKkEDQ
MIqSAQNAlA0BlFCBoBFCBIBRSQCKwZ4HRP62MZAO8diiTC1lXAR6ztk9jtyu0N1ZTj+Vb5ptUWXCnLw3aO/njcpsbAcFWjwop4QCCQJO4DJ5KD0/pUkFvsmmtPMdjqYR
LI0dzQ0fEuXj4KOa18j0cbPLWlHmK97wGEDAUDCKAgainhFACipBFNRTQ0MKNJYQ0MIuhhQ0eEXR4Q0WEXQwiaGENDCGiwiaGENEQqaJE0eENEQiI4Q0FU0SBIhKoFUI
oiKqBAkEVUCBIgVQIEgRQJAIgVCygEAgEAgEAgEAgSAQIoEgRVQZUCQCBIAoEqEgFAkAgECVCUEEUIBAIBAIBEMIoRAgECQNA0DQNAKhoGgEQ1FNVAgEDCAQCBhA0DQC
BhA0AgEEkDQCgYRTQCBFAwqhIJxSvhkZNEcSRuD2+IOR8QszG41JuY6wyNYiM6kraiD9DVFtVH4SNDvtJXHBuMcRPl0+j1Z9TkmY8+v1aRdnIwgkEDQNA0DRTQCBZUDR
QgEAimgFFCBIoQJRSQYNTTjiBuPwUSYYLoOYRECwt4hEZVFXPp8Mfl8XZzHgm1iW7imimbtRPDh9irSeUUIraaaozX6gtlHjPW1MYPhtZPwBXPLblpMt46814huuk2v9
P1pcC12Y6bZp2/ujf8SVnhKcuKPn1Z4u/Nmn5OVC9DzJBA1AIphRTRTCimop4RdGEU8KKYCjSQCLoYUXR4TZo8JtdHhRdDCGhhDRYVTQwhosImiwhoEImiwqmiwhoiqm
iwiaIhAiFURIRAiaJVCKIMKoRQRVQiiEqBEJUJECCKARCQCoEAoBUJAIGgEAgECQCBFAkQIEgECKoSgEEUAqEoGqEoAoIlAIIIoRDRQgEAgMIBAIGgSIEDxvQNAIGgaA
QNUNAIgQNFCIaKEQIpohoBA0DQNAIGgYQNQPCKeEEg0kbgoEQUBjuVAGoDCIOCCV0d19DQTfPhDqZ31Qdpnwc4e5YiNWn5u290j5dGrWkNAwgkgEDygYKKaAQCigIGih
AlA0UIDKKMoEopIBFRcMjBUGO+IImmO+JEYj2kyhjRvO5EbuhgbDEABlx4ntVaiGUAipBFdh0ZiNmpXXGYfmbdSTVTz2YbgfavNxM7pyx5y78P0tzT5OVqJ5KqolqZTm
SZ7pHHvccn7V6ojUaeCZ3O0AqJBQPkinhFPCipYUU8KKMIpqNJBFMBRdJAKbaiEsJtYgYUa0eFNro9lNmjDSm10eO5Nmhsps0WO5Nmix3JtNFhNpotkq7NDZKbTREJtN
IkFVNFhXaaJNoSBHxCqaROO0IyRx2hVCJHaPNAt3aPNEIkdo81WSJH0h5qiOR9IeaIW76Q81Ukst+kPNEGR2hVC3dqAQLB7D5KoWD2HyQPZcfmu/hKbNFsPPBj/4SmzR
9VJ+qk/gKGjEMp4QyH9w/gmzUn6PP+ol/mz+CbNSDT1H/d5v5s/gmzUmKWpP/V5v5s/gmzUovhmjG1JDKxva5hATZqVfeiBUCAQJAIEUQkUIhKgQBQRUCVCUAgSAVAVA
FAkCwggihAIBAIGgMoBABA0CQNENAIGgEAgaBqgQNENAkU1EAVU0QIBA0U0Q0AEDQNBJAwMqKkAVBsbPabjea1lDbKOWqqHb9hg9kdpPADvKza8VjctVrNp1D1uydDLO
oZLfbo7rTvNPSYDR3F5G/wBwXjvxmvuw9NOGme7raTo70RQtHpFjEg/WT1LpPhkfYuccTee0t+71gVOkujR42XW6zNz9GYtPwcpbLm8trGPH5sB/Rt0f1u6lDoXHgaau
J+BJUjis0dyeHpPZp7n0K05aX2u+zM7G1UAcP4m4+xdq8b6w5Tw3pLj7j0VaupCTBT01ewc6aYbX8LsFdq8VjlztgvDjrpaLla5OruVBU0j+yeIs+J3Fd62i3aXGYmO7
XysJp5G8jhw8R/yVZWs+TWlGwgYQSQAQNFMIGoDO7eijOeCAQSRQVFJAZRRlAlFCARQgFFJBEhBB7BglDTEt8ZkmfMRzwEhiG4aMYCrSWVFMIOss+zQaIvlad0tfNHQR
H9keu/4YC4WjmzVj06ukzy4bT69HLEL1PGYQSCgYRUlFARpJZU8IoCjSQCLo8KNaSAUWIZNJTS1Mwiiblx3kk4AA4knkFi1orG5dceO17ctXSUVssUcZNdPNM4DLi13V
sH3+a42tk8ntx4+Gj707/aETU9H8bi18lW4j9W57h54VinESWyez485/dMV/R2Bwrz7pE8PiGfH4D5/uRuPR4P5KuPuk/FPD4hfePZ/z/cG6dHo4U1af3X/inhZ/knvP
s/0lA3fQH/cq0/uu/tJ4PEesL717P9JI3nQQ/wBHVp/dd/aTweI9YPe/Z/4ZRN70IOFprD7j/aV8HP6nvns/8E/9/Uvl7Q3/AMlqj7v/AOyeDn/EnvnAfgn/AL+o/KDR
A4WGpPl/aTwM/wCJn33gv7cj8pNFD/s5OfeP7SvgZvxJPHcH/bkjqbRvLTEp/eb/AGk93zfiT37hP7ZflTo/lpR/8bfxT3fN+I9+4T+0X5U6RHDSZPi9v4p7vl/Ge/8A
C/2kTqvSw4aRZ73tT3fL+M9/4X+1/hH8rdN53aRi/ib+Ce75Pxn8Q4b+yPyv0+PZ0jTnxc38Ffd8n40/iHD/ANpH8sbLy0lSD95v9lPdr/jWPaOD+zBfllaOWk6P3ub/
AGU92v8Ajk/iOH+zAOtLaPZ0nQj94f2VfdrfjlP4lj8sUf8Af0Q/LWh5aWoB7x/ZVjhp/FLE+0az/wDFA/Lal5aYt49//wDVa93n8Uuc8dH4IROtoeWm7eP+fqq+B/5O
c8Zv+iB+W7B/2ft/u/8A8TwPmz73/wCMIu1v9Gw24e7+5XwfmzPEz+GANcSYwLHbx7j+Cvg/NmeIn0gjrmflZ7ePcfwTwo9U8efRH8uavlaqAe4q+FHqk5p9COua0jdb
aEe5yvhQnjSX5cV/Kgoh7nJ4UHiyidb3HlR0Q/dd+KeFCeLKJ1tc+VLRj9134q+HB4sl+W125Q0Y/cP4qeHB4tkTrS78o6Uf7M/ir4cHi2I60vPJtL/Nn8U8OE8SS/LO
9dtMP9kfxTw4PElH8sb19Kn/AJr+9Xkg55I6vvR/lIP5r+9OSE55R/Ky8/rYf5v+9OSDnkHVV4c0tdLCQeIMIIKckHPLVTVBnlL3RxMJ4iNmyPJaZlFVAgECKISKEQKh
FQJUCBFERUUlQIBAKAQIoEUCQAQQRSQNAIBA0CQNENAIBAIGgSCQQCAVDQCgaoaARDQCACBoBFCIaBhFNEAQSAQMKBhFTAUHUaH0ncNV3P0am/NUsWDUVTm5bE3sHa48
h7+C55csY43LeOk3nUPpKyWSz6YtfotvhbBA0bUkrz68h+k93M/Acl8vJktknq+jjxxWOjmr9rdo26e0tBI3Gdw3e4Lvj4XfW7nfPEdKuCrKuqq5TLVVMkzjze7K9laR
XpEPLa026yxJWiQcBtdq2wxNkNPsgEI0zKa5XClwaauqYcfQlcPhlYtSs94ai0x2bui1xqKlwH1bKlo5Txhx8xgrlPDY58m4zWhv4OklssXU3OzsljO5wjfkH91wwuc8
NP8ATLUZYnvDAqaDoy1E4mSlFsqH/OZmn3+7LPgsx7xT5x9WuXDb83hmqbVBab9W0dFOaiiZIfR5jxfHyz3jeF7qTM1iZ7vPaIidQ1C0yYQNA0AEU0DUUHON3FBjSRVE
Mccz45I45Sdh5aQ1+Dg4PA4KztdBsrxzz4q7FrZu1vxQ2l1rewouzMrOw+SG0OtBOAPNRdpA5J7EVJAIoUUIp5QJAKLpGQZjcBxwU2TCNvAEEfhlac4ZgRTCipDA3lB2
VTSx1fRrQV1K52aCukjqGdhkAw74N815sdprxE1nzh1zRFsFZjycgvW8SQCCQRUgooRTCjRqKaKkFGoSAUaiDwo1EJhZluIZzpzRWyMs3SVcjsn/AFbMDHvcfgmOvPfc
+X+7ea/hYI13tP7R/wC2lulwkmAgBIjG9w7SvRFYjq+da826NZnK0wEAgFUCAKAQCgEBlUGUAUAoBFJA1FGEBhFSAU2uiIQ0jhVNBEIqoEAiBAIAKoaKSIEUKAVQKKFQ
IhoBABRTHEIL1UCAQJAkAiEVQigSBoBBEqISoSKaBIgQJRQUCVC5qCARQgSBhA0AgSBogQCAQMKhqBIGEDQNAKhogRQgaiGqBAIBAIGEDQNA0DQMIJBRUgoNnYbRWXy7
UtqoGbVRUP2QTwYObj3Ab1m9orG5arWbTqH1RYLTbtL2OK30gDIIW7Ukrtxkd857u8/DcF8nJkm9ty+jjxxWNQ4LVepJLtK6ngcWUbTuH0+8r2YcPL1nu4Zcu+lezlTj
kvS86BBVCwgqmZkbQG8cUVjlAIEoE72TjsQaK/0Lqui6yMZmhG03vHMLUI4oHO9USQNABA0U1AIoBRXtvQdcbfdLVcdH3WngqW7ZqoIZ2B7XtIAeADzBAPvK8HFVtExe
r0YpjtLqLx0MaQr9p9Eyptcp/wC7v2o/4HZ+BC504i8d+rVsdZ7OMufQXdIsm2XuiqG8m1EboneYyF3jiq+cOU4p8nNTdD+uo3HYt1NOO2KrYftwtxxFJZnHZi1HRZre
nhkmntEcMUbS58klXE1rWjeSTtbgr49PU8Ozh44yHEnB5DByCuyRGluEUZUVVMSAMccoSlG8PHYeYRYTRo1AIowi6MBRYhJkTohtAeoTkdytZ3DneOWdeq4EFVkwilzR
Hd9Gbm3B160vM4dXdKRxizylZwPx+C8vE/DNckeUvTg+KLY583GPY+N7o5GlsjSWuaeRG4jzXseDWugCCQRTUDwo0ajR4RYSAUaSAUlqISAUbiEwFlqIPGN5Ub0nfj1d
RTUv/d6ZjT9Z3rH+sF04f7sz6yx7RnV64/w1j9+rm3nac53aV3fOJAIhoBAKoEUIgRQoBVAgEUKARQgaimEa0eFmZaiHb2OwWmksjb3qMv2JSOphGRkHgcDeSeOOxePJ
lva/Jjfc4bgsOPD4/E+faGLq6yW6Ggo71ZNr0Go9Vzck7LuR37xwIx2q4M1ptNL94c+P4PFXHXPg+7LkCF7NvjzBEKsyRRklUCIEAqBA0QIBAkAihAIhoBAIBFSj3uCI
uQCAQLCIECVCKBKBFAKgRCKBFAkU0QIEgFFIqiJQJQQCKaBIBA0AgEDQCIEDVAoBAIGgaoagFQ0AgEDQCIEDCAQCgaoYRTQCiJBBIIqQCCxrVB9EdDelvkayfLNXFi4X
Boc3aG+KHi0eLvaPuXzeJy7tyx5Pdw+PUc0snXl923OtNM/1R+mcOf7K1w+L+uVzX1HLDgXL2vKjhEIhULCKeFBiSs2HEDhxCKqKqBBF49R3ggxs7gg5LUFt9Gm9Kib+
YlO8D5jvwKqNKqGgAgaKFFCBhRWbbK6qttbBXUU74KmB4fHKw4LSFm0bjUtxL6B0l0v2ivhjp9Q4t9YBgzhpMEh7d29ngd3evDlwW71dq3h6LTXqz1UXXU91oZY8Z2mV
LCPtXn5LecN80NJetfaTsrHOqb1TSSDhDTO6557sN+8harivPaFm0PCukLpIuGrA+gp2OorRn9BtZfNjgZCOX7I3eK92LDFes93GbbeekLuwSAworqbBoe66i09WXa1t
EstPP1Xo3AyDZyS09oyN3Ncb5q0tyy6xim1dw5OopJqWd8EzHxTRnD43tLXNPYQd4XSLRPVymswiJCNzh71V2m2Rh+djxRYmFgweajRgIrMo4BIXPkyIoxl5+wDvK52m
d6jvLtStYib27R/3X6nU/nIpdwGWncOS9ERERp8695vfmlrKIYc4HfuzvWW4ZoKNHhFbPT1wdZ73Q3Nv/V5mvcO1vBw8iVjJXnrNW6W5bRLfdJdvbQ6tqpYAPRq4Nq4i
OBD/AGv6QPmscLfmxxvvHRniacuT83LNC9DgaimEEwo0YCjRgKNRCYCjUQkAo3EJALLcQmApLcQvpIPSKqCD9ZI1p8M71i9tVmXbDj571r6y1l5qPSa+tqRwklcW+GcD
4AL1Yq8tIh83i8vi5739ZahdHmGEAiBAIBUCBoEiBFCAQCAUAimophGtJALLcQ6DR9lN5urWSNJpYcPm7xyb7/syvPny8lend9L2fwvj5ev3Y7/8MzXF2bcbmKWnI9Ep
MsZs8HO5nw5DwWOHx8tdz3l6PafE+Lk5K9q/5bHRoju1luenJ3jLm9bTk/NP9zsH3lc88cl4yQ7cBPjYb8Pb9HCTRSRSvjkbsvY4tc08iNxC9tZ3G4fEvSazNZ7wrwtQ
4zCJC0yWEZ0SqBECAVDRCQCAQCAQCBoBAIoUFkI4lWElYiGqEoBAlQkCKBIEgEAgSBFAIgRQgFECoRUVEoEqK1FCAQCBoBA0QIBFARDQCAQCoYQMIGoBA1QIBQCAQCBh
UNEMA9iKagNw5jzRD3do80FjY3u4MefBpKLqVjaeY8IJT4Rn8FNwupWto6r/ALtP/NO/BTmj1OWfRP0Kr/7rP/NO/BOaPU5Z9HVdHempL9qilpKqnlbRRfn6kuYQCxvz
d/0jge8rllyxSu9ulMc2trT6N1FdIrTa5J2gCQjZiaO3l7gvnVr4ltPfMxSu5eNSvfJI6SRxc9xJJPMr6cRERqHgmZmdyrIVQsIDCKWEAgrqGZj2scEGGQikqIv3tI7k
GK3gPBEKaKOaJ8MrQ6N4w4IOGudDJQVJjdl0Z3sf9IfitIwggaKEAopoBRUgVGkw4jgouy2h9Fvki7G1yG7wQ2WUCyqEoJN4qNPb+gW6UzaO6WZ8gbOJBUxtPzmloa7H
gQPNeHi69Ys9WCfJ3+o9MWHUTf8AKtujnkAw2ZvqSN8HDevFTNbHPSXqtiraOsPOLr0L0crnOtd6ngzwZUxCQfxDBXprx0/1Q4W4SPKXCat6PazS1I2qrrxbpOsOIYo9
vrJTzw0jgOZ4BerFxEZJ1ES4XwTXvLkmDYGAu7EQy6OB9RMyJjcuccALF7RWNu2LHN51DOrHRNDaanOYYzvcP5R3N3hyHd4rWKkx8Vu8vPxWaLT4dPux+8+v/DE38O1d
nla6m3TAdxCy6wzsKNhFSHeoPQbwPlzo3tN2HrVNqlNHOeewcAE/0PNeXFPJntTynq75o58MW9HCL2PEaimEEgo1CQUahIBRuITAUaiDAUdIhNoWZaiFoG5SXSIZtvxE
6oqz/wBWp5JB9bGyPiVyv8Wq+svRhnk5sn4YmXK1G6MN719F+fYxQCIEAgFQkQIpohIBFCAQNQJFCjRhFiEgstRC2GN8j2xxtLnuIa1o4kngFmZ07UrMzqHodxeNJabj
ttOR8pVYLpXt4t+kfd7I968FY8bJzT2h+gyzHBcNGOv3rd0NDabtl3t09ZcGSSOEpjawPLQAADndxO9az5rUtqHDgeDx5aTe8b6tJUbGm9XyGhe91PSzbJDjklpA2gTz
4ldI3kxdfNx6cNxW6don/wDq3X1vFPc23CHBp65vWBw4bWN/mMHzU4W+68s+Tp7WwRXJGSva3+XIOXsh8W0IqsTAKrKKrJIgRAqhoEUAgEAgMoBFCIaARQoLoh6ue1VJ
TRAgSBZQCoSCKAQCBIBEJAIEgEAgWUUZQJAioEqK1FCBoBAY3IBAIhoBFNVDUAgEAgaAQNAIBAIGgEEo2PlkEcUbnvPBrRkn3JMkdXQUOkrzVAOfFHTNPOd+D5DJXK2a
sOtcVpbun0CMA1F1HeIofvJXOeI9IdI4f1lsYNC2luOsmrZf3g0fALnPEXbjh6M1mldMwDM0AP8A51SfxCnjZJa8HHANHoql9qO1NI+nIHH7Sm8s+qcuKPRA3TRtP7D7
aMfQh2vuV5cs+qc2OFR1XpiL9Gf5ul/uV8K54tIQdriyt3MZVuHdCG/engWPGqqdry3j2aWsP8I+9Pd59Tx4VnX9P82gqD4ygJ7vPqe8R6If4QmDd8nS/wA8PwT3b5nv
Hye0dGbX1enI7zPTugfXEvYxzskRA4affvPkvHnrEW5Xox2m0baDWlx9NuZgjdmGD1R3nmV6uFx8td+rhxF9zy+jmSF6nmRIQRKBIoQCKDvBbyO5BrXbiQeSAVBxUGGz
2AqAoiirpYauB0MzctPA8we0IOGr6Z9FVvpnnJbvDh84citCgIGgFFNAIoCinlRSJRQgAimgAopgqLDLoK2qoKuKsop3wVELtpkjDgtKzasWjUulZmJ3D2TS/Sk+qp5G
XS3NdURBuZKd+ztg7idk8N+OB5r5uXhOWfhl9DFl54n5Me+dMJHWwWe1M2wSGz1Em03xDRx95XSnB+dpcr54idQ8mu10uF3r5K+5VUlTUv4veeA5ADgB3Be2tIrGoea1
pmdyxWDaOCrJWNtk3/FYnRsP514w8j5o+j+PkpSnNPNPZM+bkr4dO89/+P8AlRvXd4TQa4DYqiOxxWZdas3CjoEUwoPQui9zLhFfNMTuxHcaUujB5Pbuz8QfcvHxXwzX
JHk9WDVotSfNw0kckMj4pWlsjHFrweRBwfivbE76w8ExqdSSIYUaSCLCQUbhMKNwkFluITAUluIWNCzMtxC1rVmXSIW1buosVS7nUTMhHgPWd9yuKN5Y+S8Rbk4W0/im
I/3lytS7LwOwL2vhqUAiGqEUAiBFJA0QIoKBIGEBlQCNBRYMKNwm0LMt1h3WgrbBE2fUNwIbTUgPVZ5uHF3u4DvK8fEXmf5dfN9v2bgiIniL9o7NBe7lLdbhNWyjBecN
Z9Bo4BdsdIpXUPHxGec15vL0Ho33afJ+lUvP2BeHivvvt+y4/kb+cvN7rVGe610+c9ZO8/0ivdSNViHxM9+bJafnLrKAHUOiJ6HG1WW87UXaQN48xkeS81v5WXm8pfSx
f/7XBzjn71Xn5C90PgTCJWnOSKrMolVklUNEJVDRCQCAQJQMKgQCARTQCgyGjDR4KsmgRQJUCBIEgSBoEiEUUkQIBAkCQCKECQJAioAIK0UIGgEDQJAIGiBA1Q0AoBAI
GgEDQJUNQCAQbW0Wp9a4SSuMdODvdzd3D8Vmbaaiu3aULaShj6ujhbEOZG9zvE8SuUxM93WJiOzCr9TRUjiyEmaUcQ04aPEpGPZOTTSVGrL1NkMqRTtPKJoB8zvW4xVj
yZnJZq6i4V1Qcz1tRJ9aVx+9aisR2hibTPmxDvOXb/HetIXgB5IHk9qKSAyoHlAwVFbnStkk1FqCgs8eR6TKGvcPmxje93uaCs3tyVmy1jmnT6uu8sNnsL/RmCOOKMRQ
sHzQBgDyXyq1m9tPob5a79HkT3FznOccknJK+pEPDM76oFVlAoIkIqOEAihAzwUGvqBiZ3fvVFaBoMSMbnD6LiPigeMIEUGk1FbvS6br4xiaEEgjmOYViRx0UrXHYd6s
g5dveFraaWqARQgaikimikoGimihQLKKaijJRWbby5sde4HGKR4Pvc0LnfvH5u2Ofvfkw1tzMIrLgYWeufa5dysU33c7ZtdKrF0eYKAQYFQNmod4gqS617MwcFHUKARW
50rcTaNQ264ZIZFMNvH0Dud8CVyzU56TV1xW5bxLf9J9tFv1XUSRtAhrWioYRwJO53xGfeufCX5scR6M8XTlyb9XHhel5kgimFGkwo3CYUbhIKNwsAWZdIWNCzLpEL2B
Yl1iFWoHFlLbaUfq3zu8XOwPg1deG6za36PP7StqmOn5z9XLynMjj3r1vkIIGEQKgQCIECRQgaBIBQCARQophRqEwCpLpEM+026e5V8NHTj15DvP0RzPuC5ZLxWu5erh
8Fs14x183T6zr2U0UGnaD1aamA63HN3Ie7ie8rzYKTP8y3eX1faOatKxw2PtHdybCDxXrfHeraJkhp9GuqHOaOrMzzvHJfOzxvLp+h4C/Lwu/wA3lL8ceZ3r6D4My32i
rn8nXyHbdswVH5mTPAZ4H3FcOIpzU/J7PZ2fws0b7T0U6ytXyXfJ42N2YJvzsXgeI9xytcPk5qMe0OH8LNOu09Yc64L0Q+bMILTEkVWSVZCIaISoEQIBAIBAIGgECUVJ
oyQFRklGS5qgQRKAQJAFAkAiBAkUkCRAgSBIBFBQJAkAVABBUihA0AgEAgaIEDQNAIBAIBAIGgEDVAoBBl2+m9Jm9fdE3e7v7klYdK2YMaGtAa0DAA5LGmttRcro+TME
LyGcHOB9ru8FYhNtQStISAQCAQBQJAIphQMIPbv+j/YsfKGo5mbz/ilMT7jIR/RHmvBxeTWqvVw9NzzO56QK31YKJp/bcscLXczZ1zzqunBOXveNBEIoFhFIoIlFIIGo
MCs3Tgdrc/FUUhFSyiMeIZmnb+0D5hFhJzEEC1ELgg8/1Ja/Rqwlg2YpCXxOHzTzCpDURVT4ndXUA7vnBIn1NM1j2vG0xwI7lQ0U1FJA1FCKAgaKWVFCBooCgzqL/Mrm
7G8QNH9MLnf70O+P7tvy/wBxarXcbt6R8nUU9SKdhkmMTC4RtHEk8vtWptEd3PfTabKbq9+5zu3l7luI0898k26JYK05jCAQCDBrB+e8WhZl1p2ZEZzG09yOsJKKYQTG
Du7VFem6nHy90c2e+D1qmgIhnPPHsH4hp968WH+Xmmnq9WeOfDF/R5sF7ng0kEWEgosJhRuEgsukJtCktwsasy6QtYFmXSIZEbC4hrRlzjgeJWJl1rG+jC1RIPlmqY05
ZThsLfBjQPtyvTw0axxPr1fO9pX5uItEeWo+jms54ru8AVQIgVCQCARAgEUIDKgEAihRV9HSy1UzIo2Oc5xAa1oySTyCky1D2ix9CNdPQxz3S5w0UzxnqOrLywdhOQM9
y5zZuKzPZm1PQaTE/wBF1BC6bHqtdAQCe8gnCzzOmpjrMOOooDo23109ZG0XZz3QNjJzsEHGPhk+5ea+8t+Xyh9zheXheHnNP3rdnDTSOle6R7i57yXOceJJ4leqI0+V
a02ncqHjAJ7FWHfR6QpG6adVPnlFaafr9va9QbtrZx2Y5rwzxE+Jryfcp7Mp7vzTPxa38nAZ2t69z4Qy7kkkS768O/KHRVPctnarKLdLjicbnfDDl4qfy8vL5S+7nj3r
goyR96v/AGXnj174fnrK1pzkiqzJIyFUGUQKgQCBKACIaoEDQCBKKsiGXjuVSVyISoEAgSAQIoEiBAIpIBEIoEgEVFRAqoQJAuaAUAgqRSQNAIGgAgYRDQMIBAIEqGoB
AIGqGoBAkAg3dI3qYGt+cd58VFRragxwkNPrO3BFahUJAIGgWUQIoQGUAoAILI2ve9rI2l0jiGtaOZJwApI+rbHTRaT0varVu61pipt3z5nnLj5lx9y+PaZyXmX1aVil
IhyOo6w1d2qZM5aHFrfAL34KctIePPbmvLUFd3AsIFhFJBEhFRIQJA0GvuO6anPbtN+9BQDvKKllBXHurXD6cefI/wB6EMlzFFUPZgoivYVGJdaBlfRPp3YD+Mbj813J
DTzSrgcHvilaWSMJaRzBVnqMAdbA/cS09o4FZ7DLirRjErfe1XYy2Ssk9hwd71VTQCihAIpooUAihRWXR0VXWOxT073j6QGGj38EHXWbTrWU1UK14f1jGgxxndxzvP4L
Fo3MNVvMRMQ9l6NLxRwUsdhNPDSuZ+gMTAwS9x7Xd/NeTPjms80dm6Wi0alyHSzogW4y6gs8GKF5zVQMG6Bx+eB9Anj2HuO7tgz83w27uGXFrrDybivU4jCAIQLCqMOt
b6zD3EKS60TgOYh3bll1hYimoqQUV6d0XSRXO13vTNQRsVEfWMB5ZGyfI7JXh4r4LVyQ9vD/ABVmkvO5oZIJpIJW4licWPHYQcFe6J3G4fPmup1KIVTSQUaiEgo1CQUd
IWtWZbhY1Zl0iFrVmXWIbOzBpuNO5/sRuMrvBo2vuXLJ21D1YIjniZ8uv0cfWzOlMszjl0ri4nvJyvpRGoiIfmr2m9ptPmwFWQqhIgVAgSAQCgEAgEDRRzRXc6B0BddX
maSk6qKmgID5piQ3aO/ZGBknCxNtNRD2LSuhbboKGq1BfpIqien/AM36ppOye0Aje8ncOxcMuWKVm0vZwfCZOKzRixd5/wC7cNd3an1zqHrIaWdznerDC0ERwszzJ3Dv
J4lfBtfLxGTpD+pcNTgPY/CctrR07z5zP5f4h6lpfRrNG2ypur433K8MhccMOAN2dhmfiTvK+pg4aMUc09ZfiPbHt63tC3hUjlx7/WfnP/D581ML1frzJViPresJfhrg
AC45O4rrTJWsTt5M3D5svLXHG4iGHHpq+Ef5l/8AuN/Fa95xerMey+K/D+8L2aVvjv8AqJ/nG/invGP1X+G8T51/eGymtmtH235N2ZDSY2djrGez2ZznHcuUZMHNzeb0
Tg46cfheX6NL+SuoAd9vd/ON/Fdfecfq838M4qf6f3g26Yv3O3u/nG/invOP1P4XxX4f3h1ukaCttNHdH3eNsFA6Lac1zwSSAQTu7t3kvPmvW8xyd30eBw5eHrfxo1V5
nIGg+qCByyvow/NWVFahzklWSKMlgqoEQb+xAYPYgMHsQGD2FAw13YUD2XdiBYI4hA0CVQIq6EcSkJKaqAoAoBEJAIpIEiBAIEUAikiEUCQJRQqgUCRSQCoOaCpRSQNA
IGgEDCIaAQCBoEgaoAoGgEAgEAgtp2h8zARuzlBtMqK19Y/amxyaMKqx0AgSAQNAkBlAZUCQMKK7zogsnyxrOmmlZtU1vb6VJkbi4HDB/Fv9y8/FZOWmvV1wU5r/AJPW
NXXdrta2W2tdllFtVUv/AJhY4t8gPivPgx/ypn16PRlyfzIj0c4/f6xO87yvbDyTO1aqAoEijCBFqikWoulZBCuzRIjX3g7MMMn0ZR8UgY0Zy5/ccfBBYiq/ZrqR3Jxc
w+8IebZuZu4LO2tKXR5Q0rdGrtNKywoOY1XZ9pnylCz1mjEwA4jk73c1YlJhx0sQc0gjctI18sDoycesPis6VQDg54FZFzKqdvB+0Ox29XattRMlqIeseAzPs9/etRCT
bTIFLLnDQCmjmhF1NUA/o/io1uGyh09dpAD6M0AjOTI0KLtls0tcSfWdTs8X5+wKbXbNg0kwYNRWE90bMfEps22dNYrbTEFtOJHD50p2v7kTbaNaAAMAAcAOAQZtK0Cn
nfjj6o8cErFu8N17SpjnLXh7SWuByCNxBW5jbETp6vo/UcV6pzQV5YasMIIcMiZuMHd9oXzsuLktuOz1VtFoeVdJuhTp2qNytkZNnndjZG/0Z5+af2TyPu7F68ObmjU9
3lyY9dYeduGF3c0MKoEGLWj1WHvSW6IUx3OHesu0L1GjRTCiuk0HcfkzVNvqHOxG9/UyfVfu+3C4cRXmxy74Lct4bTpMtvoGqZ5WsxFWNE4xw2uDviM+9Thb82P8meKp
y5N+rkML0PPowEVIKNwmFluFjVJdIWNWJdIXtCy6QymuMNsuVTwIhELT+084+wFSsbyVh1vbkwZL/LX1cfVHGy33r6D86xsogVQIgVCKBgF3AKbFnUSngw+SbEXRSNGS
0j3JsV70VYyGR59VpKmxktt9Q4ZDCm10rkpZY/abhNmlGQHgFSVfRPRuyap6HLrT2l7hcBLMcRnD9r1XDGN+S0bl5eJi047cvd9T2PfFTjcVs33d9d9v1clpXXN40/cX
1FTJPcIHsLHQzzuON+cgnOCviYeKvjtuer+m+0fYXD8Zi5K6pMTuJiI+nl0bLVPSPdNRMhoqKnfQQB4OzDK4ySu5DIxu7gtZ+LvljliNPL7M+zfDcFM5MluedecRqP8A
vq7G1TT6F0Jcb5qCplNdVNxFTzSlzgcEMZgniSST2DwX0uCw2pTd+8vxv2i47BxPERTh4jlp5xGtz5/p6PnGO63Nj9mCtmYM8ivXOOk94fJpxWWvSLS3dum1PXSNhpau
tmldwZG3acfcAsThx+jvHtDiPxy66j0f0lzNDxBcGN/1r2sPkVnwcfofxHP+OULlp/pGt8TpZ6e59W0ZLowJAP4cp4NPRf4hnn+tx8+ob7E4tdc6kEHBBI3fBXwMfov8
Q4iP65Y51Heyf/ilQPePwV8DH6J/EeJ/HLbWq36r1ftUtG2sr2x4c8ZAY3sydwWq46U6xDjm4zNljV7bhtR0Ra1k/wBGMb9aoYPvXTmeSWm1F0f6k06yOW6UOxDIdlss
bw9mewkcD4qxZiYbex9FGqLvQRV8VLFDBKMxmeUMLh2444SbaTUtszoS1MeL6BvjP/cpznKup+g/UT5XNlqKCJjcYeZC4O8ABlOc5Wc3oJuh9q60Q8GvP3JznKtb0E1n
zr1SjwhepznIuHQU/Z336n2v/Tu/FOc8OTZ0H07Gj0nUcLH/ADgINw83KTkarhtbtC9vQ1YWD89qhnujYPtcp40erpHCZZ7Vn6SZ6J9Ix/pdWMH70Q/9yz49fWHSPZ/E
T2x2+k/8GOjHQYGHatafCeEKe80/FDf8M4v+1b/8z/w4LpR6P4tKRUVxt9cay21hLWPcBtNdjI3jcQRvB7l3pfcPDkxzSZrMamHmnNdHMKoEF8Ywwd6IkqGgSARCRQiE
gSKEQIEgSBZQCBIBAkAikoBAkAgpRTQCBoBAIGEAiGgEDQJA0AgaAQJAIGgyKL9KT2BBnZRWslOZHHtJRUEQIoQCIWUUZQCAQCgYUH0H0L0ENm0VU32rGx6Y907nHlDG
CG+Z2j718zip58kUh9Dhq8tJu4ynuEtx1PJcZs9bUvkeR2ZBwPcMBfQrSK1iseTxzbmtMugO9VEUAgSB4UUYUVIBRpF0eRuTZpQ5pB3rTMwwLy3at8h+iWn4qwjApcui
LvpElJWF+EGPWu6uJkw/kpWu+KJLoXNBO7hyWHRWWdyCsx5QRMeERi1UkULS2d8bQ4Y2Xn2h4KwPONQ251uq/wA3vppSTEeztafD7FvaaarZDuKIrfTNfxaCmhdRWoSy
bbs9U3iO09iaSW6ZG7aDGtyeAACu2dNtDRGOPeMvPErMy3yotpC6VjSPacB8U2adcQBuAWWiVElAblAbkGxpZKc0TxJKxjo3ufsni8FhaAO/OFzvE83R2pMcs7ahpIAB
XZxZNJUS01RHUQSOjljO01zeIKxasWjUtVtNZ3D2PT13otU2mWjrYY3ymPYqKd4y2Rp5juPwXz70tjt0encWjbw/pF0XLpW4sfC8y2ypJ9He4+s0jeWO7wOB5jvXtxZe
eNT3eW9NOMwF2YRwqjHrB+Zz2EKNU7sanPrEdyjvVkqNGimoJsJBBaSCOB7CpLcPWtbNF+0Nar/GMywta6Qjsd6r/JwC8GCZplmkvXxFYvji0PLcb173gMIsGFGoTAUb
hMLMukLmBZl0hewLEusJXd3VWWnh51FQ6Q/VYMD4krfDxvJM+kOXH25eGrX8U7+jkqo5lI7Bhe18VQiGqgRAqBo2iApKw9k6LtC2Kr0/Waq1SX/J8Di1kYcWggYy443n
ecABccmSKRuXp4bhsnEZK4scbtPZ1Ak6GYjgUpdj/VzFeP3/ABev7PvR9lPaU/0R/wDqGTQUvRDfKyG10lrDqipOww9XKzfj6Wd3BapxuO9orEuPFfZvjuGxWzZKxqO/
WHkOu9HfIOra200bny0zC18Tnb3bLhkA9pHBeyLPgzV6jYtN6X0Jpakumqrc2tudW4fmnMDzHkZ2WtJxuHE9pwvPn4iuKNy+n7M9lZuPyTTF5RuZntDMZrvo/jH5vSuP
90i/FeOfaWP0l9+PsZxv46/v/wAM2x6i0dqi5x2WHSMWJ2u2nSQRANaBkk43+S6YeNjLeK1h5faH2azcDw9s+S8TrXSN+bwXpBsVPZtY3S2W4ufSwTYjycloIB2c88Zx
7l9DfR+Y09k6LKc6J0NW6ovD5G+ltaYaXaxtNG5m76TifcFwz5Yx1m0vd7O4HJxvEVwY/Pz9I85c7d9Y6cuk76ip0RSmZ5y57apzC49p2QF8W/EYrzuadfzf0vhfYvG8
PSKU4qdR/wCMT/lttCaqs41DQUNDpGhpHVEoj9IErpJGZ5guC7cNmpzxFaRG3g9s+y+JnhcmTLxFrcsb1qIifo5Lp4r7hUa4ntk9S99LTMYaeHg1gc0E7uZJ58V9mH83
WdGXRrLf2C63N7qW0MJzJwdLjjs54Ac3KTOu7URMzqHfV2vdN6Uida9I2qGYs9V0+cMJ7dr2n+PBfNze0K1nVI2/Y+zfshmz1i/E25I9PP8A9OSrOlDV1Q8ujq4KZp+b
FTt3e85K8VuOzT56fpsX2U9nUjU1m35zP+2l1s6VtU0soNVJTVsfNskQYcdxbhapx2Wvfq5cR9kuAyR8ETWflP8AtLfasoNPa70PXasjoTbblRMe58pAAkLQCWkj2wc7
jxBX1+Hz+LXm0/Ae1vZt/Z2fwbWifOPy+ceT59YxskoaO1eiXzNvoq0GTRfQ7FV0jhDcq5wka/AJ2nndx7GBeTi8048czHd9j2BwNeN46uPJG6xuZ/L/APrhj0gav2vW
vk/ua0fcvje+Zp/qf0f/APx72ZEf6Ufv/wAvaNNQm7aDpJdUVBqRPiqldPgAMDtpoP7OAD719nh72jFFrz1fzf2zgxfxC+HhqaiJ1ER5z/8A15hrPpFulfdnMsFbNRW6
H1IzEdky/tHu7ByC+ZxHG3tb4J1D9x7I+zPD4cEe9Ui15778vlH+7W2G5a31Fc4rdRXq4Pkfvc7riGxt5uceQC5Yr58tuWtpevjuG9lcBhnNkxV6fLrM+kOs6Uq6q07a
bNYqO61z6g7U89Q6Zwkk5DJzkDJOB3L18XacVa44mXxPs5gx8dnzcVkx1iOkRGo1H/enV5i6+3l49a7V58al5+9fNnLf1l+xrwHCx2x1/wDzH/DHfcrg85fXVLvGZx+9
TmmfN0jhsMdqR9IbfR7Jbnqa3U9RPI6ASiWYueSBGz1nZ39jV2wRzZIiXg9q3rg4TJekRvWo/Oekf5a+910lyutZcZHEuqZny+AJyB5YXLJeb2mfV6+D4avD4aYo/piI
+jA2zwWHr1BBpPADyTaTpl2yilrrjS0MbPzlRK2Ju7tOFukc9or6vPxOauDFbLPasTP0dz/0hbhFTiy6dgcBHSwmZzRyz6jPgD5r9TjjUafwzNknJebz3md/V4UDldoc
JSVQIjJG4AdiqGgCgSARCRSRAgSAQCBIEUCKgSqhECBIBFCBIEgSgrRQgaAQCAQCCSAQCIEDQCAQNAIEgEDQZFJ7TvBFhmAoNa/2neJRUFAKgygMoEgEBlAZUAisi30k
1fXU1BTgmaplbCzxccfes2nliZkiNzp9FdIc8Fi0jRafoiGtka2BoH6qMDJ95x5lfP4WPEyTefJ7+I+DHFY83mFkP+VqcfW+wr6MvA7DkstEUCQGFFMBFPCiwkAo1CbQ
o1EJOgD28N6zvTXLtrLnTn0KoYfoE+W9dIttytXTSUO6lYe3JWpZheoMeuYZKOdnawqwkt7apPSbdSzc3RjPiN33LM9247MsxZ5KKwbhU09BD11VK2NvLPF3gOasdSZi
Hnt315NPtQWuI0zOHWyAGQ+A4N+JViI82JtPk1NkqZX1j/S5XyGY525HZO17+1b0xt1NzpxX2SRhbmen/ON7Tjj8MrPm6d3EEdiqMi30k1bUiGIHA3vdyaO1RXXxW2Nk
YYMNY0c/tKmzR2iW2T1k0NNMJZom5yBuI54PNJ2sabkwNPAKNaQbTgTxHHB215BElm4RAgSAQIcUUigWEDbuQZ9sudTbKuKrpXlssZyO/uPcsXpFo1LdLcsu0vbYukGl
oYYQI3RB3XNdxY48wvDNrYrdXrrjrenyeX610ZW6Vq2NlcZ6Kb9BUhuA482kcnD4jeF7MWWLw8N6csuTcADuXZhj1QzA/wAMote7Bg3SDvUd4ZajZqKaKm1ZlYes9Gkr
Lrpm6WCc5aCdkHk2Qfc4ZXz+Jia5IvD34dWxzWXmU0UkE0kEo2ZInFjx2EHBXvidxuHzpiYnUohUiEgo3CQUbhYFmW4WsWZdIXt3DKzLrDF1I8trKel5U9Mxp+s71j9o
Xo4WvwTb1l4fatv5lcf4Yj9+rmHnacT2leh8wlQIgRCKCdM0vmAAyexZs1D6J1wPya6MrDpth2Z6hrXTDtwNt39Jw8l8r2jk1SKx5v2n2N4TxOLtmt2pH7z/AOtvISc8
V8Tb+nREOi0A8s1nY3D/AL4weZwvRws/za/m+R7crvgM3/1l7PU6bZcOkSe71jQKOkhieS7g+QNOB4DGT7l+i8n8aiJm2oeSdI2phqW/yTRPJoqfMVMO1ud7ved/hhfn
uLzzlvuO0dn9f+z/ALL9w4WK2+/brb8/T9HIrzafdesdB9E2Oou98nA6umhEYJ7/AFnfBo819T2dTrNn4X7acTy48eCPOdz+nSGl0Xp06w1jU19ewupBM6pqSfnbTstZ
7/sBX19v55pd0salZeLo210Ug+T6Alg2NzXycCR3DgPevg8dxHiX5Y7Q/qX2W9le6YPGyR8d/wBo8o/XvLzvZeG7eydknG1jdleLT9TExvldBoQ7OsLIf/GRj4rvw0/z
a/m+Z7bjfAZv/rL0HVmixqbpYcJg4UgpoZKhzeOwARgd5O5fpd9H8WhrulLVbXP/ACWsrmw22kAim6rcHkfMH7LfiV8XjuJm08le3m/pP2W9iVxUji80fFP3flHr+c/t
DzalpamtqYqakhfNPK4NZGwZLj2AL51Ym06h+xy5ceGk3vOojvL0qg6IL1NTNkrLhSUsrh+i2XSEdxI3Z8Mr6FfZ15jczp+Rz/bPhaX1jpNo9ekOcumhL9bbxS2uWmDz
VyCOCeM5jcfHljiQV578JkpeKzHd9Xh/tBwfEcPbPW2uWNzE92+6ZLrQ6d0zQaFt0m4RtkqdncSOIB+s7Lj7l9/DjilYrHk/lXG8Xfi898+Tvaf+x+jzXQemo7/1z3Pl
EgnjhjDSMEuPNbtPV5Xq/TbWtp32ewUxAipoetc0fwt+APmvke0b7mKP6B9i+FitMnEWjvOo/TrLzK10clyuNLQxgmSolbE3Ha44XzaVm1oiPN+14nPXBitkt2rEz9Ho
fSjqyKZjdMWWXFvpWtjnkYd0pbuDR+yMe8+C93GcTE/y6doflfs57HtWZ43iY+O3WI9N+f5z+0PPrNa6683GC32+Ey1EzsNHIdpJ5AcyvHjpbJblju/T8XxWLhMM5cs6
rH/fq+idI2m2aV9G0/S4nuU7DNVS43kD5x7Bk4aPevv4MFcVdQ/kPtb2rl9oZ/Et0iO0ekf8+rxvpUujLlrOv2XbUdLimZv+jx/pEr43GX5s068uj+kfZrhfA9n033t8
X17fswej+xwah1NT0FUXClDXSTFrtk7IHDPeSAs8LhjJk5bPR7c9oX4Lg7Zcf3ukR+cvY29GGi2jL46g/Wqyvq+5YI//AK/BT9qPac9pj/8AKms07oXScPpc8FTFFWsf
SmZsj5AGuG8ZHDIGM+K6U4TFG5h5M/2g4/Lqt7R8MxPaO8dmLR6a6OK61VtzoaN01NRtLpHOkkaNzc43lc78FgrWbTD04PtH7UzZa4q5OtpiO0ef6PCZC0vJa0NBOQ0c
u5fEl/VaRMR1em9FOn7RW2673m+0kc9HTNDWiQHAwC558sBfQ4Hh63ibWjb8X9qva2fhbY8WC81mdzOvpDOZrrootU8dZRWeVtVD60bo6XDge4l25fSrwuOs7ivV+Kze
2eOzUnHkyzNZ7w8P1zqOfVOo6y8Ss6sTOAjjznq2AYa3PPd8SvXEPkzLQtW2E1Q2DLwERkFVAgFAiqBECKSIECKBIGgigECKBIpIhoEopIBUCgiVQgoIooQCBIBA0Aga
BogQNAkAqGoBUCAUDQCC+lPru8EVlc1Br5Pbd4lFQQCAQJAKhZUBlFGUDCI9F6ErV8oaw9Oe3MVuhMw7Osd6rPtJ9y8nGX1j1Hm9PC05sm58m46Qrr8palqAx2YKUejx
+72j558lvhqcuON95Tib82SddoaSxn/LFOO532LvLhDsuSypIoQPCimAipYWWjAUahawKS3DIY1Yl0iBU0wnp5YyN7mOHwKnNprki0OIp2lkEbD81oC9LxLAUEwA4EHn
uQZOmXhtpe17g0U8rmuLjgAcQpbutezX3TVrGONPa2CaTh1rhlo+qOfjwSK+qTf0aF1DcbnMZ6pzi93F8x3+4Le4hjUz3ae9addSbVVGQ/nIA3H7w+9I1KzGmjBc3gVW
XXWG5mWIGRwErPVdk42h2rMw3WWtr7ZI26ei08e02Y7UXZsn8E21p01PT0dmoHMdINw25H9p7fBZXs4i732pucjoosxUWdzeb+934KxDEylpuKpbdYamn4RHMhPDZ5j3
hWYSJepMc1zQ5nskZCw7ER62e5EkxlECBIA7gSeSAA3IowgRQRKAHFFbKzXGotdbHV0z9l7TvHJw7CuWSkXjUuuO81l63BNadZWKWlqYWywyt2Z4HHew8iDyI4grwTzY
7O1qxaNx2eA620jW6VuXUSl01FMSaapxukH0T2OHMe8L6GLJF4eO9eWXKzt/NPH7JXViO7VxnD2nvUemGYFGzUDCjSQUV2nRlcPQtTwxOdiOraYHeJ3t+I+K8vFV3Tfo
9PD21bUrOkq3eganlma3EVYwTt+twcPMZ961w19016OfEV1fcebkgvQ4xCQUaiEwo3CxqzLcLowsS6QzKOLr6mGH9Y8N+O9YtOomXoxU57xX1c9eqn0i4VtSDufI7Z8M
4HwAXvxV5aRD4fGZPFz3v6y06284VQIgKIR4IOv6L7N8t6xtdG5u1EZhJL9RnrH7Me9YtLdXoHTNc/TNXvpWOzHRRNh3cNo+s77QPcvz3H35suvR/WPsjwvhcBF573mZ
/TtDz9rHOa5waS1vE9i8L9TMxvUtzpB/V6osz+yti/rBdsE6yV/N872tXm4PLH/jP+HsXTFqgWy2fIdJJirrWkykHfHFwPvdw8Mr6nHZ+SvJXvP+H4P7K+yvHze9ZI+G
nb52/wDX+XhUNLLUMmkiblkLNt7jwaMgD4kBfGiJnq/pF8tKTFZ7zOoUbJBwo6+T22wU8tp6JQ2GIurbtJiNreLjI7ZaP4Qvv8Dj5cUfPq/kn2o4nxvaF6x2rqP+f3S1
LWQaA0bHZ6KQfLFwB6yRvFuRhz/d7LVnjeI8OvLXvLf2a9k++8R4uSPgp3+c+Uf7y8WpoJaqpiggYZJZXhjGDi5xOAF8OsTadQ/qeW9cVJvedRHd3HSTZo9OUOnbO0h0
kdPJLM4fOkc4bR+GB3Bezi8XhRSnyfnPs/xk8dk4jiZ7TMRH5RHRzmi3bOrLKf8AxkX9YLhw/wDq1/N9b2vG+Bzf/Wf8PojWtwisFhu16hAbWPibExx4l28N8skr7vE5
fDxzZ/KfY3A++cbjwz23ufyjrL5de4veXOJJO8k8SV+dmdv7PWuoet9FdDSWXT1z1rcGBwiY9kAPJo9ojvJw3zX1vZ2GNeJL+efbH2jab14Ss9I6z+flH+7yPV2tb3eL
m+snrpm4f6jY3lrY+wNA4YX1H4bbrNOdN97oLYKO40MFzljGIqiSUsf3beAdrx3FJg28z1BXXG911ReK+brJqiYl7uHrYzgDsAwPJWB7H/0d6VtQ+bbbuppevJxuJI2W
/eVm3dqOzQdIFzN21bdKsO2ohMYo/qs9UfZn3r85xWTnyzL+yewuFjhuAx4/PW5/Oern6apnpZmzU8ropWggPacEZGDj3FcY3E7h9TJjpkry3jcIDLlG3uFBHbejvQ0V
7p4hXXG4MYGzbPqkuG00Z+aweZK/QcJgrjpEx3l/IvtB7VzcZxNsdulaTMRHzjpufmr6N62dlq1FrG5yukmDSOsf87ZG0R4ZLRhd8l4pSbej4/CYLcRnphr3tMQ8YqZJ
KiaSoldtSSOL3E8yTkr8zNpmdy/uOPHXHWK17R0+ilpcw5aSD2go3MRPdlU3XTyshYXOke4NaMneScBIiZnUOWSaUrNp7Q9R6X5BaNP6d0vAQOqZ1shH7I2c+8lxX6fF
XkrFfR/EeMzzxHEXzT/VMylcg/TvQ1TUziWVV1eC/PHDjtH+i0D3ry8fk5cWvV9z7KcL43tCLT2pEz/tDyMY2sngvgz3f1fryvXdSP8AyW6FKaladipueyHjgfX9Z39E
AL9FwePkxRD+OfaHivefaGS0donUfp0fNUrnySucTxK9sQ+FMpsb2rUQzK1aQKCyLe/wCsJK5VAgECQCISKEQkUFEJFARAgSCKAQGEAikgSIECRSQCggikgEAgEAEDQN
A0AiEgaAQCBoBAKgUDQW05/Oe5Blgo0wZv0jvFQVoEgMopZRBlAkUIFlBIb0HuvRrE3TXRrXage3FRWudJHnmB6kY89or52b+Znino92D+Xhm7gHOLnFzjlxOSTzK+g8
LKsZ/wAt047nf1SkkO2HBZUIpc0DUUwo0mAoqbQo3C1oWZbhewcFiXWrKhA2hntWJda93CVMfV1E0f0Hub5FeuJ3G3z7xq0wqwqyYOCisN1uikdJ1r5HRvftmMOw3PeO
abTTJhp4IBiGFkf1R96bXSYGFApoxKzZdwSOg84uVOynuE0cbdlgOWjsyujlPdjHB4hUXwVlRTODoJnsIGBg8uxTS7lZW3KrrqcQVEoLM5OGgbXipqCZlXbbPNcajqos
NY3e+Q8Gj7yk9CNy7ultcVFSCGnbgN37+Lj2k9qztvTNt8m4wuGCN7fwUlqs+TMcN6iyiiBAYQQkPss+kfgEEs5RTQIoIkKKSKkDhFhs7Ldau1VrKqlkwRuc08HDsK5Z
McXjUutLcsvWmmy600/JTVcQfFIMSRE4fE/k5p5EcivHEzjn5t3puOnZ89630vW6YuJpaj87TS5NPUgYErew9jhzHvG5e7FljJHR5L0ms9XCDIW3XbMCjokimFFSCism
kqJKWeKoiOJInh7T3g5H2LFo3GnSs6nb1rpGgju+mKK9QjPVbMuR9CQAHyOF4eGmaXmsvXxFYtSLR5PKSF73h0YRpMKLCxoWZdIhaxZl1hsKB4h9Iqzwp6d8g8cYHxK5
2jmmK+svRjtyRbJ+GJlxlRujDSvpvzLGVAiIogRCO9JV7r/0e7dFTtvOo6oBsNJD1bXHlu2nnyA81xyWiI3Lvhx2yXilO8zEOEutbJcblV10pJkqJnSuz3nK/LXvNrTM
+b+6cLgrgw1x17ViI+jo7dbNno9vN2ez26uCCNxHIZLviW+S7Ux/yLX+cPl5+L37Vw4IntW0z+vb/EuctVQykudHVSBxZBOyRwbxIDgTjyXCluWYl9XicU5cN6R3mJj6
wv1Bdqi+3mrulUTtzyF2M+w3k0dwGAt5Mk5LTaXLguDpwfD1wU7RH7+c/q6HUNuOm9J2yglBZcLm/wBMqW82RtGI2HzJPf4Ltlx+FjrWe89Z/wBnyeB4n37jcmavWmP4
a/OZ+9P7a/L83K0UT6uqipY25kme2No7ycD7V5a1mbajzfczXrjpN57RG/o+paqC3We2UtTWODKW0wZaeTSG7OcduMgeK/S7jFTr2h/FIrk43idUjdrz/mXzPqq9VV/v
dTc6nIMhxGzO6Ng9lo8B96/P5c05LTaX9h9ncBTguHrhp5d/nPnLN0Pe7dp+8C6V1DLVyRNPUMY8NDXn5xz2DgtcPkrjvzWjbh7Y4HNxuDwMV+WJ7+fT0ZXSFquLVlwp
KuGjfTNgh6ste8OJO0Tnd4rXFcRGa0TEacfYXsi3s3DbHa3Nud9teTUaWd1epLS7sq4j/SC5YZ/mV/N9D2lXfCZY/wDGf8PXunaqdFZ7bSNcQ2apdI4duy3d8Svp+0ba
rEPwn2MxRbPkyelYj6z/AOnhjRkr47+j2no9rvFBWz9DdporVA+YyNjdK2FuSQSSdw478L9Fwsaw1/J/Gvb17W9o5pn1/wAOa0v0Ty3KxRNvdN6A41D5pJJRmUNwA0Bv
ADG8krt1fLj00ydZaLsemtHi82Ggtl1hgeBPJUs2y4F2zlrmkDcd2FIiLdYlvJW2K3Jeup9JeK3e6/KbqeNlupKKOHaxHStIa4k7yck79wC61ryuUzt7z0Xxt0z0X3i/
OAEsu0Y88yBst/pErjnycmObPb7M4WeK4vHh9Zjf5ef7PIXOcXHaOTnf3r81rb+2RMRG4dTBpKaXRE+qXS4YyYMZE1vFu1sueT2ZIA967xw8+D4r5FvbFI9o14GI7xvf
z1uIcsQWuXnj5vszPTo9o0e4ap6La6yyHaqaDIjzvO712fe1fd4DJzY+X0fyz7W8H4HG+LEdLxv9e0/8oaxxp3oqt1ob6lRXlpkbwO/13/8AtCntC/Li5fVfsjwvjcd4
kx0pG/1npDxnaO0viP6j2jT6H0r0fadOn7c+5WqKasfA2SZ73OztO343HlnC+1h4PFyRzR1fy72n9ouN96yRhyTFYnUa15dPRuafRukKSphmgtFGyeN4fGdokhwOQQCV
2rw2GsxMR1fOye2vaWWk1tkmYmOv5fR5DrJty1B0pfJlbB1LuuipomB20BFx2s94JK9T40Nn0317HXK3WeIgRUcG2WDkXbh/Ravje0sm7RT0f0b7GcLy4L5/xTr9I/8A
bzzTtuN2vlBbmjJqJ2sPc3O8+WV4cNOe8V9X6v2hxHu3D3zT/TEz/wAOq/6RN3abpb7FA7EVFBtuaOTn7gPc0DzX6isP4de0zO583iDRzXWHGUxuVQ0AgtgG4lWElaqy
EU0CQJEJAIBFJAkAEAiEgRQJAIAopIBQJUCBIEoK0UIBAIBAYQNAIGgEQIGgSBhAIGgEDQCCyH9IEGVlFYc/6VyiqSUBlFCBIEgEQsooQW08MtTURU0AzLM9sbAObnHA
+1ZmdRuSI30e7dIs0drtFo0xSuxHTxNLwOYaNkeZyV4ODrNrWyy9/FzyUrjh50SvoPAyLC7/AC7TfWI/olJ7EO85LLQQJA8KKYCjSxqjULGhRqFrQsy3C5ixLrVfH2rE
u0ORvUfV3WrHa/a8xlejFO6Q8fExrLZgLo4DCKYUAgMIGEHAajZsXEn6TR8CQukOUtUqiOEVIYUHc6ToOooPSXj15ztD6o4fisWnq6Vjo6HjxWW0HxtJD27njeCiLM5U
UIBUNBibW3UPPzWDZH3oi1m/1uXJFTRQgRUVFAwEVIHCis+0XastVYyppnnd7TeTh2FcsuKLxqXbHkms/J6sxtm1lY3QVMbZYJMB8Z9uJ3Ig8iORXgiLY7fN1yViY+T5
QvMAobtXUDXFzaeokhDncSGuIyfJfTrO4iXl1roIjljT3KukLEUwophRpNpwVGoexaCljvei57RM7Ji26c55NcMtPuz8F83PHJl5n0MM8+PleXTQyQSvhlGJI3Fjh3g4
K98TuNw8E11OpQAVEgFJaha0LMukLGhZl1qvq39Tp+qdzqJ44R4D1j9yuGObLHyTi7cnCW/8piP93JVJy8DsC974CgoBVEUQiiJRN2pAFJWH0UIvyZ6D6WnA2Ku6YLu3
84do/wBAAL5vH5OXFMevR+n+yvC+N7RpM9qbn/j93keMuOV8Du/rfaHtOobYLV0LU9I5uzLmGaTt2nu2j9oHuX1stOThIj8n8/4HiveftDbJ5fFEflEaeKk79y+Q/oUO
+6KNL/Ll9FZVRg0NCRI8OG6ST5rfvPh3r3cDg8S/NPaH5f7T+1fdOG8Ok/Ffp+Uec/7QxOlWvdctZVzg7ajpsUzD9Xj/AEiVnjMvNln5dHb7N8L4Hs/H62+Kf17ftoui
m3G4a0oSW5jpdqpfkfRG74kK8FTmyx8up9peInB7Pv8A+Xw/Xv8As6Hph1d6ZWDT1FKDT0zs1LmndJKPm+Dft8F247Nzz4de0d3y/st7J8GnveWPit935R6/r/j83nVq
t1bea6KhoIHTVMpIaxu7OBk7zwC+dTHa9uWvd+t4nisXC4py5Z1WHS/4M9YHhah754/7S9McFn9Hxp+1Hsz+5+0/8Ofv1iumn6qOkutOIJns6xrQ9rstyRnIPcuWTDbH
OrPp8D7QwcbScmCdxE67TH+UNPuLb5bT2VUX9cLOPpePzdONjfDZP/rP+HtXTfb5aqwUtfGwuFHORJjk14xnzA819b2hSZpFvR/PfsfxNcfFWxT/AFx0/OP/AE8FOQdy
+M/pjq9O691FYKIUNHUxvpm5LI549sMzxweI8F6cfF5cVeWs9HxOO+z/AAXG5PFyVmLesTrf5qb3rDUV+YYq64vMB4wRARsPiBx96zficmT70unCexOC4OebFTr6z1n9
3bamq/kzoLthGAyV8IeO0GRzsfAL7fBx/Jq/mf2htv2lmn5/7Q+fYCysvBFIx3Vvl/Ntdx3ncF6/J8XvL6G6TXCwaIsOl4SA9zQ6XHMMG/ze74L5ftG+qxSPN+z+xvC8
3EX4i0dKxqPzn/08ijYZHYHtHgO0r43V/SLaiOr6cp7BAzRTNMEt611vLCzgdoje7H1yv0UYf5Ph/J/Hb+05n2lPF/8Alv8ATf8Aw+ZZA9kjo5WkOaSCDyI4r87MP7DS
YmN1egdDV1bQ6qFG9+zFXxGLfw2x6zfvHvXt4DJy5eWfN+Y+1nBzm4HxY70nf6dpW9N1zNTqeC3sdmOigAI/bf6x+Gyt8ffeTl9HL7I8LNOCnNPe8/tHT/l5svnP2G0+
un5SSfxFa3Ln4dfR3/Q7bZLjq2OpkBMVDGZiT9I+q34kn3L28BTmy79H5j7WcTGDgZxx3vOv07y6fSj2ak6WLxe2gGmt7SyN3Ikfm2n4OK+6/lnm8x1lcnXfU9zr85bJ
O4M3/MG5vwC/N57895s/tXsjhfdeEx4fSI3+c9Zdf0KWsVWo5rjIAIqGAnaPJ7tw+G0V6fZ1N5Jt6Ph/bHivD4OMPnef2jr/AMPKOkG8G+arulx2ssmqHbH1Bub8AF96
sP5daXNt4Lo5mqBQNUZMYwwKsykgCiBAkAgSKSIEUkCRAikiBAkCQCihVEUUIBAIEUCUFSKaAQCBoBAIBA0AiBAIBA0AgEAgaBoicR/ONRYZWUVh1H6Q+CiwpyikgMoE
gEAgSAUHadFFuFw1vQPe3MVGHVb+z1Rhv9IhefircuKfm9HDU5ssN5q24G53+sqQ7MYf1bPqt3fit4KcmOKscRk58k2aQrs4rrGcXmkP+s+4pJD0DkubYVAgHENBc4gA
cSou2F8p0+0RiTHbhNHMyYa2lfjEzQex25ZmJbiYZ7CCARjB5rLcLWhZl0ha0LEusL4wsy6w5jUrdm6OP0o2H4Y+5dsE/A8/Gx/MifWIahdnkNFCgEDQIoOO1ZFieJ/e
5v3rpVzs51VCJQZVro3V9fDStzh59Y9jRxKkzpYjb0+NrWtaxow1oAA7AuUusJIpIAIJIBApX9XG53YNyDBizjHackpKMpvBGkwoBFIoEihAKKAcIsM21XWutVUKmjkI
Pzmng8dhXLJji8al1x5JpPyeZaqc2bU12qAC1stU+QA8to5+9dMddUiJYvMTaZhjU++Idy0tey1RoKKkFFSCjUO96K670a+S0bnYZVxEAftN3j4ZXj4yu679Hs4W2rTC
rpCofQ9RyytbiOqYJm+PB3xHxV4a/NT8meIpq/5uXC9DjpNoUaha0KS3ELWhYl1hDULuro7ZSjiWPqHDvccD4NXbho+9b9Hl9p21THj/ADn6uVlOXuPevW+QrRAVQkQi
iNvpO3OvGobdamcauoZET2AnefLKzZqHufTO+pnr7ZZ6ClndT0kG2RHG4gF24DcOTW/FfD9ozNrRWPJ/RvsdjxYcOTPkmIm06jrHaP8A24fTmmLlcb3b6SWgqmQzTtEj
3QOAazOXHJGOAK8WHDa14iY6P03tD2rgwcNfJW8TMROusd/J7h0o0M9boutpaCnknl24g2OJu07c4bsDsC+xxlZtimIh/Ofs7xFMXtCl8toiOvWfyeG02jNUyvaBYK71
iAC6IgDPaTwXx/dssz0rL+jW9t8BSOuav1fQWn7VFpXTPoNHH6TVU8RmkbGMumlIzw7yMDuC+3ixeDj5Y8v8v5fx3Gz7S43xMk8sTMR+Vf8AvWXhsmjtZ1c8k0thqzJK
8veXADJJyeJXxp4XNM75Zf0ivtr2ZirFYzRqOn0dro3TOptOWK9VkFrd8sVIbBTRl7MsbxLzv5E/AL2cPhy4qWtEdZfnfa/tTgOP4nDjtk/l13Np69fSOzjD0b6zkeXP
tRJcclzp48k/xLzTweefJ96v2l9l1jpk/af+Ha6UtUXRzp656o1ExjK0N6uKIPDiByaCN2XH4BfQ4Phpx7tbu/H/AGl9uU42a4cE7pHX03P/AKcJaul3UlZe6WGqukcN
LJUMEmzEwBrC4ZGccML36flNvSOkvQ951PfIK22OpBBHTiMmWUtOck9h3b183i+FyZbxar9l9nfb3C+z+Gtjzb3M76R8vzczbuijU9PXU1Q+a3hsUrHkCVxOAQforz19
n5YmJnT7XEfa/gL4rUiLdYmO0en5u11Vr+w2rVB01eurfQT0wE8mNoRPcT6rx2FuO8L7E1iY1L+b4s18V4vSdTHaXNXLoopbh/j2l7xA+kl9ZjJTttA7ntzkeIyvmZfZ
253Sfq/c8D9s+WsV4qm59Y/4ahnRDqcvw6otzW9vWuPw2Vwj2dl85h9O32z4GI6Vt9I/5bem6O9PafArNXaigEbd/Utd1Qd7ydo+4BejH7OrHW87fG437Z5bxy8NTl+c
9Z+nZoelDVGmdRWak03abnT0VsppGvLw0etsghoDc7gMk96+hXdela9H4/Je2a05MltzPWZeQaVq6O1alt1bOx01LT1TJHjG9zA7PDw34Xaezzx3fSup7TpLWVXBeJNY
U8cPUhkTGTR4AySThxyDv7F4c/CRltzTL9F7K+0GT2dgnDTHE7ne5mWrpNG9H9uqYKyXV0UnUSNk2H1MQa7Bzg45LnX2fSJidvXn+1/FZaWpyRG4mPPzayr6WLXF0mtr
hM6SyMh9DdI0HeM5MgHMbXwC+hp+T22Ffb+iW41c9fJqqJrqiR0pbHVNDQXHJAGzkLw34DFa026v03D/AGs47DirirFZiI11id9P1VUlH0S0FXDUw6od10LxIxwqDucD
kcGqV4DHWYmNrm+1nG5aTS0V1Ma7ev6umptN6C1fUV14p6iesL5S6eUTPa1riM43gcB5BbvweK1ptbzefhvtJx2DHXDimIiI1HRwtzn6MaKudT09luNdGx2DMypIafq5
O8eS+fe3C1tqImf1fseHxe3cuOL3yVpM+XL1/Xp0dhLYejOl03DqOagkFtlDcP25XEEnGCAe3cvdj4XBesWiOkvy3F+3va/DZrYcmTUx8o/4cxW9JmgNL2yuZpGhnNwq
GbAJjc1oOCAXFxzgZzgcV6cWCmPfJGnxeN9p8TxuveL82uzm+ivpDsOnIKpt0keWVTA2ZjYy5+0M4cORBBOd63MTvWnkiYjUxPV0jtf9ELN8em3uI7aNo+1y5RwuL8MP
pz7d9oT/APNb6sG99Mem6Oy1tDpKwPpamqYWGRzGRsZkY2sNJLiAThdaYq06VjTwcRxebiJic15tMes7eFBxecld4eSUwtMhUCgaDLG4eC0yaBIgQLKBFAIEgEUkCRAg
SBIEgEAgEUkCUQKgUUkCQVooQCAQNAIBAIGgEAiBAIGgFQKAQNABBJh9dvigykViVW548FGoUIBAIBAkAgWUBlQendGoFr0zf76d0suzSQnwGT8SPJeTPHPkrT9XrwTy
Yr5P0akndxXseNBxw0oJ2p2zc6M9krftSR6IVhsIAIIyxslYWPGW9mcIMKW2wu9hz2+/KmzSk2mQj1JmnucMK7XSsRXGhOY9sN/ZO0PJZ6S1G4Z1JezubUxfvM/BZmvo
6VyerdU1VBUDMMgcezmPcuVomHppaJ7M2PgubvDQ6sjIqaWT6UWPI/3rfDT96Pm5cfH3LfJz/Nep4DRAimoEgag5bWey2Bh4u2xgdu45W6s2ccJR84Ob4ha2zpIPYeDw
iO20bQGGnkrpG4fN6sefodvvP2LFpdKx5uoWWwgSBoGoBFYlW/JbGPErUJJRtwFBkMCKmFFCBEIpIpKARSOOaAEjM7LcuceTRlRHAarBjvtS1zdkuDXY8Whaglg0hywj
vRujJCjZqKkEUworZWWsdb7nSVrTvgla/wBwO/4ZXLJXmrMOuK3LaJep9JlFHU2mkuMWD1MmMjmx4/EDzXg4aeW01e7PXmjmeXlvYvft5NGAUWIWNWZbha0Fw2RxO4eK
zLrWN9GFqiUOvNS1p9SnDYG+DGgfblenho1ij59XzPad+bibRHlqPo5xeh89FVAURFAFBOhr6q2V1PX0UzoamnkEkUjeLXA5BWZWHr1N/wBIG9MgYypstBJOBh0jZHtD
u/Z5ea5zV05lVT/0gdQvY9sFqt0biMNcS92ye3BO9NG3MWLpc1daKirmZWsqBVSmaRlTGHt2zxI4FvgN25XSbbSfp31m4ER/JzSefouceZU5V25ah6TtaUN6qbzFd5H1
VVgTiVgex4HAbJ3DGd2OCaRvv8N+unHfWUjfq0bE5V2qf0y66fI2T5XDcDGy2njDT4jCvLBtTN0wa7fwvcjfqxMH3JpNuZv+rNR6kMfyzdqmrbH7DJHeq3vDRgZ700ba
TYe3eCVdJt0NFrXVlDSx0lPf7lHTxjDI21DsNHYFNLtZJrfVco9a/XM/70/8U0bc/UT1M8jpZJHue45LickntJV0bZdrv17tTs2+41VKefUyuZnyKml22s+udXVDDHLq
C5OaRgj0l2/4po20c9bWVLy+eaSRx4ue4uPmVdJtBoceJV0GWkbwiIiSVpyD71NLtN1TUEYLtymjakh7jkkq6NmOtHBxTSbSD5gQdo+aml2+lOiNsl36Irra7ZOxtzdJ
Mx4c7By4DZyeQLRjK4cRS16TWvd7/ZmfFg4vHlyxusTEy5Sk6P8AWFRWCndapIBnBlmIDGjtznf7l8OODyzOtP6hl+0fs6lOfxIn5RvbedMt1oNN6KtuhqOcSVfqPnwd
7Wtyckci5xyB2Bfdw44pWKx5P5bx/F24viL57f1S+dy0vcXHO9eiIeHZmIjgrpNl1RPapo2k2LBV0m17WgLSJKoagSonGMvCJLJVQIgQJAlQKBIBAIEgRRSKIRQJAIoQ
CIRQCKEQkUFAioI5QRRSQCAQCBoFlA0DQCBoBAkQIGgEAgaAQMcR4oMpRpjVftN8EIYyKFAKgQJAKBIESBvPAIPTpGm3aTs1p4Pew1Uw/afvH2hcMUbva/6O+WdY60/V
qV6HBCQ+oURGldsVUD+yRp+KD0w8T4rm2MIDCBFBTPUwQbpHja+iN5TSsdlxklfsUtM57vP7E0u2WKO8zj2WQjvIH4rPNWG4raTGnq+Ygy1cB8QfwWfEhrwrSm7S9a3D
o6inLhwIcWn7FPFjzXwbeTMpflejIZV0pqYx8+JwLh+K5W5J7PTjnJHS0bVapcySio5m5AD3N9YYIyOYPgpw/wB+YdeMjeGtvm5ZxXrfMCoEAoGgCUHC6sqeurmxA7o2
5Pif7gulY6OdpaBwy0hVAxvqAIPULGMWeh/8lv2LlPd1jsziooQNFCBqCEj2saXO3NAyT2BBy1PeS6qkfM3809xII4tHL3LpMMRbr1dDC9r2h7SC0jII4FYdIZDVFSQC
KDwRUcKBOOGk9iKxXSvdw3DuRBFE+d+y3J7SeSbIjbb00McLNlo383HiVmZdIjTgNfxNbeopBwkp27+3BIWq9mL92hpXMaXAkLS1lk57Fl0SCgkEWEgVFWN9Y4B48lmV
idvaNOtdddGwQV8TnfmzC9kmWbWydx347t6+Rlia5Zmr7eGYviiLNbetFUsFnqblAZKeWGMydT1gla4Dv4j4rtjz25orLzZMdY61efbsr2OCTVJahsLSxrrhTl49Rjus
d4NG0fsXPJ92XowR8cb/AD+jkayV03WzOPrSuLj7zlfTivLEQ/N5Lze82nzlgFVglUJECBIit7cqSql0OVNLsCBNLs+qHYmjYFODyU0bT9HGOCujZdQFNGx1IV0GIW9y
CwRtHYhsy1vcqImNp5jzU0bIMaOY800bS2G9o80NlsM7R5ppdmI2do800DYYOY80DAA5jzQM7PaPNFR2WnmEDDB3IJCPsQMR/snyTaaRdHj5p8ioabTTuo7zpytFZZ6u
amlxhxaMh47HA7iPFZlqHaVnTDraqpTCK2OAkYL4KZrX+e/HuWdQu5ec1k1VXVMlRUummmkdtPfJlznHtJPFajSTEotp5AP0T/4Stbhnln0WCCT9U/8AgP4K7g5beivZ
CrIwFUCIFQkAoLYB6xPcrCSuVZGUAgECQCBIBAIEUCRSKIiUAgEAgECKBIoQGUCKBKCKCKKFAKgQCAQAQNAIBBJAIhIBAIBA0DQCBoMpRpjVfzPeiwxcqKMogQGUCygE
CQZdqpDX3SioWjfUTMjPgTv+GVm86rMtVjmtEO/v9SKq61D2fo2nq2DsaNwWcVdUhrLbd5a1dXNVMfVARFQODnmN6D0+N22xrvpAH4LDaSghLKyJhkkcGtCo1npVZXSm
GhicBzPMDvPJOxHVs6OwwMw+reZn82g4b+JWZs3FW7hjjiaGRMaxvY0YCxLcLwstwsa5Zl0iVzXFYmHSsrGtyd65y7RK0tjc3ZlY17exwyFmYdKy5jVtnpKemjr6GIRt
LtmRreG/gcct668PltNuS0uPGcPWK+JSNerkivY+ajlAZVDyoK55NiJxzjkrEJLzSsm9Jq55+T3kjw4D4BdHOVKIYQemWM/5Hof/ACWrlPd2r2Z+VFNAIoQNBqdR1Iht
5jB9eY7I8OatY6s2nUOP2sLbm2NruT6N+y4F8BPrN7O8KTG2q2062mninibLC8OYeBC5usTtdlGggFFCKrmOIyhLGYxz3hjRlxOAqkN3BCyGMMHvPaVh0iNLoeqNTDG/
g92Mdqzbs1SN2iFF60lartUCoqX1YkAwCybcB2AEbgucZLR2eqeHpaerU/4OrVtZbXVzR2EtP3J41mo4PH6yf+D23t9m5Vn8LFPHt6NRwdPWUm6FoG8bhVn91qnjWbjg
6esrWaKtQPrz1b/3wPuU8azccJj+bKj0pY4v+qOkP+skJWfFt6txwuL0bGkoqShOaWmihPaxgB81i0zPd2rjrXtDNdNI/wBtxce1xysadIdKB6bpuWI8X08kfv2SvP2u
45I7vB25w3PYF9J44WtCktxDJ6z0e3XCoG4tg6tp/aedn7MqVjmvENXt4eG9/lr69HH1DtzWhfRfnFBQJVCRCRAgEC3IporpbLaqKO3sutyiM4leW09OHbIdji5x7O5e
XJkta/JTprvL6eDBixYY4jNG99o9decs/wBKtbf+z1v/AKSx4d/xy6e+4f7FQa634wNPW7yKeFf8cp77h/sVIVtB/wD8/bv4SnhW/HK+/Y/7NUhX0I/0Bbf4CnhW/HJ7
/T+zVMXOjbwsFs/myp4M/ilY9o1j/wCGv0S+VqX/AOQ2z+aTwJ/FK/xGP7VfokLvTjhY7WP9ingT+KT+JR/ar9D+WoxwstrH+xU93/8AKT+Jz/br9C+WhytNtH+wCe7/
APlP1P4nb+3X6JG+P5Wy3D/YBPd4/FP1P4pf8Ffogb5LyoLeP93Ce719Z+p/FMn4K/QfL9QOFHbx/u4V93r6z9U/imX8NfoPygqif80oP+HCe719Z+p/FMv4a/Q/yhq8
gimoR/u4T3avrP1P4rm/DX6A6ireUNEP93anu1fWfqfxXN6V+g/KKv5R0g/3dqnu1Pn9T+K5/SPoBqO4jeBSj/YNT3anz+p/FuI+X0MakuQ4GnHhA1X3bH8/qfxbifl9
II6kup/lIR4QtT3XH/2T+L8T6x9IVP1BdXcZ4/5pqe64/T9z+L8X+KPpDFfdbi45dM0/7MK+74/RifanFT3t+0Bl0r2nIlb/AABPAx+ifxPio/q/aFzb3dG+zUgf7NqT
w2P0aj2txcf1ftC4aivIGBWf/tt/BT3bF6E+1eL/ABftBjUF4PGsP8A/BPdsfofxXi/x/tDW6rEVRQ2+6dWyOpmdJFKWDAkLcYdjt3rfDzNb2p5QnH8uXBj4jWrTuJ+e
vNy69b5JIgVAgFBfCMNz2rUMysRCQCBoEgECQIoBAIEgRRSKISKEQIEigohFAlFJAIEUAgrRTQCAQCBIBA0DQCBoBECAQCACBoGEAgEGUDuCjSisHqNPehDEUaJAIBEL
KBZQCDpNCMAvMtc4erRU0k37xGy34lc8vWIr6uuLpM29G1JJJJO8rq4koqmY7wqirkUHpFueX2+lfnOYm/YsNrKmojpojLK7DeQ5k9gQYNDSVN4lFRUExUoPqgc+4fik
zoiNuop4YaeIRQxhjByCxLcLgFFSCjUJBRqEgVluJMySN4AKaheaVfp0rTjqwVJpDUZZhdFVVDzvpHkdoWJpEebvXLafJndRHX0VRRzxuY2RuPW5Fee88lotD2UjxKTS
Y7vL54nwTSQyDEkbi1w7wvpxMTG4fCtWazNZ8lSqGqBRGl1JUmCgmLTh2zsjxO4LUJZwoAAAHAbltzCBoPSrJ/8ACaIf6lv2LlPd2jsz8qKMoHlAZQGUHGagqvSbi5jX
ZZCNgePM+a3EdHO07lrAqyeUVl0FdNRS7cRy0+0w8Hf89qzMbarOnYUFZDWw9ZCd49pp4tPesTDtExLLUaCAKKpqPYHikEsm1xe1M4dzfvUtK1jzbMALLbBrHGKvo3g4
xI0/0t6s9YlInVodQRgleZ9KCysy6wRKjcIFRuESstIEoqJCNAKLDpdNyB1NJEeDXjyK8+WNTtjI8UroTTV9VTkb4pns8nFe+s7iJeKe6tqNQV5f1dkhj51FSXfusbj7
XLfDxvJM+kf5cfaFuXh4r+Kf8OUmP5zwC9z4itECqEiEiDKoFAiimEV21e0w2ixwdlJtn945Xhxdb3n5vs8d8ODBT/x39Ws48V3fMACIeEBhUPCgMIBFCAQCBIEgECVA
ogVAgEDCAwgMIHhAYQGFBIIui1UCy2WOH/VSSkd7nLnw/XJefye/jt14bBT5TP1cyvW+SCqhIBA1BksGGAdy0zJogQCBoEgSBFFCISAQCBFAkCQNBEoBFCISikUAqEgR
QJQQRQgEDQCBKAVDQAQNA0AgEQIEg2unrfRXK4dRcLkaCnDC50wgMx48A0faVi8zEfDG2qxEz1l2zNJaHwNnVdVOf2o20/8AWaVx8TN+F15Mf4lUmmtLsdiOq64ftXqG
P/8AjU58v/YleTF/2UxprT+N1JG7v/KWD+wrF7+v7M8tfT9wNMWUg7Ftjd/+pYP7KvPb1/Y5a+n7oP05b+DbZEP/ANRwfgpz29f2WIr6fuxp9M0Dmhr6FjRnORqGA/8A
tUm9/X9pbitPOP3Sh0jYnAbcoi/+u07v/wCNIvk/7Ekxj9P3ZLdEaWlIa7UboHOOAG1EU+/91oWbZcsdo21THjtOt6afXGho9NW2C5U149NgkmEJa6AxuaSCQc5IPBMH
ETktyzGm+I4Xwq823D5XqeQZQLKBEoOt0s3qbHXTfOqp2Qg/ssG0fiQsa3f8m96pPzZq6OQKKxZneuURXlEegWOojbY6aWR2GtZg+4lYnu6R2ZFDQPu0orawEUrf0UX0
u8932qTOliNuiY0NAAGANwA5LDSYRUggYUWEgo1BhSWoWDfxWZbhZGWtO5oHuWZdK6ZDXZWJh2rK2Jrg8OB3c1yvTmh2x5ZpO3Ja2thgq23GIZjn3SY5PHP3j7F34S/T
knyeXj8URbxa9pcsvW+efFAYxvPBBxerKjbkggB9pxkI7huC3DEueWmRhA0HpNoOLVRj/Ut+xc57u0dmZlRTBQGUQs5QY9fUiko5pyd7W+qO1x4JEEzqHCEknJOSd5K2
5DKBophQZFNUTUsolgeWPHx7j2hNNROnXWy6w1zQw4jnA3s7e8LnMadq22z8qNpBBXOBho55RJbaKMRxsYOQwsS6wmitPqKQw0wqP1YJ8t6sM26dXYwzNmhjkach7Q4H
xGV5pfSr22ZWXWJRKjUSiVGolAlG4lEqKgSo1BIrcacl2aqSM/PZ8QuOaOm0t2ecayh6jVFyYBgOl6wfvAFenDO6Q8Vulpado5ngttQx9SnYmoqT9TTNLvrPJcfuXfhY
+Gbes/4eD2pbV6Y/SP8APVy7jlxPevU+YSISqEiBVCQCAUUjwIQeg0sceobdQSUM8PpVPA2Cane8Nc0t5jPEFfO3OG0xaOkv0OTFHHYcd8MxzVjUxKT9NXNvzIP59q17
zR5/4TxPpH1hV8gXL6NP/Pt/FX3in/YP4TxPpH1hJunrgedL/wAQ38U94p/2D+F5/l9U/wAnK/8AWUY/3lqePX5/RP4Zm9Y+pHTtcOM9CP8AeWp49fSfofwzN6x9S/J+
qHGrt48alqe8V9J+i/wvL+Kv1I2Ccca+2j/eQnvEek/Rf4Xk/HX6oixSHjcrYP8AeQnjx6T9CPZd/wAdfql8h49q7Wsf7wFPH/8AGV/hdv7lfqRs0Y/0za/59PH/APGT
+GT/AHK/VH5Ii53u1/z6vjz+GT+G/wD/AFr9UHWqnHG+2v8AnU8afwyfw6v92v1I2ukHG/2v+dKeNP4ZSfZ1I/8AmqPk2hBwdRWsf7Qq+Lb8EpPAY4/+apGgtg46ktn8
RTxLfglPccX96pGjtA46lt/uDk8S/wCCT3LB/fqBSWbG/U1D7mOTxMn4JX3Ph/78GKax89S0nujcnPl/Ae6cN/fj6F1NhH/aWnP+xenPl/Ae68J/fj6Dq7AP+0cPugcn
Pl/B+57rwf8Af/YbGns79RM/4dyc2b8H7nu/Bf3/ANgfydHHUGfCmcnNm/B+54HA/wB79izpv/58/wB1K5N5vw/ung8D/en/APJbemRxvkx8KVybzfh/c8Lgf7s//knV
GmI/XNyq5wP5NlPsl3dk8E/nz05Yj9Tk4CvWckz8tOfvl0ddK7r+qEMLGCOGIHOwwcB4r0YcXh108XGcVPEZObWojpEekNYurxgqhIGgYGSB2qDJWmAgEAgECQCBFAkC
QCAQCBIEgECRQoBVCUAqpIEUCwoFwQQRQEAgaAQCAQCAQMIGgSIaBIJxMdK9sbGuc925rWjJPgAorfUtmulvPpFdbKylikbhj54HRhx44BI3qRaJ7SsxMd4ZIe4cyqgL
ieJQCBgeCCQA7B5IJg4SVBJPNRWTREiqh3/Pb9qzf7suuP70Oo6W3A6Mo/8A10f9Ry8HC/6s/k+lx3+lH5vFV9F8ksoBAkHbW9nVWmggO4iIyOH7TztfZhSvnJbyhatM
kisJxySe9ERRHY6PpJbjTtjmBFFTvOf23HfhYtOm6xt34ADQ1oAAGAByC5ugwimgEDRTUVIcVGtpgrLUS1t4v9nsrdq518UDiMtj9qR3g0b05Zns1zxHdxFz6VoWZjs9
qklPKWqdsg/ut3/FajF6sTn9GmPSPq6V4LqqnpYs72wUzS7Hi7K34NWfHu3lJryjqbfPR3mtuk5l2dl76aLERBzkbBGfevPODJW8XrEfu9NeKx2xzjyTPX5Qup6jT1X+
g1JTRk/NqoXxfHeF08TJHen0cvCxW+7f69G0gsc9Q3ao6y31Y5dRUtd8FieKpH3omP0WODvP3Zif1Ylys16hhcBbagk7ssbtfYt14nFP9TNuFzR/S8vvlNcW3aofUUNV
ExmGML4XAEDvx2rvS9Z7S898d694lgAA/OGezK66cg4Y3qCO12Ir0m1A/JtGD+pb9i5y6R2ZnBRUdpADKB5wg5vVFVtSRUjTub67/HktVhi0+TQKspIGihQPKKk1zmuD
muLXA5BG4gorqLReWzbMFY4Nl4Nk4B3j2FYmHWt/Vv8AcFl0QwH1ELf2sp5LEdW0bnisOiWcBBotVvHyQ8H5zg1Wvdm/Z0mnXGSw2+Qnf1DWnxG77lwvHxS92G26Q2OV
h3gsqNRJOUaiUCo1EoFGtokKNbLIUXbNtT9m4QHO4u2T71zyR8KuW6SIeq1CyTH6amY73gkfct8NO6aeXJHxOapozNNHCOMjg3zOF2tOo21jrzWivq0V/qhU3avqGn1D
K5rPqj1R8Avbhry46w+HxuTxOIvaPX/HRpF1eYIyFUJAKoSAQCgRRRjnzQiTye1TTW5HkmjY3dg8k0bG7sHkmgbuweSAIH0R5IHu7B5IDA7B5Jo6Hgdg8kXoN3YPJTR0
Pd2BF6EiAncillEG9DYymjaWT2qmxk9qaNjJ7U0bLJ7UTYz3po2MntTRssomyymjYyqgQCqBAIgRU4t7x3JCSvVZCAygEAgSAQJAkCQCAQCBIBAkCQJFCIFAlVIoBQJU
CCtRQgEDygAgEAgEAgaAQCAQbGxWuS73BtK2VsETWmWeoeMtgiHtPPb2AcyQFm1uWFrXcuxjvfyOx1NpmL5NpwMOqMA1U/7T5OX1W4A7+K5+Fzdb9f8ADp4mulOjTyXS
uuNZK6trqmqONxmmc/HmV1iIjpEOUzM9yKqEEVIIJBA0DUUworKo/wDOYfrj7Vi/aXXH96HSdLX/AOTaL/1zP6jl4eF/1J/J9Ljv9KPzeL5X0XyQgEDjYZJGx83kN80H
ePI2jsjDRuA7gMD7EiNQkzuUVRF5w0nuRGCSqMm3UctfXQUcH6SV2yCeAHMnwCkzoiNvYaCjgoKOKkpm4ijbgdpPMnvK4zO3aI0yFAIFhFCBhBJRWLcrhRWykfWV9Syn
p2cXvPPsA4k9wTW13p5RqXpJrqsvprE11FT8PSHAGZ47uTPiVuKerE3nycI1k9VK6eaR73POXSPJc5x8TxW4hhmxxsjGGj381oTQMIHkqCPA7Tdx7RuKK2NDe71QkGku
9dCBybO7HkVztipbvEOlc2Sva0uhpekXVdOAHXBlQ0cp4Wuz7xhcZ4PDPlp3jjc0d52zh0kvn9W66YtFY08SGbJ+IKx7nr7tph09839+kSRv/R9cP8/0c+nceLqZw+4h
TwuJj7t18XhLfexgW/ouqhmOvudA48pNogeYP2pzcVXyiTk4O3nMOgorfp+SGOG36po5Axoa0SOaHYHvCxPE5a/extxwmG33MjM/JWulG1S1VLUN5bD0jjqf1RMMz7Py
a+GYljTabvEG99E9w7WEOXevFYp83G3CZq/0tbPT1FPnraeZn1mELpF627S4zjvXvEsSSUNa5ziA1oJO/ktsS4mpdJPUSVEnF7s+A5LbkrxhAIp5UBhFPCCSBEqK3Nqv
T6fZgqSXw8Gv4ln4hSYdK313dbRFsskcrHBzC0kEHIK5y7xLZArLZ8eKDR6sZm3RjPGZo+1ar3c8k9GbpS4u9FdQuZuhO00g7yCfxXPJXrt6cGTpyy6Zskbh7QHjuXGY
l6otBlw5EFR0iUC5RqJRKjUSiSjW0S5vNwHvU0u4VOlYOBz4JqTngop3tmjcz1cPBz71LV6LF+rUdIdQJb9GzJPVU7R5klZ4aPgYz9L6aGgcIpZKo8KaF83vDd3xIXW0
b1X1lcU8u7z/AExMuIlJDADxPFfTfmN76qEQKpJIgRCVAgaBFAigFAIGihAIBAIGihA1FCAUVsbJZrlfrlDbLTSuqauXOyxu4ADi4k7gB2lS1orG5Nbb3U/R7qLTttF0
q20lTRB4jklo5+tETjuw7cMb92e1YrlradLNZiNo2PQd7vFvp62nfQxGrDzRU9RUBk1YGe0Y24347ThLZa1nRFZmNtVZ7JPdG3CQSxU1Pb6d09TPPkNjAOA3dv2nO3Ad
q3NohmI203uwtBoBVAgSBohZQJAIgQCBqhIGiEirYRxKQzK5VAgECQCoFAkAgRQJAIBAkAgSAQBQRKKFAlQIEoBUIoBQVo0FAlUCBhA0AgEAgEBlAIBB0llcYLW9rTg1
Mm089rW+yPDOT5LOuu13001lfUmVxAPqfNH3qodoP+MSfU+9BtyVQBBIIGgagYRTUVk0ZxUw/XH2rF/uy64/vQ6XpYOdGUX/AK1n9Ry8XC/6k/k+jxv+lH5vF19B8oID
KDMtEfWXGAY3A7R9yQS69VkIK5z+aKDDQZFtrJbfXwVsO98Lw7H0hzHvGUmNm9PaKWphq6aKpgdtRStD2nuK4S7QsKAQJFCgEGi1Vqeg05RiSoPW1UgPU0zT6z+89je/
yViNkzp4Zfr3cb7WGquE+2RkRxt3MiHY0cvHiV0iNMTO2LT0+fXkG7k3tWtIzgqGgaAQNAKARQgSKSgYJHNFI4PEA+KC2GaSE7UMj43DmxxafgpMb7tRMx2bWm1TqSlx
6PfK5oHIylw8jlcrYMc96w614jLXtaW5pukfVUIAkq6eoHZNTtOfLC4zweLyjTtHHZo7ztsWdJcs0ZiuOnLVVMcMOw0tz9qkcJr7tphZ4vm+9WJUSak0XVg+laQmp3H5
1JVYx7ty14eeO1/rDM34e3emihqOjiQjrIr3D9c7WPJYtPFeWmq04Oe+21pqHowqB/8AFKqMn9ZK9n2tWJycXHlDpGDg57TLNbpXo/m/QX12/wD8az7wuc8RxMd6/s6R
wnCz2t+63/BvZqsD5Pv0mTwz1co+BBVjjskfeqzb2djn7tnBajsNdp+4Ooq1g3jajlb7Mre0feOS+hiy1yV3D5ubDbFbVmoK6ORIqQ3KDodIVMguRpy89W+Nx2eWRvWb
9nXHPV2u5cnfY2sI002ptp1BGfoytPwK1XuxfsULW26rpKloxFI0Mk7shSesN16TEui2zwXJ6YHFSYaiS2nD5x81NN7IyO+kfNTS7Qc7PMn3ppdo5UagBxUa2m3Jc3HH
Iwsz2arPVzep5xUagrn5yGv6sfujCYo1SDLO8ky1dY/qbHWv5zOjgHntO+AC6443lj5dXLib8nC3n11H+8uQqD6wC974CpEJVAiEqgQCAQBQCBIBA0AgFAYQCKEAgfJF
GVFMKK9R0S59i6LdW6jgJZW1MjLdBKNzmNONrB/e+C4X65Iq3H3Zk9BygdFvSL1v+a9RG1rTwEhacEd/s+QTJ/qVSv3ZZVnu9gqbho+/suDnXCzW9tFFZI4XGaepGQ3Z
d7Oy4uyT3LNq26x6rExLFvOmL/V2t2nNO0BqoaeodNdaqN7WirrsFzo2bRG22IEgAc8laraInckx5Q8rcHNcWOBDmnBBGCCOS9DmSqGiBAIBECBKgQCgFQIBAIgRV8W5
isMymiAlAZQJA0CQCAQLmgSAQIoEgEAgRRSQCIEUlAKhFQCoSAUFaKECQAQNAIGgEAgECQNA0HQj83b2gcowB70RpKjdLs9gCKyrR/nEn1PvUG3VAEEggkEDUAgYRpfS
n/GIfrj7Vi3aXSn3odH0quzoyi/9az+o5eHhv9WfyfR4z/Sj83ja+g+WFAsoNzpuPaq5ZPoMx7yVYSXSqoEGPVbmAd6DFQPKDvOj26BwktErt4zJBns+c37/ADWLx5t0
nyd0QubZEIpKAVGi1ZqGl09bDVSgSVD8tp4M4Mju/saOZ/FIjaTOngdyr6u510tdXTGWolOXOPwAHIDkF1iGEaeEe24buQViBlhVEgUU8oDKB5QPKihAZQCKEAopIBFC
AQJRTQNRTBRVjXEc1FS2+3f4obWRzuYQW+qQcgt3EKTG2otL1ux3Ck1/YXWe7PDLpTt2mSgesd2BI37HBfOvFuHvzV7S+jSacTjml+8PNLtbKu0181vrY9ieJ2Djg4cn
DtB5L6VLxevNV8jJjtjtNbMJbYCgbHvY4PY5zXtOQ5pwQUWJdJa9SvYWxXAF7eUzRvHiOfiFia+jtXJ6urgminjbLE9r2O4OacgrDtvbHvUfWWubd7OHeRSO7NuwfGyo
oxG/2XsHDlu4p5tx1hk0Ej3wNbJ+lj9R/eRz94WJh1rO4ZW0o3si5TS7VOcmmolEOUaiUsrOmokwVGtrIpGxPEr/AGY/XPgN/wByzeOjpSfihwrpXTSPlf7cji4+JOVv
WujlFtzuVGoZNi326mHF5kqHe87LfgCuvDR8Vrfo83tG+seOnruf9ocvKcyHyXrfJQVCRAqyEAgSBoBAkDQCAQCAQNAIEoBFCAygMqK9Y0S2k1L0Y3PR8VxpKW7x1wrI
Y6qQRtmbuOAT4Ed25ee+65It5OletdMfU01t0poI6KprhTV13r6oVNykpX7ccLRjZj2uZ3D49y1WOa3MTOo00OmKmDTNmqNUdfC67yl1LaoNoOdE4jElQ5vLZG5ueJKt
4m08vkkdI266yy0c9JoG+uvdFBa7BFJLcI5KgCYVG2XHEftPc/dvHaVymJ+KNdZa32nbyWvqXVlwq61zdk1E8k2z2bTi7HxXqiNRpymdyoVQIGiBAFUCBIBECKEQIoQC
BKDJaMNA7lpk0QIBAkAgEAgEAUCQJAIIoBFCBKBIGqBEJAKKSoEAUCUFSjQVQIBA0AgEBlA0AgECQGUHSe1QNxzjag0lW0iodnu+xBkWrdO/6n3qDbZVDBQSBQSBQPKA
yooyir6Y/n4vrj7Vm3aXSneHQdKRxo2hH/jWf1HLw8P/AKk/k+jxf+l+rx/K9z5ZIBB02mY8Us0v0348h/etQkt0iEgxqo72hUYxQIoLaSompKmKpp37E0Tg5juwhSep
D2i03CK526Cti3CRvrN+i4cR7iuMxqXaJ2yyopIMevq6a30U9bVyCOngYXvd2AffyHeiPnnUt6qb/dpa+oy1p9WGLORFHyb95PMrpEaZmdtdBHtuyfZCqMwLSGgeUDRR
lA1A8ooyijKB5UBlFGUUsoBAKARQgEU1AIJAoqWUACorNt1fU26shraOUxVELtpjhyP3juWbVi0alul5pPND1O7Gk19pYXOhjay80TSHxA7+0s7weLT27u1fPx2nhsvL
b7svflxxxWLmr96HlGchfVfGPCgeEAis2219TQSbdPJsg+0072u8QpMbai0x2ddS3ukuVNJTvIhncwjYcdx3cjzXOYmHaLRaE7XUCWihIcHYbskg5Unu6Uno2Ebw1+0O
zB7wpLUSv2wd4KzpvaBeml2rc9TTUSQcmmolIOWdNRKYcppqJa+91PVUD4wfXm9QeHE/896murXNqHMg9nFWUhg6lePlWSEH1aZjIB+6N/xJXp4eP5cT6vD7StviJr+G
Ij6Oezk5XZ4BlVAiBVCQNAIBAkAgaAQCAQNEJFNAkAoBAkUIAhp4tB8QikAAMAADuQLA44G/iUDwM5wM9uN6ARDRAFQ0AgSAQCARAihAIEgEEm73AIMgqsFlAZQGUAgE
CQCBoBAkCRSKISKCoEqBQJAIBAFBFAIBAFAkFajQQCAQCIEU1UCAQCAKAQAQdFbniSiYDyBaVBhXOAtDZvm+yfHkqKbYfzz8fR+9QbQFUMFBIFBMFA8oDKKYKgvpj+fi
+sPtWbdpdKfehv8ApROdHUP/AK1n9Ry8XD/6k/k+hxX+l+ryBe184ZQCDsrHHsWuDI3uBcfeVqGZZ6IRQYlUfzmOwIMdUCgaDq9C3oUNf6BO7FNVOAaTwZJyPgeHks3j
fVqs6enblxdRuCo8j6W7/wBdVM0/TP8AzcJEtSQfafj1W+4b/E9y1WPNm0vNWgucAOa2yzmNDWhoWhJAIhopoGgEAopoBFCAUUZRQgaAUAihAgUUwoDKBgopgoHlFGVB
udLXyr09d4q+nBfH7M8Wd0jM7x4jiO9cc+KMtOWXfBlnFfmhs9W0VLT3mSegc19DWNbVU5HDZfvI9xyFeGtNserd46OXF0iuXde09Wiwu7zEilhAwCins5UVmUFVNRy9
ZC/GeLTvDvEKTG1iZjs6alvVJO0CX8xJ3n1T4H8Viau1cm+7PbUAcDkFTTptPrQeaml2W3nmmmtmHd6ixKQf3qN7S60AEk4A5lTTUS5m4VXplSXNz1bBss8O33qL3O3x
tfXU7XexthzvAbz8AueSdVl6eHpzZKxP/ddXKV07p5Z6h3tTPc/zOV9CsctYh8HLfxMlrz5zMsFVzCqBENVCQNAIEgEAgEAgaIEUIgQCARQoEgECQCAQCKEAqhqAVDQI
oBAZRAihAkAgEAgAoJxDL/AKwkrlWRhFGEQIpIGgSARAimiEQgWFFIoBAsIDCBIEgSAQCAQCBFAkAgrUaCAQCIEUYQNAIBEGFQYQCBoNha5hHKY3uAY/n2FBuZI2gOZI
0SROGHBRdtdFDTQzu9Hlkdkb2vZgt9/NIRflUPKCQKCQKIeUU8qKYKC+B2Jo/rBZt2luveG96UD/APg+hP8A41n9Ry8eD/U/R9Div9L9XkgyeRXsfPT2HfRPkgi5rsH1
T5IO6ptmKmij2mjZY0ce5aYT6xv0m+aAMjBxe3zCDBqJGmV3rNx4oK9pv0h5oDbb9JvmgRkZ9NvmqI9azO6RoPblQev6OvDbzbAXyNdVwYZNg8ex3v8AtBXK0al1rO4b
a6VbLdb6mvkwWwRl+PpHkPecBZjrOlmdQ+a7kat9bNUVp2p53uke/k5xOThdezCNKzJL+Q4KwMpVAgaAQCKEDQNQCKEUIBRSQPKB5HageQop8eCGy2SeSGxsP5NQ5i6q
p+bED4uUOZHqawn1mMA7ihuVwhmxvZ5JtoxDOeELz4BTcKvZQ1j/AGaaU/ulTmj1ais+jY0mlr5VsZJDTwBjhkbdVEw+Rdlc7ZqR0/2l1rgvaNxr6w3NPoHUrwMUtN4i
rjP2Fc54nHHf/DrHDZJ7f5bX8htQvpIIJ2xM6jaDNmQO9UnP25WI4rHWZmPN1twGXJWIny2pPR/ducsY8VffsbMeyM0+aTej+5n+Xi809+p6L/CMvrCQ6Prl/wB6gHvT
36nov8Iy/ihP/B9ccbqum95P4Ke+09JX+EZfxQiej27cqqjHi534K++09JT+EZvWCHR/dRuNZR+bvwU99p6S1HsfN6wkej+4uGDX0g9zj9ynvtfRf4Rl87QyaPRF4psB
l3ptj6BY4j+5SeNrPk6V9k5I/qhuGaXqtkbVZDnnssdhT3yPR0j2Vf8AF+x/k3O3jVs/myp73Ho3/Cbfi/Y/yfeP+uN/gP4qe9x6NR7Jt+P9iFhfnfWMx9RZ97+TceyZ
/H+wm01FPEWS3B7Wnj1bRv8AHKk8XPlCx7L69bMQaStzXYNdNjvLQse9Xnydo9mUj+qWFfbNR2e0VlfBUySSCMxsBIIy71eXiV0w3tlyRWYc+JwU4XDfLWeutfXo8vqN
zWtX2H5FjogRAgFUCAQCAQGUCQCIEAgAgaAQCARQgSBoBAIEgEAgEAgaAQCBIBAIBECKEAgSgYVG6sduiq4ppZi8AODW7JxyyVmZ0sRttPkWj7Zf4v7lOaTlgvkak7Zf
4v7k5pOWD+RqTtl/i/uTmk5SNmpO2X+L+5OY5UTZ6Ttl/i/uTmlNF8kUnbJ/EnNJovkmk/1n8X9yuzRG1Uv+s/iTZpE2ul/1n8SbTRfJlN/rP4ldmkTbab/WfxJs0Xyb
Tf6z+JNhG3U37f8AEmxE2+nH0/4kC9Ap+e3/ABIiJoIP2v4kC9Ap/wBr+JUL0Cn7H/xIF6DT9jv4kETRQfteaBehQ/teaBehw9jvNAjRw9jvNAehw9jvNAvRIex3mgPR
Iex3mgxOpj+j8U0uy6qP6PxQ2Oqj+j8UD6mP6CB9VH9AIARR/QCB9VH9AIbPqo/oBAxFH9BqB9XH9BvkiDq4/oN8kUxHH9BvkgYjZ9BvkoJiNn0G+SC9kjmjHJUUxhwn
c4jcRxQX5QGUEwUEgUQ8ooygYKirYT+dj+sPtUns1XvDrdaEv01St5ektP8ARcvJw/8AqT+T3cX/AKUfm8/MeDuC9j5xet3qhEHvQLZ7lFGz3KiJYexQR2T2KiJaexQL
B7EUi1BHCIzLXdK+0VQqrfO6GXGyd2Q4dhHMKTG+6x0dLddbSXizGgq6Mwyl7XOkhOWvA5YO8b8cysxXU7amdw5WV8EgLSx7mnk5oW2WJsNbuijcG95youxsu+iVV2Ax
/wBEoiQjk+gUEhDKeEblFSFNOeETvJNmkxQ1R4Qu8k3C6n0TFvqv1RU5oOWfRIW2qPzPiFOaGuS3osbaakjfsj3qc8LyWWNs03N7R71OeF8OybbK/nK1TxIa8KUxZG85
vgniL4U+qQskXOU+SniL4PzWNstNze4+5TxJXwY9V7bPSD6R8lPElfBqtbaqQfNd5qeJLXg1WNtdGD+jP8SzOSWow1WC3Uf6keanPZrwq+ixtDSN4QMU55Xw6+i1tNTt
4Qx/wqc0ryV9ExFCDnqmfwhOaV5YWNa3gGNHuU2uoTDQoq+J2y4b+akrDzOp2PSJsNbnrHcu8r6UT0h8eY6ypD3N9glvhuUVaypqWnLaiYeEjh96kxDUWtHmy47tdI/0
dzrW+FQ/8VmaVnyhuM2SO1p+rMh1PqGH9He64eMpP2rM4cc96w6RxWeO15ZcettUM4XiV312Md9yxPDYp/pdI4/iI/rZcfSDqZu41NO/61O37lmeDxejpHtTiI8/2ZMX
SRfm+3DQyf7Ij7CszwOP5utfa+eO8QzI+k2vH6W1UjvqvcPxWJ4CvlLrHtnJ51hlR9Jv6yzD9yo/ELM8B6WdI9tT50/dlx9JtuP6W1VTT+zI0rE8Bb1dY9s086ysPSHp
+TfJTVzfGMH7HLPuWSO0w6x7XwT96JVnVukak+ualhPN0bx9hKnu3ER201HtLg577+i2O86RdvZc3M+vt/eFJw8R6OlfaHCfi/yvZcdNv9m9Uo+sfxWZxZo/pda8dw09
rwvjqLTxhvFA794fisTXJHesu9eIw27Wj6oyuE3+bVVI/wAHLPWO8S7xek9rR9XLa1kqqW1Q00zmE1E+16n0Wj8SF7eCjd5t6Pj+3MnLgim+8/4efzOy/wAAvpvysq0Z
CARCyqHlAIBAIhIpoBAkAgYQCIMooQGUAgEDQGUCQCBIBA0AgMoDKAygMoEgEAgFAIBAIGg7LT8ZitURIwXkv8zuWLd247NiSsqiVUCBIiJVECgSIiVUQKCJQRKoiSgj
lVESggSiEgiVRElBElAiUCQCCJKBIESiFlFYCqhQCAygEDQMFEPKKMoHlECKYQSCBgqCQKCQVDygMoGCgmCgkCgaBZUVbA789H9YKT2ar3dfrFw/J+jHbUD+qV5OH/1J
/J7eK/04/Nwy9j55YCBgBFMAIJYCgMDsCKNlvYEBsM+iED6tn0R5IHsR/Qb5KKOrZ9Bvkin1UX6tvkgl1UX6tvkouh1cX6tvkhoxHH9BvkiphjPoN8lBIBv0R5KKkMdg
RUgo0kCipAqKeUUwopgqKkCgeVGjyimCoJAou0g5RdpByjW0g5RUw5RTDlNKe0mhIEJoMyMbxcAmpTcQrfW0zOMnkCVYpLM5awxJ7zAz2WyO8AtxhtLE8RWHK3GCCXbm
oopmTOdtFr3AtOeOOYXevPHSXkvNJ61hrurrWjfS58Ct7c0C+ob7VHJ7k2Eah49qmlHuTaj0tnNkg9ybDFXDzcR4hNiQqYD/ACgV2JieE8JW+abEusjPB7fNFPa7CPNQ
RcHuHquIKaXaOzOPnpo2YMw5gobPrKgKLtF1RUZxsZ9yBRvc8nbYBjuUVa0DkAE0u1kDx1krXOJwRgE9y1WGLTMoSH13eK05ygSEQkQIBUCgFQZUAgSoeVAZQCAQCBoE
gECygMhNh5HaPNA9odo81Qttv0h5oaLbZ9JvmoaLrGfTb5ps0XWs+m3zTZodbH9MJtdF10f0wmzQ66PHtJs0XXR/S+CbNDr4+0+SbNDr4+/yU2aLr2d/kmzRekM7CmzQ
9IZ2FNmh6Q36J802aHpA+ifNNmi9IH0D5ps0PSP2PimzQ9IP6v4ps02Vqdb3uLq8ytwdzWty0jvPFOq9HYwVlJK0CCaMgDAAOMe5Z0u1u0FAZQGVUIlBElERJQRJVESU
RAlURJQRLkEC5ERJVESURAlULKBEoIkoI53oEiBFIlBElAsoEUCyiMHKNDKqEopogRQgeUQZRRlEG0exAttyKW27tQG2/tKBF7/pFBHbf9M+aA62Qey8g9+9BD0qsHKF
/mFOq9EhW1A40wPg9NyahY2ufzpX+5wTZpYK/wD8NL8END088qaX4Js0Xp0p4UkhQMVVWeFGfe5BJs1w2g5sETcHO9ySsS2NRX3KtZG2vlDhGPUa32W+5ZpStezV72t3
UFbcyyoGCgYKKeUACgllAZUUAoJAop5UBlFPKKeVA8opgoGCoqWVFPKLs8qLtIFDZhyLtIOUXZ7SLsByi7SDkXZ7Sml2A5F2kHd6mjZ7SaXZh6ml2Yeppdph6ml2e2ml
2kHpo2YkTRsbamjY9U8QEUbMR4xtPiE6pqEHQ05/kWeSbn1TlrPkrdTUx/kgtc9vVPDp6KnUNMfmY96eJZPBp6IG2055OHvV8WyeBRD5KgPBzver41k93qg60Qn5w97U
8afRPdo9VbrHCfmxHxateN8k92+al+n4T/IwnwTxoSeGsodp2I8IB7nK+LVn3eyl+nG8o5B4OV8SqeDf0Uu0+9vsmce9Xnr6sziv6KnWadvCeYeIVi0JyW9FTrZWN4VT
ve1XaalW6huA4VDT4hOqIejXIc43J1Nn1VxHGFh8Cr1Nl/j7ONLnwQ5lLpKnrNo072nwKbTex11QT+gcfcU2mjElQeFOfIptNQe1Vf8Ad3fwlXcmoP8Axw/yB/hTcpqB
itP8gf4U6r0PZrT/ACPwCdToNiuJ/R/YnVOg6mu+iPgnU6Dqa3u8wmpNwXUVnaPMJqTcH6PWc3DzV1JuD9GqzxkaP3lNSbgvRqrnKPNNSbhIUtR+tHmU1JuD9Dm/XD4p
o3A9Dl5zD4po3A9Bfzm+BV0cwNCf13wU0bMUHbL8FdHMYoG85T5Jo5j9AZ+sd5BNHMPQI/pu+CaOY/QIvpP+CaTmHoEPa/zTRzSYooB9PzTUHNJ+iQDk7zTUHNI9Eh+i
fNNQbkeiw/Q+JTUG5Ho0P6v4po2fo8P6sK6NyOoh/VNU0m5PqIf1TfJXRuT6mL9W3yTRuR1UY4Rt8k0bk9hg+Y3yTQey36I8kNlsjsHkgMDsQPAQCAQGUGRFWVMX6OZ7
e7O5BmRXmpbukbHIPDB+CzpdsyK9U7t0rHxn+IKaXbLjraaX2J2E9mcFNC4lBEuRESVRAuQQJ3oIlyIiXKiBcggXIiJcqEXIIlyCJKBEogyqEXKBbSoRKBZUBlAiUEco
MNVQoBA1QKAQJAIqQRAgaoEBu7FAYHYEBgdgQGy36IQPYb9EIp7LfojyRDAHYPJBIAdg8kEtwQPKBgoJt4pKwnI71QpDUqiVWCygMophyB7SB5QG0op5QMFFMFQMFFPK
AyoDaTSmHIuzDlDaQcimHIu0tpQ2NpF2e0obSDkXZ7SLs9pQ2e0i7MOU0uxtJpdntJpdpAqaNntJpdjaU0uz2k0uz21NGzD00u0g9NLs9pTRs9tNLsw9TRsw9NLsBymj
Z5TS7PaTRsbSaXZ7Sml2Mpo2MppdnlNGxlAi5Ai5AsoEcdgUUi1h4sb5K7k1CBihPGNvknNPqctfQjTwH+TCvNb1ZnHT0QdRUzvmfFXxLeqTgxz5IG30o37LvNXxbp7v
j9GFPSNBOwT711rknzebJw8b+Fhvjcw7wV0i0S81qTHdDC0wWFULcgRCBYRAgSBFFCISBYRTQNAIh4QJAIBUCgEAgEUIEiDCAKCKKEAgAiGikgFUCAUAgEUkAgECQCAQ
HFBdFPLF+jle3wKgy47nUt9rZeO8YTRtkMusZ/SRub3tOU0L2VlPJ7MoB7DuUFm0DwIKoiXIIlyCBKIiSqIEoESgiSgiTvRBlULKBEoFlAZQGUESUCJUCyisVUGUDygE
AooygEQIGEDVAoGqBAIDKCQUDQCAQSQGUDygeUEgd6LCTzkBSFlXlaZLKgMooygeUBlEMFFPKB5UU8oDKB7SKeVAZQMFF2eUUw5QPaQ2e0ml2eVF2e0mjZhyml2kHIuz
yhs9pNLsZUNntIuzDlNGzDkXZ7SLs9pDY2lF2NpNLs9pTS7MOTS7PbTRs9pTS7PaTRs9pTS7PaTS7MOKGz2lNLsbSaNpbSaXY2lNGz2k0uxtJo2NpNLstpDZbSGy2k0b
PaTRs9pTS7LaTS7G0mjY2k0bIuTRtjyhbhysxZB2rcONlD4weAwtxLjakKXNIW9uc1QKrGkSqhIEUQkUIhIoRAgEUIBVDQIoBAIBAIBAIBAKKECVQsKKEBhAIgVAgECU
UKoFAIpIGgSBIBAIBA8oDKIRKAyipNke32XEeBQXsrJm8XZ8UF7a0H2moLBUxu54REtsHgQgWUESUCygWUQsqhEoFlAZQGUCygRKCJQLKgoVUIoRAgEAgFA1QwgaACAQ
CBIHzQSCBoBQNA0DVCUDBRTBQN53KKhlVksoGgaoMqBZQPKB5RTygMoHlAZUUZQPKBgop5QGe9QPKKkCgeUU8lQ2eUXZ5QPaUU8po2Mop7SinlDY2kNntKaXZ7SGzDkX
Z5UXZgouxlDY2kXZgqLtIOTRs9pNGz2lNLs9pNLsbSml2A5NG0g5NLs9pTRstpNLs9pNGxtJpdkXJpdjaTRstpNJsbSaXZ7SaNjaTRsZU0bGU0bGU0u0H7wrDMyxnrcO
VlLlpzlUVpiVZAWoYmECFdsTCJCJoiFUJEJUCAQCAQCBIGgSAQHNAIBAIBAIBFCIECQCihVAopIGqhIBQJFCqBAYQCBKBIBAIBAkDQCBIoQNAIGgA4jgUFjZnjmgsbUH
mERMTNKCQcDzQGVUIoBAkAgRKBZQIoBBjqNGqgRSCIaAQCimqGEDRAooKqBAIAIJBA0AgYQHNQMqgUAimEA5BAoGiGEAqAIAoBFNQNAIBAIBFMcUDCAQMKBoqQRTCgki
mgAopoBFCBqKaAQMKBjiimimEDUUwgCgFFMIpoHyQMI0FAwgMoqQQMKKEUDggCgSKSIAgaARQiGikik5ElQ9WHOyp61DEqTwWnOVZVSUSqySrKJVSUSiEqhIoKgFUCAQ
CAQBUUlQFECBoEgEUlAwqBECKEQIBRS5qhKBqgRAgSihAkDVCKgSAQJUCgECQSQBVRFFNENQJFJAIBAwgkgk0lBME9qImCVRJEBQLkgEEOaBoFzQf//Z
END_EMBEDDED_ASSET -->

### thumbnail_style_tinh_di.jpg

SHA-256: `e18d5944f310bef135e5a7e1a889daaf73d930abfd7aaa5b2d71f31a6de25e1d` — 61304 bytes

<!-- BEGIN_EMBEDDED_ASSET: thumbnail_style_tinh_di.jpg; encoding=base64; mime=image/jpeg
/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAcFBgYGBQcGBgYICAcJCxIMCwoKCxcQEQ0SGxccHBoXGhkdISokHR8oIBkaJTIlKCwtLzAvHSM0ODQuNyouLy7/2wBDAQgI
CAsKCxYMDBYuHhoeLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi7/wAARCAKjBK8DAREAAhEBAxEB/8QAHAAAAgMBAQEBAAAA
AAAAAAAAAAECAwQFBgcI/8QAWBAAAgEDAQUEBQYICAsGBgMAAAECAwQRBQYSITFRE0FhcQciMoGRFFKhscHRCBUjQmJyktIXM0NTgpOU4RYkNERUVVZzorLwJUVGdIPC
GCY1Y2SENrPx/8QAGwEBAQEBAQEBAQAAAAAAAAAAAAECAwQFBgf/xAA3EQEBAAIBAgQEBAUDBQEAAwAAAQIRAwQSEyExUQUGQWEUMpGhFiJScbEjwdEzQoHh8FMVNGL/
2gAMAwEAAhEDEQA/APih63kAQAAAABQAwAqGQBQEAUIikABDAZQEAUMAACBAMoRAygACBlAQBRIBgIBgIBEDKGQIoQDACAKABkAAAADKEAgAgAJAGAGgGgJYKgSAkkBN
IgeAGoATjAC2NNgWxoSl7MW/JAWxsa8v5PHm8BFsdOl+dUgvLiDaasKK9qrJ+SwDayNpapcVJ+cgbSVvaL+RXvbBtPsrVf5vT+ACcLb+Yp/sgLs7b+Yp/sgHZ2v8xT+A
A6Nq/wCRj7myordpavukvKQXaD0+g/ZqyXmkyG0HpkvzKsH5rANqp6fcrlT3l+i8hdstSjODxKDj5rAFTpgRcAIuIEWgItFEWiKMBCCkwEAAACKAAAAEyAAZQAIgQAAw
GAihMAACBFCAZAAIACkAMICgIABgIKAgKFgBgJgAAAAAAAiBlAAgAAAAGAmAAGABkEQphDAApAMAACoMEUgGAABUBFAQyhMigBAMIaKABgIBkAAigCmEIAIGgGAFDAaI
GUIgCgACAAChgIAIAAKGAEDKEQBQEAUBAYAaQEsAGAGkA8ASSAkohE1ACcYFFsaWSDXb6fcVsOFJuPznwXxCOhS0dLjWqrygvtGzbbRtLSjjFFSfWfEiMVxWxWqKOEt5
8FwKqPa+qgIOo33gLfAW+Ab76gG+At/xATn4gLe8QJKQBvsoamQWKo+oE41Wu8CxV8rD4ro+IRCVC1q+1SSfWPALtRU0uEuNGt7pr7QbYq+n3FJZlSbj1jxQNscoBVbi
BFxAg0URaIE0VUSBAACKGAAAA0AAAAAiBAPBQIBgIBAAAAgAAIABAIKAgAYAAigAAAAAAABAAAAAACACAAChEUFQwEAyAKAAAAEQIAAkAgoAYAEAUgGAAAQAAAFAAAgh
hTKhgIAIAKAAAAYBgIMAMKAhgAAAwGAgAAKAAIGUAAAiAAYDQAUDAQAQGCh4IHgB4AYRJIKaQElEImogWRhkC+FFvCSA6ltpFaolKp+Sj+lzfuGx1aFlaW+N2nvzX50+
JEXSm33gVtgJgefuptXNZfpsqnGWYoIeQBtlCyAZAMgACyAZAeSAyUPJA0wJbwDUgJxn4gWxq+IF0K7XeE0jVpW1x/GU45+cuDCsVbS3zoTU182XBg251WhOnJxnBxl0
aKrPKGAK5RIINARaClgoQCAEQMoCAAQAAFCACBlAQBQAIgChABAFAQACYCwAFAQBQAACIoKgAAAAAGAgAgQUyoQAAEUAAAAioAGAAAUiIAoAQABIIAoACoAAigBAADAA
AAAAEAYCGgplQwABEUBAFADQQwGUBAAAAAABQ0AwAgQAUBAwAoRAwEAwAAQDAAAoCBpASQDwA8ANIImogTUALI0wLoUgOjY6bWuXmK3affN8vd1JajvW1pbWiTpx3qnz
5c/7iKsnPIRTJlEQIrmFDA83eP8Axuv+uyiyHsR8gJBAyhEAABTCEygAAAgEA0AygAkmQNNgSUgLIzAthUwBa3Tqx3KsFOPRgYrjTMpytpZ/Qlz9zBtyatKUZOMouLXN
NFVRKJBW4gQaAi0FLAAUMgAEAgAoYCwQIAKGAEAUIAAAAgCgACBFCAQAQAAUAAAgABgIAAAoIhBSYAVARQEAAFAQFUgAIYAAiAKAAIABASAAoACoAERQEBQyKAAAAAAI
AoAAGEMoAAgCgAMEUIqJIBkCAAAoAGAgGAEDKABAMAARAAMAKAAIGAwAAAeAHgCSQRJRAmogTUGBbGm8gaaFrUqy3acHJ9EgNc7GVBxVbEW1nC4hHV0q2tZUZTnRjOSl
hOXElHSlLCSSSS5JEFMpAVtlUgFgCEHltd+QJtEHmb3heV1+mzQsp+xHyAkAFQYIoAADAQFAAYIFgBgMBgAUwgAaAkgGmBZGQF9ObQFtSlQuo7laOWlwkuaIONf6dUt/
X9uk3wmvt6FNufKmVVMokEGgItBSwVCIoATKAAAQDARAABQiAKAgChgGCAYCKABMBEAUIgAAAKAgCgAApEQFAQACKoIFgBgIBhCCgoQAAAAQwABEAFAAAgiQUgGAFQAA
UiBlQEUAIBgMBAAAAAMAAYQABQAMKAhkAUCACBgAAUADAQAAAADIAoCAAYAAAADAAGUMgaRRJIiJKIFkYgXQp5A2WtnVrzUKNNzl4dwHbttGp00pXMt6XzI8viTaN8VT
pR3KcYxj0isEHI1ir+Xh+p9pYNGkTfyaf6/2IVW1sgiwFgoCB8GBVDnP9ZgWY8APMX+Pl1x/vGaVOn7EfIImA8BBgAClgIMBQEAUAGAHgAwEMAwAJAMBgADQEkwJKQFl
Ko95hWxVE6MVJJpuSaffyIlc2909OMq1ssxXOHTyKOPOOCqolECDRBBlCYUiAARQAAAAiAAQAAwAAAAGAgEUACIAAAQCKGQAAAFCIAoAABABFBUACAAoZAghlCCkyAAA
ABgAQFCIoCAKQRMKQAEBQECCgBhAFIBgADCEFAAAAADCGAABQwAAIGAFDIAoCBgIBlDATAQAQMoCAKAgYAAAMBgIB4AeAhpFEkiCaQFkYgaKdPIHoNO0Sc1GrdZp0+aj
+c/uJtHciqVCn2dGChFdyIKJybYFT4hXE1p4uaf6n2lg2aLxtJv9N/UhR0MECwA0gKbtYovzRYOfx6gNIC+0nJTknywSq4V8831x/vGagvpL8nHyCJpBDwAsBSaAMALA
BgAwA8APDAMAPABgAwEPAAFGADADAAGAU3iUgL6k8UKX60vsIi6zq88sozalYxqKVeguPOUF3+KA4U4hVMkBBoCLQVFlCAAABEAUIgABgBQAMAACAATKABAIgAABMBAM
AAAAoCBAAAUIAAAAigqABEUAIAYCAAGAAACCAKQDCABZ4gSAAoAAgAQUwAqAigAAYQBSYAAwAAAYQFAAwGAECAYAA0AwBAAAAFDACBABQABAFDQAAEDKGAEDAeAHgIkk
UTSILIxA1W1CpWqRp0oOc5cFFd4Hr9L0mnZJVq+7Ur93SHl1fiZtG2rUbfMiM8myithSwBwddWLqn/u/tLBv0FZspP8A+4/qRKro4CFgCM5Rgk5cMgYarc2+eCinGCoa
Ip44dAONeRxeV/12VWukvyUPIIlgAwAmgBxa5rBARhOfCEJT/VTf1DZoSpzh7dOcP1otfWNgSzxWGUS3QDdAN0B7oC3QgwFGADADwAYAMAGAiUYOXBJvhngRScWiiMPb
mBK4aVvR/Wl9gErWXCQRspzw+YHN1S0is16SW636yXc+oHHnHAVU0BWyiLAQUYAQAAAIAAQAQMAAAAoAABAIAIEUBAFCIHgAwAAIAAQUBAAYKABAMBAAAAmFIgAEAAMA
KAiEABRgqAikwgCpAIB5CAKAhAAUwAAAAgKoIAoZAFQEAAFDIGUBAyhABAwABgMoAAAIAAAaKAAIEUAAQSACgAYAAwGENIipJBE4riBbGIGq1tqlerGlSjvTl3Ae20mx
o2FDMcSrS9qf2LwM1F9WeSDPJ5KqDAWAFgDg68v8ap/7v7SxW/QF/iM/96/qRKOlgIaiQZr7CjDzZYMsN2XOWCW6WTaO5vJtGtppbZ20bi8oUJScY1JqLa7jHJl243Jr
Cd2UjbrOm09PuKNGnWlUVSOW5JLHHBy4Oa8ktsdOXjmFkjy99FK7rrpNnpno4r6S/JQ8gG0whpPoBHUbmFhRoQhu/LLhb6qTWY0IZwnjvk8N+C8WZ9XTGeW2aWrUbSO5
Y0I16nOVzdrfcn3tQ5L35Y7b9V1GaptFrFTg9TuIr5tKe4l7o4Hbj7L5ox13V48tVvPJ1nJfSXtx9l80461eTebhUK/jOmk/jHDGtJY6FtW7eG+qSgvCe8gxZpduhksA
PBQsAGADdAMAGADABgB4CNmnZi7t/wD4tX6jOX0ajnZNMnhBSuP8no/rz+wBWr4SBWlMIti04uMuKfBoDiXtu6NVx47r4xYWMUogVSiBBxKFgKTARAgAAAQAUAAAAAAQ
ACYAAFAQIoCAAQDAQAAAIAAQDKEAAIAIAoAABBSIAIAAKAAIZQiBBTCEFAC7wJAIIAAKAAAAAGgAAKAiAKAGEMoRAwAAQEihEDAAABgAAUMAAAAgCgAEAyAACgRA8AMA
AAAoCCSKh4IGiiaRBdGIGq3ozq1I06cXKcnhJBXsLCyp2NDCxKrL25fYvAztm1dGo87vcApyeSKiygwA8EBgDga8v8ap/wC7+01Fbtn1/iU/94/qRKjqYIDAGPUF6tPz
ZYjVo+oW9jRqQq2irOUt7Lxw4cuKPPz8N5LLLp34uWYTzm2WNWkqU49n60m2nnkde279WO6a1pVSqSpVYVqeFOD3otrPE1ljMpqs42y7iV/eXN5UhUrzUpQWItRSM8fH
jhNYtZ8mWfq89dtyu67/AE2dZ6MVuoR/JQ8iIs3V3gdKpStdHowr6hSjXvKkd6lZyfCCfKVT7I/ExbcvR0xxk868xq0vxjXqXdZpV5Yy4JRjhLCSS4JYNzy8mtuPK3n3
STKbR+T1P0fiF2sjb/Ol8Am0o0Gn7ax5A26ml17W1m416TlCfOpD24eKXJrwJZ7J/d2a1J03H1ozhOKnCpB5jOPVf9cBK52aVNAGPAAwA8AG6AnEAUQBRAe6VEqcV2iT
WVx+olWFSuZxjNRUI78HCWI9z5jRtQ0kVBgCu64UKK/Tn/7QotOKl5gacBDTAnhTjuTSlF80wMdxpiacrfn8x/YByKtNxbi001zTKqiUSCtooi0BEKCAAAAoRAgAAACh
ABAFAAEAAigACBAMBAAAAFCIAAAQAAABQgEAZCggAAoRAAAAEAUgAAAAEEAVIqAgQUBAABQAwAAAZQEQFAQMoCKeCoAAgMFDACAAYAAwABANFAwAAIAARQ8AAAQADQDA
AAAAChogkESSKJJEFkYgaacEB63R9P8AklHt6sfy1RcF8xfeZtStdSYFVLMq/PhjIqrZriQGAHgBpASUfADz+0Cxd0v939rLFbdn1/ic/wDeP6kKjqYMqaRUZNQjwp+b
LBjSwAYT8wHusAwgOPeRSu6+Pns19BuoL8lD9VEGujUo2NKep1oxn2T3aFOXKdXuz4R5v3Gb5+Uawn1rzVxd1ritUr16kqlWpJylKTy2+prWmlEqnBgU5KBMB5AYD4d4
HT0y+3F8kqvNKTzBv8yf3Pv9zJZ9S+c06e6HMt0A3QHugPdAW6A90B7oC3QJU4rfWfH6hQaXTpVdQtqVSKlCU0nF9/A581swtjfHJcpKu123pUdRlTo01TgoRe6vIz0+
Vyw3V5pJnqOa00md3J0Np6NOlS05U6cYb1Nt7qxl+rxOHDbd7duSSa05tkvyc/1l9R2cmnACwENcCi+DAhd2dO7jx9Wolwl94Hnrm2qUajp1Y7sl9IVklHAFTQCwFLBQ
nyIEUACZAgAAKGAgDBAYKAAIABAAAAigARAAAAAAIAAAAoRAFCACBFAQAUFQgDADIEAgoAQDAAgCgIYAAFBgikAwgCgAAYQFAAwAAACCSKAgCgIAAYAkA8AMAAADBQwD
ACIDAAUMgZQAAAAyBgBQEAAYAaQEkgJJBE4oC+EfAI7+z1kq1ft6kc0qXHj3y7kSq9HXnlsyjJLiUO2/j5fqfaKsaGuJAboCfqxcnwS4sCtXVv31UNUSVzbvlViTVVw9
b3al1TlCSklTxw8zWPoNmiVqNK0nGc1FupnHuQsHWpThVTdOSklzMizdAx6lH1afmyxKyU6FapHNOlKS6pEueMurWpjb6NVpKgrOrCaj2rb3cric8plc5Z6N43GY2VZp
NSFDUrerWcY04yzJvkuBeeXLCzFOKyZS1ftDXtru8pzt6kJQVPDcVjjlnPpsMscbMmufKZZbjyF4sXVb9dnr+ji3UI5oQ/VIOTr925XFOzi/ydtHGOs3xk/qXuJPd0no
5PaFUt/xAW+BOGak4wgszk1FLq28JAd7a7ZXWNkbq2ttXhRU7ml2tN0p7y4PDT4c08Z8yTKX0XLGxwVURWXc2c2c1faWV5DSLeNaVpR7arvTUfV7kureHheBLlI1Ja4m
8sJmkelsK3yi0p1H7XKXmiOd9WrdCDdAe6AboBuhD3QHugG6RUKnqxk1weCjHHejJSi3GS5NPDQsl9SJylOb3qk5Sl1k8sSSeUL5+pICrUJ1J0qG/KUsOSWXnC4CTSo6
fnfku7AqNrQBgAwBJLARdTeAHd21O8o7kuE17Muj+4Dytxbzo1JU6kcSi+KKrNKIFbQEWgpNARwAFCYCAMAGAABkCwAFAQDRQgEQAAAAJgIAAAAAKEAEAAABQAIgQCAY
UFCCAKCBADAQAAIAAYCAAhlAQAAyqAgCggAABgADKAIZAFAAyAKGAAABggYAAygIAoAGAYAAEAAMAQDwQBQIiGFMAwABAVTQQ0A0QTQFkEBroU3KUYxWW3hLxKj3FtRj
Z2lOhHnFes+r7znbsVzeWUQwBK2X5eX6n2kqxpxxIDAVG4x2FT9VliOEzQXFAUXLzOPkBbaR/JvzA7mlJKnV819RnIbTIxai21SXizURChXrUYbtOWI9MGMsMcruumOd
k1FD4dx0YJtgQkuBByLmL+VVs/OZqDq20V2FN/oolHhris6terVb4zm5fSadlW8wHvAGQg3iK6Gp6xqmr1KNXVb+veVKNNUqcq095xiu5CTXol82LgUbdN1fUdKlXlpt
9XtXXpOjVdKW7vwfOL8CWS+p6MW9lYKPR7NvetK0fm1PrRKxk7O6RkboBugPdAN0B7oBgAwBXVh+Tl5AU2kITr04zWYt8RndY2rjN1ovaFGFxbwpwxGbSks8+Jzwytxt
reUks00avYULadt2NLdU6mJcXxXA58WeVl21yYya0x7SUqNu7aFKG4nvvHwOnBlcpbWeXGY2ac2xeakvI61zbmuC8yCW6AYKgwBJcwLqcgIalYq7odpTS7aCyv0l0A8n
VhxKqiUQItFEWiCDRQgEABSIAoCAAAAAKAgTKEAYAAAgTKFggAEAAAAAAAAAFCAAEAiAAChMKCAAAEwEAACCGFACCEBIoCKAAqABEUwAAAZUBFNBDKAAAYAQNABQwEQM
AAYAUMgCoCKCgAAGQGCgwECQUwgwRQEMAKoQDCABkDAaAkgL6a4lHoNnrbtbztWvVpLe9/cZqPRVDIpk0u8qq95PkEWW38fLPzPtJfRY1rHVEUeQFdwvyFT9VliOCaDw
Bnrpb68gOhaxpx0Wdbd/KfKVBS8N3ODl3Xxe36ab1PD39dt2k5lTqP8ASX1G8mHSUTKsepRSVN+LNYpTtrilToqMotvL4o5cmFt264ZSTTBvZb8zs5WtdhShXvKVKa9W
Tw/gc+XK442xrCS5arRqljTt60I087rjvPJjhzuU3WuTGY3yeWvUlc1v1mehzdC2TdvTXc4pER4GpF06s6cucJOL9zNO8QyA8gGQDIDyA8gGQhpger2ZptWE5v8APqPH
uWCVjL1dnBGRugG6BXXbjTzF4eQKHVqfPZQu1qfOYQdrUf57A122ZUsyeXklU68fyM/IQc1PDynhrvLfMSjOUqtNzm3iS4t8uJLNS6XfnHZ1uva1IUVQrdo1J5xNvB5u
nmUt7o7c1xsna4GoZqU6LbbxKXN56Hqk041VaervNcGVGh1J/OIg7Sp85lGmjmVPL4sip4CDAE48GBroSwwOBrtkqNz2kF+Tq8V4PvRYOHOOGVVTQEWiCDQEcBSAAEEP
BVLAAQAAUGCIMFUsAGADBAYKFgAwAmiBYKFggTKDAAQADAAEUACIAoQAAgDBAgoAQAAgAoAgIoAAhASKAgAoAAAAAAGEIBlDQAAyBgAAA0AygAMAADRAygIAoADBA8FB
gAwAwDABgiGUGCBgAAAgppFBgBkQwGUPBBOKKjRSXFAez2foqlp3aNetVk37lwX2mKNcyDl6gs1Y5+aagyYwVTcmQCKOzpWfkz/WZijVcf5PV/VZIOBg2gSCs117a8gL
LXPZtZeN7OM8Ar0GjQXZVf1l9RnJE7+tOlVjCEscMkkK59Wde5nTpwU6k28RjFZbfgkXyhrb1WlbLa1O2j21pSoNvP8AjFWMX8OLPLyZy5eVenDCyecTjsNfRbdbUdOh
/wCpJ/Yb8eezHgX3X0Nk61vVjVWs6YnHl68vuJnyzKa0uPFcbvZXmz1zcTTlrel5Sx7cvuM4ZzCa01lx931cuewFzXrTqLXtKSk8pOUvuOvj/aseD92+lsNWp04ReuaW
2lj25fcTxvsXg+75l6QtBq6BrUYzr0LindU+1hUoNuOc4lHj38n7zrhnMovbcfJ5VHQMIAAAAYABKMZSkoxTcm8JdWB9A0+2VrZ0rfvhHDfV95muNu61bpELBQ8EFF2v
yXvRYMZQ8AIDfZr8h72SguU+xqeQgyabbRuL+3o1E3Cc8SSeOBnlyuOFsbwm8pK367p1Cyr0Y0IuMZQbeW3xycun5Ms8bcnTmwmNkjmJdx3cld6kqFL9aX2FiM9tx3ii
9IiDAGy3X5L3iizBAKIU1EIup8ADUKPymxqU0szit6PmixHjKsTSs8kFQaAiyCOABoCOADAUAAQYCjAQYKowQGADBULBAYCjABgBYKhYAWAFgilgoMALBAFAQACZQAAC
AQAAAIgGUIigIQUAIoCAYAEACAkABQEIKYBkBoAKgAAAigCQQAMAAYAAygIGUGAGgHgIeOAUYCDADwAYCngiDABgKMBBgAwUNIgeAowAsAGAgwUPBAABRIBpAWRQRppL
vCvd2kOzsqFP5tNGKgkQc7UP42P6pqDEyiOAJIDt6Txtn+uzFVquV/i9X9RknqOBg2h4Az3UV2kcfNEVfaW9aVpVuI026UJYlLuTM3KTLt+q9ts27Gi7/Z1cfOX1EyQa
jTnO5iorMnFJJd7yWegy3+vT0DfsdI3Fe4xcXmMtPvhDol9Jjs7/ADvo6TLs8p6uDHaPWYVe1eo15SzlqUspnTsx9me6+7XV1q+vIqcriok1xSkSYSFyqj5RVfOrN/0m
a1E2FWn8+XxGjaSr1FynL4k0bEripJfxkv2mNG3I1ei6yhKU5PnjLzxNQl04ri4vD5h1IAAAABgGG+QHrtiNClf1Kt1Uk1VhHNrScf42S58e7hy6s5559v8AY13eU9Xf
3Wu4rgkkUS3SA3QM97H8j/SRYMGCgAYHRsV+Q/pMzfVU7iDdGphfmsQYLSFZ3FOFDPbSeIYeHnzGdkxty9Fxltki7Uad9Tr0qV4578/Zcpb3DODnx54XG3BvPHKWTJdq
OkVbGVJdqqrqNpKMcGeHn8Td1prk4uzTl6nQq0Y0qdanKnNOXqyWH3HfHKX0crLPVTax4SKi5rAEeIRttVmj72Si7dAWAACUANNLmEeR1Sh2F3WpLkpcPJ8TSuZJFVW0
BHAA0AsECwUGCBYKDADwAboD3QDdIDdAN0oW6AboC3SKWADAQsFCaAWApYATQCxwAMALACIABFAAgEQBQAIAAGAgoAQQEUAIAKhEAFSKAgAgKFgimgGVAAwAAAAAgYEk
UGCB4AMFDIDADAaRQ0iCSRUPBAYKDADSAe6A90AwAbpAboD3QDdAaiUPdATiQLdAGihYAMAGCAwUMCSAsgQaqMctLqUe9eEkuiwYRXzZBzdSX5WH6v2moMTKAgaQHb0d
f4s/12ZyVtrr8hV/VZkca2UflFLeXBTWfiay/LVx9V2p7sr2tKEcJvgvcY4vyReT81ci6UlVj5HWMulp9St+K7i2jTzTnUTlLD4NYOdxnfMvq3Mr22N2lb1OnUXii1iq
tRvHa13cd9Kk5R8+OPpEm5pZfPbws6kptyk22+Lb7zoiHNgbLSWIyj4gaN4A3gHvAPeAou/WpPw4gcqtT3+PKXUNS6ZZQceaDe0WFLuAEBNLPDvA9PsjptOtc1Xf2VGt
Q7PKhWT3s54NYaaOXLvXlVws3p7ejeWun1YKhZUozhhxUd71enece3LL1rf8s89NktZ0qvKUrrZ+1nKbzKdOcqcm+uU+Ze3KemRZjfWIz0+yu6E7rR6lWapreq2lXDq0
4/OTXtx6tcV3o3MrPLJyy4vri5M5Rgt7u8Do4odvTfX4AQvlm3z+kiwc5ooWADAHT09Zof0mZqrK1SPZVY96WBBhtK/ye8o3G5vdnLe3c4yTkw78bi1hl25StWoXny+8
t6/Y9n2eFjeznjk48XD4eNm/Vvk5O/KVv1a8lO5spS3MQqZ4eaOXBjrHKOvLluxztqqyurujVUov1WuDydunx7cbHLmy3ltntbGlDS6uq3t7Ss7SNTsoSnCU5VqmMuMI
x4vC5vkjrcvPUYmPlus0bnQpc9akvOxqfeXeXsanus7fQMcNbf8AYao3l7HbPdKGo6HShuLVJy481Z1EL3exqe6qpqml4ajqMn/+rMefsmp7o/jXTu67k/8A0JIuqmk1
qenvlWn/AFTGqaS/GVl3VZfsMapp0aE4zipRacZLKaCOFtFTxdQqfPh9RqEcCaKqpoCICAMEBgoaiQPdKDdAe6AboDUAHuAG4AdmAbj6ALswFueAC3CBbjATgwE4AJxA
i4gRcQqLiULdCE0FLACwAAIBMBAAAQIoAEyBFDAQCIAKABhEWUIgmUBAFUABAwgKGAAMA7gAB4ACBoCQAUMAwQPBQ8EDSAkkESUSiSiAboD3WBJQ8CCSgUS7NgPsgGqX
gA+y8CB9kwDsmVB2QA6b6BUHABOAEXECLiAsALAA0AICSAsiQaqDxKL6NAexndLnuP4k0yqV4k87jfvGlZbqt20lJRxhYEgzMoaIJxCu9o0JStHiEn675JmMr5rGm6zC
hXUsrEHzWO4yPPQqpTi1NcHnmbvok9VtSrv1HNyTb6Exmppbd3bFfTzUjhfmmoOjpVxKGm17bdf5SqpZ8kjnlhvOZNzPWNxaYXXYprcUs8Tetubj7QXDrW1Saju8FH6T
UhHl2yqAi63lhsDVvAGQHkA3gE3lNdQMcohSpWlxdS3LahUrPpTg5Et16keq0bZfTbvSKU7qDdxNycqlKphw443enDBm5XbcrNe7C1YpysL6FTpCtHdfxXATJdvM6hom
qWMsXFnVSbwpRW9Fvu4o1vayvTvQK9laUq1OlFyUE6qUfWi8cfNE253dXaXX+R3KnNcGsSi+DwTKd0Mcu2t93cU41pS3lKEm25R4mJHfcqCqwajh+1yKLre4rWtenXt6
kqdWm96M4vDiyWb9SV0b2tT1aiq1vbxp3u9+Wp00lCf6UV3PrH3omG8bq+jHJjL5z1cjdaliSaaeGn3HVwabqP8AiMZLqiS+a/RzcGkGAHugdXTYZt8/pMxlfNqRjuP4
6ovFo1EUuAC5FCfHmQZbyLUabXV/YBHamo6Wl6LY5fq0JV5LxqSb+pImPra1fSR5c2gAeMgSSCLIoKsQRYpAes0pYtKMe9RyzNSse00cQtpfrL6iwjzMyipoqotAGAJb
oDUQJKJBNQKiSpASVF9CC2NrOXKD+AE1ZVPmpebKJKzl3yigH8j/AE18AGrSP859AElYxa/jF8AE7Bd1VfAgg7CXdOAFbsavcovyZRCVnWX8nL3cSKg6Elzi15oCDpeA
EHT8AK3TYFbgBHcATiBFxAi0BHAUmiiLQCYESAACgZAFCAAEAAIKRAABRFhB3kVIICgIAKZUBAAMAAkgAoAHgB4AMASSAeAHgglgBqIRJRAkoATUCiapsCapAWQt5z9m
EpeSCL4WFeXOCj+s8EF8dP8AnVIryWQLFY0VznJ+XACcbW2XOMn5yAbo26fCkvewJblBfyUPgAbtH+ah8AHu0P5qHwAHTtnzpRAToWz/ADWvJgRdpQfKUl9IFUrDPs1E
/NYAqnY1lyhnyeQM06Li8NNPxAplTa7gqDgURcQE0AsANATiBopAeoi9+jCXWKf0ERTJEECiu4l2VGVRLLQHOnqFfHqxpR/oZ+saVV+NL+Lwrmcf1Eo/Uiai7So3d5cX
FKEr25TlJLPay4fSLJ7LLXoKFTUqXCGt6jGPzXXcl9OTlZj7Om77tau9Sxh6nUn/ALyhSl9cRrH2Tz91Na4v8Z7a0n+vY0/sSGoebdomkapq8KlWFHR3CnLdcqtvKLb5
4W7I558mOHra1jhcvZbWoz06pf6deWtnGrCEJ052u/h7yzx3m+5Du7tZSlx1uWOVN5efA9EcGDVFmxreCT+ksI82yqWQLKLxJgaFIIe8AbwFlvTq3Nenb0KcqlWpLdhC
PNsluiTbuT0jTNP3Xq+qb08ZdGxiqjj4Ob4J/Ex3W+kb7ZPWs9bW9JtPV0vZ+hKa5V76TrS/Z4RXwHbb607pPSOZfa5quoKMLm7l2S4KlSSpwS/VjhGpjJ6JcrfVq0DV
KumXPPNvN/lIPl5rxRbNkr6CqtOpGLhJest6PHmuq6o5tPIbcV6+7a0IRmqO85TmspOXcs/FmsWV2x97d3KuLWvJ1aVGmpJy4ySbw14oZSQjFf1L3Sbydu50q9q3vUo1
4KonB+fHhy5kmMq700W2r6E1u3mmVrab51LGv6r8eznlfBolxz+l/VqZT6x1KVpRu7KV7pV0rqjFtTpzhuVYJc3u5eV4pme7z1l5NX03FNCmqkXJySSeMLma0zM/JRqO
q22nQ7OnFVK3dTT5eMv+smpGbS0XUHrNCVtXS/GNFOdKUVjt6fNwx86PFrrHK7kS/wAt+xru/u1Vpt2qpY708ierDHum0LAEkiDs6clDT5VZcoyefoOWX5tOmM/l251V
b1WpKKbTbfI6RhHdzRb6MopaCI4ApuoSqdjTivWnJxXm8IK522lWNTaC5pU3mnb7tCHlBKP2MnH+VvP1cBG2UkESSAmkUTRBNAW04OcoxXNvAHrrRbvqrklgzUc/aaSc
LWP6z+osHm5IqoNFEWgBRAmohFkaZFX06EpPEYtgaoWePbko/SEWqjQh3bz8QJb8Y+zFLyQEHVfUCLqPqBDtGAb7YDUs+QE99hRvsA3wHvgNVAJKr4kGmlSoVKadSlCT
ffjiS1RPTLSa9Vzg/B5+sbNMtXR5/wAlVhPwfBl2mnPr2FelntKMkuqWUXYyOl4AQdIorcCCuUCiDiQQaCotARaKE0AiAAAEAFCIEUBAsFCYAABUWEBBIKQDAZUMBAAD
IGA0AwGUGAGkBJEDSAkkBNRCJKAFkaZRZGkQWRotvCWX4BGynp9WfFxUF1kwbaY2NGPt1HLyWALFG3p+zTjnq+IDdfuT4BFbqvqFLtAI9owDfATmAbwBvAG+Ab4D3wJK
fiBJVPECyNV9QJupGaxNKS8QKp2tvU9nMH4cUBkrWFWGWlvx6x+4DHKmUVSgFQcQDBBJIqL6XMD0eny37OC74+qyIc0FR3QM99Fu2morLWHgQcVxcnhJt9EFQdCtxbo1
MLv3WTcXSNOsqU41ISjvReUUa1rFdPjCD8mZ7V20U9dS9uj8JE7V7miOt2suEqdRfBk7Duev2O2s0XT7evQu514OdRTju0t5YxjuOPLw5ZXcdePlxx9VW0F3R1bUrnU9
N7SpZqnThOco7m60sYafF+41xztkxy9WeS91uU9HGcs8Tu4M18t60rr9BgeYZWkQJQfrAXJhBkBqQHSpV/xbZOdN4vrqG7F99Gk+b8JS+heZmzda9I5G81nBpks5AMAT
jPjjAV6vZXUoSX4qvGpU5PNBy/Nl83wz3Gcp9Vj10rWhUt5UKtNVaUvajPjkxtp4jTLt6BtLc279W0lUdKWfzY84v3ZN2bjO9V2ttbKVfTo3lNetbvLx3wfP7GZxq14N
ZaWeRtlqtL2vZVIVratOlUhJTjKDw01yYsl8qsuvR1tR1Geo2UtQ06fyeosK9t6fDdzyqQ/Qb5r81vo0Yk15Vb5+cefjHrzOjLTa1qltXp16FSVOrTkpwnF8YtPKaJZs
le1q3VDUrGOpW0IwbkoXNGPKlV6r9GXFr3ruOc8rpcp9YxYNsDdAmogde3aWiV/1n9aOd/O6T8iqxgpU6zLkzizbqVvOT4LGF4s19T6MjRWSwBfp8YvVrKc/YoylXl5Q
W99hnP8ALWsPzR4W7qyr3FSrN5lOTk34vizoKUBJBEkUTQEkQWJAbtNhvXdPK4J73wCPSU36svIyjia5Per04fNh9bNRY48gIYKHu5AlGBBoo0Jz9lcOr5AbadClTWZv
ef0ATdVJYjwXgBXKpkCDmBFyYEclCyAmyKE2+ARYuHAKeQDIBkAyAZAay2kub4AdOHqpLpwMNJqTAkpsCSqtd4RXVo21b+MpRz1XBjY5tbT47zVKfLul95uVlirWdSn7
cGl17ijLOlgDPOGAqqUSCDiBBoqotAJoBYIEAAIoRAFABEAIAoTIIlAQMKCoaAZAwAoAGA0gGQMBpFDwQMCSQRNRAsjECyMH0AuhTKNlGzqTWVHEesuBEaoWtGHtycn0
XBAW9rCCxTjGPkBXKu+oEHVYFbmBDeAN4Bp8ADIBkoMkBkAyUBAZCjIQZAe8A1ICcZAWxm0BfCpjvIHUp0a69ePrfOXMDBcWU6eZR9eHVc0UYpUwqtxwEGCqnDgyI7Wj
VPXnSf5yyvNCo6M4gUyRFRwBsoxUYRaSzjng5W+brjPJstKELmvGnVWYNPK68DNuo1JtsWh6ZnjawMd+TXbE/wASaX/odP4Dvp2xCWg6U/8AM6fwL307YcdntJz/AJHA
nfknbG6z2c0SpXpwqWKab44k0TLkyk9Wphja4W0umabYa7Vt7C0hRp04Qxzby45by/M7cOVyw3XHlkmWo5+7g6Oaq4jmhVXWD+oo8n3FaJAEXxAsyEGSiVJxUt+a3or8
35z6ECq1J1akqlSWZyeWwIMAAABPD4LIVdFyi1KOVJPKa5pgfTdntUjqWnqc2lcU/Vqx8e5+TOVmq3Lt5Dbeh2erxrRXq3FNP3rg/sN43yZsek2Ru46ppMrO69epRj2U
0/zoNYT+HD3GMpqtTzeE1G3dhfXFnP2qU3HPVdz+GDpPOMaVWtCrd1o0aFNzqzzuwjzeFn7BbJ51dCi529RypycZYaz4NYaKiGc8OgAEb9G1Cem3naODq29SPZ16Ocdp
B815rmn3NGbNtSvVVKMIuLp1FVozip0qiXCcHyf2NdzTRJds2aQcQhYKjZRqpWU6DXtN8TFn8225fLS6w3Yxqwl3xeBTFmqtSoQx3F+qfRlcSoTiUKrP5Pp2pXPJq37G
L8ZySf0KRL52RrH614R8W31NhpANBDQFiQE0gLIoI6WmQzOcuiwB2aMeBEcC/qKrcVJrlnC8kVWGSASiBdTpuTSSbb7gN1K2jD1qmG+gE5zWMLggKXMCDbAi2AsgLJQZ
AMgDIqcI4XHmBIAAAEAAAF1rHeq57o8SVY3oyoAMgPJQJsIz1Z7tR+JYlEa75dxURnb0Ky5bkusfuAw3FhUgnKKU49Y/cUc+dMKolTYFUogQaAg0FRaAQCIEUAAAgEAg
ABECAQU8BAFMqJIAIEUSQDIGUNAPAEkiB4KJJEE4xCLowAuhT8CjfQspyw5+pHq+ZEboQt6C9WKlL50uIRCpXb7wqmVR9QK3ICLkUJsBNgIKCCS5FQwoIgwFADAMMB4A
TQCAMASSCGgJpgSTAujJkVdCeO8qIVralWTccQn4cmBy69GVObjOOGBQ44KCJFa7ao6VSNSPOLyEejco1KanDjGSyiIpcQqEkoxcpPEVxbCKvxrbU0otzl5RMXG7dJlq
LaWv0KE1Upwm5LquBPD213rHtZVz6tsn/wBeZPBXxF0NqbqSTjp0mnyai2h4c9176l/hLevlp0/2GPDnunfUo7T3keenP3wkPDnud99mi32vvoVYzp6bByXLMZMzeHG/
VZyWfRm1HUJ6pdyvLq2qW9eaUWoUXuywsJtt8OhvDHtmoxne67rKm+86OYmswkuqYHj2VpEBrmBJMIGygbARAwpZ44AYQBVkZ8cPn1A6GkahV02+hcRy4ezUh86Pf95L
Nkel2zVKvpVre0XvxhPhJd8ZL+5GMfVq+jzuzupS07VaNdtqjJ9nV/Vff7uDNZTcSXVdzbzTUrm31CK9WrHs5tdVyfw+omF+i5e7l6HrMdHp1FC0hVqyllVG8OKxjGcZ
GeHd9SZaYNXvvl97K77GNFzSUoxeU31Ljj2zSW7u2Lk8/E0iwIOQV3tntQjn8WXEkoVJZt5yfCFR/m+Cl9Dw+9mMprzX18nY72mmmnhp9wc01T3gPW22k6VS0DT7+rbV
q1a4Ut/8u4RTUmuCSOGWd7rHpx48e2VRKhpmcw0+pF/+al9xnvyXsx9mZ2dg3/klRL/zEvuL35J2Yqb6ztY2zdvbVFVckl+Ucvowaxzu/Os5YTXlHHlSnGW7KDi/E7Sy
+jjZZ6udtLLsNFpU/wA6vWcvdFYX0yYn5m5+V41I2iSCGgJpATSAsSAsigO1plPFDe+cwjXdVVQtZyXtNYj5sI83PoFRUSi+hQlUeEuHe+hBtjGFGOI8+99QKpzAqlIC
GQEVSYQgAKAgQE4LPEirQEwABAIAAANtpHFNy+czNajQQAAAMBMoyXWcxZYlVJ4KicZtAXQqNd5AVKNCuvXjiXzo8yo5t1Y1KScsb8PnL7QOfOmBTKHgFVSiBW0VUWgE
wEAiAKEQIoRFBUAEWQIKkVAAyBoAKBAMgkgGUSSAaQEkiCaQRZGAFsKYG+3s51PWxux+cwjdCnSoeysy+cwIzqt94FMp5KI7zII5KE2AAACAADIE1yIpgAAAYA9Zs9s9
b3NnC8vlOSq8YU4vCx1b8Thycll1HbDDc3XX/wAG9I/0aX9ZIx4mTXh4q5bO6UuVvL+sY8TI7IregaWv83f9Yy+JknZFctB0xcrd/wBYx4mR2RVLRdNT/wAnf7bNd9Tt
iqWk6euVv/xsvfU7YonptmuVHH9JlmVTtip6fa/zX/Ey91TtiHyK2T4Qf7TG6mma5t1T9aGd3o+41KljKpGmVkJtAWzjCvDcqLyfegOZdW0qUsPjF8n1AytYAlF8QO3p
FwmnbzfPjD7UKOlOGCI5+oycbSpjvwvpEVwp8SqqYEoPgwPqNjCPyG2VNer2UMY5ckeW+rv9Glby4cSKnFyfDj8CK6unUmmnuv4HLNvFwtvJt3VjFp8KMua/SO/Telcu
f1jyuEeh5xjjgo8ZUWJyXSTX0laQAAGghlAQGUgqE5Y5cwFACzIDyEGAqUZ44P4geo0a6jfaFqGi1sdrGlKrb578es4+7GfezN9drPTTziUUuqZpl7mFf8c7GzpNOVxb
xx74cU/fE5+mTfrHgstvPU6MlLjFoB03vRyBJcOHwAYC3cget0q+V9RXbPN1TWJv+cXdLz7n8e8xrSZefm6UXgMvY2lRVdkLNLnSr1YfSn9p5uSazevju+OOeZaARk1G
rOnRjuPDk8ZOmGMt83PPLUYrmT+R0pS9pvmawms7Iznd4S15Da2u53Ftb/zVJZXjL1n9aO2P1rF9I8+kaQ0BJICcUBZFAWRWQLqcAjvWWKdGEWuSIjBqtwqtbch7EPpf
eWK5zTyBbQoSqSxyXe+hRue7TjuQWEvpIM05MCpsKg2AioMgAUAGAAiBJt4QVauCwBIAAQCYCAAJJNtJc2B0oxUUorkuBhowHgAwEJ4XfgK6umbPavqlo7yztoStVNwd
WdWMVvLmuLz3nHk6jDj/ADV0w4c+T8sbZ7EanVgt+7sKbT/nXL6kcfx/F9Nu34PkQew9xDjPU7b+jTm/uJfiGH0lWdFn7qpbJqLSeopt9KL+8z//ACE/pX8FfdwoaVqN
XtJULWpUpwm4qfBKWHjhnmeq9TxzW68/gZ3eoyRck2nlNPDT7j0OLTTqNcyCm4s6VbMoYpz8FwZRybi2nSluzi0+7oyjFUp4AplECuSCoNALACYCAQAAiBABQmRUQJFQ
wHgBkAUIgkkAyiSAkgJpATSIi2EM9xRqo0JTkoxi3J9yA6lCzp0fWrYlL5vciIsqVs8mEZ5TbKqpsgTAWSgAAABAAAQGALI8go4gADQDSA+paDBfiXT/APcRPFn+avVh
+WNk4mWlMosqKpRKimawWIz1EaiM00WIz1EWIzTRplXIoyXvCi/+u41Ga5CZtg1IC2E2Bf6tWDhNZTA5lxQlSnuviuafUCjGGBdTm4STTw1xTA9FaXMbqjvfnx4SX2kR
G4pRnTlCazFgcaen+t/GSx5DbWjjYU++pLPkNrpoqaDcfycorzZnvi9op6RrMIqNO8nGK5RjVaS+kndi1qpPStck/wDLKn9c/vJ3YmqlT0bXc5V9Nf8Arv7x3YnbXRoa
XtHBerfv33EvvJcsL9FmOSVxY67bOjXv61CtTqb0IdpJ1HwxnHHhz59S43G+WKZbnnVbjg6ORJcgjx92t25rR6Tl9ZWlAUAMBhAA0A91d6QUmo9EAJIIeOAEQsgyF0st
61S3rQrUp4nB5TBpJPPFcunQrL02w90qWo1bSb9WvDKX6Uf7smMo1jfNw9VtfkWpXNr3QqPd/V5r6GWecSshRXTaU5R94FuMgPADAvtLmVtcU60ecXx8V3oD27WeRhh6
TQJ9poN/b/nUq8Kq8msP6Ujz80/mlejhv8tiPAw6B4AxX6hN0+0qKEI5b6s6YWz0c85L6ufdVY15wp01iHCKR1wx7fOuWeXd5R4TXa6r6tdTXs9o1HyXBfUdMfKF9WBI
qHgCSQE0gLIoC+EchGy3pOUox6vBB0b2qreluxf5SS4eC6hHFfMqpQg5yUUuLKN3q0oKEfe+oRnnLPeRVMnkog2QRKoCAARFMACEFWQjhZfMCYAAwEAmAsAAF9pHerJ9
0eJKsbzCgoADAHrLfsdM2UtL+laUK1xczaqSqw3vzmseCSj9J4OSZcvPcN6kj2YXHj4e/W7a9hsdc2l7s3fRt7aNu6ddSnCKwsyXNfA83U8WWM1ldu/T8mOV3jNLp4SP
nvaw1uJuMufVhmSXibR4CF9eXG09KLqSUI3HZxpxb3d1NrkfX8HDDgt+23y/Eyy5v/LNrTj+OL3cXDtX/eejp/8ApY7cOb/qZMakdnNZGbILMwqQ3KkVKPRlHNu7JwTn
TzKH0oqOZUphWeUSCtoqoNARYEWQAAyiLACKQQmBHAVIqGAyBgBQ0iCRQwGkQTSCLEgLoQyUb7O0nXliKxFc5PkiI68I0raG7TXHvk+bAzVajbAobASAUiiLAAAAIAqj
ABgAwAwLIrgiAaAWAHgBpBH1fQI/9h6f/wCXgeHP81ezD8sbpQMqpnEo5dXUtPjJxd1DK6ZZuYZezHdGSpqlh3Vm/KDNTDJnujNPVLJ/ykv2Ga7KndFMtRs3yqv9ll7a
ndEFdW9V7sKqbfc+A1TcKZRTJFRkv1+Q/wCuhqM1xTbAyFNMC+nLlxCNEoRr0tx4z3PowjkVIuMnFrDTw0FV5wBotLidCqqkHxXNdzXQD0catK5tu1pPvw13p9DNIyVV
gjW2SrPclGWOTTGlld2nfWs4qSr01nrLBy7a3uLo3doud1RX9NDtpuLY31iud5Q/bRO2+y7icdQsF/ntD9tDtvsvdGqhqWm546hbLzqIzcMvYmU90dfvbC5tbGNrf21a
pT7RThCom1nDTx7mb4pZbuM8urJpwVOMu9fE7OCfBLi18Sm3j9T3FqFzHeXtt8ytRjzH50fiAb0fnR+IBvR+dH4hRvR+dH4gPeh86PxAe9H58fiA96L/ADo/EAzH50fi
AKUfnL4hBmPzl8QIqUce0viG56Byh3ziveFLeh8+PxAlCcU8by+ISxqsK8rW9oXUZJOlNS593f8AQS+bG3ptuKNKF1bXkWt2tDdb8Vy+hkwvlprJ5R7suUo/E0y6+g2t
td0a9C5hCTi1OMs4kk+DwzNLTvtHqW637aarQ+b+cvvLtNuQ6kE2nJJrubK0TqQf58fiBdZRVxdUqMWm5SWePJd7IPeVbm0t6Uq1ancVaa7qDjleLz3GLL9Emvq7egXe
kVIyr2NxWrRlHdq0ZSjF46NYyvM48ky+rvx9s84sqShvvcjJL9J5ObQTyBwNotR0u1qbrhcVbtRScYVEox88r6DtxzLX2c8+3fm4NPaG2jKLVtNSTys1U8P4HXVc5JHm
arTqSeU3nmbQosCaAkkBNIC2CCNNKHEG2+jVp2+Kk1nHJdWTSMNetKrUdSbzJlVUuLKNtulTp7z9qX1BEKk8kVTJlFbYEQoAAAAIgAMBU6ccvPcgLcAAAAYAAFggMFAB
ts4YpuXfJma1GgyDBQYAkgPR6LVhf6VX0OrNQqbzq20nyz3x+jPvZ4+ol485zT/y9PDZnheK/wDh1fR/cVbXVtQ0a5hKnK5o8IS+fDj9KbM9Xrk4pni1028OTtr0jzxT
5o+K+qzVUaiVhqtQzN4SjxZ0k35MW6eE0yELOVXXL1bqblK3pvhKcnnjj/rqfY5Mu/XDh/5fM45228uX/h5+pUlVqzqzeZzk5N+LPZJJNR5bbbujJUPIDUsMC6nUwwjN
eWUaidSisS74rv8AIo41SGM8CKzyiBW0UQaCo4AQABFgJgBBFhUWBMqGAyBgADAaAkkBNIqJpAWwjkg6djZyrvefq01zf2IDrynClTVOnFRiu5BljqTbYVU2BEoaICQE
GULADAADAUYCHgAwQGALIrggptALABgCSQH1rZ9f9hac/wD8eB4eT81evD8sdBow05O0M3S0qs4vDm1DPg3xOnHN5MZ+jws10PS8529vWuq8LejHeqT4RTeM8Mi2Sbqy
bulFalUo1JUq1OUJx5xksNFl9kvkrwVBgDtQzKlCb74pnNtCRRjv/wCIf/XcaxZriG2CYUICcXgI0U54YFOoQUkqy8pBHOYUKWANFtdVKE96nLnwa7mB1adVXEN6EuK5
rvQ0KqkZd7IM8m48sfALtVKpPr9BRB1J9V8EQLtqi/OXwRQ1d3EfZqY/or7iaFkNU1GnLep3lSDXJxST+olxl+jXdVq1vV1xeo13719w7Z7J3VJ6/rP+sq/xX3Dtx9ju
qp63rEm3LUazb78R+4ds9juo/HWq/wCn1fhH7h2z2XuvuPx3q/8ArCt8I/cO3H2O6+5rXNX/ANY1v+H7h24+x3X3L8eau/8AvCt/w/cO3H2O6+5/jzWP9Y1/+H7h2T2O
6+5rXdY/1jX/AOH7h2Y+x3X3S/H2s/6yr/8AD9w7MfY7r7k9e1n/AFlX/wCH7h2Y+x3X3L8faz/rKv8A8P3Dsx9juvuf4+1j/WNb/h+4duPsd19zWvayuWo1vhH7h2Y+
x3X3P8f6y+epVvhH7idmPsd2XuX4+1n/AFjW+EfuL2Y+x35e6L13WH/3jW+EfuHbj7HdfdJa/rKWPxlWfuj9w7Z7HdfcVNf1qokp6pcSS5JtP7B2Y+yd1KOu6xHlqNb4
R+4duPsvdfdYtotbXs6nXWem6vsHZj7J3X3Re0Gtt5eqXHxX3Dsx9juo/H2sttvUazfe2o/cOzH2XuvuHr2sf6wq/CP3Dsnsd190fx7rGc/jGsn4KK+wdmPsndfdL8fa
xj/6jX+j7h2Y+y91R/HWrPnqFb3YX2Dsx9juqqeoX03mV3Wb8ZF7Z7JuoK+vE/8AKqv7Q1DdEr25b3u2lvdXxGobqPy28/0iXwX3Dth3U3d3EvaqZ84r7hqJslWqPnJf
so0JqrU6r9lEE41anVfBAXQlN9/0IDVTjN9/0IiJVqytoZbTk+UcLiEcmtWnVm5zeW+ncVUYvIFtOO9JIDRUn3AUSYEGURAQUBDAQAFPARKKbeCKuSSWEAECKGAABFAQ
mgBJtpLvA6sIbsFHosGGzwABAUGAJRympJtNPKaA9Jo+uVql9ZRuqFOvXpVF2Nw3uzg/F96PBzdP2Y5Zcd1PZ7OLn7spjnN/d7qdW3uo/K7WcJ0ajfsyyoy74nyc8Ljd
WPo4ZTKeVY6/AkWvOa1qttZbtKrWVOrUTccx3kvFroerh4c+Tzk8o4cvLjh5W+r55eXdxe1nVuKrnLkuiXgu4+3x8eOE1jHyc88s7vKqEdGDAAGA1IC2nUaYRXeW0a8X
UppKp3r5394HFq08Z4YZVZZIgrkFQARQmAmQIoTQEWQRCrSoEQMAKGQMCSAkkBZFBFsYgdGwtHXnl8Kcfaf2Adec4wioQSUVySCMk5tgVgGADACAGULACwAYIHgAwAAM
AwUGCCyC9VAPAUYAMANIg+u7Or/sHTX/APjwPDyfmr2YfljouJhpwtq4/wDZX/qx+07cX5nPk9Hh3E7uDp7PSS1m0yvzn9TM8n5a1h+Z6PV7e1u4NXEI4j+e3hx95ywy
s9HTKS+rw13So060oUK3a01yljB6ZbrzcL9mZ5Kjt23G1pZ+ajnfVuehNAY79fkH/wBdxuJXCNsEwEENATjLiBoSU6coPlJYA5M002nzQFbChPARdRrSpzUoSw0B1aF1
SuEoTxGp9DAdSg+gGadLAFEoYArcQqDQCwwFgAwAsAGAFgB4AWCgACAAAABgAAAAIAAEVDIpAMoCBgGAHgBAMAAAHgBqIRNICyMQLoUwNVGi+gQq95CinCliU+vcgObO
pKcnKUm2+bYVDmBbTg5PCQGqMVBZbywK5vIFbZRFgIBMAQDARFAQ0UXQWF4sipgABgAAALqVvKqpTcoU6NNb1SrN4jBdX9i5vuM2tSbFG3lVoxuZ1aVtay9mrcy3FJeC
4t+5MW/Re3aNSrolL2tWrVX/APZs24/GUl9Q/m9jtnuVK80XtIyWo1kl/OWjX/K2S93sds926lc2laW7b3dKq+kW0/g0mTzXS4IWAgwUACAMZINum6veaU6jtJpRmvXp
yW9GWOWV18Tny8OHLNZN8fLlx3eL2l5qVL8UK/jdUYqduqjmuMYTxxXjh8D4k47Obs19X1u/fH37+j5TcXFe7rSr3E5VKsucpH6DHHHCduM8nxssrld1Xg0yCgwAAAQA
NPAF1OeAKL627aLq01669pdSjiVIEVnkgqDQESiLAQAAmBFkC7wJlAgGQNFAQSQEkBOKCLYIDZZ28q9WMI8O9vogO9Lco0lSprEUEZZyyBWwAAAGgFgBYAMAGCgAeADA
CIGA8AGALI+yhVMgCgwAYIPsGzcf/l/TPG2geDk/NXsw/LHRkjLTi7Twc9HrYXsSjL6f7zpx3+Zjk/K8M0el52jTrmFne0rmUHPs23up4zwaJlNzS43V2q1S+r3096rP
EO6nHhFfeMcZj6GWVrmPJuMlgqO7ThuUacXzUUc7fN0+iMkBi1H+If8A13GsWcnB7jowQAEIBoC6nLiBmu4YquWOEuOQMclgqoNkCTAnGeAN9tqE6aUZ+vDx5r3hG6E6
NwvyclvfNfBgRnQa7gM86WAKXT8AIOHgBFxATiAsFUsAGCIMBSwULABgAIAAAAAAAABlBgIMADChIBgBAwGkAFBggeCoN0ge6A1FhViiEWxp5AvhR8AJznRofxkvW+au
YRir306nqx9SHRd/mVWZyyAIgupU5TeF8QNi3accR+PUCqUgK2wI5KEABSYAAyBAPBROnHLz0ILQGAwAAINenafX1CrOFBRjCnHeq1aj3YUo/Ok+5fWTLKRccbkw7Qbm
5TtbC4dxbUsznNw3FOfLKT4tJcFnx6jH3rep6R56tXrVKjqVpynPGMyfJdPBeBqeSq3NsGji0+4DZZwhGvTnXnWhSz63YtKePDIo9lTp0o21OrbVI1rZ+rGpDPB9GnxU
vB/Sc9s2aGQhAJooQAwLrHTr3U687eyoqpVjTdRpyUUorvbfLmviYz5McJ3ZejWGGWd1i9gtB3Nl6ejXNSMq8qMu1qQ4xjUlJy4dUnj4Hx8uonj+Li+phw2cPh14LVtL
udLnCNd05qa4Tpt4z3rjxPr8PPhyz+V83l4cuO+bnHZxPAAyhAIBAAQ0+IF9KeGBh1K3UfysF6sua6Mo5FSPEKpaCoNARYCATATATIIgTKGgGAAMCSIJRQFkUEX0ottJ
LLYHobWirWgo/ny4yf2BEakssClgADwAYwBFygpKMpwi3y3pJfWF0moxlyrUP66P3k2aWuzru3ncxjCpRptKcqdSM9zPLOHwz1G56GqzmkLBAwAoCAAMAPAA0BZD2URU
sALAAkAAfZdno42d0h9bOm/rPn8n569uH5Y3uJlpTWp06lKdKpFShNOMk+9GpdJY83cbNW3F07qrFdJRTOvi1yvHHPq7ONPhecPGn/eanL9mfDZamgSX+dLH6n95qciX
BU9EjH2rn4Q/vL3p2IrTKNOScpynjuawmXvp2rZp95BVIDDqX+Tv/ruN4s1wDowAEAAARJcALMxnFxmsp9wGG5oSpvPOD5MoyyTIqJQskDUsATjVaA2UdRrwWJNTj0l9
4Rrp3ttUXrqVN/FA0u3aVRZpzjLyYFc6L6AVOi+gEJU2u4CtwArcQpYAWChYCEAYAMBSwQPBQYIDADwAFCwAwgAWAABpASwRTwA1EBqIRJQyBJU/ABqkwLFRAnGi+gFi
oYWZYS6sIhO5tqXDec30j94GWtqFSeVDEI+HP4hWNzbfMoWQGmBooU5VJKK976EG7Eacd2PL6wKpS4gQbAiVSYQBQABAgowQAEorPAouSwsEDRAwAoeCC22tqt3cUrai
k6lSSjHPBeb8FzJbqbWTd0lrep0dxaVps2tOoyy58nc1O+pL7F3Izjj9b6t32jiTrNwaz3G0ZuEvaSfuCl2dN/mIoeEuSSIDLA16dqFWyqylD1qVRKNWm3wnH713PuFm
1empShUpxqU5b0JLKZmsVJogWAFgoOREZr3Vb7TaMVYXlW27fMavZvDmlhpN+ZLhjn5ZTbWOeWP5bpx62qalcfxt/dTz1qss4sJ6SF5M761mpyfbQlKUm95Zbk2bkk9G
d7dRpALACKgwAmgEAsAARKLwBelGcHCazFrDQHDvLd0asoP3PqiqxTRFVSKIsCICAQCYCIJFAgGBJABBJFE0QXQQR2dIt1l3E1wjwj59QjdVlkCiQEcAEnGKcpSSS5tg
U/KrZfy8PiFDu7burQ+IHPvoK5qwlSnGaSw/WXD4hYupYowSdvSk1378DOhp0e6naTvYy7OFO5tp0ZZqxS4tNd/VIX6LPq217O7oUqNxWoSjQrcaVVNShPykuDEyluoz
cbPVVumk2TWAIoBgPAAA8APAE4L1URUmBF8Fl/SBONGvKO9GhVcfnbjx8Sbi6VylCD/KTjHzZTT7Vs1OnW2a0iVOUZRVpCLcWnhrPDh3nz+T89e3D8sb6kHFZa4GWmaY
RnmixGaojcZYay5mozWGsaZrJUNJWeZWVEijDqX+Tv8A67jeLNcFI6MABAIACGFSiEXxUZwcJrMWBzLmjKjNxfLufVFGSSIqJQsgLJAZAkpgNTfMovhdV4ezVmvfkguW
oV1zcX5xCLaV8pSxWikn3x7gNjpKUd6OGnyaAonSwwKpQAi4hUXEBboQYAWApYAMAGAHgAwAYKFgiDBQ8ECwA8ASSCpKIRJRAmoAWwpeAClVtoPdlPiuiyUR+V2q/Ol+
yDQ+X2q5RnL3YIaQlqcF7FD9qQNKJ6lcP2XGC/RQNM869SbzOcpPxYFe8FLJQ0wJIiLYRbawstlHWpU1QpY/OftMgqnLIFbYEWAihAAAABQA8kDwBbCOFx5sCQAAwHgg
aQDr3fyKxuKsHitVXYQa5pP2n8Fj3k1ut4vP9rkqoueeBQ0QPJQZIDGSgxgDt6Bc5VW2b5evH7TOUSuzzMoeAhMov0+yuNSvKNlaw369WW7Fd3m+iS4tmbdRZN3Tkbaw
srTVqmnWlSrVhatxlVqJR7SWFlxXzengb45bN1rKauo8066TxGDb8DSaWQpXdRpxt5LxksfWE8nXowqRpRVVpzxxaIieADAQsARYBgoWAEwBBFkHhgLUKPb2++l68OPm
u8Dz9VYZVZ5cwqDIIlCYCIEAgGUNAMgZQ0BNEFkQNNvTlUqRhBZlJ4QR6dwjRpRpQ5RWAjPICACwBg1dtUILucuPwCxyG+XAKAqSXDqEJxi+aQA6NPHFetnpwJ57Xy06
1nq1ax0tWdKScO07TdnFTinx5J8E+PMlxluzdTo63f1qkYR+Sxy0syt6ePqJlqTZJt24S+VaffwuaVr8rspw3a9tFRU4uTjKL3eElnDUvPqMbvVnpTKesv0c7BtgwABp
APADQFsY+qmRW+101ypK5vK8LO2fFTmsyn+rHv8APkZuX0jUx922pqmi2qUNOtvXSx21SSc345ece4x25X1re5PSOLfqF+3KvUuJN97ryf1nSeTO65FxosWm6NeWfm1O
K+JZTuV6TrGs7L3yrWc5UnLKlB+tTqLxXJ/WZzxmc1XTHLXo6+ze2q06/q3upWVxf3VbKncyunvJPuUH6pjk47lNTyXHKT1fWNB17Steouen3O9OKzOjNbtSHmuniuB5
cuPLH1dZlL6OjUjgi1lqYw+K+JYzXOrPMnxRuM1jqpPkzUZY6sTUSs0yopkVGHUV/i7/AOu43izXC7jowTAiABCYABJAWQeALqtJXFDc/OXGL8QOHUi02muKKKWFQZAm
ygyAskDyUPIBvEElLAGy1u6lB+o8rvi+TKOnSure4wm+zm+6XJ+8jK2du0FUyovoBU6fgBFw8AIbvgBHdAN0A3QpboQ1EAcQFugG6AboBuhUtzwCGoATjB9ALI0/AC2N
FvuCI1alCjwlLMvmx5hXPuLudTKXqw6IoxynkiobxQt4gMlDyQLIEsgADQFsEEdGwpc6rXBcF5gaKkssCmQEGAgBlVFhAQADwAYAEgqymuOQLQAAwA0QSAAORrlR71Gn
3JOX/XwLG8XLUg0kpASUwO1stV0GnrdCe0tG4raWlLtIW79ZvHq9HjPQzlv6E1vzcuu6Pyiq7ffVHfl2am8yUc8M+OMGkRU2mmscOvEDsbWbRXO02pw1C5tbW1nChCio
W0N2LUe9+P1LCM4zUat3WTQm1qVPH50ZJ/At9Ga9WYZMCElzfcVHttBsJ6LYyrVY41C8prKfOhRfFR8JS5vosLvOOV7q6yds+6+UKdR5nThKXVwTYHmdqrKxVa2uOxh8
qSaUksNRXh5m8Gcq87XXqp9GdIwowULACaAiwhAIBYKFgAwESQF9KXcwOFqNHsa84Jerzj5FVzpoiq2BEoTARBFlAQCKJIgZQwGgJxIi2AHb0OjmpOu1wgsLzYSunVlk
DOwFgB4A5us8KFP9f7AsccKlECQAAARn7IFlBLAK72iN/I9VS5dnR/8A7UZvrD6VNI0ylgBYAMASSAspUalWW7Tg5y6IlsnqSW+jDe6rUsZdnbVbd1U+OIKo4+/l9ZNb
dMZY4t/qF7qE3UvLutWl+nIskno0w7qzyKq+lc16HGlWnDwT4fAGnUs9bcnuXcUl/ORXD3ojNxdhwo3FLdlGM6cl5phj0ee1TTZWc1Ug3KhJ8H3xfRlbl2zWl9c2Nenc
2tadGvTeYTg8OLJZLNVqPsOyW2M9etXSuFThf0V+UglhTXz19q7jycnH23y9HXHLb0DqylzjH4GNLVFRxecwTNMslVx+YviWIyVGvm/SajNZZpPJpGeRpGLUP4h/9dxr
FnJwTowTATAQAEAAgqyIRopSwBh1Sju1FVS9WfPzBHLmiqrZAmAgEAgGAZAaYE4yAmplGy3vq1FJRnmPzZcUEdClqVCpwrQcH1XFENNUY0aqzSqRn5MCEqLXcBXKi+gE
HRYEXSYEez8Ag7MKOzYB2fgAuzAfZgHZgSVFgTjRfQCxUH0CJulCms1JRiureAM9W9tafCGaj8OCC6YLi/rVFhSUI9I/eU0xOoRVbkwI5ARQIBgADAkA0BJAX0ouUkku
LeERHd3FSpRpruX0hGapzCqWyhEAAihABAFDIp4AeMvCCLFw4IKkgGA8EAUSQAQcbX44nQqdzTiWN4uQmGzyA0wHvBDU/EBqQEkwOts5Bz1Df7oQbfv4Ey9Evo9RIwyj
yCPS7JadCpN6te0lO2oSxRpyXCtVXc/0Y837kYzv0jphj9a79xOVarOrUk51JtylJ822YjVZa9Snb0p1qst2EFls1Ga8Pe3VS7uJ16nOT4L5q7kdJGNslRZiyxGcoTKI
tALAQsALACwUACCACcHxAz6vS37eFZc4PD8mBwJoNKWUQYCYCAiyBANASKGQMoYE4kF9NcQPUWFPsbGmnwclvP3hmnMCsAAMAc3Wv4in+v8AYFjjBUogSAAGApJ7oEqL
BXf0P/JdTXWlS/8A7EZvrD6VbjBpkAGCoMEUYCGqFW7as6cZSlXapqMXhybfBEvl5tT1ef1Szo217Xt7e4VzTpScFVisKTXPHhnPHvEu5t1Ydx9GVUd2XQBqGPaYDcVj
gBt0u9la1FSqSbt5Pj+g+vkRmzb01a3VejOjUWYTWHj60GHiry2q2lzUoVVxi+D6ruYdIu0nUq+lahQv7f8AjKMs47pLvi/BrgTKSzVWeV2/QNncWmoafb31rUTo16aq
R8M93muR47NXTrtXVgse2ipXPrrdfB5NRlkqGkZplRRI0jDqP8Q/+u41j6s1wjowQCAQAAwgAaAupviBbcU+2tJxxxS3l5oDz80VVTQECBARYAAAAAA8gPIDyBJSZRZG
o08ptPqBspajc0+HauS6S4hGunq+f4yhF+MXghpohqFnP2lOHms/UBZ29lLlcQ9/ACWKMvZq035SQElRT5NP3kB2HgEP5O+hQvk+O4mwOlBe1KK82iiEp2sPar0178gV
yvbKHKUpP9GIFE9Upr+LoZ8ZP7gaZa2pXM1iM1BforBV0wzqylLMpOT6t5Cq3Nsgg5MAyAgEUAAQBQAPIEkwJICcQOhplPfuFJ8oLeIjo1XxYRnkFVMoTIEAAGAAoCBg
SwBJRx5hUkAwGgGQSwUPBAAY9Ut3cWklFZnH1orr4BcbqvMorqADIBkAyBLIDTA9ds7aOjZOtNYnW4rwj3feZyrGVdUyjraNot1qkt6Edy1jJKrcy4Qp/e/BcTOWUjWO
Nr2FyqcY0qFvDs7ahBU6UOkfHxfNvqznG6zNtFR5faO/7aqrOm/UpvM2u+XT3HTGaYyrh4NMotAZ2sFCwURaCFgBNAJoBALBQNAIIaAtnBVaFSk/zotAeXqLqVWeQVWw
EwEAmQLvAaKGQADKGgJxINdrB1KsIL86SQR6+okkorkuAZZpIKi0AsAGAMGswlK2i4xbUZZeO5YCxw/IKjkLpOOX5BE+CAfADtUNNVzpFK5WKcovd3n+f6z4e4m/PS30
2qjpUk89tFPyZWdttnRla060FPe7XdUnjuTz9ZDazBUGADADwAYA00qrsbK81CLxVhDsaD6VJ5WV5R3mZy8/JvCfV5FpLguRWkGFRZRBgRCo5A9NoV92lr2FR5nS4Lxj
3fcSsZRHX7OreKlUoU06scqSbxldw2Y3TydaFSjUdKrTlCa5qSDb6t6LLx19FubGb42tbMf1ZrP1p/E83NNXbpj6PY1lg5wrDV4G2WWZpGeoVGeZpGHUP4n4/UaxZrh4
OjBAJgIAxwAAgQEkBZDmQa6Lw0Bwryn2depDpJmhjkgqDAgyBAACAGAFAAwGgHkBpgPIDTIJKbAe+UG+BJVGu8gfbT+fL4gTVefz5ftMBOq3zk/iBHfAi5gLeYCcmBFy
ATYEWAFAAiAKAAAAAAAkgJICyIR2tJhijUn1eCC6oBRICtgRAMAAUFQACIpoInBd4VMBgNIAwESwRUkgDADwAkstIDi6xprpyldUI5pvjOK/NfXyLK3jl9HHDZYAQDAk
lkDsaJpMryoq9eLVtF/1j6LwJbpLdPZ06cpuMKcG5N7sYxWW30SMOb1dhspTtIxude3lUazCwhLE341GvZXguPkcrnb5Yusw155OrUrTqKEEowpU1inSpx3YU10SJItu
1bZUczWr1WVo3F/lp+rTX1v3GsZtLdPFPi8t5fU6OZYATRRTNesyoi0AmgFgBYAi0BFoBYAMFCwENIC6mB5zUKfZ3VaGOG88FWMEiKra4lEWAmQRYCyAyhkDAaKGgJx5
kHV0WG/f0c9zcvgglelqBFEuYEcALADwQPBQnFclFfAg50Y1Lu5fZYjb05YlLHtvogrTc6ericJKooYWMKJU24sKCneRt3PdzPc3unHmFdmxtI2ynmSnvY5x5BGvCAMA
LAQsBTwAsAGAGkBk1mq1Z21unwdSVRr3KK+0n1bx9HEaK0gyKrkUQYVBgLOWkllvggPe2VGhpOldmqcXXnxlUa45737uSM+tc7XGq1ZVZOTbx0yVGa8oxubdxazUiswb
7n08irLqtno+1SWnXl9mj2katKPDexhqX95z5MO6Ond2va1NpM/5ov2/7jE4funifZmntBvf5qv2/wC4vhfc8RVLW8/5v/xF8NO9RLV8/wAh/wARexO5W9Uz/I/8Q7Tu
Y7m7qV+DSiuiNSaZt2ymkJgJgIAAQEkESQE4gaqXcQczV44um/nRTKRy5FVWwIMBECAQAFAQyhgBAwABlAA8gGQFkgaYEoptpLLb4ID1ljodvSpRd1DtazWWm/Vj4Bm1
K60Szq032Mexq44NPh70VNvKVYyp1JU5rEovDXRhtDJAsgDZQskCAAAAARQAAAAAAAgJICSAsgEd/TVixT6ybIHPmBRJAVyQCQDAChEAAYAaXQC1LgFMgaAaKJJANEDA
aQDwBOEcvIF0Yog5d9otvWbnQl2M3zWMxfu7hK1MtONcaVeUU32W/FcXKDyXcbl25zi84awVRGEpTjGPOTwgPXaPs9btRr3VWNfpCHse995i5xm7d6tOzoyhGVenGO8o
uNP1nBZ54XDh5nPv/p8yYX6voej07bR6cnZW6+UyWFdVPWqJfo90fccv5svzOs1j+Upyc5OUm3JvLb4ts0yrkUc/UdQo2NPeqPem/Zgnxf3Ism2bdPH3t3WvKzq1nx5J
LlFdEdZNOdu2ZlEQBhFclxAhgoMAGAItARaATQEWgFgoWABIItp8wOLrkUrxv50EwRyJBpWyiDATAiyCIEigAZAwJICceZR2tn+N8vCEiJXoZhlS0RUcAGChpEDSApvZ
9jaVqi5qPDzYDsqSoW1Omlyjx8wL3nuKjzdCkpa3Gk293t2vpFaeiUeGQgwAYIDBQYAMALAAkBJIg5WurE7d924/rDeLbszszX2hsdau6F7bW/4stu3lCs8OquPBdOXP
q0iZZadJNvNySaTT5lZStqEK1xRozrQpRqVIwdSfswTaW8/BZyFdfbnQaGzGvT0qhqlHUYRpQqKtSSWN781pNpPhnnyaJjdxqzVeafE0yttIr5XQlL2VUjn4hXutVS7D
h81/WZjk8/noUSi+KCKdmKb7a8qr2cqK+LYbyegZGEWUQYEGBBgIoQCAWAFgBAAQwGgLYgaaQGHW1itT/U+0DjyKqpkEGAgEUGCBAADQDAAABlAAEDKEAEDAus5Rhd0J
z9iNSLflkD6CvFhzEknwQHhdXlGWp3Lg8x38cPAOk9GMAAWQEwAAKGQJlAAAAAQBQAADQEkBbDmB6HTuNjDzf1kQVEBRJAQaAiAAAA0AAMKsigJYIGkAYAkkBNIB4AMA
NICWALILkQXKPDiQdiy2bv7tQqV3TsbefGNW5e7vL9GHtS9yOWXNjLqeddMeLK+d8oz7UaRb2EKVO0lXq05QbqVaiSc3nuivZS82znncrO6fR6+nnH3XDL6vEXNvFyca
kcNcpI9XHyTObjy83Flw5dtaLDQ7uV1UgqE51KVFVt3dw9x8pePPuNbjnu3yey2N0ylfW+o2tz61GrSjwXNPe4NeJ5Mr/qXT3dtnTYX716Kw2W0exw/k3bzX51eW99HI
vdXn07jxjGCKpbKjjavq9O0To0MVLjv6Q8/HwNzHbNyeRr1alepKrVm5zlzbOjmrCBrJQsECwURaAi0AsAGAItFEWgE0BFoCJQYCDAFlMDja/wD5VTf/ANtfWwscWQVW
yiLAiyCLKEQHEoaAaIGBJASiB2tn3i/iusJIM16SS4gVNECwAt0oaiQSSAxatxoU6S51KsYoLG3GGENIDz9sv/mOC/8AyGL6NO6lwXkGUsALABgBYAMALBQYIJJAYtco
79lCoudKfHyf94axee3nFNJtJrDw8ZXQOiDbKISbAraWOCS8gqPICEptcgPZaVfx1O0jTlJK5pr1oPv8V4MyxZpVVsqkJPdWV070VlztSuYWdKUcrt2sKPevFhZNunol
s7XT6cZLE5+vLzfd8AmV3W9hEGERYVBgQYCKEwhAAUggwAsAAEkBZEDXRQHN1qWbmMfmwQI5EgqpgRAQAUIAYAQADAQDKGAgBANEDACgIGgOvY67cW1NUatPtoRWIvOJ
JdPEJYnd6/Xq03Tt6XY54OblmXu6A04uQoAAEUIgAGUBAAIoAABAMgCgAEBNAWwIO/pTzaSj82QRbUQGeSArkBEAAAAKMASigLEAASSIHgCaQEkgJAGAHgBpAWR54xl9
F3mR7q20taZQh8lhSnqUYZqVasd9QnzagnwWOWePHJ5OWZck8r5PVx9uF85uoWOkXVe7jqGqXFSdVSUkpSzNvuy+7yRjj4+1vPPbtXNvb3NN069NSj9R1l05+rwWr6RT
027pVKtGNe1dTMVx7n7L8cHG3Ljy3PR9Lj7Oq4+zL1j1dGdOtUt7iluuNSOFJLjjnj6+B6MbuPmcmNwysv0c/ZHfqXmqXP5sqmF8Wzjh5219Dq/5ePjw+z1LR1fPU15R
pQc5NJd7bLB5XVtZlVzRs5OMOTqcnLy6HTHH3cssvZwGjbCLQCwAsFAAsECaKIgRYCATQEWihNARaAjgAwVBgCyC4gcPX3/jcV0pr62FjiyYVWyiLATAiyBAMoAGQNFD
IJoo62hyUdQoeLcfiiJXq5ojKtriFLABgBqIDwEc1f41qvWlar4zYa+jp7qDIx0A87ZrO00Flf5Q/tF9G49EorC4rkGNjdXUA3V1QNouK6oGywuqBsNeQCwFGADACnBV
ISpzWYyWGgPKXlCdrXlSn3cU+q6ldZdszZFVtlEGwqLYEWA4zcGnFtNcmnhog1PUL50pb91VlFcOMgmo1bPadK+uflFaP5CnLLz+fLp942mV09hKKI5K5IKrkUQZUQZF
RZQmBFkCKBgIACDADSAaQFsEBrorkEcTU6naXdWXcnhe4qxzpkVWwIsBMoQAQDAQDACgwQNFDAQAA0AyAAAADpaRp/y+pPek4Uoe01zb6IJbpfrGlKypRr0akp0291qX
NMEu3GCgAAAAAKAgAAoQAAgAgYCAAJANAWw5gdnRqn5SpT+dHK9wSt9VcSDPIopkgI4AAAKAJJBE0FMgEgJoBoCaQEkgGA0AwJRRB1NAt1W1Wg2sxpPtH/R4r6cGMvRr
D1e6oNtuUuLOVdWjJlSfECi7saN7Qnb1l6klz70+5oWSzVb487x5TLF5q3rPSFcWdy8SpZlTfjh8vB5ycePLttxr39RxTmmPLh9fV1NkYqGkuai06lVvj344G+Oajl12
e+XXtHcw2uRq5yPJ21wtqd78XQazjtVn4M64ernn6PItnRyJlRBoCOAABAIoTAiRUWVCwAYATQEWiiLQEcAGAGVE4oDzetT37+rj83EfggscqQVBgRZREBMBEDKGAAMg
EUTRBrtarpVITi8OLTTCO3Wu7rmq8wMk727XK4mDSp6he/6TMaNF+Mb3/SZ/QAvxlff6VP6AaP8AGd//AKVP6AaVw1C8ppqnXcU3l4iuL+AVYtX1BL/KZfsr7iaTR/jj
UVyuX+xH7hpdK46leQrKvGpTVVPeU+xhnPXkNQ2vjruqrh8pj/Uw/dHbBL/CDVf9Jj/Uw+4dsC/wh1b/AEmH9RT/AHRqB/4Q6r/pFP8AqKf7o7YF+P8AVu64h/UU/wB0
dsHc2a2oqU7+lR1i2tb6xqyUKsJ0IxlFPvjKKTTRjLDy8mscpvzjta1Z0rPU7m3oNujGWabfPdayvrLjdxjKay057iaQsANIIz6hYU76hut7tSPGE+n9xNtS6ePuqFe1
rOlXg4yXLo11XU06y7UNkVEoTAiwFyA7WlaTVvoU3PNO3zmU8cX4Im2Llp6+jb0rejCjRgoU4LCSI527EkBVJBVUkUVsCDAiwIlCYCAAEEADAaAkkBdBcQNW8qVGdWXK
MckSvL1ZNtt83xZWlEmBWwIsBFAAEAAigAZAFEkAAADAAAgQDAMAdPRtRjYTnGpFypTxnd5phLNr9a1Wne0Y0LeMlDe3pSksZx3YBJpxQ0AgAaAAEAABQAIAACBAAAAw
GA0BOIG2yqulXhU+a+PkB6Gqk+K5PkRGaaKKZICDAMAIKEBNICQDAaIJJASSAmgJIBkDQDwA0gj0uzFFxp1q7XGTUE/BcX9hzzdMHqaWMYObompx7Ts0/WUd5+WcE0qe
SB7zRRztW0ehqlWn2zqKcF6zg1Hh3Js+bz9VrP8Ak+j6XTYZY4Xf1brW0hZW1K2p53IRxHLzn3nTp+pud7cvVx6nhu7nFrqYXI9Hhefq8/fpxNpXvaZLwqRZ6cHHP0eP
OjkGURYRFgJgAEWAFEWAsAUXNzRtku1bc2sqEeePHoF0wT1SX5lCCXjJtl0J0dSjJpVae6usXkaG9OMoqUWmnyaCEwIMBYAaQRZHhxfJcSo8bdVe0rVKj/Ok2GmVsKiy
iLAiwEBEgkUAEgABoBoC6myDsU5dpbwl3pYYRmqRAokFQYEWUIgQAAAACAADADwAAWU36yA+majNXVlpOoL/ADi0ipP9KD3X9hzw9bDk+lc1xNsFuhRggsiuBBC4tqFz
TdO4pRqQ8e7y6FJdPPXuzjTcrOsmvmVPvLtuZ+7nR0HWKlWNGjYVa1SXsxorfb9yFsbll9GbUNOvtNqqjf2lW2qvjuVY4ZJlMvRqyz1YXldxR3NK0pTca94sQ5xpvnLz
8CueWXs+k21O21XTqE6l0qF9TbpylOm3GpFcYttcmstcu5HnndhlZryWyZyXfmHs/qrw6Ft8qi+UraSqL6OK95rxcfr5M+Fl9PNU9n9bbx+Krr9geLh7nh5+yqps/rcf
+67n9kviY+6+Hl7M8tD1n/Vlz+yPEx907MvZW9A1p8tLuf2f7x4mPudmXshLZ/Wlz0u5X9H+8viY+69mXsrlomrrnptx+yO/H3Tsy9kPxLq/+rbn9gvfj7nZl7MVehWo
S3K1KdOXSUcGpdpZpUVCIAqGgphDwQSiii+mssIp1esoUY0E+MvWl5CK4FSXEKqYEGAihAAAQBQ8ECKABgMAAYAAABAAMAAutLard3EKFHG9LPF8kgLL+xq2FWMKrjJS
WYyj3gl2yhRgIAAAAAAAAAEUIgAEAAMoCBgNASQF1OWAO/p1ZVrfs5e1D6gic0BTJAQwAYAWAGkRUsFAA0QHa0YvE6sI+bAspzo1Hu0q9Gcuilh/STa6WYknutNNc00V
DSIJFQBUkiCSQRLAHtdMpK3s6NLHFRzLzfFnK+rrPKOlB8DLTJYV+11G+ln1Y7sF7s/bkuU1IS+bpp5MKmmkstZ8BfRYlCcZxlKDTU3vJrvT5M/PXcuq+1Na3Eak3GEc
vjk68W7nNMZ67btCTyfcfIcnaBZ0ut4OL+k3j6s5ejyB0ciZURYCAiwEAmUACAruKqt6M6zSe6vVT75Pl/14BY83UnKpOVScnKcnlt97NIgFSTA36bXaqdlJ+rLivBhH
TIhYCq5VKcXhzin5gTg1L2Wn5BFOp1ew0+rLPrT9Re8sHkajK0pYESBMoiAmBFkEigQEkAIBgNAWQYHU06eVKk+/iiJUq0MNgZZriBU0BFlUgEAAMBAIAIGAyhEBnDQH
0XQKnyvY7cfGdjd48oTX3o53yz/ut88P7FumnMnECLQU0iItpwc5KEU5Sbwkllti2T1WTfo9bpWyUHFXWuXErS3XHsaazVl4dInhz67Du7MPOvZh0eVndn5R36eradpF
jVttF0ynbymmpVc702vGXNv6DWGOef8ANmmWWGHlg+R7WWdxqtF16FKdWvSk5yUVl7r5m+ntlpyWOJpukyoU6dxdUJRqzW9BTjjC64PXvbz5V37Cwncz3nmNJe1L7ES3
TMm3oaVONKmoU1uxXJGG2DVdTlp1OMoJ9rN4i08Y8TGe9abw9duFPVNRvqqSu686suC3ZtP6Dnjuejplq+dRvaGt29JVql1XdPvcaze75nonn6uFYHdXi53dx/WM3qJs
fLrxcryv/WMaibJ6he993Xf/AKjGobL8Y3q5XVb9tjUN1lu9Svq8XSnd1nT71vviNQ2z0a9alwhUlj5ucp+4o7VGaq0o1FykgiwBAAQ0BNICyMQjRHdpwc5vEYrLYHnr
yu61adSXNvl0QVikwqGQIlAAiBgIBlARQEADRQANAMAAAoIgCkA0Bfa16ltWjWoy3Zx5PAS+ad7d172oqleSbisJJYSQJNM2MBQAggAAAAAApBAUIAIEAANFDACBgNMC
cWBsta8qU1KPk/FAdeMlNKSeUwgaAg0yKi+HPgBFSj85AWJAPgUIg5t1dSlJwpvEFwyu8pGXIUcAjqadftONvcS3qb4Qm+cH931EsV1cBBggeAh4AYGrTqPbXlKm1w3s
vyXEl9Fnq9nB95ydEq9bsLepWz7Ecrz7hJtdufs+2u3b5vDZc0xdxMw2kpNd4GZU7ilN/JZ03Tbz2VVPEW+e61xXkeXm6XDkvd6V6OPqMsJr6J0JVqu7VrOGMZjCGcLx
bfMvF02PHdz1Tk58uSaXtnpcHN1vjplz+qn9KNY+qZejxrZ1cSYCYEWAgFgoAABAc7WpNW9OK755fwLFcQoYQAW2uflNLHzkKr0DRlHPu7huTpweIrg8d5oZU+IF9HKk
pReGEY9cuu1nTorlTWX+swRxJsqqmFIgRRECLZAgGUNEDTKGgAgZROLA029V06kZrmmB16qU4KceKayiIw1I4AokgItARaKIhQAwgAQUgGQAAA8Aey2BrOc9R058rm2c
or9OD3l9GTnyfStY+csdbHDJpxRaCotAOKIPb7D6ZTpaff7QXXqql+Rts98/zmvq97PJ1UvJj4cvq9fS6wviX6J3NxVuZuVWWei7l5GeHp8OKaxa5ebLkvmzSwehxY40
KdGLVOOFlvzLJqaiXdu2O/tIXdJQm2pJ5UlzXU1LpLNp06UacFThFRjHgkASQGW5tqNzTdOvSjOHj3eQGSw0u3sZVJUt5ub5y4tLoNFu22UYyg4TScZLDT70VHg9QpO2
u6tu/wAyWF4ruNoyZKE2ELKCssvafmAIDs6f/kkPN/WErSwhAMBpAWxQF9OPgEc/UrpT/I036kX6zXewrkSi5SxFNt8ku8Ksem6hu73yOrjy+wG4xSTi3GSaa4NPmgqI
AEAAAIBgAUBDKGAANAGQDIDIEAYCngAQR0tP0PV9Rh2tjp1zXpfzkYYh+08Ixc8cfWtTHK+kZby3qWdxK3rSpOpH2uyqqoovo2uGTUu5ss0pxkrKLWApAAQgphAABSCA
AAChABAFDACAAso0qlaahSpynN90Vlga56XqFOO/K1nu+GG/ggm4ohLdeHzCuhZV917svZf0BK63Z+qmuKYFNT1Vkisk23z4lEAJ0p7rw36rA04IKrqe5b1JLnjCA4pV
AQASQV6Kwm6trTlLi+T9xErSQAQwGkB2Nn4L5TVk+cYcPezOTWL0KfQw25mv3EoWcKa51KiT8lxNYzzStOkLd3/EmSx1ozMaaSUskEovigqu2f5GPhn62BY5AYNV9bT7
lf8A22anqzfR406uQATKIgJgHHjhcFzfQgold2kXuyuqCfTfRV0shUhUWac4yXWLyESAxarQdW13o8XB73u7ywcHBVIIANmmUnUuFPHqw4vz7iVXZk8JvoskRxMN8X3m
hJRCLXNUKMqsuUVw8WB5+vUlOTlJ5beWw0zNgRZRFkEWAgIsBBUioQVJBDQAAyBpgWwlxKOrYVlKDoSfjEIlWhggyyiFVtBEMFEWiAKpAAQAIimAAAAB29kr1WWv2NeT
xBVUpfqvg/rM5zeNi43Ve3uqPY3FWj8yco/Bkl3NudmrpQ4lEWgLLa3q3NzStqEd6rVmoQj1beES3U2sm7p9J1x0bKhZ6FaS/IWMFGbX59Tvf1/E82PnvKvVl5SYxxGs
m2EJIqKai9V+RUUNccFEGgiuSKK5AQKhMlV5Xau3xXo3SXCa3Jea5fQbxSvPM0iLYEWwKABAdyyWLWn5BF5AFQ8ATigL6cQKtRuFRpdlF/lJrj4II4FVvuDUd/Z61VOg
rqazUqZ3W/zYhnKu3jIZcbaGwp1bWd3FYrUllv50fENSvIthsBAAwABoBgADKAAIABgIBgNLIGzTtN1DUq/yfT7Orc1FzUFwj5vkveZyymPq1MbfR7HT9gK0knquqW9r
1p0V20l7+EfrOV5vaOk4vese1NLZzZapSpadTqalqe7vb15uujR6NwXtS6JvC7y4d2fnfKLcccb5PKwntbtddOjCd5f7vBx3t2lSXjyjFGv5cF88nvdM2Y021pxW0tfR
aCUcOnZucZr+knu59xzueV/Ls7J9UbnTPR28wp61fU5dVUjJfTEd3L7J2YOfLZHS7x/9kbUW1ST5Quae4374t/UanJlPWJ4c+lcfVtmdZ0mDqXdnJ0F/L0X2lP4rl7ze
OeNYuFjiLjxXFG2QwgAAEAAACKAAARAyhkCAeUB7jS7OFpaQhFLtJJOcu9sM1s3cBlwdobOnGMbyCSlvbs8d/RhqVxYSw+DDTtabX7Sm6Mn60eK8UEWXUH6oGOSCq2Ag
NdNtwi30IKr2Lla1ElyWSjj4CgIABAej0yLhZUsri8y+LJRrSIHuvoAptU4uU5JRXNvkEYKms2lJvEatXHzEkvixqrpq0vamwt6s3VoXMFNJZW7LHwJZWpqPX2F9b39F
VrWtGrT6ru8Gu4zpWLX3iFtn57+wuKZOpZvd3jNajZGZkWxmFTUiKpt55pc/zpL6WUWOREZb95tK6605fUanqV5A6ORAIAAquKtOhSlVqvEIrLxz8l4lHlr7UK95LE3u
0l7NNPgvvfiWTS7Y8oonRrVKU1OnNwku9Aem0u7+W0nvYVWHtJd/iSo3boRwNTt4W9WPZvhPL3ehVYcAOKTlFZ5tID0dCjTo01TgsLvfXxMjPK5j2klzhyLoYd3EnHoU
WRgwjmancb0+xi/Vhz8WVY5U5ZIqtlEWwEBFkCAiwowESKERTAYDCABoCcWBfSm4SUovDXJgdeM43FJTXB966MqM9SGCCiSwBW0BBoKWAgCgAZUIBkUAIAAtotqaaeH3
AfUatT5TChd/6RRhUfnjD+lHPH00mfrtQzTCEgPWbC20bd3ev1opxtF2dun+dWkvsX1nDlu/5Y9HDNbzq6cpVKjnN5lJ5bfe2FQoSVSjGa78/XgUgmVFFX2ZeRUZ37Xu
QCYt0sm1clkz3r2qZrmjpGKppS7SlCfVFQ2iDm65b/KNNrxSzKK34+a/uyag8G3k2iOQE2BUAAd+hHdoU1+iiIsKhoCUUBdCIFlarC2oupPn3Lqwjz1xXlUnKcnmT4hp
lcsgev0OrTq6bRSa3qfqSXRhmujkI5uuXEKOm1958Zx3Irq2CerxG7nkHRvWlah2Pau1nu4z448uYTcYQoAYQ0UMAAYAAEAAwAoa4ges2d2Ud1bx1TV6krbTvahBPFSu
vD5sfHv7upxz5NeWPq6Y4b8669/txp+l2/4u0m2p0qMOChSWI+b6vxZicdvnXTu15R4zUNqtTupuUazguiOswkZ3XDubqtcVJVa83Ob5tmp5D0lxtfc09IoaVpUI2VvT
jiXZrDk+9+b68zHhze6u68rVq1as3OrVnOT5uUsm9IUcFFsasocYtp+AR1tL2k1rTaila39WMe+EnvRfmmZuMvqstno61XWdB1df9pWS069f+d2cfUk/06f2riZkuPoW
SuXe2Va13am9TrW83+TuKL3qc/f3PwfE3LtzuOmQrJABQgABMAIAAAYDhGU5KEIuUm8JJZbCt1bSdQo0XWqW0lBLLaaePPAZ3GBxYV9AtKsK1vTrU5ZjOKYYXZA420te
EbONDPr1JJ48F3hY8upNBppt60qdSM4vEk8plHo6dSne2qqQ4Tj7UejMoxVYYKM7QC5vCCr4VqbSinjHVEF8cNdzQHHu7eVCfLMH7LKrOAYCNNhaTuayTTVNP1pfYB6Z
QjhKKwlwRkYbm6dObp0+a5yKMjuamc9rLPmBzru+rXLUZzbhHkvtKMkuICwgN2l6hcabdRuLZ8VwlDumujJZtXuNUuYXdvY16cs06nrL34M4+RXdotLJmtLlMirFMgmp
kNqbaonGaXdVmvpLoXb/AIhWe8blb1Unx3X9QiV5Thg6OZLiBLdfQCDKOFtFXe9St0+CW+/PkixXCZQgh8gNuk15Ur+jh4UnuS8mKO5qF/8AJ/ydPEqvfnlEkiOFUq1K
s9+rOUpdWVSAMAabW6q0HhSzD5suKA1UVGq1urm+QGq7dCbShxmuGVyJEc+/ufk1Ldi/yklw8F1KPP1JcQqhsKiyhMCJABSAiAAMqAimVAAyAAkiiSZBJMDXa3Doz3ua
fBrqEdOUY1IKpBpxfHJUZakGRVEogQaAi0FLABgqDAUgAgAAAAnHg0+gH0HQa/b6HQWcyoTlT9z9ZfWznrWSZekbGisFTp1KtWFGlBzqTkoxiu9vgkLdEm7p7vUIUrC3
ttGt5JwtI/lZL8+q+Mn9nuPPj53uv1evLWM7Z9HNlU3U30WTbG2fRZ79jx5xnJfTn7Rn6mPo2TRItZ6vJlRlfDgVEWyog2+o1DzVvmUY7GWVVp98JvHk2WkaHwAhLjzW
UEfN9QoO1va9DuhNpeXd9B0RmTAUuQEAGlxx1A9GlhJdEGRgCSiBbGIFtSrTtqfaVXw7l3thHAvLudxVc5cF3RXJIKxSlkKg2BdZ3dezq9pQnjPtRfFS8wWbdZbS1VHH
yOnvdd94CdrlX15WvqinXkuHsxXBRCzyW6O6K1K27XG7v9/Xu+kqV7V70nw5hh4fVlBanc9njc3+7lnv+kjpPRkw2spPC7wpANBDKAgZQAMgAAoYHpdmNLtZU561qyXy
Cg8Qpy/l5ru/VXf15dTlnlfyx0wx+tYdp9qrvVq04Qm4W64JLhwLhhMW7bXlXxeTSFnAEZPgFQjLuAsTKhgCYEskCxkDVZXlxZylGhJOFThOlJb0Ki8V3+fNDQ1TcJy3
6dOVNP8AMlLe3ff3rzK5XX0QAAhFCYAAEAAZAnKE4pNwkk+WVjIHU2aw9TW+lvbktzz/AP8AMhMvR7DecVx5d+ehWHzyvKEqtTs/Y3nu+WeAdGrTtTudPyqbU6beXTny
z1XQhZt0am01WUcQtIRl1c20E7XFr16txVdatNym+9/UVUFIgsjIo2Wd1O3qKpB+DT5NAdWNWNeG/F5zzXejKKaifQonaqnFS3uE3yb6EVQo4RRdbzjCT3mksc2QZr67
hVg6VNNrKzIowAIDp6fqFKjSjQqxaSbxNcfoJYOtOovk86tOSa3cpoDjNPvKKbjMaM34Ac4AyAwDLQHpdIrTq6VbwlyhcSivLg/tM/Vb6PcqMo9xhdKq9/a23+UXFOm+
jfH4DWzZR1bTXDtPl9BR6ueBqqy3G0uj0E38sVTwpxch21NuVT2z0+j2qjb3NTeqzksRS4N8ObL21dq6m2+8vyOmPzqVcfUh2HchZ7S6hfXaoSo29KlKMs7uW+XVl7JE
21twhFym8RSy2GXGub6dVtU24Q7kub8zWhj7Sae8pyT/AFmFbbPUZb6pV3vJ8FJ815jQxbRU5K6p1McJU/qYiRx8FUgAIsoNwqwnHnGSaA0ybk3KTbbeW2AsAADAkoga
qDlHejF4UlhhFletC1pb8uMn7MeoHAuK06s5TnLMnzDUZZPIEGAihMCLIFgAYVFhAAwGFAAEBQwGA8gNMgnFgb7K57J7suNN8108QldGpTjKKlBpp8U0EZKkMBVMogQa
AjgBYKBoCLCkQAAAAMD2Gx1Rzo3dunx3I1V5xeH9DMZesp6yx6DOPaQc3otk6dOlWr6vNJq0ju0U++tJer8Fl/A5cl3/ACu3DPXJdUeW23lt5b6hpkupYoz8Vgs9UqvR
JKMbin0kn9AzMXRkzLSipyZUZpIqK5FRBsoqk8MDm289zUJrPCbaNfRG+RBFlHjdrrfs72lcJcKsMPzX92DWKOAUJ8ghJAW0Yb1aC6yQV6FIjJqIFsKeQFc16VpDM+M3
ygubKOBd3VSvNzqPL7kuSAySkFVtlCyQGQEAANJcwOh+ONQVLsldT3cYzwz8eZU1HPlJsivWadd6etKhGdSlGChipTfNvv4d5WbLt5R4y8LhngRsBAUSAAABkAAAatNs
56he0rWEt3ffrS+ZFcW/ciZXUWTd0t2o1iNzVhp9l6lhbLs6cV0XeZxmvN1ec3jYMgJsKgyCIEoy7mBPJQZAeQh5A6GlXlKhUlQulvWtbhPrB9014r6USpfNfd0J29eV
GbTa5SXKSfJrwZd7c7NKcgAQAACACgAutJUoXVGdZZpxmnJY7iD0eu3lpPTZQjVp1Zya7NReWvHwKzJdvMQqzjJTi3GSeU1waDTbX1a/uKLo1bmTg+DXBZ82E055FIAA
eShgNMgsjLBRooV50pb0Hx7/ABA61CrTuFw4S74kRKcMAV444fAKw1ZOb6R7kBU0BHACwAsAabW5nQ3o5zTmsSj9oF6eVkCNaO/RnFc8AcphSAaCHyA9LpNWgtMo0oST
qKpKdRY9lvGF8ET6lc13FxUm83Fbdzx/KP7yqlzeX8QhtrGAMNxT3ZJr2X9AFSigp8gOloT/AO0Ifqy+olHY1ebjaqCftyw/IkRxMtFCyUSUUwO1fWrvtLpOP8dGKlHx
feveT0HkpZUnGScZJ4afcVUWghcgrZGhOlCM6ixKSyl3pBDAaQDSAkogXU4ZAtq1KdrT7SfPuj3sI4VzcVK1Rzm+P0JdArNJ5Cq2yiLYCAAEQBQgIsikBIIApgAQBQVD
AZAwHkCyMsAbbS7dJ4frQfNfcDTpbsKsN+DzEIzzp4AolECDQEWihNEEWgFgKMBBgAwFGAO7sjdK01i3lNKVNz3JxlylF8MMznNxZ5V9ZVW25w0ywh/6O9/zNnHV92pr
2FSvKdNU8QjCLclGEFFZ64QkXf0UORUZbmTaSRYlZNnakq+qXNOKclKn6qSznD5/SXPyhh516V2txLKhRlNr82LTl8E8/Qce6e7p232c+pLi4tNSXNPg0bjNUSfEqItP
o/gUVvPRlRVPiEc2ra1XXdSGF62U2zWxtUpZeYpLzIBtAcPaukquluol61Gal7nwf1moleLSNIbiA4xA02cM3VJfpZA70Kee4iLVTSWXhJd7CMF3qcKacLbEpfPfJeRV
cStWlOTlKTcnzbCqHLIEGBFgAAAAIBgADAAoAYQANFDAAABkDA6FC4/F2j3V1HhXuX2FN9IrjJ/UjN866YR5hyy895WyyAZATYCYEQABqTQE1JAGceQDTCBy5AduhP5b
pWW/y9m0s/Opt/Y/rE9WcozorBgMIQAAFCZAAABgBMoAABAMAAYDTAmpEFkKji002muTQHUtr5TxGvw/SX2hGutTi6e9Fpp96AxVKeAqiUWBW0AmiiDRAAareeYbr7uQ
FoHPuaEoNzivUf0BVGAGEC4hZG7S51I3KpxfqVMpr3Fq06OVF5IytyAgKq/Gk/ADKA8AdHQ1/wBoRf6EvqJVdXWYuVtCa/Mlx95IjjI0ppIBvK5Ad6nWVvaRVRpbkFlt
4MsvLajWhXuN+m8pLDeOZpYzIB44FG+tXhXcHF8oJYfUgrCpJBFkYMC+FLIBc16VpHD9ao+UfvCOHcXFSrNznLLYXTLKQVBsoi2QLIAAigIEAAJlEe8imAwAAAAgACiS
IGAwGmBOLwBptridGWYPnzT5MDrUa1K5jherPviwiNSi0+QFEqYFUoAQcQItALACaAMBQAgNNi92vGS5p5Xu4gezuNtqFrVnQlp1ScoPG8qqWeHPkc+xrbOtvqbf/wBL
qL/1l9w7Daf+HVJrjpk/65fcXs+6dzLebaRq0pQhYVISlwcu1TwvgJjot24tTaC7nSnRhUnRpS9qNN43l4vmzWp6rLr0c6NRuopwcozXFSTw17xWpXq9L201e0Uad5Kn
qVCPBRu1vTS8Ki9ZfSc7xY/Tyb7vfzeq0jaCnrFGtOjTlb9nPHZ7ye6nxXHvJ269WMr5+TU5zlxlKXvYZRaKISCINlEGwE0UZNQoqrZXFOXKVOS+gRHz+CykbRZu5XAC
yFJvuA6GnUF8pi+ibCVtudQtbdOMX2k13R5fEiacW8v61xwnLEO6EeX95V0wynkqq5PIESBAJgAAAFAQAAUNEAFMBFQwpkQwGAAAAFU61Weba1T9WjSWf1pcX9ZI64+j
l5Kp5IDICAAEAAIBgGQHkCS4gb9IrdjexjL+Lqp05rwfAlRoa3W4vmuDNOQAAgwAigYCIGAihgJkCACgAAAAAYBkCSZBOM8AaKNzUp+zLh07gN1O6o1Fip6j+gInKnFr
Kw11QFE6b6BVUogVuICaAst+EmuqAvlKMFmTSQGS4uFODhGPDPNgZQoCGuAWV19M7GNJ1I4lVSllZ4pYBazUpcMBFiAbAprvFNrqBmSCpII6Oi8L7P6DJR6CXZ1IOE1m
MlhoyOFdUVRrSpxlvJccmlUcSo0WlShS369xL+L4xh85kHOvburdz3pvEVyguSKMwUYCGkBKKA0U23wYF8It9wGmnTaW88JLm2E2yXWoqnmFvhv5/wBwXTkVKjk2222+
bbKqiTIINlCIIsoQAAAIAACKTCIgSCgBoAAQAAICSCGAFDRA0wJplFsJtNNPGCDpUL/go11lfOXMJpsUI1Ib1OSkuqCKKlLAVRKAFbiBFoCLQCAABJAShLs5KS7mBRey
VS6lJSzlL6gqtYQA2AgFnAEoS3XngwS6T7TPcviGu57LYGPrX0+O7iC9/Exkt83r85zhcM9DKFl9AiLAgyiLAi3juA52t3tO3sqlPfXbVYuMI548ebLIjx1Omk0sr4m0
aoUU13BNqqtxCm92mlJrv7gM1S5qS4OTx0XBBVEplFbkBHICyAAACAYCAYUYCAgCgAYAQAAiiSIAKYQFDIGl3BXKv5795Wn1kR1jMFMAAAAAAAAAAAABoCyMmpJrmnkD
rTe/Jy68SuV9SwEPAQigACBFAAgAAAAABADAQAgGANgADyA8gSUwLadacHmEnHyA1QvZcO0ipLquDImmlKFWO9BpoCudNoKqccAKHqyy+CAz1ZyqSy+XcgqGAFgIAEFS
g5QkpRk1Jd6A00pJrxQRbvgJyAUnvW9RtcVJY8gKEA0B0NIajcylJ4SpviSi26u51W1TbhDw5saGZPBQmwMly8yUegFOAHgCSiBJQYFkKbYGmlQbxwCLa1xb2q9d70/m
R+3oByru+q1+De7DuhHkF0wynkKrbAi2URbAQDATRAsMoMMAwwDABgBNEEcMBhQAwBgIAAYAAwgKHkgaYDyUSTIJqQGihcTpT3qcnFgdehqdCaUbmlGL+fFcPegjeqFC
rDfp7k49Y8SIplbR7oR+BV2olQivzI/AG1box+YvgDat0o/Mj8AIunH5i+ABuQ+avgAnCPzY/AB7sfmQ/ZQCaj8yH7KAW7H+bh+ygbG7H+bh+ygE1H5kP2UAer8yH7KA
XD5sP2UBfSu7qkmqdxUgn3Rlgml3U/l98v8APLhf+oxpC+X33+mXH9Yy6NpK/vv9Mr/1jGhJX19/pdf+sZNQWxvb3/Sqz85sag0Ur68Ty68n5vI1DbXHULl8XGhJ9ZUI
N/FonbDuq2erVKEN6r8lj4fJoZf0Dsh3VxNT1u5vYdi40qdHOcU6UYuXm0voLMZDdclzKIuQEcgIBFAAEAAFAAwHgAAADADIDBQYIDABgBgMKAAIFkCceYVxLj+Nn5sj
tFQDQAAwAAAAAAAAABoCaA6lLjSg33orll6p4CGEIAKEAAIAAQAAAAAQJlCAAAAAYAAEAiiWSB7zKLaVadOW9CWGB0qF3SqpRq+pLr3ERfOh3oDNWp4XLmFZXTYEHECL
iAsAGAFgCdPKkBcgGAPoBHdAaiBbQk476X50cfSBMAwAYAzVI5nJ+IEVBgSVNgWxot9wGinbN9wQVKttb8JT3p/NjxAwXGoVZpxh+Tj0XP4hdOdOo2FVOQCbAi2AsgJl
CIJx5gWqKKHuIIe4gE4IBOCANxBScEAtxZCM5GgAwEAAAAgGAZAMhB3lDyQNMCSYDTAkpATU2gLqVxUpS3qdSUJdUwOrb6xJYVemprrHgwmm+F1Z1/ZqqMvmz4BEp0O9
cuoRRKi+gXamVJ9AIumwIuDCouICcQDdKE4gLdCDdClukBusA3QJKDCJqnkKthS8Ai+FFvuAnOVCgvylRJ9FxYGStqTw40YqC+c+LGjTnVaspycpScm+bZVVORBFsBAA
UMqAAIAAyAIBlDRAFUwgAAAgYAAFAABTIDADwwPXbK7A7R7SKFa2tFbWUv8AO7rMINfornL3cPE5Z82OLePFll6PrOkeiTZXTqUausXFbUKi4y359lS/ZXF+9nn/ABFt
8necEnq/Pm3Gm2+mbV6xZWbh8lpXU+x3HmO4+Mce549x68bvGVi+V086VAAwGAAAAAIAAAACSAYHWgt2EY9EiuNTQAVAQIoCBFAAgBgIAIAoRAFAAgGAgAAyAAADIEA0
wJKXiBpt7utR9ifq/NfFAbo3tGrhVY7j6rigizs4VFmnJSXgwKpUH0Cq5UX0ArdMoj2ZAtx9ABRaaAuwAY8ADADUQHuBE4Q58AqxRAagwH2b6BFUaLb5BVsbZvuCJShR
orNWpGPg3xAzVdRoU+FGm5vrLggaYa9/WqrEqmI/NjwQVjlUArcslVBsgi2AslCbAQAQMolDmQaFyKhhQEIAATCkEBBlCgKAEAAAQBQAwAACAB5AYDTAMgPLAkmBJSAs
jPAF9G7rUv4urKPk+ATTdS1asuFSMKi8Vhg00w1O2njfpTg/DDCaXRr2dT2a8V4S4AT7KEuMZRl5PIEXbvoAvk76AL5O+gEXQfQGy7BlC7B9CA7BgCoATVv4ADhTh7VS
C82BF17WH57l+qgKp6hCP8XS98mDTJWvq8+DqNLpHggMzqBUXIojkKWQgyQGSgyAEAAAMBFU0QMIChgADQAAwAAAMEAAyhogcU20kst9yCvrmxOyFDToU9S1ihCtev1o
UKkVKFHplcnLz4I+N1PX5ZXt4/T3fS4Okkndn6vXapt1VsG6VKtGvVSxuuKaj8Dhx58mXna75YYT0eH1faC81acp3N1Nd+4niJ9Pg5Mb5fV4Ofjynn9Hy/a6lL5XTuo5
cakd1vxX9x7HHCvPBsBAA0AAAAAIAAAGAZAutodpWgu7OWEyuo6pXIwAAKgAAEAAIBMBABAgAoApBAAAAAwEAAADAWSAyAZAakBJSAshVcXmMmn1TA109QqxwpNTX6SB
pojfUJe3TlF9VxCaTVS2nyqpefACSpRl7Mk/J5ATt30Ai6D6ATVBtIA7F9Ao7F9AJRoPoETVB9ALYW/q8gbN0lHnheYEJVban7demvBPIFVTULOC9Xfn5LH1gY6mp4X5
KlGPjJ5Bpkq6hcT4Oq0ukeCC6ZZ1c8QKnMKi5eJRFsBMCICZAgEUMAAAJw5gaFyCGAu4AAAEAgAKykCCgAAAAIAGABQEAUAAQwAKYQwGA8gGQJbwDUgJKYElN9QJRqMI
vhdVo+zVmvKTAuWo3S5V5e/iU0mtTuv5xPzigmkvxpcdYfsg0Hqdx+h+yDSD1K46x/ZRF0i9QuX/ACiXlFA0hK9uHzrT+IFUq85e1OT82BHfAHUYEXIBNgLIUBAULIDI
AAKpkAAFAEBFADRQ0ENEAUNEDAAGAFAQAAA4gfSvQvs9R1faKrqV5SjUs9Ngqm7NZjKrL2M+WHL4HDny1jr3d+HHeW3s9rttatW5qafpDVG2pvdlUgknN+HgcuPgmt2N
8nNd6jw1afbycqqUpvnLvOmXDhl9HPHlyx+rn3dCUYt84dTlx8Fwz39HXPn7sNfVxNXoK5s503z5xfRnseaXTxUk4txksNcGg6oNgAE6bgpxdSLlBNb0VLdbXes93mQe
juNl7m6pu+2bVXV9Olx/IQ3ri3/Qq0l6ya5byTi+afcTfutnsxXOzuuWdhU1C+0u4s7WDS37uPY77f5sFPDk/BJl3DTjZKhgShTq1N/sqU6m5FznuRb3Yrm3jkl1JsSt
adS7rwt7aEq9eo92FKlHflJ9ElxZdjfrOk3GjXUbK9nSV2qalWownvOhJ/mTa4KeMNpZxnD4iec2Xycze48CDux0u+sKFrcXlrUoxvaKr28prHaU843l7/s6ll2xmeMF
YADACoRAFCAAEAgEAAACAAEQBQAAAAiAAChZAMhSyQBQZIDIBvANSYElNgPffUBqpjkEWxua0fZqTXvAsV9cL+Vb8waTWo3K/PT/AKKBo/xlcfOh+ygaH4yuO5w/ZBov
xndLlNL+igE9Su3/AC0l5YQNKZ3lxL2q9R/0gaUutJvLbfmwIuowIub6hUXPxAi5FEWwFkgWSgAWQABMBAIAAYAQOHMo0xAkAggAYCATAQGQjQAAgAApgAQBSAYAAgGE
BQyKYDQQyhABAwHkoeQDIEkyBpgS3gDIBvAG8VBvEUZAWQHkIMlDyAZACACgBFDAZAAAAAAMqAgeAowUMAwENASWAAAACBlAAAAUEQ0u4K+47Kp7N+ieFxD1LzWKsqif
fuv1V/wr6TyZfz8uvZ6J/Lx793jmkehwPADnBVKcqcuG8sAeUrVW1OD9pNxa6NGh57U7dzbrQXH85dfENY36OU0GwAEEqNWrQqxrUKtSlVjynTm4yXk1xCp3Fzc3dXtb
u5rXFXGN+tUlOWPNthFWQAo0WN7d6fdU7uxuattc03mFWlJxlH3k0O9X232qrUJ0Y6s7eM1uzlaUKdvOa8ZwipP4k7Yu6815s0jq6Fpa1C8ipp9hF/lH18Azbp+jKVtY
+kLZJ6JcunR1axhm1q4xutLCePmtJJr3nlu+PLf0dZrkx19XwS/tLiwvK9leUpUrmhN06lOXOMlzR6pd+bz2a8mYqABgAQgEUACAAABAAAAgAgQUFQAIAIpFAEAUgAgC
hMBAAAQGQDIBkoMkQ94KN4Bb3iAbzAe8AsgLICyULIBkBZIFkBZKBkCyAgAoAEwABABAABRKHtEGpFDCAAAAEAmAAYyNAACAoYARQAAACAAAAAAhoB94DAAGygIAB5KA
AyQNMCSYAmUPIBkAyAZAMgADCGiKPEIMlUZAeQDIAAyAAAABgMACGFMqAKZEADKBAMAAZAwAoAERTCLbajO5uKVtSWalacacV4yeF9ZLdRZ5vs/pAuadvqWnbPWzXyfT
LWFJpct7C+xL4nn4p5XL3d+W+cjylRb0l4nVyPkVBzA8nr8HaaqqiX5K6jnymuD+PA1PQc+XFlRzbuzXGdH3x+4NzL3cuWU8GWyyAwEAZAaAYBnAGyxtJXTy8xprnL7i
pbp6/SacaMFGmt2EeCDla9NouqXOl6hQvrabVSnLOO6S70zGWMs01jlZdvWelLZ+22l0SntpokN+6p0l8spQWXUpr879aHf1XkceLk7cuyu3Jh3Tuj4euPHuPU85oBgA
QiqGRCKEQBQABAigAAEAMikAFCyEAUAIAZBEoCAKBkCKEyAKAgAABNlAQIAyUBAZAAEAmygyAZAWSBAACKAgRQwABAIgAAAKEQTp+0BqiVEgAgQAUACAAMRFAUwgCgIA
GAgpAABgIAoAAiQUBAAygACBgIBgBQ0QNAPIAAsgMoMkDAChkDyUGSAKGABAAwpgIIZFMAAChhDRBJAGAGUAAAwAgYAAAMoCKAAI9f6LbCF9tzpjrJdhauV3Vb5KNOOf
rwcua6wrpxTeTo6vezvtTvtTk8yrVZVV5Z4fQXHHUkTK7u1ilGpGM4vMZJNe8BMqADlbSWXyrSqk4rNWh+Vh14c/oLB4Kte1Zv1Zbq7lE03MVM7mvN8amPJYIlmlclvv
M+L6sJtVKn834EamSvDzx4Bo0mA8AICcYuXcE3pdGksZlxLpm5LFUqwxuVJxS7kwjradrcrdqncR3qfzkuK+8JY9VQqwrQjOnJSjJZTXeEfSPRlqVXTrudpdPFjcPnNp
KEuuH3Pkzzc2MvnPV34cteV9Hj/SzsUtmtVV/YU8aTezbhFcqFTm6fl3x967jrxZ900zy4dt2+ds6uQACoAABAIgCgwAgAgRQAIAIEFACKABAAQgoIAoRAAIoRAFAAMg
iUBAFCIAAAMgACbAWShEAyhZIAAAChAAAAAJkAAigIAoRBZS5ga48ioYCAYAAgEAAZ6cMkVZ2SAfZIB9kugQ+yQC7JFD7JALsUFPsUQHYoA7FFQdiiAdFALskAdkgu0Z
08IChgADKAAACAKABkDKGQGQEAFDIGAZKGAyB5KFkBgBAwGUAAAwABgMgCoaIqSCGA0UAAAAADIGAABVMgAAI97sBmx0HabWFwnKjTsKL/SqPel/wo48nnlI64eWNrHP
2JJcsM6MHolXtLTs2/WpPHu7hR0WiKEEKclGPGLafPgB831DRL2nfV6dtaV6lBSzCUabaw+K+406SqJaTqUVl2Fz/VsJaplZXsfasrhedKQZR+TXC9q3rLzpv7gG4TSx
KDx4xCKpQj0QXdOFKDa5fELut27bRjJ04Q3scOATzTpaLqdSMZ07WUoyWU95Yf0k2NlDZvVKjSmqFJdZ1fuyNo7dpsTRqpfK9obG3XeoUatV/UkZuV+kakn1rpUdhNlY
NO62o1Gqu9W9gofTKRi5Z/SN/wAnu9DpWn7CaVTVNQ127SeV2lWEV9CM3xb7H+n93dp67shQjm32YlUku+vWcmTs5Pde7CekdOvtjoOv6dV0PV9NqUrKvHs23LeUOkk+
aa5p+BicWeF3K34uOU1Y+Davp9XStVu9NryUqlvVcN9cprukvNNP3nsxu5t5rNXTIioCoYCACBAIoCBFUEQiqAhBQRAFIAKAITAiwoACAKEAECKFgAAAEQJgBQgAAAQB
kBEBkBFAAmAAIgAGUIAIAAYCYCCgIAAKQE6ftBGyPIqGAgGAAJgRYBkCFEKtCGA0A8gADAAAAAYAAgEwAgrq+yBkfMNEEMoYAAEAAFAQNMBgAAUBAwAoAGiBlAA0QADA
AGUADAYQwGAEDwFARIBooYAAEAABTQQwGAihkDAaA97a/wCK7FaTaLhO7r1r2ouqzuQ+iLOU887XT0wkYXyfkbZc3R7jsL2MW8Qqeo/sLR6V5yYUFQsJ8+4CWWu8gTbf
ewI8er+JQZfV/EKOfiAnTpP2qVN9cxTA87tdp1F2UbyjShCpSklPcilmL8ujLKseLwytPQbL6hKhdxtJvNGryXzZf3iplHtXhoywWMADYEWAsASSQHA2ufaX1vXlxnKh
GEn13eC+jHwLj6GV24BpCAZUACIABFCYCIABFAQAAVSZAAIACEVSCAKRAFCAAAIQUgEAARAAAAATIEUBAFCAAEQBQsgAARTKgAQAAMBMBYIoAQAEAE6ftFGyPIIeQFkA
AYCYEWAYAhR5BVwQAMAAYDQAAAAAAAAAwACur7JBjlzCkAAMAyAABQAMgADJQyAAYAA0AwGAwAAAYAA0UADIGEBQ0RTQDCGAANASAAAoZABQA0EMAZQiBgMB5eHhce4D
3uqfkq1CzXs2dvSt15qKb+ls54+m3TL10wy9l+Rpl518Hw4PqaR66yrK5tadbPGS4+feYVoIABAGCgwAgHggTKrDrcN/Sb2L5djJ/DiIR813jbbTp0m9QtVH2u1jj4kK
+lx5Iy5mAmAsAGAADzu08k61vHvUZP6TUSuGVAAIoAEQMBFCYCYCAAAAACBAGAqOCgIhFUEQgoKABMgRQiAAMFCIEwEAgABFAAgABEAAAIBAAAFAAVDAQAAAIgCgIIgA
DAlT9oDXHkVDAAAAYCAQBkCFIKuCABgADAADIAAABA0UAAAAQq+yBilzIpAAUBAAwAAAYAAIBgAAAyhoBgPvIAAKGA0AAPBAwAoaAeAGABDIGUMBgMgAAACmAAMBgACA
EEMDfolBXOr2Nu16s68FLyzl/QmTK6izzr011WdxdVq751Kkp/FmZNTS27qmT9V+RRwpI0y6ugV92pO2k+EvWj596M1qO8ZAAABQAGAB8CKhKSS8+BRy9o7unQ0mvByX
aVo9nBd7zz+gT1I+ePGcYNt7j0OzWk1JXUL2vHdhD2It8ZPrjoZrOVe0jFpcn8CMmAngAwAgFNqMXJtJJZbfcB43U7lXd5OrH2F6sfJG9IyYCDAUioYCACAKEBFgIAIA
AKoCEAwEAgpBAwqLAAAgRQAIAYCAQCIEUACARAMoRAFAAmAiAAQUAAQBQABAUIgApBAUBAAACAnT9oDXHkVEgEAgAAAQEcgKkFXIiAoYAAANAAB3AGSARQ0AAAABXV9k
DG+ZGiCEFADCH3AAAUMgAGAAADAAGgGAwAAAYDAChkDKGQMBlDAAgIGA0A0AwAKYQgGABUkEAUAAQgGgOxsysajKv/MUak1543V/zGcvRrH1dZcEl0CI1H6kvJgchxNI
UXKnOM4NxlF5TXcwrq2m0thUnKjczVCrF43pexLyfd7zFiurC5oVFvQr0pR6qaf2gRqX9lR/jry3h51EBirbR6NT/wA9U30pwchoYK21+nwz2Vvc1X4pRX0saGCttlWe
ewsKcfGpUb+rBdKw1tqdXqcI1KNJfoU19uRoUw1TULiD7a9rSafzsfUVKzVKi3nOdRyl+lLLAyJt8Zc2FNcHlcPIIuhc3EPYr1Y+U2gLo6rqcPYv7hf02/rCr4a9q8f8
9lL9aMX9g0L47S6rH+VpS86SJqI0W+0mo1pSjPsFhZWKZdAub+7uY7tas3D5sVhF0jKEBQAIBEDAQCKABMBABAgAAAAAoTIEUIAIpAACKhBQQIoCBFCACBFCYCACBAAC
AAEUIgAAACkUBEAAUIigIQUAAAggAApATp+0BqjyKylkBAIKAgAAIhUaQFyCGAAGQACSAAAAAADIDAYCAhV9kDE+ZFIBAMAAAGUBA0AygIAAAYAUMgZQwAAAYDAYAQSR
QwhoKCBlDCAgApgMIYAFMACABgNBQEAUBCAaA7mz63aN7V6qFNe9tv6jNano6GQiNV/k5eQHOaNIw6jXdvbymn63KPmFjzOW+LI0FhdyAlldF8AiKi88AqxQ6sIkqcc8
gJJLogFUk4wbXADOm3IjSxFQ8hEo8QJJLoA8LoAt1PuAutUo1l4rBYVvyVARAAMBBQAgAqERQghMBABQEAygACBAIoQCAAEFIAAiAwBgIAAiQBQmAgEwEyAAQAUIAACB
AAAAgABBTKgIpBCKoIgCgBAMIQVOn7QRqXIqGAAJgAAAmAgI0gq4IAABgADAAAAAAGAAMAArreyBifMikAwAKQDKgAYDQDAQDAZAFDAAJAAAA0AAMBgMBkDAYDAZUADA
CAAYDCgoZAFQyACmAAACyEGQGmgPQaT6um/7ys38El95m+rX0asgV1ZepIqMb4Io85rdftLlUU/Vp8/MixzQptgVzeIgXQwBaEMBgRqLMJIDLAjS1MqAB0nle8C0IYDA
lB4nF9GVG8qGQAAUBFIIAEULBAFCZAgAqmggAQCIABBSAMFCAAEQIoTQAABCCggTKEAECARQmQGAEANAIAAQAAigARAAIBgAUioAEQBQEUAACyBOnzCNS5FDCEAAIAAT
AQCpBVwQAADAAAKAhgAAA0AwAAArreyBilzIpAMoRAFDAAGAAMAAZA0AygAYDAAACQAA0QMAAaAaAYDKGEMgChgBAAMKYAABDKGQACbCoSkBS6q31HPrPu7ybXTXGyv3
DtI2F3KHzlbza+OBuGqz77U9yScZfNksP4DZp6OzluWFtH9Fy+LZBep5KgqcYsDJdVY29CpWlygs+b7ijxk5SnOU5PMpPLfiRogGBXU7kSkW0XmPkWFXrkEMAAAMuN2c
l0YVJMAb4MApPi0BoQQwGAAdGLzGL6oqGEAAAAIAKpMgAhFAQIoAAigIRQmQBQEUmEIqgIGQIoQAAgpAIAATIEAgBgIoAEAAIBEAAFEWQAAVSCAAIAoAABAACIoAAhBR
gCUPaCNUeRQwgIAoQCYCYCyAUgq0IMgCYDAAAB5AeQAAAAGAAAFdX2QMb5kUigAGAEDKAgCgAZAwACRQwABkAAyhogZQwGAEDKGRAFSRUMgApooYQAADIGFADAXeA0VA
AMgpnPd4vkRX2n0eeiGlqWn2+r7T1atOnXiqlKypPcbg+Kc5c1ldy+Jyy5PZ2w4/d9gsdE2T2XtoytrHTdOpx/lZRjFvznLi/icss9edr08fDnyXXHju/ZXLbbZKM+ze
0enprhhV0cfH4/6o90+EdbZ/0sv0aLzTNmdqbJ/KLbT9Tt5LHaJRnjykuKfvOuOcvnjXh5eDPjvbyY2X7vifpK9H1XZigtU0d1a+kQSjUhN707fo2/zo+PNd/U7Y578q
82WGvOPntGrvG3OxocvVNMvP7RXOeztYv9Of2ILHCCmAAVTeZMirLd+s0WFao8gyYAAAZ6yxNPqgqOQFJ8CB0niaBWpFRIAAYG23eaMfDgVFoQmAmAAAAwpBAygARAAA
AAgABYKFgBkCCkUIBEAVAAmRSKEAggCkwEAgAgQAAFCAQCAQAAiBMoCKCoCBAMoAABABAgoCAKAhBUoe0EaY8iiQQgABAACARFKmUWhAAAMAIAoaAYAAwAAAYABXV9kD
G+ZFIoAAigIChkAFMqAgZQEDTKJIAAADIEkAwGAwGAEEsFQIgaCmihoIYUBDIBFDIAKAGAAADCABSAy1KqpyUpR3oppuPVdDNbj9tUq8NW0GncaVddkru1UratBJ7m9H
1Xjw4Hlzl1ZHu4Mscc8cspuT1nvH5K1yvqVTU7iOrXFateU6koVHWm5NSTw1xPgZ91v83q/rXTThnHLwyTG+mnPz4mfN38nT0XXdS0S8heaXdVLetF84PhLwkuTXgzWG
WWGW8a4dV0/D1HHcOXHc/wDvT2fqDZXWbXa/ZSje3FvBxuacqNzRfGKkuE4+T5+8+3w8nfjMn8v+JdF+E6jLi9Z9P7V+YNfsnoe0WpaM238kuJU4t98ecX8Gj2S7fJs1
VXapQc5PEIrMn4Gow8dc1pXFepXlznLPku4qqwABZAqZFSpvE0wVtiyspAAABVcL1M9GFjPkihsAi8NAbIsrKWQABoDVaP1ZLo8lStAQgEFAAAgAIAAoAEFBABAABQAA
ICLAAAqIsKAABAJkCKEAAIBMBAIgRQEAUJgACYCACBFAwEQBQMikEBQAAAAAIAARFBUJkVKHMDUuRUMBMAAAEAgACNMC1BDAAAAAYDAYAAAMAAADIFdX2QsY3zIoCAAA
CgIGABQVDAYAA0A0AyAAChoBkEkUNAMCRAFDIGA0AwhgAAUNEBkKTYEd4A3gDfAN4B7wD3wFKfADJWkjNaj9Gfg7bTU9Q2cuNnK9VO602e9Si3xdCTysfqyyvejjnHfC
+T0+tei/Z3V9oLrWr2d1J3DUpUKU1CO9jDeUs8Tx5dLhllcq+/0/x7qeHgx4cNeX1r5R6V9E2R0KvZ2mgVJK9Tl8poqs6ihHhjLfKWc8Dw9Tx8eFkwfqPgnV9Z1GOWfU
T+X6XWv/AKPnkUm1xPJuv0NksfpT0L2la02GpTqxaVzcVKtPPzeCT9+GfY6OWcfn9X85+Y+THLrbJ/2yR8S9KFejX9I+vTpNSUa8aba6xhFP6T34+j81l6vHazdqnZqh
F+tVfHyR0lc9OBvBdHkIeSiMnwIsVNkUZA1055SZrbOlm8A99BD3kBGb3otdUBkyRonLiRRvFGuEspMrOk94Ie8A0wNNo/Xa6osStYRFsBOQVFyAN8BbwBvgG8A94AyA
ZATYBvALeAe8AbwBkB5ATAQAEJhQUIAZBFgIoQAAmAmAgEAgEQBQAIAACBFCAAEAgAAACAKEAEUBCKAigAAQEqftBGpcigYAAAIAATAAiMGFT3kAbyAe8gDeQD3kAbyA
FJEQ95FBvIKamgmhvoB76AW8uoD3kBCrJboGRkaAAEAAAAADAYAgGAYKGQMoZAAADAaAkiiSIGAwGgDAEsAMAAAGA0AMCEmTa6fQdi/RZr209lDUqlajp1hUWaVStFyn
VXWMF3eLfExc5G5x2vVP0C3b5bTUv7G/3jPiNeEj/AHff7TUP7HL94eIeEP4A73/AGno/wBjf7w8Q8IfwB3v+09H+xv94eIeEf8AAJef7T0v7G/3h4h4Q/gEvf8Aaej/
AGN/vDxDwifoDvWv/wCT0f7G/wB4eIeEpq/g/Xsk/wD5oo5/8nL94ne1ONyNn/Qtt5pm1Pb2es22mxtsSpalRm5b+eajDn5qXDzM2tSaff8AayF3DZHVlbV5K6jZVN2p
H1ZZUeLWOT5nHm32XT3fD+2dVx983Nx+RalOTlvZy3xbzzPhTJ/VNSPqvo+9FVTVKFrq+u1uysasVUp21P26se7ef5qfx8j3cPS90mWXo/M/FPj84MsuHhm8p5b+k/5f
b9RV3YaQ6Wi2NOrcQgqdtQzuU4vGI7z7orv7+B9KSTyj8PyZ5Z5XLK7tfEo+g3Wq1Spc321NtO6rTlUqyjayacpPLeW+rOkycrjtTdfg+31xW7SW1NFLGEvkb4L9oven
Yq/+Hi7X/iqj/YpfvDvPDed2x9C20Wz+nVNSsbqjq1vRi5VYUabhVhFc2ovO8l4PPgamcZvHXybtE+KZrbOnodjNj9c201KVjo9GG7SSlXuKr3adFPll9X3JcWZuWmpj
t9Vj+DrqDgnLaq3UscUrOTX/ADGO9vsNfg7XyfHaq3/sUv3h3nYvp/g93aWP8KaL/wD0n+8XxE8NwdpfQjtVpapT0upR1inOag1SXZVINvGWpPG71afDoWZxm8d+jr2P
4P8ArFS2hO92htKFdrMqdK3lUUfDebWfgPEXw1//AMPd/wD7VUP7HL94niHhhfg+3v8AtVQ/scv3h4h4bm6z6AtdtbSdfS9YtL+tFN/J5UnRlPwjJtrPnjzL4kOx8Wua
Na3r1bevSnSrUpuFSnNYlCSeGmu5pm2HrNgvR5tFttUqT06NK3saUtypeXGVBS+bFLjJ+C5d7MXLTcx2+nU/wfL6EUpbU0M+FnL94niHhpv8H69fLaih/Y5fvF8Q8Mv/
AIfL7/amh/Y5fvE8Q8N5Dbn0V6/sjZS1KVWjqGnQx2lehFxlS8ZQfJeKbN45ys5YWPBW1RRrR4+BvbnY6SeUVlCXgFet2K9H2v7XqVez7K2sIS3ZXVxndb71FLjJr4eJ
jLORvHC17h+ga9/2moJ/+Ul+8Z8Rvwh/ANe/7TUP7HL94niHhJfwCXn+01H+xv8AeHiHhfdF+gS9X/iej/Y3+8PEPCUV/QRrEYv5NtDZVJdyqW84fSmy+IeFXmtV9Em3
OnRlOnYUL+Ee+0rqUv2ZYZZyRm8deGure6sriVte29W3rw9qlWg4SXuZvbFmlO+hs0i6iQ2afRtjvRRtBtLY0tRq1qOm2VVb1KVeLlOrHukoLkvFviYucjePHa9QvQJf
d+01H+xy/eM+I14RP0C3r5bTUP7HL94eIeEX8Al+v/E1v/ZJfvDxDwnz/bjYbXNjatOWoRp17KtLdp3dBtwcue60+MX4Pn3G8c5WMsLHloyya2zpYioTAQCAAABNARaA
WAAoRAmAmAihAIgWAAAAQAAgAoRAAJgIBAADAAEFAQAIAAAAKQEocwNCksFQbyAN5AGV1AN5ALIBlALKArAWX1IDLAMsoMvqQSywDiAZYBlgGWUNNgPLIDiAcQDiAPLA
W4ih7iIDcKDcQB2aAfZoA7NA2fZogfZoqDs0QNU0U2fZoGx2a8QbNUl4hdpKkiJs+xXiU2fYx8QbHYx8QbSVCPiDaaoR8SCat4+INpK3h1fxKbNW9Po/iDZq3h4/EhtJ
W0PH4g2krWn+l8QbTVpT/S+INpKzpfpfEG0vkVLpL4gNWFN8lJ+8GzVhSzxcvcyBysqCXKX7QU9M0u3vtZ0+xcZONxc06UlnmnJJ/RkzlWsZ5v1htZqkNmtmL3UrehTl
8kpJUqT4RzlRiuHcePl5OzC5Pr/DuknVdThw262+Or0166uH4p0/4z+8+f8Ajs/aP1/8K9P/AF39j/hs13/VWn/Gf3k/HZ+y/wAKdP8A139h/DXrn+qdP+M/vH47P2P4
U6f+u/sP4bNd/wBVaf8AGf3j8dn7H8KdP/Xf2H8Nmu/6p0/4z+8fjs/Y/hTp/wCu/sP4bNd/1Tp/xn95fx2fsn8K9P8A139h/DZrn+qdP+M/vH47P2P4V6f+u/sts/TL
r1zd0aH4osH2lSMMKU03lpdfEs63O30c+T5Y6fDG3vv7Ptur3sdM0m+1CUVL5NQnV3W8ZcYt4yfRzz7cbfZ+O6fhvNzYcc/7rJ+r4fP01axKLT0fT2msNOU2vrPmfjs/
aP2/8KdPPTkv7MUfSzeLns1ovupMz+Mv9Mdf4cw//bL9WuPpo1x7sKej6euSSTn8OZudbnfSR58/lfp553PL9n3u3qVJ0aUpwSnKMXJLubXFH056Pw+eMmVkfGNovS/q
en65qFja6XZzoW1eVKMqkpOUt14zwZ87k63LHKyR+x6P5Z4eXgwzzzstkv0+rlv02a53aTp/xn95n8dn7PR/CnT/ANd/Yv4a9dfPSdP+M/vH47P2h/CvB/Xf2fS/Rxtg
9r9MuKtahSoXttU3alOm24uLWYyWePVe49fT8/izz9Y/OfGPhf4Hkx7bvG+m/wB4/Nnpn2Ujsttxcxt6W5p9+vlVskuEd5+vBeUvoaPdjfJ8HOPvH4PmmUbL0b2d1Gko
1r+vUrzl3y9Zxj8FFGMr5umM8nC1/wBMGp6frd/Y2umWdShb150oSnKe9JReMvD8D5fJ1uUyskftuk+WOHl4MOTPO7sl+n1c6Xpr1t8tIsP2p/eY/HZ+z0fwp0/9d/ZF
emvXU/8A6Tp/xn95Z1uftGb8q8E/77+z7NsdrFfXdm9O1W6t4UatzTc5Qg20vWaWM+CyfQ4s7nhMq/I9f02PTdRnxY3cjw3pD9Jd9sxtA9Js9Ptq0YUoTnOrKWcy44wv
DB5eo6rLjz7ZH2/hPwHj6zp/G5MrN2+n2eTfps1zu0nT/jP7zj+Oz9n1P4U6f+u/sS9NeuZ46Tp/xn95Px2ftD+Fen/rv7PpHo12tvtrtPv7q9tKFv8AJ6sacexbalmO
XnPuPZ03Nlyy2vzvxn4dx9Dnjjx23c+r84/hBUqFn6T9QdtGKdWhRrVUvnuHF+9JM9cy0+HcZX6a9HtnQ0H0f6LbwpqEKVhCtU7m5yjvyb8W2zOV15unHh3WYz6vl1X0
1605t09IsFFvgnKbaXxPl3rs/Z+5nyrwenff2KPpr1tc9I0/9qf3k/H5+zX8KdP/AF39jfps1rHDSLD9qf3l/HZ+yX5U6ef99/Z9ioVY65spTralbwhC+sd6vS5xSnDi
uPdxPpceVuMtfiuq4seLlz48buS2Pw9bRjGrF7zdOM+D6xT+49UeCvoq0XT93K7X9sndWbGG706ypxk4qplJ/njupI/U+ztvb6BshY29Oko0rOxUmvFQ3pZ83k4ZZa3X
s4ePvymE+vk+Qz9NetL2dIsOPFetP7z5X47P2fup8qdPr89/ZU/TXruf/pOn/Gf3l/HZex/CvT/139jXps13v0rT/jP7x+Oz9ofwr0/9d/YP0166/wDurT/jP7yfjs/a
L/CnT/139mi29NupxkvlGiWk137lWUX9OSzr8vrHPP5T4r+Xkv6R6rSPTJs7duMNRtrqxk/zmlVgveuP0HbDrsL+aafN6j5W6rjm+PKZftXqtQ0/ZfbfSl29Kz1O0lwj
Vg8yg/CS4xZ7MOSZTeNfnufpeThy7OXHV+74L6Q/RVc7MRnqenyrXmjp5nJv8pb/AK+Ocf0l7zvjnt48sNPHbN6XbajtDpWnTjKcbm7pU5Rzzi5LK+GS2+TMnm/WG2Ws
/wCDOzF7qtGhTnK3UY0qTe7HLailw7uJ5Obk8PC5PrfDejnV9Tjw26lfH/4a9dT46Vp/xn954Px2ftH67+Fen/rv7H/DXrf+qbD9qf3k/HZ+y/wp0/8AXf2abD0x65d3
ttarSLFutVjTSUp54tLr4msetztk058vyv0+GGWXffKW/R9C9LFpbXPo81+F0k4wt3Ui3zU4tOLXjn6z6uN834XP0flW2taLXrb3uZ2jzVrjZUmvVbfvNsoys6a+d8Qi
Dtaf6XxBtB20fH4gR+Tx8fiDZfJ4+PxBsnQj4g2i6K8QIujHxAi6K8ShOivEgXZLxAOyj35KbDox8QbQdFdwNk6S8QpdmvEgXZIGx2aKIuCAXZoIW4go3EAtxeJAbiKE
4IA3EAuzQBuIA3EAbiAW4gDcQC3EAbgBuEC3ADdQC3eIBuhT4hBxAOIBxAOJQcSBZZQZZBLBQYAMAGADADwAYAeCAwA8FDSAMAGAHgB4AMAPdCDdAe74gG6uoBurqBJJ
dQHhdQHhdQDdXUB7q6gNRXUB7i6gPdXUBqK6gSwuoDUV1Aap5IGoLvZUTio9SKmkuqXuCGor5xRJRXX6CKkor5y+ARJRXzgLIxj876AJqnH530BU1CPzvoAmoLr9AE0o
93F+JBPGV7X0AG4ueQKa8eD9ZEqx1fRtbSu/SJoNLnGFx2r8oRcvsOeVdMJ5vtPptuHR2HlS77i6pQ9yzL7D5/W3XG/U/LXH3dbv2lv+z83yXFnx39FnoiFAAwgKEEMi
vQ7B2/yzbDRbbGVK7ptrwTz9h24Md8kj5/xTk8PpOTL7V+hvSpdfJdg9YnnDq040l/SkkfV6m64q/BfA+Pv6/jnt5/pH5aa4s+La/puPp5kRXS2ctvlmv6ZaYyq11Sg1
5yR045vKR5etzmHBnn7S/wCH7EnONGFSpLhGKcn5Life3p/JZLlZI/GWo13c31zcN57WrKefNtn5+3d2/r/Fh2YY4+0kZTLqaA9n6MNols9tTbVatTcs7j8hcdFGT4S9
zw/iejpuTw89/R8n410X4vpcsZ+aec/8f8vqfp62Xe0GxFa8tae/f6U3dUsLLlTx+Uj+zx/on238usei9GVq9O9HWztCa3XT0+nUl71v/aStYTd0/MGo1pXF7cXEudWr
Ob98m/tPgZXb+v8ADh2YzH2kZsmHYc8liWv19sjafIdlNGtsYdOzpJ+e6m/rPvcU1hI/k3X8nidVyZe9r84elW6d3t7rM85jCqqS8N2KX1pnyepu+Wv6F8D4+zoOOfbf
6149HnfXPPERL6P0Z6DrXstiZ1kuNzd1J+aSUfsZ9fo5rj39388+Zc+7q+32k/5fnX0uznrHpZ1ulB7zd5TtYY/RUYY+J7H5x+tNrJw0rYvVXDhGhYThHw9TdX1nHmy1
x5X7Pf8ADePxOr4sf/8AUfkpnwn9Y15kRVlClKtUhTjznJRXveDU82OTLtm6/WO1FxHRdhdUqrC+R6ZUS8408I/QYzUkfx7mz788svevw9TnLs4xXzUvoPRK8un1TSZy
r6Za1XznSi/oM1moq0ndX9rbLi61eFPHnJIlqyP0Zt/X+QbD63VhLdcbWVOL88RX1nl6i648q+z8I4/E63ix+8/Z+TZcz4df1PHyIjQKBEDCjIHY2c2g1TZ6/je6ZdSo
z/OjzhUXSUe9HTj5cuO7xeTq+h4erw7OWbn7z+z9K7E7W6dtjpE5xhCF1CO5dWsvW3c96zzi/wC5n2ODnnLjv6v5v8U+F8nQ8vbfPG+l/wDvq+W/4CS2e9NWz8rKm1ot
3VqXNBd1GUIScqfu4NeD8D078nyNar2PpyuOy2KhRzxr3lOOOqSlL7EeHrbrj1936f5Yw31nd7S/7Pzoz5D+hkUem9Hlp8s200ShjK+VQm/KPrfYduCb5MY+b8X5PD6P
ly+1/fyfbfThf/JPR1qEN7ErqrSoLxzNN/RE+7j6v5Tn6PzTaNy45O0rz2OrShle0vgbjCzc/SWPIIhKnB9+CiDpLGU8+QFbprr9AEHTXX6AIumuv0ARcF1+gCDprr9A
EXBdfoAi4Lr9AEd1dQE4LqUJwXUCLguoC3V1ATivAgTjHqAtzxKIuKATiuoEd1dQE4oAcV1AjurqAt1dQDHiAYXUAwgFhdQFhdQowAsALABgAwAsALABgAwAYIFgoMAG
ADCAMIBYAMEEihYAAGAAAAA0AwABhDAOADIBFDAAABgPAAAwHgAAeQGgJICQBgB4AfBdwEk35AGcgSQDSIJoCSCJoKmkBJICyMQJrAEk35EE4gTSAsSAe7wAz1+RmrHt
fQhbwrbe9q8Zt7OrNebcY/aznn6O3H6vZenr5VX03SLO2t69VSrTqS7Om5JYikuXmz5vWy2SSP2PyvcMOTkzysnlI+ILSdUf/d13/US+4+bcMvZ+0nU8X9c/WHLSdSgm
5afdJLm3Ql9xO3L2b8fi/qn6xhfAy6kVDSyRW2OlalKEZx0+7lGSTTVCTTXXka7MvZwvU8M8rlP1hfinVXy028/qJfca7MvZj8Vw/wBU/WPd+h7Q7/8Aw6sbi5sLmnRt
4VKkp1KUopPdaXFrqz09LhfFlsfG+P8AVcf4HLHHKW3U9fu+h+ne7VDZC2tk+NxeRXmoxb+vB6euuuOT7vhfK3F3dZc/bG/u/OrPlP38IivZeiq1+Vbe6NHGY06kqr/o
xb+vB6Omm+WPj/HOTs6Hk/tr9X6P2uuvkWzGrXecdnZ1WvPdaX1n1ubLtwt+z+e/D+PxOq48PfKf5fkGa4ryPhV/WpUSAAafEqV+ofRbrkdo9kaCuJKpcWq+TXClx3sL
g35x+pn2el5O/jn2fzP490X4bq7qfy5ec/3/AHd3aCVDSNk9RdCEaVK2sZxpxjyilDEUvoOvLlrC37PB0HH4nU8eHvZ/l+QpPJ8F/XESC+xoO5vLe2isurVjTS82kaxm
7px5suzG5e0r9nUYRp0Y0lwjTSivJcPsP0EfyHK7y37vx5tFcu91zUbtvPbXNSfxk2fAzu8rX9a6Xj8Phww9pJ+zlmXoSissFfqv0ZWystg9Eg1uuVHtX/Sk5fUz7fTT
XFi/l/xvk7+u5L99fo/J+zcv8IvS/Z1d5SV5rnb8+ce1c/qR6HyX6j9L932GwWpYeHXlTpL3zTf0I8nV3XFX3fl7j7+vwvtu/s/MUubPjv6VPREiu3sfa/LdqNItMZVW
8pJ+W8m/qOvDjvOR4fiXJ4fS8mftK++em+5+T+jXWoqWJXShbxf601n6Ez7+Pq/k2d8n5Zt9DrVqS+SYnXbW7F+rn3s6zycLdvoml2f4u0i2tK84VK1OLUpR5c84Xlkz
bujdsfR+Wbc6HQxvRV0qjXhFOX2Eq4zzfU/TXddjsJcU88bm4pU/p3n/AMp4usuuKx+l+W+Pu67HL2lv+z80s+O/o4IqynTnVlu04SnLpFZY0lsnnU5WtzBZlQqxS73B
ouqkzxvpVJGgAij0GxWv1tm9obTU6cpdnGW7Xgvz6T9pfb5pHXi5bx5TKPD8Q6HHq+DLiv19Ptfo/WcKdrc/J7lRhV3PylGpjOMxxleaZ92XyfyjPG42y/R8g/CDuVG1
0WzT4zqVarXkkl9Z8/rr+WP13ypx7y5c/tI+GHzX7cIix9F9CVr2+3NGrjKt7epV8njdX/Mevosd8r8/8y8vb0FnvZP93q/wjrnd0TQ7FP8AjrudVrwhDH1yPtYv5rm+
I2cVwOkcK61NcDcYSaKiDiBHBQm+qTAi1F8njzArlDqgK5RCIOIEWgquSAjgAwBFgRaKI4IE0AsFCwAuIC4dAFhALd94CcQE0BHACwAsBRgIQCwFIgWCgAQAAgAAAAEA
AMBAACAABASwAsEBgoAHggTKDiBJJgPD6EBhlD3WENRYD3X0IDDAN19ADD6FDwwDdfQgai+hQ8PoA1F9CCW6+hQbr6AG6+hA1B94ElDHcyh4fdEB7s33ANQl0Ae7LoyA
3ZdAGoS6AS3JdGBJQl0YDUZdAJqEugE1CXQCSjLoBNRfeBNRfdFhElGXemFTUX0Akoy6EFkYvoBYoy6ATin0ILN145BWS5jLD4Eqrtkdoq+ym0tvq8KLrU4p069JPDnT
lzSfXgmvFGMpt0xun6HsvSZsNc20K72htaDkuNO4bpTi+jTRz1XaZRd/CTsJvKP+FembzeEu35k0u3X2nunabN6tdKWOytKslx7914OfLdYWvX0OHidTx4+9n+X4+6Hw
a/rUnmCNLKFN1akacfanJRXveCybYzy7Zuv2J21noujKpd3ELezsqC7SpUliMIRill/A/Q4zU0/j/Lnc+S5e9tefl6TNgYvD2s0z+v8A7iue3T0Ha3Z3aGrWo6HrNrf1
KMVKpGjPe3U3hNgfL/wgbrMtEsuiq1n9EV9p83rr+WP2vypx6nLyf2j4ofOfsgB9O9BFq6+2Fa4a4W9nOWfGTUfvPb0U3ybfmfmjPt6ST3sfU/S/d/JfR/qSziVZ06K9
8ln6Ez29Xlrir8z8v8Xf8Qw+27+z8vyeWfFr+mSEFAQAfQfQ5tA9H2rp2dae7Z6ilQnl8FP8x/Hh7z19JyduevpXwPmDo/xHS3Kfmx85/b6vsnpYuvk+wWrvk6sYUV/S
mke/qrrir8h8B4+/r+P7bv6R+W5e0z41f06ehEHo/R9aq8220Og1lO7hNrwj632Hbgx3yYx834tyeH0XLl9r+/k/U+tXKs9H1C7bwqNtUqZ8otn2s7rG1/Mumw8Tmww9
7J+78bTbby3lvifAf1/yLgQCXNLoWMZyv19ot3pdlpFjZSv7NKhb06WHWh3RS6n3cMsZjJt/Kep4ubl5ss+2+dt9L7qra02OtriFza2+h0a8HmFSnCjGUX1TXFG+/H3e
f8Nzf0X9K8B6dtUtp7O2FnbXVGq6t3vyVOopYUYvnjxZ4utzlwkj9P8ALHT5Y9RnnlLNT/NfBW+J8yv3M9CIr3XoetPlW32mya4UFUrP3Qf2s9XSTfLHw/mDk7Ogznvq
fu9v+Erqjstj9MtYKLlcX6bT6Qg39bR9rH1fzPLzfnaw2muLSrCo7anNRecKTizo5ae40zVPx3GhGwhOpVrSVONFcZb7/N8zNNPt2w3o4nompWutahfupe04y/IUors4
OUce0+Laz4Iza6THXm5f4QFwqelaPZqXGpXnVa8Ixx/7j53X5akj9f8AKnHvk5M/aSfrXwfhk+Y/dEwPqfoFtVV2qu7mSyqFm8ecpJfVk93RT/Ut+z8x80cmukxx98v8
Sv0K402sbqfgz6un4DdeG249HukbQ2VaraWlG01VRcqValFQU5fNmlwafXmjzc3TY5zy8q+38M+N8/S5yZ5XLD6y/wCz8x16U6NWdKpFxqQk4yi+aaeGj418n9JxymU3
PqhkjRp8SxMvOP1V6Lr+V/sJpFacnKpTpOjJv9BuK+hI+102XdxSv5h8c4fC6/kxn1u/183yr0/XXabTWFqnlUbNS8nKT+xI8XXX+eT7P1Hyrx66bPL3y/xI+UnhfqAF
fY/wfrfOpazeY/i6FOkn+tJv/wBp9DoZ/Na/H/NXJ/pceHvbf0n/ALc38Ie6dXaPRrJPKo2c6jXRznj6on1sX4PN82s4S4cDpHKupTg8LgaYScX0AhKL6FRU4voBFxl0
Ai4y+ayhYkuSZBCWXzj8CiDi8cAIOMugEHF9AI7r6AJxfQCDjLoBHdfQA3H0Ai4voBFxfQBbr6AJxfQCLi+gC3X0KBp9AFiQCw+9ADj4NEEXFgR3ZdADdfQoW6+hAt19
Apbr6ADi+gEd19ADdYCafQBNMAwwDDAWGUGADDAMMgTTAXEoOIC9xAwFkoMkBxAYAAABQwGQNAMoAGAEQFDIoAAGVEkmQHBd4DTAeSg8yAAlkoaIHkB5AYBkB5AeQGmB
NATi/cBNNLxAlve4IaCppgSUgJpgNMCcZEE1ICalnkBJSxzefACupLeWO4mlYLiGcksalcm6pvjzMWNylszp87/a3Q7JptVr+hB+W+m/oTM1uV+uPSpdK32D1mTeHVhG
lH+lNL6jydVdcVfc+Bcff1/H9t39I/LUvaeD4j+nzzhFHZ2Ptvlm1Oj2uMqpeUk/LeWTpxTecjx/EM/D6Xkz9pf8PvnpzvFZ+jDXGpYncKnbx/p1Ip/Rk+9H8ktfj5Qc
nltl0xt+iPwYbBQs9otQa4yqUaEX5Jyf/MhWsfNz/Ttd9ttnTt0/Vt7SnHHRtuX1NHyOtu+TX2f0T5Y4+3ou73yv/D5meN+kBB9u/B7tMfju+a/mqMfpk/sPpdBj+avx
fzZy+XFx/wB66np8unT2bsLRPHb3mWuqjF/a0b62/wAkn3eX5Ww31GeftP8ANfn0+U/fgIAACVOUoTjOMnGUXlNc0+pZWcsdzT7JtvtStd9FGl3LmvlNa6hRuV+nCLb+
Pqv3nv5+Xv4JX5L4Z8PvS/Fc8deUls/tf/tPjL5ngfrp6AivoXoUtflG3VvVxlW1CrV+jdX/ADHr6Ob5I/PfMnJ29FlPeyPtXpRufkuwWs1U8OdBUl/Sko/U2fQ6m64q
/H/BOPv6/jn33+kflSftHxa/p+PoiFGSA+BUs2Bs0AsgCgg+segK27TaHUbtrhQtN1ecpL7Ez3dDN52vyvzTydvT44e+X+I5f4VF23qOzmnJ8IUa1dr9aSiv+Vn1pH4G
vgkOjOkc31H8Hq1+Uek2yeXuULetWlHubUcLPvkTNrF9+9Le1Op7MaTp9TSa8KVxcV5RlKVNT9VRzyfi0eDq+bLjxna/R/L/AMO4es5c5zTck/t5vgu021Os7TVLepq9
zGtK3i4092nGGE3x5eR8zk5c+T8z910Xw/g6OWcM1v187f8ALhHN7QQdzZrajWNmqlxU0i4hRnXjGNRypRnlJ5XNcOZ14+XPj/LXi6z4fwdXJOab197H0n0b7d7Wa9td
Z6dfX1KraTjUlVj8nhF4UW+DSzzwezp+o5M85LX5v4x8I6Ppuly5MMdWa1533fc232ee8+i/FfV+UfSXQp2+3WuUqaSj8pc8LrJKT+ls+J1E1yZP6j8FzufRcVvt/jye
UaOL6pkH6W9Cmf8AAKhn/SK2P2j7HR/9J/OPmT/+/f7R8i9MF18p281JJ5VBU6K90Fn6Wzw9Vlvlr9X8A4+zoeP77v7vDHlfcAH3/wBANq6ezupXjX8ddKCfhGK+8+r0
M/ktfg/mvk31GGE+k/zXy/01Xfyn0lahTTzG2o0aC8MR3n/zH0sfR+Pz9Xl7VrCNxyrfGXA1GQ5FEHIIqlIog5ALeAg5AQcgI5Ae+15AJyi+awUQeXywwINkCyURZAgI
sBMBAIBZAWQFkoMkCbAiwEFGQDe6pMoXB81jyIgwu5hSwwIvIAAAJgRAAAAKEAEAAgAAATAWQGUADACBgAAUMBgMAAAGAANcSB464QBw658ioMroQPeYCyVRkIkiCRQA
GQGmAwHkBpkDyUGSB5Aay+QEuHe/gA1LHLgBLeAkmUTTAakQS3gJKQElICW8ETjJsCW8o83x6BR2rfDkvABqoAb2SCuayTSsNeCwSxqV6T0RWKvPSXoccZVGc67/AKEG
/rwc8vR0w9X2n063XyfY+2tlzuLuKflGLf14Pndddccn3frPlXi7uryy9sb+787PmfKr+gz0HAivbeiK0+VbfaVlerRc6z/owePpwerpJvlj4fx/l7Oh5PvqfrXu/wAJ
a8VLYvT7NPjc6hFvxUISl9eD7UfzLJ+Y3UUUaYfqf8HK3dL0eSuXHjd39aafVR3YL/lZnJ0wfMfSldfK9vNZqZyoVlSXlGKj9h8Pqbvktf1D4Hh4fQ8eP23+ryJ532Ag
P0Z6C7Tsdjqly1xubucvdFKK+pn1uimuPb+efM/JvrJh7Sfv5vMfhCXedQ0ayX5lKpVf9JpL/lZy6++eMfS+U+P/AE+XP7yf/fq+NM+c/YgI6VDSbmvol3q9PjRta1Ol
VWOW+nh+WVj3o3MLcbl7PPepwx5seG+tls/8OazD0AC/5XcfIvkPaP5N2va7ndv4xn4Gu660x4ePf3689aZzLYA+x/g+Wm/qmsXjX8XQhST/AFpZf/KfQ6CfzWvyPzZy
64uPD3tv6T/29Z6dLpUdioW+eNxdwhjqknL7Dv1t1x6+75Xyxx93W93tL/w/OJ8l/QyIAICgIpgAAVL6Pu34PtqoaZrV61xqVqdJP9WLf/uPp9Dj5Wvw/wA18m+Tjw9p
a+UfhJXzufSQrfezG0saVPHRvMn9aPo4vx+T5RyNsPuP4Lln2u0euag4/wARZwpJ9HOeX9ETFrpI9R+EBcOepaPZ5f5O3nVa/Wlj/wBp8rrsvOR+5+VeP/S5M/eyfpHx
4+e/XgAAawFfUfQLbqrtZd3DjwoWcsPo5Sivqye3ocf9S1+X+aeTXS44z63/ABt+hWm0kfWfgPq/JG3N5G/2v1q7i8wnd1FF9UnhfQj4XNl3Z5X7v6t8M4bxdLx43+mP
PnF9A48WWJldR+pfRRaO02C0eEliVWMqzX60m19GD7XSzXFH8y+O8nidfyX28v0j857Y3fy7anWLrOVUu6rT8N5pfQj5HLlvO37v6F8P4vD6Xjx9sY4pzew48WWJl6P0
16Hbb5NsDp7aw7ipUqv3yaX0JH2OkmuKP5r8w8nf12X2kn7PzjtteK/252gu4vMJ39VRfhF7q+o98fncr5s1u8JG451sjLgaYJzArcyiDkBFyAi5ARcgI7wEXIBNgRbA
WSh7778PzIFmD6oAcXzWGvAorbATZBFsoWSBZAQCbAWQDICyAFUiBBCKpEAELOAo3n//AKAZXevgAer1wULGeTT8iBNNc0AihEAUAAAgAgRQECAAGAABQwAgAABgSACh
4YBw+cggzHo2RT3vBFC3n1AAHkAAZAAMIYEkUAAQADRQ0A8kDWXyQEuC5y+BQby7l8QDebAMkEsgNMCaYD3gGpANSAakBOLzwQE8pe0+PRAHavkuC8AGpAG8A1ICSkA9
4DLcS4MzWo+ifg92irbbXt5JZVrYyw+jnNL6kzlm7cfq9T+EDd5lotknyjVrNebUV9TPk9ffyx+7+U8NTl5P7T/d8UPnP2QA+qegS17Xae+umuFCzaT6OUkvqTPd0M3n
b9n5b5pz7emxx97/AIjP+FLeYuNmtPi+UK9eS83GK+0+vi/n2T4An1NsP2l6GrP5D6M9nKco7rnbdvL+nJy+0531dY/N+u3Xy3WdQu857e4qVM+cmz89nd5Wv6/0vH4f
Fhh7ST9mAw9Bx4ssTK6j9Vei+1+SbA6NTxiU6Lqv+lJy+0+1001xR/MPjfJ39fyX76/R8Z9N918o23qUt7Kt7alTx0bTk/rPB1l3yf2frvlrDs6KX+q2/wCz50eN+iC5
gfePQ7odvqOwGsW15DNHULiVJvHJKKSfubyfU6TCZcVl+r8N8wdXlxdfx5YXzwm/3fFdZ0+vpWqXen3UcV7erKnNeKfP38/efOzxuNsr9n0/Njz8ePJh6WbYTDsQDAO8
H0foL0A2rpbO6hdtY7e73U+qjFfaz6vQzWNr8D808ndz4Ye0/wA1zvwg7rdo6JZJ+1OrWkvJKK+tmeuv5Y7/ACrx7vLyf2j4cfMftwB6fYnZG82uvriztLijQdGl2sp1
U2sZSxwO3Dw3ltkr53xL4nx9BxzPOW7uvJ7R+hPWV/3xYfsz+49P4DL3fF/izg//ADv7H/Apq+OOs2P7E/uH4DL3X+LOD/8AO/s+Za5p8tJ1a802daFWVtVlSc4cpNd6
yePPDsyuL9H03UTqOLHlk1ubYDDuEUs8n6T9C1o6OwlGrjDubirU81ndX1H1+jn+nt/OPmTk7utuPtJP935m9MN38u9J+0dZPKhddiv6EVH7D24+r87fR49LhyOjD7l+
DFrdhZ6xrGiXFSFO5v4U6lvvPHaOGVKK8cSzjwZzybxfc9pth9A2kv6d9qdO4lXjTVJdnWcVupt8veebl6fDku8n1ui+LdT0eFw4ta3vzj8xbRUbW11zULayi421K4qU
6SlLee6pNLj38j42eMmVk9H9L6XPLPgwyz9bJa5ph6DXPiFfetjfRjs1qOzOl3+oULmV1c0FVqONdxXHisLywfU4ek48sJa/CfEfj/V8PU58fHZqXXo97stsfoey87me
k0KkJ3CiqkqlVzbSzhceXM9XHwYcf5Xwut+J9R1kk5r6fbSvb7aKjs3s3dXzqJXMoulbQ75VGuHw5vyM8/LOPC1v4T0OXWdTjx/T1v8Ab/2/JtSTlNyk22+Lb72fDf1S
TSIGnT7Stf31vZW8d6tcVI0oLxk8I1jjbdRy5+THjwueXpJt+vezpaNoSjS4UbG1xHyhD+4+9qYY+X0fyfuvUc+765X/ADX48rTdSbqSeZSbk34vifAr+tYTU1ECNmuo
L5x+tdlqUdJ2K0uNTCVtYRnLwe5vM+9w46wkfyb4ly+J1XJl96/GdK4lcXFW5b9atOVR+O82/tPXHyq61CSaXczcc60uTXBmmUXMCDkBFy8QIOQC3gE5ARyAsgRbAWQD
JQmyBNgLLQD7TPtJS8wFmL5PD8QE4yXHHDqgIgJgJlESACgIRQBSIEAgAoQAAiBADKI94EstcmwDezzSYB6viiAwnyaAWH0AQCYCAAABAADzHxKDK8QDK8QHw8QDh4gN
Y6MgOHeBLeguoBvx+aUDmvEgjleIBleIDTj4gNbvRgPMfEAzHxAMx8QHmPRgPMejAMx6MoeY9GQPej0YQKUekiqkpR6SIDMejAMx6SAacekgifqL2m0ULfgnyb8yBuon
87AEd6H6RQ96HSRA96PSQD3ofpBTUofpBElKn+kA9+HSRQ96HSRAb0P0gJKUOkgG3Bc8+QD7WPJbyXgAb8P0gGqkP0gJdpD9IB9pDpIBqpT6SAfaU+kgCVWHSRBkr1YY
5SJWo+1/g2W0ZUtor/D4zo0FnwTk/rRxzd+OOX6dbvttsoW6fq29pThjo23J/Wj43W5f6mvs/o/yxx9vRd3vlf8Ah8yPE/SBBX3L8H21UbPXL1r26lKkn5Jt/Wj6fQY+
WVfh/mzl3lxYfa18z/CTvvlXpDpWyfCzsKUMdHJym/rR9PF+MyfJGsxaWctYRpl+6mloewyprEfkGlqK8HGlj6zz8l1ja93R8fic2GHvZ/l+S5fYfAf12UiKlFNvCXF8
EWJl6P2PoVsrPR7C0SwqNtTp48oo+/hNYyP5F1XJ4nNnn723935e9I918r231ysnlfKpQT8I4j9h8bqMt8mT+l/COLw+i4p9t/r5vLnB9M48ZIsTL0fqL0RW3yXYLSk1
xrKdZ/0pvH1H2elmuKP5n8f5O/rs/tqfs+fenjZ90L+12hoQW5crsK+FyqJeq/euHuPL1vHq9/u+/wDK/W9/Hl02V/L5z+31/d8dZ89+uIoCBriUfqD0QWnyXYDTZNYl
WdSs/fN4+hI+z0k1xR/NPmDk7+vzntqfs+Zenu77bau1tlyoWcc+cpSf3Hj67L/Uk+z9J8rcWukyy98v8R8sPE/ThEV9v/B+td2nrd/40qK+mT+w+l0M/NX4n5r5P+nx
/wB60elP0wVtido6ejW+j0b3/FoV51J15QcXJv1cJPuSfvPovxr6NsnrNbXNmNK1q6to2tS8t43EqUZOShnjjL58Asfk7V7l3mp3l03l1q9Sp8ZNn5/O7tr+vdNx+Hx4
4e0kYjL0JR5kL5P1l6P6CsdiNDpSxHFrGpLw3vWf1n3enx1x4x/Kvi/J4nW8uX3/AMeT8U61d/jHXdTv5+s7m7q1c9czbPXi+Rkz7kccjbG1UlKjJVqLcKkPWjKLw4tc
mmuTMZRrGv3Lss7i02L0qpe16tavS06nUrVast6UpdnvNtvmccrrzenix7spj7vyddVHWrTqyeXOTk/e8n5+3b+v8ePb5K0zOnU013gfpHSPSVsVZaTZWf4yqJ0KEKbS
tp90Uuh9fDquKYybfzrqPgPX8nLln2+tt9Z7s+r+mPZu2oy/F1G7va2PVW52UM+LfH6CZdbhPy+bfT/LHVZZf6tmM/Wvie1e1OqbUah8s1GosRyqVGHCFKPRL63zZ87l
5cuS7yftOg6Dh6Lj8Pin979b/dwc5OT3bCA+u+g7Zed3qUtpLqm/k1o3C3yvbqtYb8op/F+B7+i4t3vv0fk/mb4hMOL8NjfPL1/t/wC31b0i3XyLYfXKqe6/ksoLzliP
2nt6i64sn5f4Rx+J1vFPv/jzfkxs+JX9TgIrTp9B3N5Qt4+1VqRgve0vtNYzd0xy59mNy9pX6j9Il3HSfR/r9aPBUdPqU4eDcdxfWfocZ9H8c5Mrlblfq/G9ruxUY4fB
JHePNXWozgksqXxNxitCqxSxhtdMlZCnCXLOemQIucVwal8QIOcOkviBFyh0l8QFvQ6S+IC3odJfEA3odJfECLlDpIoW9HpIBb0ejIFvR6MBb0ejAN6PRlCco9GAnKPR
kEd+PRhTVRLlvIBurF84vPUoMwfJvPiQRlhc0wiLcejAWY9GFPej0YC3o9GAt6PRgGY+JQZj4gLMejIDMejKFmPRgLMfEAyvEBNx6MBZXiQLK8QDK6MoMx6MgWY9GA/V
8QGml1KDeXiwE3HowF6vUAwl1II5XiAPHiUHDoQJFAkA8LqAcCBbwBlsAAAAoCAyAwGgGAZAYAAAMoCBlAQAEkBNRfN4XmAm4rrJgRc5eXkUCZA8lBkiAqnkiDJVPIDy
yIeShpkEkwJrhxk8eAC7TuisIBZAMgGQHkB5KGpED3gDeAJSAx158GYrcfpP8HW17HYOvcuOJXV9Vkn1UVGK+pnHP1ejj9Hy70oXXyvbvWqucqNfsl/Rio/YfC6m75cq
/qfwTDs6Hjx+2/183kjzvrGgP0h6EbTsdiI1scbq6qVPcsRX1H1+in+nt/O/mbPfW9vtJP8Ad+b/AEw3ny70m7R1d7KhddgvBQjGP1pnvxfmMq4GzFm9Q2k0ewSz8ova
NPHg5rP0ZNVJ6v2R6UrhWmwetzzhzpqkv6UlH7TxdVdcVfc+Bcff1/HPvv8ASPyvJ5Z8V/T4RFdLZ61+W65ptolntrmnDHnJG+Obykebq+Tw+HPP2lv7P2JVlGEXN8Ix
y35I+/X8jxm7p+NNUru61G7uW8utWnPPnJs/P53dtf2Dp8ezjxw9pIyGXU48wP13oEaWi7IWHap7lpYRlNLn6sN5/aff4prCT7P5J1/J4nU8mXvb/ll1q3sNtti5xs5q
pQ1C2jXtanSWN6D8OPB+8nNx9+Fxa+HdXel6nDmnpL5/2+r8pXFKdCtOjVg4VIScZRfOLTw0fCs0/rGGUyx7p6VSRTAa7/IsZy9H6+2PtfkeymkWmMOnZ0k147qb+s+7
wzXHJ9n8o+IcnidXyZ+9r86+lq6+Vbe6u8+rSlCiv6MEvryfK6q75a/f/AePs6Hj++7+teKPM+0aCv0V6CrVUNjK1w1xuLycvNRUY/Yz63QzXHt/PPmjk7usmPtJ/wAv
zx6dr13/AKUtdUeKoyp28Uv0YJfW2e1+afrGrCOibCOkvV+Q6VuLwcaWF9JjkusbXq6Pj8Tnww97P8vyXg+Bt/XdQiCyhB1Kkacfam91eb4FiZ+U2/WWu1Vouxl/W9mN
jps8eG7SaP0GE1JH8e58+/O5e9r8L2ye7HPPCPRjHkyrZjgbYFvbyury2tYLMq9WFJL9aSX2mK1PV+29sq60vYnV5wwuxsZU4+e7ur6zyc+WuPKvrfC+LxOs4sfvH5Kl
zwfCf1cgABkCKAIAr1ewex1/tZqao0VKlZUmnc3OOEF0XWT7kduHhy5ctT0fM+J/E+LoeLuy88r6T3/9P05Y0tK0Cy0/S6Dp29FtW9tTzxnLDePF4Tb97PtY4zGaj+Zc
/Pnz8l5OS7teO9N9z2Ow1emn/lNxSp+eG5f+083WXXG+18t8fd1svtLf9v8Ad+anzZ8i+r+i4+gI1HpvR3afLdtdEoNZj8qjN+UfW+w7dPN8mMfP+Lcnh9Fy5fa/v5Ps
f4QV58l9Gt5SUsSu7ijQ81v7z+iJ97D1fyfP0fli2O0cK6NNm451ZvFQt4CSqd0uIA+KzF5RRDICbIFkAyAsgLICbAWQFkoMgLICbIpALIBkAyAKTXJ4AaknzXwKDCfs
tMCL4cGsAIgAEUGSAyAslBkBEAUIgAABMBAGShgACACBAMAyAsroAcOoBllCAYCACAAYAAFAAEAgGAygIAB5AMgMoZAASUZPjjh4gHqrm8+QB2jXCKS8gI5zzKABgADA
MgPJAZAYAEPJQ8hUkmlmTwvEgTqY9nh4lQt4B5Ip5CDJQ0yB5AN4oe8AZQDyQRnILGOvJLnzMVqP116G7T5F6Ndnoz4Odu68v6cnL6mcMvV6cZ5Pzhrtx8r1nULne3u2
uak89cybPz+d3bX9f6bj8Pjxw9pP8OfhnPb0aSiuPEqW6fq/0dW6sdhtDpSxH/FlVl4b2Zfafb6ea4sY/lvxnk8TruXL76/TyfifW72Woa5qV/J5lc3VWs3+tNv7T1x8
ivWeha1V96T9n6bWY0q0q78NyEpfXgZUxj9EenO67LYqFHPG4vKccdUlKX2I+f1t/wBPX3fqPljDfWd3tjf+H50wfI2/ohPgEev9Flt8r280aDjlQrOq/wCjFv68Ho6a
b5ZHyPjmfZ0PJl9tfrX6U2lufkezWq3f51K0qzXnus+vyXWFr+ddFx+J1PHh72f5fj193gfBr+t4zWxky0vsKDub23oJZ7SrCGPNpG8ZvycebLsxuXtK/UPpJufxZ6PN
oqtOW66WnVIRfRuO6vrP0Efx/O23fu+efg07SxvdnrrZevWzcabPtaCk+MqMnxx+rLP7SKzHG9NugLTNpFqdCGLbUY77aXBVVwkvfwfvZ8jrOPtz3Pq/ofy31vjdN4WV
88P8fT/h8yPG/SADTp9tO6vba2im3VqwppebSLj53TnzZdnHll7S1+zaUI0owpxWIxSil4LgfoZ5P49lblba/IO1lz8t2m1e6zwq3dWS8t5nweXLedv3f1roOLw+m48f
aT/DjnN60oL1kIX0fqX0XWvyTYTRabjh1Kbqy/pSb+rB9vpZrij+YfHeTv6/kvtdfpH5Ob/wi9Lbz68b/XfPMHW+5HofGfrL0oXCtdg9bqZxv0lSjj9KSR5+quuKvsfA
+O59dxye+/0j8szWJHxa/p+MsiJFdvZCzd5tPpFtjKqXdJNeG8m/qOnFO7OT7vL1/J4XTcmftjf8Pv8A6b71WXow2glvbsq1KNCPjvzivqyfoJ6v5Db5PxzTis8DtHC1
e1wNMu96O7T5d6Qdm7VxzGV/SlJeEXvP6jGbph6v0/6ZLv5PsFeR77mrSpL9ref/ACnz+suuKv0ny7x9/XY32lr80SabZ8av6Rj6IhdDBU0MA0eGBdZ2d3fV429lbVbi
tLgoUoOTfuRccbbqOfJy4cePdndT7vqeyHog1G8lTuto6jsbbg/k8GnWn4N8o/Sz28XRZZeefk/M/EPmbi45cOmndff6f+31fV9X2W9HmzkalzOlYWFJNUqMOM6sukVz
lJ9fiz6WGGOE1i/FdR1HJ1HJeTlu7Xx30bbX6n6Q/TJDVLuLo6fptnXnaWieY0VLEMt983vPL93I04PUfhA3ajpujWSb9etUqtfqxS/9x8/r7/LI/X/KfH/q8mftJP1f
Cms8j5m37gsNAkfRfQjbdvtxRrbuVb29Wp5cFFf8x7Ojx3y7fnvmTk7ehynvZP8Ad3/wnLxx0LQbBP8AjrydZrwhDH1zPtYP5tn6Pz7b8DrHGtsHwNsJ7wQsgLeAaljk
wJb6ftcH1QCllcea6oojkilkAzwCDIEWwE2AsgLIBkKMgLICKDICAMgGSBZAkptcM5XRgPMXzWCgxnlx8gIsBd5AFCYCAMgJsgMgGShZACAARQwAAARAFAAAJkAAgGAA
AAAAMAAMgBQABAAMAyAFDIGA0m+SYDwl7UvcgDfS9mPvYEZSk+eQAoQDRAyh5IDJQZAMgMBkAAyhpN8eS6sglvxj7PF9WEQcsvLfEKRQ0RDyFGQHkB5AMgADyEGQpgQq
TUeC4sDBXllPxM1uP2D6JNZstf8AR9pKoVIudtbRtLmnF4dKcVutPplYa8zz5R6cMtecZ/4Itjs5dO8/tL+48n4Piff/AIl673n6H/BLsZy7O8/tLJ+C4l/iXrvefoi/
RDsdnKhe+Xyn+4fg+NP4l637fo6O32v6ZsVsVc15SjTcLd21lQzxqz3d2MV1xzb7kj144yeUfC5eXLkyuefrfN+J1T4LL4459Ttp59vc+iDW7HZvb/TNQ1CcadpNTt6t
SXKmpxwpPwTxnwyTKeS43zfrXaPZrRtqbK3t9SVSpSpT7WnKlVceLWM5XNYPLy8WPJNZPpdF8Q5ujyuXFfXy85t5mXol2NX8ne/2l/ccfwXE+n/E3X+8/Ql6Itjn/J3v
9pf3D8FxH8S9d9v0dfZ30f7NbO6lHUtPpV/lMYuEZVKzkllYfA6cfTYYZd0eXq/jXVdXxeFyWa+0d++oabrenXunVakK1vU3qFdUqnGL74trk10OuWEylxr5/Bz58HJj
y4es848XL0R7HP8Ak73P/mX9x5vwXE+1/EvXX6z9Ff8ABFsdnjC9X/7P9w/B8Z/EvXfb9Gqx9FuyNld0LulSupTo1I1Iqdw3FtPKyu/iXHpOPG7Y5fmLreTC4Wzz8vR5
X8I3aqz03ZCrs7TqRlqWqOKdJPjToqW85vplpJdePQ9Uj4Vr87+jjaepsntjp2tScvk8J9ncxj+fRlwmvHr5ouk2/Zms6RoO2ejW0bhq5sZuNehWoVMZ4cHGS7mmcuTi
x5JrJ7ej67m6TPv4r5+jzi9EWx/81ef2l/ccfwfG+n/EvW/b9E16ItjV/J3v9pZPwXEfxL13vP0aLD0YbJ6ffW97QpXUqtCpGpBTuG47yeVld/EuPR8WN2xzfMPW8uFw
tmrNej2kbq0q3NSzVxSdzTgp1KKmt+MXnDceaTw+J6nw5Xgq3ol2QqVZ1XTvPXk5NK5eOPuPLej46+9j8x9bjNTX6FH0S7Gd9K9/tLJ+C4mv4l6/3n6J/wAEmxvNUrz+
0sfguI/ibrvefo6u1+u6RsHsbUuZONOnbUOwsqLl61Wpu4hFderfRNnqxxkkkfD5ubLlzy5M7527r8bbF6pT0La/R9buk50rS7hWqpcXu59Zr3Ns6XFwmT9s6rpuj7W6
FG3r1flGnXO5Vp1KFXCmlxi013HHk48eSduT2dJ1nL0nLOXi9Xl16JNju+nev/8AZf3Hn/BcT6/8S9f9v0S/gj2N/mrz+0sfguI/iXrvefo26P6Ntl9G1O31Kzp3LuLe
W/T7Su5RTxzwaw6Xjwy7o49R8e6zqOK8Wdmr6+T51+ErtPZw0i12UoVY1L2vWhcXEE8ujTjlxz0cm+XRHrxj4eVfnWimjrHGr3yNMvR+jnWLXQdutE1a9ajbUbjFWb/M
jKLi5e7eyYym43jdV+vtf0DSNqtLo2mouVS231Wpyo1d3PDg01zWGeXk4seSayfT6LruXo87ycXrZp5f+CLY/P8AFXv9pf3HD8Hxvp/xL132/Q16I9jf5u9/tL+4fguJ
f4l673n6B+iPY3+bvf7S/uH4LiP4m673n6EvRFsbnjTvX4fKX9w/BcR/EvXfb9HRs/RnsVatOOkRrNd9arOf0ZwanScU+jhn8wdfn5eJr+0kdC91XZDY+2aubzStJpJe
xvQpt/0VxfwO+OGOP5Y+Zy9Ry813yZW373b5Vth+EDpdvTqW2ydjO9r4aV1dRdOjHxUfal78HSYuFyfnnaTXNa2m1Kepa3qFW7uZcE58IwXzYxXCK8EXtZ7n0T8HfXrD
QtuJ22oVI0qepW7toVZvCjU3lKKb7s4a88EsWV+ldqdjNE2pqW1XVYV3O3jKMOzquHBtN5XuOHJw48n5n0ui+J8/Ryzi15+8efXok2Oi+NO9/tL+44/g+J9D+JOu95+i
z+CTY1r+LvP7Sx+C4j+Jev8Aefo7GzWxGgbMXdW70ulX7erT7NupVc/VznCXuR04+nw47vF4ut+L9T1mEw5bNS78pp+ffT/tPZ65tdb6dYVY1qGlUpUp1IvMXVk8ySff
jCXnk9eE0+RnXzaijrHGtMWaZNsIWQoyAZCDIU4zafBgSzGXLg/oAg8rmgFkIMgLIUmyiOQFkgMgGSgyAZIFkAyAZAWQEUBA8gCYEt98nx8wDMX4MBNPz8gIgIAKEQIA
AChZAeSAAAAoAABZIDIAAZAChEAAAAUAMIMhQEBQEUBAAwABlAQSUe9tIA3orks+YClOT4Z4dAI5AaKDJAwD3gGQDIDyUDYCyQPIDTAlkCUU5eXUobcY8vWf0EEJSb5s
oWWQGQDIDTAeQFkAUgHkB5AeQDIDT8gFOp3R+IFEnkKz1EZqxo0jW9Z0G6d3o2pXNjXaw50J7u8ujXJrzMWbdJdPQ/wq+kTl/hTdf1dP90z2tdyP8KfpE/2qu/2Kf7o7
TuP+FT0icv8ACm7/AGKf7o7TueZ1fVtX127+WazqV1fXGMKdeo5bq6JckvIsjNy2yqJtkpwyTS7eg0fbnbLQrSNlpW0d9b2sfZpbynGPkpJ4XkZuLUyb36VPSL/tVd/s
U/3TPavcP4VvSL/tTd/sU/3R2r3M156S/SBeUJ29faq/7Oaw1Tcaba84pMdp3OJoO0e0Oz9zUudF1i7sqtV5qOlU4VH1knlN+LHadz0n8K/pFx//ACi6/q6f7o7TuJ+l
b0jP/wAU3a/9On+6O07in6UfSJOLi9q71J8Huxgn8VEdp3PI3de6vripd3txVubio8zq1pucpPxbNaZ2pdLI0m3e0Da3arZyjK30TXryzoSeXShPMM9VF5S9xLi13Oyv
Sr6RFz2pu3/Qp/ujth3FL0q+kV8tqrtf0Kf7pO07kJ+lH0iTg4S2rvUnwzFQi/iojtXueatdZ1u01Z6xa6te0tSbzK6jWl2kvOXf5Mdqdz08fSp6RVw/wqu35wp/ujtX
uSfpU9In+1N3+xT/AHS9sTuqP8KnpF/2qvP2Kf7o7Tueb1rWNZ166V3rOp3V9XSwpV6jlurolyXuLMUuTBuMuk272h7X7V7PUHb6Jr17Z0G89lCeYZ6qLyl7jNxWZOqv
Sp6RVz2qvP2Kf7pO1e436VfSI/8AxTdr+hT/AHS9sO5XV9J3pDrU5U57V327JYe7uRfxUcodp3PKzqVritOvcVZ1q1SW9OpUk5Sk+rb4tm5GLV1OJqRmrWuBWWeojNaj
t6JtttfoFsrTSNob22tl7NFSU4R8lJPHuMWOkydF+lb0i/7UXX7FP90z2r3Iv0rekX/am6/q6f7o7V7gvSt6Ru/am6/Yp/ujR3FL0qekWSx/hVeLyhTX/tHadzlajtrt
nqUXG92n1WrB84/KZRT90cDtO559xnObnOTlN85SeW/eXtZuScaeDWk2s3C6TaM6eSWLK9Tp3pE270y2haWe1F/GhBYjCclU3V0TkmzPa13NT9KnpEf/AIpu1/Qp/ujt
h3F/Cp6RVy2qu35wp/uk7V7me/8ASLt1qdtO0vdp7+dCaxKEJKnvLo3FJ4LIlyecpcO43GK3UpcDcc6vUuBUPeAW8ELeCjIC3gDeYC3gJKbXB8UBLCazF+4COWAslCbI
I5AWQDIBkoeSBZAMgLJQNgGQABZIDIBkAyAgGm1yeAHv/OWQHiL5P4gRaa5lCAWSBABVAQECyFPIBkAyEIoAAgAoKgAMkUggCmEIBgAAAAAAAwBASUWwD1V358gDffJc
AI5AAAAAYDKAAIABlCIAoAGBKKbfBZIJNxjze8+i5ARc3L7gFkAyUGSBgIAyUPIBkAyQPIDyAZKGiCEp54LkBFsBZArkskVTKBNNbVuCJpdjsxo2FAaNpqBdJtYo8Cps
pRIbVyh4E0u0HTGl2XZ+BNLsuzGk2OzGl2OzGjZ9mNJs1T8C6NpKCGjaW54F0mycPAmjaHZjS7HZroNGx2Y0bHZjRsdmNGx2Y0bNU0NG0lBDRs9xF0m0XAmjaPZ+A0ux
2ZNG0lTRdG1kIF0m1sVgrJtFFU4kVVKBnTW0HTJo2OzGl2OzGk2fZjRsKn4F0bTVMaNpqBdM7S3C6NouBNLtXKmTS7RdMmjY7MaXaSpouk2sjAuktXR4FZWqbKiW8A8l
BkgMgGQFkoMkBkBpgS397hL4gDi0srigIsoiQIAAYCyAFAAgAgQDAAEAFAAiAAAAoe81yZAbyfNfABYzyeQDACYAAgEABQAwAACEFAQgGAYAYCAAAAAAGAAAU0mwh4S5
v3IA30vZWPMBOTfNgIBAADAYAUMgAoCAAKAgYAALjyAlhL2n7kAObaxyXRARAZQEAAABQZIABgAAAwAofJcSCEpZ8gI5AAAoMEEXEKW4Q2TiU2N0ge6AyhYAHEgW6DZb
g0BwGjY3BoG4F2N0aTY3RpdnulQ8AG6QLdBstxDQN0GxuoKN0aNjdCHugG6DYwAt1AG6gbPdQBugSSKGAAJoCO6QLdBsbiC7G4NJs9waNnugPdKbGAHgBYBst0aNluk0
bG6NLsboRNIoMYCGA0wpqQRLJQZAM8AEAEDyAZAAHGTT4MCWYy8GURkmiCIAUACAAAgAEAAGSgAQAAECKAAIAoGQIBhTUnyfFeIQ/VfgwE0AmBEKAAACAAAApMAAAJBA
AAAUggCgBoCW71eAhZiuSyAnJvv4AIAAAABhSCDIU8gMACAACgIAGALiBLCXtMAcu5cAIgMAKAgAGAmUBAAGQHkAAYAAcuYEW2+YCAQAAAAUAAQgAKAGAAIBgACCAKAA
ACAACgACAKYCAAAAAAABAADAQDQDAQAAwAAAAgAAAKAAqAigIAAKAABp54BA1gAAADOAHkB5AeQAAKAgAAAyA1LufFAPCfFFEWAgBkCyUAAAECClkIMgMoQAAAAAQIAK
AgAAKAgy0A97PNAGE+TATTCkEAAABQAgABATAQDCEFAQ0gDggo3unAIQAFABgAAAABgIAAYQBQEAAABTCGl1Ae9jkgEAgABgMAAGANgLJQyAAAEA8gGQJZSAi3kCLAAB
AMBAABgKQQAAUwEAAMACAAwAYCkAwEAwEABAFMAAAEAAAAAAAAAgABgAQBQA+YAAAAQAADKAgRQd5ABQVAQACAYU0yoMEAAgABoCQAAABQAIAIAAzhgSynzATQEQAAKA
AAGRSCEAwABFDARAwEAAAAAFAQIKYQBTywg4FCwQIAAAEFAAEMKYQBSCJdwEWwpAAQBTAAhlCIoAAGgEA0AFAQAQBQEMKaAXNhAAFAQMoEBIgAEUIgADvAYAFAQgDuAO
4AAiwGgABhSYQBTQCCEABTAQQBQghoKYQBSAABgACAADvAAAAQDAXcAACAAGUIgAEAwABd4QwAKEEMKAAqAgZQADATAAAimUBAihBDQABJcgEwEQCKGQNFAQMoXcABQE
ACAAAglEAkkmUJADAQAAmRQEAAABSAYQgGUACIAKAhlEWAEUwgAAEAMKlHigFIIgAwoKgXMK/9k=
END_EMBEDDED_ASSET -->
