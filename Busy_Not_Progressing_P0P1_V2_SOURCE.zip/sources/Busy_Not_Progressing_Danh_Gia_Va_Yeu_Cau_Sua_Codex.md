ĐÁNH GIÁ BẢN RENDER & YÊU CẦU SỬA GỬI CODEX
Dự án: Người bận rộn nhưng không tiến bộ
Tệp đã kiểm tra: Busy_Not_Progressing_1080p.mp4 (trích từ video-shotcraft-downloads-busy-master-20261119.zip).
I. Kết luận
Bản dựng hoàn chỉnh về mặt kỹ thuật, nhưng CHƯA ĐẠT mục tiêu kể chuyện cuốn hút, nhịp nhanh, chuyển động nhân vật rõ nét. Mức đánh giá tổng thể tham khảo: 6.5/10.

Đối chiếu trực tiếp khung hình rải đều toàn phim và dải khung hình liên tiếp: tồn tại chuyển động nhân vật và biến đổi UI, nhưng phần lớn hình ảnh tập trung cùng một phòng, bàn laptop, bảng kế hoạch. Nhân vật thường giữ tư thế chống hai tay vào hông hoặc ngồi trước bàn; nhiều hành động quan trọng được kể bằng chữ/đồ họa hơn là diễn xuất hình ảnh.

Kiểm tra kỹ thuật độc lập: 509,8 giây, 1920×1080, 30fps, H.264 + AAC stereo 48kHz. Đo âm thanh hỗn hợp bằng FFmpeg: -14,07 LUFS integrated, -1,92 dBTP. Chưa thẩm định bằng tai chất giọng, cảm xúc TTS và độ đồng bộ lời-khung hình ở cấp từng từ.
II. Sửa theo mức ưu tiên
P0 — Cần sửa trước khi đăng
1. Giảm lặp bố cục phòng + laptop. Sau hai shot cùng phòng/giống góc, phải thay bằng hành động nhân vật ở bối cảnh khác, camera chi tiết hoặc hình ảnh tương phản. Không dùng màn hình hồ sơ năng lực/giấy checklist liên tục để thay thế kể chuyện. Không kéo một khung UI gần giống nhau trên 3–4 giây nếu không có biến đổi lớn.
2. Nhân vật có diễn xuất thật: hạn chế tư thế tay chống hông; khi mệt: vai rũ, mắt nặng, cúi người, đưa tay bóp trán, chống cằm, thả tay, bỏ điện thoại, gập laptop, đẩy ghế, đứng dậy, bước đi và tương tác đồ vật. Dùng rig các khớp vai, khuỷu, cổ, hông, gối, cổ tay. Chuyển động phải có chuẩn bị–hành động–hệ quả; không chỉ dịch chuyển toàn bộ sprite hoặc camera.
3. Phải thể hiện riêng biệt các địa điểm: phòng ngủ tại nhà (đêm), văn phòng nhiều bàn và đồng nghiệp (ban ngày), đường phố/xe buýt, quán cà phê có cơ hội dự án, góc học thiết kế tại nhà, cánh cửa biểu tượng cuối phim. Duy trì palette xanh đen; thay đổi ánh sáng theo thời gian thật: sáng, chiều, đêm.
4. Tăng tính kịch của cơ hội vụt mất khoảng 04:20–05:20 (kịch bản) / 04:40–05:25 (bản video thực tế). Hiển thị brief thiết kế quán cà phê, Minh tìm hồ sơ chỉ thấy bản nháp, ngón tay dừng trước nút gửi, thông báo công việc được giao người khác. Không cần hội thoại hay hai nhân vật nói chuyện. Cận mắt, bàn tay, vai, màn hình; 1-2 khoảng lặng có chủ đích.
5. Cao trào 05:20–06:00 (kịch bản) / 05:20–06:10 (video): trước/sau tương phản. Cảnh Minh gục ở bàn trong ánh sáng lạnh, camera từ sau lưng tiến gần; tắt hoàn toàn UI 0% lặp lại. Kéo chậm 2 shot giàu biểu cảm thay vì giữ pose bất động.
P1 — Cải thiện giữ chân
6. Nhịp dựng có mục đích: hook 0–15 giây dùng shot 1–2,5s xen đồng hồ/bàn tay/mắt/email/đích 0%. Cảnh thường 2,5–4 giây, montage 0,7–1,2 giây cho từng cut; cảnh tâm lý 5–8 giây khi cần. Không tăng tốc cơ học toàn bộ video hoặc tua lời dẫn.
7. Đa dạng góc máy thực: ECU/CU mặt–tay–vật thể, OTS, POV, top-down, tracking side view khi đi bộ, dolly-in, pull-back. Ưu tiên quan hệ thị giác giữa hành động và lời kể, tránh máy quay luôn ở chính diện.
8. Phân biệt thật sự 120 shot: mỗi shot phải có (a) bố cục khác trước hoặc hành động khác hẳn, (b) điểm bắt đầu, đỉnh, kết, (c) diễn biến thị giác dễ hiểu khi tắt tiếng, (d) tránh một poster chữ thay cho cảnh quay. 120/120 shot có pixel change không phải bằng chứng rằng nhịp phim tốt.
9. Phụ đề: kiểm tra ở kích thước điện thoại, vùng safe-area, tránh quá nhỏ. Dùng từ dễ đọc, highlight hạn chế, không phủ nhân vật quan trọng. Giữ đúng tiếng Việt và một giọng kể.
10. Âm thanh: giữ thông số kỹ thuật ổn (-14 LUFS, peak khoảng -2dBTP), nhưng duyệt cảm xúc voice-over và nhạc bằng tai ở tốc độ 1×. SFX theo hành động; không để tiếng click lặp liên tục, để yên ở cao trào.
III. Bắt buộc thay theo cảnh
- 00:00–00:20: đồng hồ không chiếm nhiều giây; cắt xen Minh gõ–duỗi vai–tick việc–0% hồ sơ, camera tăng tốc thật. Mục tiêu hook xuất hiện trong 3 giây đầu.
- 00:40–01:20: sáng hôm sau và văn phòng phải khác hẳn căn phòng đêm, có thực sự đi ngoài đường/xe buýt/đến văn phòng; không dùng bối cảnh cửa sổ sao ban đêm cho cảnh sáng.
- 01:40–03:40: giảm chuỗi màn hình, folder, checklist; thay bằng các thao tác cụ thể bằng hai tay và phản ứng với báo động, lịch, cuộc họp.
- 03:40–04:20: montage sáu tháng có thay đổi trang phục/ánh sáng/mùa/giấy lịch, nhưng cùng một motif để khán giả cảm nhận thời gian trôi.
- 04:20–05:20: tạo câu chuyện nhỏ có đầu đuôi về brief quán cà phê, dự án người khác nhận, biểu cảm mất cơ hội.
- 05:20–06:00: cao trào mệt mỏi, tuyệt vọng; cận tay, mặt, bờ vai; nhạc hạ, không màn hình demo đứng yên.
- 06:00–07:20: phân biệt rõ bản thiết kế 1 → sửa → bản 2 → hoàn chỉnh 3 sản phẩm; động tác kéo thả, chọn màu, đặt bố cục là hoạt động của Minh, không chỉ cửa sổ tự đổi hình.
- 07:40–08:30: giữ ẩn dụ cánh cửa, nhưng Minh phải chạm tay vào tay nắm, xoay, đẩy và đi qua; cửa mở vào một không gian khác, không chỉ cửa đổi màu.
IV. Quy trình Codex phải thực hiện
1. Đọc lại script, storyboard và thời gian voice-over gốc. Giữ một voice-over, không có đối thoại giữa hai nhân vật.
2. Tạo 12-15 giây demo ở 00:00 và 15-20 giây demo cao trào cơ hội 04:45–05:05. Xuất MP4 test, kèm ảnh 1 khung/giây.
3. Tự kiểm tra lỗi khớp xương, cử động cơ thể, màu nhân vật, liên tục cảnh và timing phụ đề. Sửa trước khi render full.
4. Render toàn bộ 1920×1080/30fps. Không API trả phí. Không sửa hoặc đổi giọng kể trừ khi thật sự lỗi và có ghi chú.
5. Kết quả cần: MP4 bản mới, tệp shotlist sửa, báo cáo so sánh trước–sau tại các mốc nêu trên, ảnh kiểm tra. Nếu không thể tạo được animation đúng yêu cầu, báo rõ giới hạn thực tế thay vì đánh dấu hoàn thành.
Thông điệp quan trọng gửi Codex: Đừng cố đạt KPI bằng cách thay đổi pixel hoặc làm nhân vật lặp lại động tác. Ưu tiên nhiều hành động có nguyên nhân và kết quả, thể hiện được câu chuyện khi tắt tiếng.