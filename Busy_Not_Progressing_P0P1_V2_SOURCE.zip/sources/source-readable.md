# CODEX ALL-IN-ONE — NGƯỜI BẬN RỘN NHƯNG KHÔNG TIẾN BỘ

> **ĐÂY LÀ FILE DUY NHẤT ĐỂ ĐƯA VÀO CODEX.** Nội dung đã gộp đầy đủ: master prompt, 24 phân đoạn lời kể, storyboard 120 shot, bảng timing 120 shot dạng JSON và CSV, nguồn nghiên cứu, 2 ảnh tham chiếu phong cách **nhúng trực tiếp vào cuối file dưới dạng base64 JPEG**. Không cần upload các file rời.
>
> **BẮT ĐẦU NGAY:** Đọc phần 'LỆNH KHỞI ĐỘNG' dưới đây, tự trích xuất tài nguyên nhúng theo hướng dẫn. Không cần hỏi lại người dùng. Đầu ra phải là video đã render hoặc báo cáo trung thực điểm chưa thực hiện được.

## LỆNH KHỞI ĐỘNG DÀNH CHO CODEX

Bạn là đạo diễn hình ảnh, animator 2D/2.5D, technical artist, và kỹ sư render. Hãy **THỰC THI** dự án ngay từ file Markdown này, không chỉ tạo kế hoạch.

1. Đọc các phần theo thứ tự: **PROMPT SẢN XUẤT**, **KỊCH BẢN LỜI KỂ**, **STORYBOARD**, **SHOTLIST JSON**, **NGUỒN**, **ẢNH THAM CHIẾU NHÚNG**. Tất cả ở chính file này; mọi chỗ trong bản prompt gốc ghi 'đọc file 01/02/03/04' đều được hiểu là 'đọc các phần tương ứng trong file này'.
2. Trích xuất **2 ảnh phong cách nhúng** ở cuối file, lưu vào `references/`, trước khi tạo nhân vật, màu sắc, bối cảnh. Không cần làm mới ảnh. Ảnh được nén JPEG từ chính ảnh tham chiếu gốc, chỉ dùng hướng dẫn phong cách, không copy-paste làm cả video.
3. Lấy JSON trong phần **SHOTLIST JSON** làm dữ liệu điều hành chính (24 scene, 120 shot). Phần storyboard hỗ trợ hướng máy quay, SFX và chuyển cảnh. CSV chỉ để đối chiếu.
4. Kể chuyện hoàn toàn bằng **một voice-over tiếng Việt**, không đối thoại giữa nhân vật. Bắt buộc giữ Minh nhất quán, tốc độ nhân vật nhanh hơn bản cũ với các mốc động tác ở master prompt; không tạo slideshow ảnh tĩnh.
5. Chỉ dùng pipeline local miễn phí, phù hợp PC i5-6500, GTX 1060 3GB, RAM 16GB, Windows. Nếu không có narration phù hợp, render bản hình + SFX, ghi rõ còn thiếu voice, đừng mạo nhận là bản đầy đủ.
6. Xuất `output/demo_12s.mp4`, `output/Busy_Not_Progressing_1080p.mp4` (nếu đủ dữ liệu), và `output/QA_report.md`. Kiểm tra file thật bằng ffprobe trước khi báo thành công.

### Trích xuất 2 ảnh đã nhúng (chạy bằng Python, chỉ dùng thư viện chuẩn)

Trong workspace, đổi tên hoặc giữ nguyên file .md này. Lưu đoạn script dưới tên `extract_refs.py` và chạy `python extract_refs.py <tên-file-md>`; hoặc Codex tự thực thi logic tương đương. Đừng đưa chuỗi base64 vào prompt đầu vào model; đọc xử lý bằng code.

```python
import base64, pathlib, re, sys
source = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
pattern = r"[Extracted JPEG asset]"
found = re.findall(pattern, source)
assert len(found) == 2, f"Cần 2 ảnh, thấy {len(found)}"
dest = pathlib.Path("references")
dest.mkdir(exist_ok=True)
for name, data in found:
    content = base64.b64decode(''.join(data.split()))
    (dest / name).write_bytes(content)
    print('Extracted:', dest / name, len(content), 'bytes')
```

**Quan trọng:** Trên Windows: `python extract_refs.py CODEX_TAT_CA_TRONG_1_FILE_BAN_RON_KHONG_TIEN_BO.md`. Nếu file có tên khác, thay đối số tương ứng.

---

## PHẦN A. PROMPT SẢN XUẤT CHI TIẾT

# MASTER PROMPT CHO CODEX — DỰNG VIDEO 8 PHÚT, NHỊP NHANH HƠN, NHÂN VẬT CỬ ĐỘNG RÕ

Bạn là đạo diễn hình ảnh, đạo diễn hoạt hình, technical artist và kỹ sư render video. Hãy làm một VIDEO HOÀN CHỈNH, không chỉ lên kế hoạch, với bộ tài liệu trong thư mục hiện tại:

- `01_KICH_BAN_LOI_KE.md`: Kịch bản 24 đoạn S01–S24, một giọng người kể.
- `02_KICH_BAN_HINH_ANH_GOC_MAY.md`: Storyboard 120 shot, camera, chuyển cảnh, âm thanh.
- `03_DANH_SACH_120_SHOTS.json`: Shotlist có start/end và hành động cụ thể.
- `references/thumbnail_style_mac_ket.jpg`, `references/thumbnail_style_tinh_di.jpg`: HAI ẢNH THAM CHIẾU CỦA NGƯỜI DÙNG. Quan sát kỹ phong cách; giữ nhân vật và gam màu tối giản, không chuyển sang anime/hình người thật/3D chân thực.

## A. Mục tiêu & giới hạn

1. Video dài khoảng **8 phút**, 16:9, 1920×1080, 30 fps, MP4 H.264 + AAC, tiếng Việt. Đầu ra cuối: `output/Busy_Not_Progressing_1080p.mp4`. Đồng thời xuất `output/demo_12s.mp4` và `output/QA_report.md`.
2. Đây là video **KỂ CHUYỆN 100% VOICE-OVER**, không có một cuộc đối thoại nào giữa các nhân vật. Không dựng miệng nhân vật nói/đồng bộ lip-sync nếu không có lý do. Minh 27 tuổi, nhân vật chính xuyên suốt.
3. Bám đúng mạch truyện và 24 cảnh S01–S24, đặc biệt các cao trào S14–S18 và sự thay đổi S19–S24.
4. Sử dụng **100% công cụ miễn phí chạy local**, KHÔNG gọi API trả phí, KHÔNG yêu cầu credit, token của dịch vụ bên thứ ba, KHÔNG dùng model sinh video nặng. Bạn có thể dùng Godot Engine (MIT), Python/Pillow/SVG, FFmpeg (theo giấy phép của chúng), các thư viện và tài nguyên miễn phí hợp lệ.
5. Cấu hình mục tiêu: Windows, Core i5-6500, GTX 1060 3GB, RAM 16GB. Ưu tiên 2D/2.5D sprite vector có rig khớp và background phân lớp. Không dùng render 3D nặng, particles quá mức, video diffusion.
6. Nếu có phần mềm/skill dựng video phù hợp đã cài sẵn, hãy phát hiện và tận dụng; nếu không, dùng **Godot 4 (2D) + FFmpeg** làm stack mặc định. Cấu trúc dự án sao cho có thể chạy lại bằng một script PowerShell.

## B. Thiết kế hình ảnh BẮT BUỘC

- Chất liệu hình như 2 thumbnail tham chiếu: tối giản, cinematic, xanh navy/xanh xám đậm, viền mềm, đầu TRÒN ĐEN, đôi mắt TRẮNG, áo sơ mi trắng có điểm nhấn xám, quần tối màu; ánh sáng vàng ấm ở cảnh giấc mơ/thành công.
- Nhân vật chính nhất quán về tỷ lệ: kích thước đầu so với thân, màu mắt, áo, quần. Không tự động đổi màu tóc/quần áo hay hình dạng đầu giữa cảnh.
- Bối cảnh chính lặp lại: căn phòng ban đêm (bàn, laptop, cốc, đèn, cửa sổ, kệ sách) và văn phòng. Lưu file character master/rig/background để tái sử dụng.
- Không biến reference thumbnail thành ảnh nền tĩnh phóng to 8 phút. Không dựng một loạt slide tĩnh. Vẽ tách nhân vật/bàn/đèn/laptop/cửa sổ thành các lớp có thể animate. Hai ảnh là style guide.
- Chỉ dùng rất ít chữ trên hình: 'HỒ SƠ NĂNG LỰC', '45 PHÚT', '0%', 'MỤC TIÊU', '1 KẾT QUẢ HÔM NAY', các câu nhỏ có trong shotlist. Chữ là tiếng Việt đúng dấu, không in prompt/ký hiệu sản xuất, không tiếng Anh thừa.

## C. SỬA LỖI QUAN TRỌNG NHẤT: NHÂN VẬT QUÁ CHẬM

Tôi đã chê phiên bản trước vì nhân vật động tác quá chậm. Bản mới phải có NHỊP HÀNH ĐỘNG THẬT, không giải quyết bằng zoom camera.

- Tốc độ cử động ở các cảnh công việc từ S01–S16: **nhanh hơn phiên bản chậm khoảng 1.35–1.6 lần**, nhưng vẫn tự nhiên. Không cho tất cả animation chạy cùng một tốc độ máy móc.
- Phản ứng mắt/đầu khi có thông báo: bắt đầu trong 0.12–0.25s. Quay đầu dứt khoát trong khoảng 0.25–0.45s, với 0.1s follow-through.
- Bấm chuột / chạm điện thoại / lật trang: động tác chính 0.2–0.5s; dừng ở đỉnh động tác 0.06–0.15s rồi trở về. Phải có nhịp ra/về rõ.
- Đi bộ nhanh: nhịp khoảng 1.8–2.2 bước mỗi giây khi gấp. Thân có bob nhẹ, đối xứng tay/chân luân phiên, chân chống không trượt trên mặt đất.
- Ngồi xuống/đứng dậy: diễn trọn động tác trong 0.6–1.1s, chân/tay tương tác ghế và bàn. Chuyển tư thế kiểu người thật giản lược, không teleport.
- Gõ phím: hai cẳng tay, bàn tay và cổ vai cùng có chuyển động; các nhịp gõ 3–5 nhịp/giây theo cụm, kèm micro-pauses.
- Ngạc nhiên, thất vọng, bối rối: biểu hiện qua đôi mắt, góc đầu, vai và nhịp thở; tránh nhân vật cứ cúi đầu đứng yên 15 giây.
- Phải tạo rig 2D với các pivot: neck, shoulders L/R, elbows L/R, wrists L/R, hip, knees L/R, feet. Tách đốt tay/chân nếu phù hợp. Mỗi chuyển động có pose start/anticipation/action/recovery và easing tinh tế.
- Mỗi shot trong JSON phải có hành động diễn ra **trên thân nhân vật hoặc vật thể thật**, camera di chuyển chỉ là phụ. Ít nhất **70% shot** có chuyển động chủ thể, không chỉ pan/zoom/scale.
- GIỮ CHẬM CÓ CHỦ ĐÍCH ở S17–S18 (sốc mất cơ hội) và hai câu kết S24. Đoạn này không slow-motion cả cảnh; cho cử động hít thở, buông tay, hướng nhìn để duy trì sức sống.

## D. Tốc độ cắt dựng và góc máy

- Thực hiện đủ 24 scene và **120 shot** theo `03_DANH_SACH_120_SHOTS.json`. Mốc cut tham chiếu 3–5 giây/shot (tốc độ trung bình ~4 giây/shot), có microcut 0.7–1.2 giây bên trong montage.
- 0–10 giây đầu: cảnh phải có ngay đồng hồ 23:48, ngón tay gõ máy, checkbox hiện, đôi mắt mệt, và đối lập folder còn 0%. Không intro logo, không mở đầu dài dòng.
- Dùng góc máy OTS, ECU, CU, MS, WS, POV, top-down, 3/4, tracking profile. Xen kẽ khoảng cách máy để có năng lượng hình ảnh.
- Ưu tiên hard cut, match cut, whip-pan ngắn, L-cut/J-cut âm thanh, montage dạng action-to-action. Hạn chế dissolve/blur dài và chuyển cảnh màu mè.
- Parallax 2.5D phải xuất phát từ các lớp đồ vật/nhân vật khác nhau; không giả 2.5D bằng cách scale cùng một hình.
- Với các shot trong storyboard, triển khai hành động vật lý theo mô tả; nếu cảnh không thể có đầy đủ vector chi tiết, thay bằng động tác chủ thể tương đương, không được thay bằng ảnh tĩnh.
- Thời lượng mỗi scene có thể lệch ±3 giây để ăn khớp voice-over; tổng thể mục tiêu 07:45–08:30. Tuyệt đối không cắt lời kể ngang câu hoặc tăng tốc voice bất tự nhiên.

## E. Âm thanh & giọng kể

- Duy nhất một giọng dẫn chuyện tiếng Việt, tự nhiên, trầm vừa phải, nhấn hook và cao trào, không có lời thoại giữa nhân vật.
- Ưu tiên nạp `assets/narration.wav`, `assets/narration.mp3` hoặc `assets/narration.m4a` nếu người dùng đã có bản thu. Căn S01–S24 theo đoạn lời kể thực tế bằng timing hoặc marker.
- Nếu CHƯA có file giọng đọc, hãy kiểm tra có hệ TTS tiếng Việt miễn phí chạy local hợp lệ hay không; chỉ dùng khi thực sự hỗ trợ tiếng Việt dễ nghe. Không được ngầm gọi dịch vụ online hay API trả phí, không tạo giọng đọc tiếng khác giả làm tiếng Việt. Nếu không thể có narration hợp lệ, vẫn render demo và bản hình + nhạc/hiệu ứng, xuất `output/NEED_VOICEOVER.txt` ghi chính xác file cần người dùng bổ sung. Không tuyên bố bản cuối đã có voice nếu không có.
- Tạo SFX local bằng oscillator/noise/one-shot tự sinh hoặc dùng thư viện local có giấy phép rõ: click chuột, bàn phím, thông báo, lật sách, kéo ghế, đồng hồ, cửa mở, bước chân, quạt máy.
- Nhạc nền instrumental nhẹ, hạn chế nhạc lớn. SFX đúng lúc tiếp xúc đồ vật. Voice luôn rõ ràng, không bị nhạc che. Dùng ducking: nhạc giảm khoảng 12–18dB khi voice hoạt động, tùy kiểm tra tai nghe.
- S17–S18: nhạc giảm gần như im lặng, 1–2 tiếng piano thưa. Kết thúc S24 fade âm 2 giây.
- Nếu render phụ đề, dùng tiếng Việt chuẩn, chia từng câu ngắn; đặt vùng an toàn phía dưới, không che tay, đồ vật và cảm xúc nhân vật.

## F. Quy trình phải THỰC THI, không hỏi lại

1. Đọc tất cả file kịch bản và hai ảnh reference. Tạo thư mục project `busy_not_progressing/` và lưu `assets/`, `characters/`, `backgrounds/`, `scenes/`, `audio/`, `output/` rõ ràng.
2. Kiểm tra hệ điều hành, Godot/Node/Python/FFmpeg hiện có. Chọn stack không tốn phí và ghi lại quyết định kỹ thuật.
3. Dựng **character master** có rig khớp, các action reusable: `idle`, `fast_walk`, `sit`, `stand`, `type`, `mouse`, `phone_reach`, `page_flip`, `head_turn`, `hand_to_forehead`, `reaction_surprise`, `reaction_regret`, `open_door`.
4. Dựng background master cho bedroom/desk, office, street, abstract achievement bubble, café-project graphic, door. Dùng palette nhất quán.
5. Dựng thử **12 giây đầu** (không chỉ ảnh demo), xuất `output/demo_12s.mp4`. Xem/kiểm tra chuyển động (tốc độ tay/đầu, đủ hành động, không giật/chuyển frame lỗi), sau đó TỰ SỬA các vấn đề phát hiện.
6. Thực hiện toàn bộ 24 scene/120 shot từ JSON theo thứ tự. Tạo transitions có chủ đích và âm thanh đồng bộ, không để shot bị lặp lại quá lâu.
7. Có narration thì đồng bộ theo voice; không có thì làm bản video hình + nhạc/SFX và ghi thiếu giọng rõ ràng. Không cắt bớt một nửa câu chuyện để giả có video 8 phút.
8. Render thử 30 giây bất kỳ gồm cảnh tương tác tay/chân và cảnh căng thẳng; kiểm tra không có bàn tay xuyên vật thể, đầu bị giật, foot sliding, layer lỗi.
9. Render toàn bộ bằng cấu hình phù hợp 3GB VRAM (render 1080p, concurrency thấp, ưu tiên reuse vector/sprites), xuất MP4 H.264 yuv420p, AAC, 30fps. Nếu cần render sequence theo scene rồi nối bằng FFmpeg để tránh RAM tăng.
10. Chạy `ffprobe` kiểm tra duration, fps, kích thước video, stream audio. Tự kiểm tra thumbnail frame tại 00:05, 01:35, 03:30, 05:30, 06:30 và 07:50 để phát hiện cảnh quá tĩnh, text sai hoặc biến dạng.
11. Ghi `output/QA_report.md`: đã xuất đủ 24 scene chưa, tổng shot thực tế, 5 khung kiểm tra, độ dài, fps, âm thanh và lỗi chưa xử lý. Cho đường dẫn cuối cùng **ngay sau khi render thành công**. Không báo thành công khi file chưa tồn tại.

## G. Tiêu chí nghiệm thu

- [ ] Không đối thoại; một voice-over xuyên suốt (nếu có file voice hoặc TTS local hợp lệ).
- [ ] Nhân vật Minh đúng template xanh đen tối giản, không biến đổi hình dáng giữa cảnh.
- [ ] Tốc độ hành động tay/chân/đầu nhanh, dứt khoát, có phản ứng trong 0.12–0.45s nơi phù hợp.
- [ ] Ít nhất 70% shot có motion chủ thể; tổng 120 shot không phải slideshow.
- [ ] 0–10 giây đầu có hook mạnh, ít nhất 3 thay đổi góc/quy mô cảnh.
- [ ] S17–S18 chậm lại để tạo nỗi đau, S19–S22 nhịp tăng trở lại, S24 kết lắng.
- [ ] Không lỗi chữ tiếng Việt/khớp tay/chân/biến hình; SFX khớp hành động; voice rõ.
- [ ] Có file MP4 thật, chất lượng 1080p/30fps, dài khoảng 8 phút hoặc báo đúng trạng thái chưa hoàn thành.

**BẮT ĐẦU THỰC HIỆN NGAY. Không dừng ở kế hoạch hoặc chỉ tạo khung hình tĩnh. Không yêu cầu người dùng mua dịch vụ. Không đợi xác nhận sau demo; tự chuyển sang dựng bản đầy đủ.**


---

## PHẦN B. KỊCH BẢN LỜI KỂ (ĐẦY ĐỦ)

# KỊCH BẢN LỜI KỂ — BẬN RỘN NHƯNG KHÔNG TIẾN BỘ

- Video: 16:9, 1920×1080, 30 fps, khoảng 8 phút.
- Hình thức: 100% voice-over, **KHÔNG có hội thoại giữa nhân vật**, không nhân vật nào nói với nhau.
- Nhân vật: Minh, 27 tuổi, nhân viên văn phòng, muốn làm thiết kế tự do.
- Nhịp lời dẫn: tự nhiên, có nhấn và khoảng ngắt ở 05:20–05:50, không đọc như một danh sách mẹo.
- Các mốc là chỉ dẫn dựng, cần căn lại theo độ dài bản thu thực tế; không tua giọng quá nhanh để khớp mốc.

## S01 — 00:00–00:20 | HOOK: Mười bốn tiếng

Hôm nay, Minh đã làm việc gần mười bốn tiếng. Điện thoại vẫn sáng. Hộp thư vẫn đầy. Danh sách công việc gần như đã được gạch hết. Nhưng có một điều Minh chưa dám nhìn thẳng: sáu tháng qua, cuộc sống mà cậu muốn xây dựng vẫn chưa tiến thêm được bao nhiêu. Một ngày rất bận. Một tương lai đứng yên.

## S02 — 00:20–00:40 | Đồng hồ lúc nửa đêm

Mười một giờ bốn mươi tám phút đêm. Minh ngồi trước laptop, tay vẫn di chuyển trên bàn phím. Một cốc cà phê nguội ngắt. Cổ vai căng cứng. Cậu kiểm tra hết cửa sổ này đến cửa sổ khác, rồi thở phào vì hôm nay không bỏ sót việc gì. Cảm giác ấy giống như chiến thắng. Chỉ tiếc, nó biến mất ngay khi màn hình tắt.

## S03 — 00:40–01:00 | Sáng hôm sau

Sáu giờ ba mươi, chuông báo thức vang lên. Minh bật dậy, xem lịch, kiểm tra tin nhắn rồi vội vã ra khỏi nhà. Trên đường đi làm, cậu vẫn nghe một bài học mới về cách phát triển bản thân. Minh tin rằng chỉ cần chăm hơn một chút nữa, mọi thứ sẽ khác. Và đó cũng là điều cậu đã tự nhủ suốt nhiều tháng.

## S04 — 01:00–01:20 | Lịch kín mít

Ở văn phòng, Minh xử lý báo cáo, sửa bảng số liệu, trả lời email, tham gia họp rồi tiếp tục xử lý những việc phát sinh. Cứ hoàn thành một việc, một việc khác lại xuất hiện. Minh không hề giả vờ bận. Công việc của cậu thực sự nhiều. Nhưng giữa nhịp quay ấy, có một câu hỏi chưa từng xuất hiện trong lịch: hôm nay mình đã đi gần hơn mục tiêu nào?

## S05 — 01:20–01:40 | Giấc mơ thầm kín

Minh không muốn làm công việc hiện tại mãi mãi. Cậu từng ước có thể sống bằng nghề thiết kế tự do, được chọn dự án mình thích và có thời gian chủ động hơn. Trong máy tính đã có sẵn một thư mục tên là Hồ sơ năng lực. Minh dự định sẽ điền đầy nó bằng những sản phẩm tốt nhất. Chỉ cần chuẩn bị thêm một thời gian nữa thôi.

## S06 — 01:40–02:00 | Học mãi không xong

Buổi tối, Minh mở khóa học thiết kế. Nhưng chỉ ít phút sau, cậu tìm thấy một hướng dẫn khác được giới thiệu là tốt hơn. Rồi thêm một video, một bộ tài liệu, một danh sách công cụ nên thử. Từ một bài học, màn hình mở ra mười hai tab. Minh lưu tất cả để xem sau. Và tự thấy mình đang đầu tư nghiêm túc cho tương lai.

## S07 — 02:00–02:20 | Chuẩn bị thay cho bắt đầu

Cuối tuần, Minh dành cả buổi sắp xếp tài liệu. Đổi tên từng thư mục. Chọn màu cho bảng kế hoạch. Vẽ một lộ trình rất đẹp. Những ô nhỏ lần lượt được đánh dấu hoàn thành. Nhưng khi mở phần mềm thiết kế để bắt tay vào sản phẩm đầu tiên, cậu lại đứng hình. Minh chưa biết nên chọn ý tưởng nào. Thế là cậu quay về nghiên cứu tiếp.

## S08 — 02:20–02:40 | Cảm giác hoàn thành

Đó là cái bẫy khó nhận ra nhất. Những việc nhỏ thường cho Minh một cảm giác tiến bộ rất nhanh. Xóa email: xong. Dọn bàn: xong. Viết kế hoạch: xong. Còn làm ra một thiết kế thực sự? Có thể mất hàng giờ và vẫn chưa đẹp. Thế nên Minh cứ chọn những việc dễ có dấu tích, để tránh đối diện một bản nháp chưa hoàn hảo.

## S09 — 02:40–03:00 | Việc quan trọng bị đẩy đi

Mỗi ngày, Minh đều tự hứa sẽ dành một giờ cho hồ sơ năng lực. Nhưng rồi điện thoại báo có việc gấp. Đồng nghiệp cần hỗ trợ. Một biểu mẫu phải cập nhật. Đến lúc mọi thứ tạm yên, cậu đã không còn sức. Một giờ quan trọng ấy được chuyển sang ngày mai. Và ngày mai lại có những thứ khẩn cấp mới chờ sẵn.

## S10 — 03:00–03:20 | Bận vì khẩn cấp

Nghiên cứu về hiệu ứng khẩn cấp cho thấy con người đôi khi chọn việc có hạn chót sát hơn, dù phần thưởng của nó ít giá trị hơn. Với Minh, điều đó xuất hiện dưới một hình thức rất bình thường: phản ứng ngay với mọi yêu cầu mới, rồi để việc dài hạn nằm yên. Không phải mọi việc gấp đều vô nghĩa. Nhưng điều quan trọng nhất không phải lúc nào cũng biết gửi thông báo.

## S11 — 03:20–03:40 | Đầu óc bị chia nhỏ

Ngay cả khi Minh ngồi xuống thiết kế, cậu cũng liên tục bị kéo đi. Vừa đặt được vài hình khối, điện thoại sáng lên. Trả lời xong, cậu kiểm tra email. Quay lại màn hình, Minh mất một lúc để nhớ mình đang làm dở điều gì. Nhà nghiên cứu Sophie Leroy gọi phần chú ý còn mắc lại ở việc trước là sự tồn dư chú ý. Đổi việc không phải lúc nào cũng miễn phí.

## S12 — 03:40–04:00 | Sáu tháng trôi qua

Ngày nối ngày. Những ô lịch bị xé đi. Các dự án ở công ty đến rồi kết thúc. Minh vẫn dậy sớm, vẫn về muộn, vẫn ghi thêm ý tưởng vào điện thoại. Có hôm cậu tự hào vì mình chẳng có phút nào rảnh. Nhưng tháng thứ nhất trôi qua. Rồi tháng thứ ba. Và đến tháng thứ sáu, thư mục hồ sơ năng lực vẫn gần như trống rỗng.

## S13 — 04:00–04:20 | Cuốn sổ cũ

Một tối, trong lúc dọn bàn, Minh tìm thấy cuốn sổ ghi mục tiêu đầu năm. Ở trang đầu tiên có một dòng được gạch chân: hoàn thành năm thiết kế và tìm khách hàng đầu tiên. Bên dưới là những việc nhỏ đã được đánh dấu kín trang. Minh lật tiếp. Lật thêm. Rồi dừng lại. Mục tiêu lớn nhất vẫn nằm đó, không có một ngày hoàn thành.

## S14 — 04:20–04:40 | Một cơ hội đến

Đúng lúc ấy, một người quen đang mở quán cà phê cần bộ hình ảnh quảng bá. Một dự án nhỏ, nhưng rất hợp với điều Minh muốn theo đuổi. Cậu lập tức nghĩ ra ý tưởng về màu sắc, phông chữ, cách bố trí hình ảnh. Lần đầu sau nhiều tháng, giấc mơ có vẻ đã ở đủ gần để chạm tay vào. Chỉ cần gửi vài sản phẩm từng làm.

## S15 — 04:40–05:00 | Thư mục trống

Minh mở máy tính, tìm đến thư mục hồ sơ năng lực và nhấp đúp. Bên trong có hàng chục ảnh tham khảo, vài file chưa đặt tên và một bản phác thảo dang dở. Không có bộ sản phẩm nào hoàn chỉnh. Cậu mở lại các folder cũ, hy vọng mình đã bỏ quên thứ gì đó. Nhưng màn hình chỉ trả về những tài liệu đã lưu, không phải thứ cậu tự tạo ra.

## S16 — 05:00–05:20 | Cơ hội đi qua

Minh quyết định sẽ làm gấp một bộ mẫu để gửi. Nhưng cả buổi tối trôi qua trong việc chọn bố cục, chỉnh màu rồi xóa đi làm lại. Hôm sau, người quen đã tìm được một nhà thiết kế khác. Minh không trách ai. Cậu hiểu cơ hội ấy không đợi mình được. Và điều khiến cậu hụt hẫng nhất không phải vì mất một việc nhỏ, mà vì mình đã có quá nhiều thời gian trước đó.

## S17 — 05:20–05:40 | Cao trào: Tất cả những ngày đã qua

Minh ngồi yên nhìn màn hình. Sáu tháng. Bao nhiêu tối thức khuya. Bao nhiêu lần nói rằng mình đang cố gắng. Cậu không hoàn toàn đứng yên; cậu đã học được nhiều điều. Nhưng tất cả hiểu biết ấy vẫn nằm rải rác trong các tab, ghi chú và kế hoạch. Minh đã dùng sự bận rộn để tự trấn an, thay vì nhìn vào điều mình thật sự tạo ra.

## S18 — 05:40–06:00 | Nhận ra điều khó chịu

Lần đầu tiên, Minh hiểu rằng cậu không chỉ thiếu thời gian. Cậu đang tránh một nỗi sợ khác: nỗi sợ làm ra thứ chưa đủ tốt. Lên kế hoạch cho một tương lai rực rỡ rất dễ chịu. Bắt đầu bằng một sản phẩm vụng về thì không. Và chính khoảng cách ấy đã nuốt mất nhiều tháng của cậu. Điều đau nhất không phải thất bại. Là chưa từng cho mình cơ hội thử thật sự.

## S19 — 06:00–06:20 | Một quy tắc khác đi

Sáng hôm sau, Minh không quyết định thay đổi toàn bộ cuộc đời. Cậu cũng không đặt ra ba mươi thói quen mới. Minh chỉ viết một câu lên tờ giấy nhỏ: hôm nay phải có một kết quả nhìn thấy được. Không phải số giờ ngồi trước máy. Không phải số video đã xem. Một sản phẩm có thể mở lên, chỉ ra chỗ tốt, chỗ dở, rồi sửa tiếp.

## S20 — 06:20–06:40 | Bốn mươi lăm phút thật

Tối đó, Minh đặt đồng hồ bốn mươi lăm phút. Cậu tắt thông báo, mở phần mềm và bắt đầu ngay bằng một bố cục đơn giản. Có lúc bí ý tưởng. Có lúc muốn tìm thêm hướng dẫn. Nhưng lần này, Minh không bỏ chạy sang việc khác. Cậu chỉnh từng khoảng cách, chọn ảnh, thử phông chữ, rồi xuất bản đầu tiên. Nó chưa đẹp. Nhưng cuối cùng, nó tồn tại.

## S21 — 06:40–07:00 | Sửa thay vì mơ

Những ngày sau không phải lúc nào cũng thuận lợi. Có hôm Minh tăng ca đến tối. Có hôm mệt đến mức chỉ sửa được vài chi tiết. Nhưng khi không thể làm nhiều, cậu vẫn biết mình đang sửa phần nào. Cậu gửi sản phẩm cho vài người xem, nhận góp ý và sửa lại. Sự tiến bộ không còn là một cảm giác mơ hồ. Nó có phiên bản cũ, phiên bản mới và những lỗi cụ thể được khắc phục.

## S22 — 07:00–07:20 | Bốn tuần sau

Một tháng trôi qua. Minh chưa trở thành nhà thiết kế tự do. Tài khoản ngân hàng cũng chưa thay đổi đáng kể. Nhưng trong thư mục hồ sơ năng lực đã có ba sản phẩm hoàn chỉnh. Cậu vẫn đi làm mỗi ngày, vẫn có trách nhiệm phải lo. Chỉ khác là khi mở máy tính vào buổi tối, cậu không còn phải tưởng tượng mình có thể làm gì. Cậu có thể nhìn thấy điều mình đã làm.

## S23 — 07:20–07:40 | Sự thật cần công bằng

Không phải người bận rộn nào cũng đang đi sai đường. Có người phải dành phần lớn thời gian để kiếm sống, chăm sóc gia đình hoặc vượt qua những giai đoạn quá sức. Nghỉ ngơi không phải lười biếng. Và không thể đo giá trị của một con người chỉ bằng năng suất. Nhưng nếu bạn vẫn còn một khoảng nhỏ có thể tự lựa chọn, hãy tự hỏi: mình đang làm điều quan trọng, hay chỉ đang làm điều dễ gạch đi?

## S24 — 07:40–08:00 | Kết: Cánh cửa

Chúng ta có thể đi rất nhanh trên một chiếc máy chạy bộ, mồ hôi ướt áo, chân không ngừng chuyển động. Nhưng khi bước xuống, vị trí vẫn như cũ. Bận rộn cũng có thể như vậy. Đôi khi, điều thay đổi cuộc đời không phải thêm một giờ làm việc. Mà là dừng lại, xác định đúng cánh cửa, rồi đặt tay lên nắm cửa ấy. Và thật sự mở nó ra.

---

## Chỉ đạo đọc
- Một giọng kể duy nhất; không lời thoại trực tiếp của bất cứ nhân vật nào.
- 00:00–00:20: rõ, gọn, nhấn “một tương lai đứng yên”.
- 01:40–03:40: hơi nhanh và dồn dập, không lướt qua từ khóa chính.
- 04:20–05:20: nhịp căng, khoảng nghỉ ngắn ở mỗi bước vỡ mộng.
- 05:20–06:00: đọc thấp giọng, có khoảng lặng sau câu “Sáu tháng.”
- 06:00–07:20: dần sáng hơn, không lên gân như diễn thuyết.
- 07:40–08:00: chậm lại có chủ đích, 1–2 giây im lặng cuối phim.

## Ghi chú nguồn cho hai ý nghiên cứu
- *Mere urgency effect*: Zhu, Yang & Hsee (2018), *Journal of Consumer Research*. Nên hiển thị nguồn nhỏ ở cuối video hoặc phần mô tả.
- *Attention residue*: Sophie Leroy (2009), *Organizational Behavior and Human Decision Processes*.
- Hai ý khoa học mang tính giải thích chung; không phải chẩn đoán tâm lý nhân vật hư cấu Minh.


---

## PHẦN C. KỊCH BẢN HÌNH ẢNH, GÓC MÁY, ÂM THANH (120 SHOT)

# KỊCH BẢN HÌNH ẢNH — 120 SHOT CHO VIDEO 8 PHÚT

**Lưu ý:** đây là shotlist để Codex dựng hoạt hình, không phải 120 hình tĩnh. Mỗi shot cần cử động thật của nhân vật hoặc vật thể, khác biệt bắt đầu–đỉnh–kết thúc. Mốc 20s/cảnh mang tính định hướng; kéo giãn/thu lại theo độ dài voice-over thực tế.

- Góc máy: ECU (cận cực gần), CU (cận), MS (trung), WS (toàn), OTS (qua vai), POV (góc nhìn nhân vật).
- Nhịp thông thường 3–5s/shot; 0.7–1.2s/cut đối với các montage trong một shot. Cao trào S17 được chậm có chủ đích.
- Không slow motion toàn bộ, không ảnh tĩnh chỉ zoom, không nhân vật đứng như tượng.
- Giữ đúng thiết kế nhân vật và màu xanh đen tối giản của hai ảnh tham chiếu trong thư mục `references/`.

## S01 · 00:00–00:20 · HOOK: Mười bốn tiếng
- **Nhịp dựng:** Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
- **Âm thanh:** Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.
- **00:00–00:03 / Shot 01.01:** ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng.
- **00:03–00:07 / Shot 01.02:** OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp.
- **00:07–00:11 / Shot 01.03:** CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở.
- **00:11–00:15 / Shot 01.04:** Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ.
- **00:15–00:20 / Shot 01.05:** Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'.

## S02 · 00:20–00:40 · Đồng hồ lúc nửa đêm
- **Nhịp dựng:** Match-on-action qua các cử động tay.
- **Âm thanh:** Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.
- **00:20–00:23 / Shot 02.01:** CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm.
- **00:23–00:27 / Shot 02.02:** ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên.
- **00:27–00:31 / Shot 02.03:** MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc.
- **00:31–00:35 / Shot 02.04:** POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu.
- **00:35–00:40 / Shot 02.05:** Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt.

## S03 · 00:40–01:00 · Sáng hôm sau
- **Nhịp dựng:** Whip pan từ đồng hồ đêm sang báo thức sáng.
- **Âm thanh:** Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.
- **00:40–00:43 / Shot 03.01:** ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây.
- **00:43–00:47 / Shot 03.02:** MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through.
- **00:47–00:51 / Shot 03.03:** CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa.
- **00:51–00:55 / Shot 03.04:** Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax.
- **00:55–01:00 / Shot 03.05:** OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học.

## S04 · 01:00–01:20 · Lịch kín mít
- **Nhịp dựng:** L-cut âm thanh giữa các khu vực văn phòng.
- **Âm thanh:** Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.
- **01:00–01:03 / Shot 04.01:** WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác.
- **01:03–01:07 / Shot 04.02:** OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt.
- **01:07–01:11 / Shot 04.03:** CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ.
- **01:11–01:15 / Shot 04.04:** Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi.
- **01:15–01:20 / Shot 04.05:** Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp.

## S05 · 01:20–01:40 · Giấc mơ thầm kín
- **Nhịp dựng:** Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style.
- **Âm thanh:** Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.
- **01:20–01:23 / Shot 05.01:** MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim.
- **01:23–01:27 / Shot 05.02:** ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát.
- **01:27–01:31 / Shot 05.03:** Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp.
- **01:31–01:35 / Shot 05.04:** Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng.
- **01:35–01:40 / Shot 05.05:** Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày.

## S06 · 01:40–02:00 · Học mãi không xong
- **Nhịp dựng:** Montage 0.7-1.2 giây/cut bên trong shot #4.
- **Âm thanh:** Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.
- **01:40–01:43 / Shot 06.01:** OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi.
- **01:43–01:47 / Shot 06.02:** ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác.
- **01:47–01:51 / Shot 06.03:** CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson.
- **01:51–01:55 / Shot 06.04:** POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp.
- **01:55–02:00 / Shot 06.05:** MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng.

## S07 · 02:00–02:20 · Chuẩn bị thay cho bắt đầu
- **Nhịp dựng:** Smash cut bảng kế hoạch đầy đủ -> canvas trống.
- **Âm thanh:** Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.
- **02:00–02:03 / Shot 07.01:** Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh.
- **02:03–02:07 / Shot 07.02:** ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động.
- **02:07–02:11 / Shot 07.03:** MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống.
- **02:11–02:15 / Shot 07.04:** OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn.
- **02:15–02:20 / Shot 07.05:** CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác.

## S08 · 02:20–02:40 · Cảm giác hoàn thành
- **Nhịp dựng:** Graphic match tick -> ô bản nháp trống.
- **Âm thanh:** Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.
- **02:20–02:23 / Shot 08.01:** ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát.
- **02:23–02:27 / Shot 08.02:** CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây.
- **02:27–02:31 / Shot 08.03:** MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống.
- **02:31–02:35 / Shot 08.04:** Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự.
- **02:35–02:40 / Shot 08.05:** ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ.

## S09 · 02:40–03:00 · Việc quan trọng bị đẩy đi
- **Nhịp dựng:** 5 inserts động; giảm nhạc ở cuối.
- **Âm thanh:** Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.
- **02:40–02:43 / Shot 09.01:** CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch.
- **02:43–02:47 / Shot 09.02:** ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay.
- **02:47–02:51 / Shot 09.03:** OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục.
- **02:51–02:55 / Shot 09.04:** WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc.
- **02:55–03:00 / Shot 09.05:** CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài.

## S10 · 03:00–03:20 · Bận vì khẩn cấp
- **Nhịp dựng:** Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
- **Âm thanh:** Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.
- **03:00–03:03 / Shot 10.01:** Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên.
- **03:03–03:07 / Shot 10.02:** POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu.
- **03:07–03:11 / Shot 10.03:** MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ.
- **03:11–03:15 / Shot 10.04:** Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%.
- **03:15–03:20 / Shot 10.05:** Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống.

## S11 · 03:20–03:40 · Đầu óc bị chia nhỏ
- **Nhịp dựng:** Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
- **Âm thanh:** Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.
- **03:20–03:23 / Shot 11.01:** OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas.
- **03:23–03:27 / Shot 11.02:** Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay.
- **03:27–03:31 / Shot 11.03:** Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi.
- **03:31–03:35 / Shot 11.04:** Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây.
- **03:35–03:40 / Shot 11.05:** Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa.

## S12 · 03:40–04:00 · Sáu tháng trôi qua
- **Nhịp dựng:** Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im.
- **Âm thanh:** Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.
- **03:40–03:43 / Shot 12.01:** Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm.
- **03:43–03:47 / Shot 12.02:** Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối.
- **03:47–03:51 / Shot 12.03:** Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt.
- **03:51–03:55 / Shot 12.04:** Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi.
- **03:55–04:00 / Shot 12.05:** CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng.

## S13 · 04:00–04:20 · Cuốn sổ cũ
- **Nhịp dựng:** Match cut trang sổ -> màn hình folder.
- **Âm thanh:** Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.
- **04:00–04:03 / Shot 13.01:** Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống.
- **04:03–04:07 / Shot 13.02:** OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế.
- **04:07–04:11 / Shot 13.03:** ECU lật trang nhanh: các checkbox nhỏ đều được tích.
- **04:11–04:15 / Shot 13.04:** CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích.
- **04:15–04:20 / Shot 13.05:** Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành.

## S14 · 04:20–04:40 · Một cơ hội đến
- **Nhịp dựng:** Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn.
- **Âm thanh:** Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.
- **04:20–04:23 / Shot 14.01:** ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình.
- **04:23–04:27 / Shot 14.02:** CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng.
- **04:27–04:31 / Shot 14.03:** Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D.
- **04:31–04:35 / Shot 14.04:** MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình.
- **04:35–04:40 / Shot 14.05:** Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở.

## S15 · 04:40–05:00 · Thư mục trống
- **Nhịp dựng:** Cut vào ánh sáng màn hình lạnh hơn.
- **Âm thanh:** Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.
- **04:40–04:43 / Shot 15.01:** POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành.
- **04:43–04:47 / Shot 15.02:** OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng.
- **04:47–04:51 / Shot 15.03:** CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống.
- **04:51–04:55 / Shot 15.04:** Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại.
- **04:55–05:00 / Shot 15.05:** ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt.

## S16 · 05:00–05:20 · Cơ hội đi qua
- **Nhịp dựng:** Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành.
- **Âm thanh:** Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.
- **05:00–05:03 / Shot 16.01:** Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật.
- **05:03–05:07 / Shot 16.02:** OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh.
- **05:07–05:11 / Shot 16.03:** CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt.
- **05:11–05:15 / Shot 16.04:** POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại.
- **05:15–05:20 / Shot 16.05:** MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây.

## S17 · 05:20–05:40 · Tất cả những ngày đã qua
- **Nhịp dựng:** Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào.
- **Âm thanh:** Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.
- **05:20–05:23 / Shot 17.01:** Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn.
- **05:23–05:27 / Shot 17.02:** ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s.
- **05:27–05:31 / Shot 17.03:** CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích.
- **05:31–05:35 / Shot 17.04:** OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay.
- **05:35–05:40 / Shot 17.05:** Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở.

## S18 · 05:40–06:00 · Nhận ra điều khó chịu
- **Nhịp dựng:** Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
- **Âm thanh:** Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.
- **05:40–05:43 / Shot 18.01:** CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm.
- **05:43–05:47 / Shot 18.02:** Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật.
- **05:47–05:51 / Shot 18.03:** MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop.
- **05:51–05:55 / Shot 18.04:** ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở.
- **05:55–06:00 / Shot 18.05:** Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe.

## S19 · 06:00–06:20 · Một quy tắc khác đi
- **Nhịp dựng:** Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
- **Âm thanh:** Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.
- **06:00–06:03 / Shot 19.01:** Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác.
- **06:03–06:07 / Shot 19.02:** CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét.
- **06:07–06:11 / Shot 19.03:** MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế.
- **06:11–06:15 / Shot 19.04:** POV mở file thiết kế duy nhất, bỏ các tab không cần.
- **06:15–06:20 / Shot 19.05:** CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối.

## S20 · 06:20–06:40 · Bốn mươi lăm phút thật
- **Nhịp dựng:** Các chuyển động rig nhanh, không zoom kéo dài 10 giây.
- **Âm thanh:** Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.
- **06:20–06:23 / Shot 20.01:** ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát.
- **06:23–06:27 / Shot 20.02:** OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây.
- **06:27–06:31 / Shot 20.03:** CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách.
- **06:31–06:35 / Shot 20.04:** Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật.
- **06:35–06:40 / Shot 20.05:** POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu.

## S21 · 06:40–07:00 · Sửa thay vì mơ
- **Nhịp dựng:** Match cut trên hành động kéo layer của Minh.
- **Âm thanh:** Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.
- **06:40–06:43 / Shot 21.01:** Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây.
- **06:43–06:47 / Shot 21.02:** OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột.
- **06:47–06:51 / Shot 21.03:** ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble.
- **06:51–06:55 / Shot 21.04:** CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra.
- **06:55–07:00 / Shot 21.05:** MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất.

## S22 · 07:00–07:20 · Bốn tuần sau
- **Nhịp dựng:** Montage ngắn nhiều cut, end một frame rõ portfolio.
- **Âm thanh:** Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.
- **07:00–07:03 / Shot 22.01:** Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay.
- **07:03–07:07 / Shot 22.02:** POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng.
- **07:07–07:11 / Shot 22.03:** OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột.
- **07:11–07:15 / Shot 22.04:** CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung.
- **07:15–07:20 / Shot 22.05:** Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật.

## S23 · 07:20–07:40 · Sự thật cần công bằng
- **Nhịp dựng:** Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động.
- **Âm thanh:** Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.
- **07:20–07:23 / Shot 23.01:** WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa.
- **07:23–07:27 / Shot 23.02:** MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại.
- **07:27–07:31 / Shot 23.03:** MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên.
- **07:31–07:35 / Shot 23.04:** OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động.
- **07:35–07:40 / Shot 23.05:** CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút.

## S24 · 07:40–08:00 · Kết: Cánh cửa
- **Nhịp dựng:** Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
- **Âm thanh:** Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.
- **07:40–07:43 / Shot 24.01:** Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây.
- **07:43–07:47 / Shot 24.02:** Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ.
- **07:47–07:51 / Shot 24.03:** Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm.
- **07:51–07:55 / Shot 24.04:** ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào.
- **07:55–08:00 / Shot 24.05:** Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s.

## Kiểm tra shot trước khi nhận bàn giao
1. Nhân vật không thoại: chỉ voice-over; không tạo miệng lip-sync vô cớ.
2. Ở các cảnh gấp (S03–S12, S14–S16, S19–S22), ít nhất 70% shot có hành động tay/chân/đầu/thân hoặc tương tác vật thể, không tính zoom camera.
3. Minh có ít nhất 8 loại hành động tái sử dụng: đi nhanh, ngồi xuống, đứng dậy, gõ phím, rê chuột, mở folder, lật sách, cầm điện thoại, chống trán, quay người, kéo ghế, viết bút.
4. Bàn, đèn, laptop, cốc và cửa sổ giữ vị trí nhất quán giữa các cảnh; không đổi quần áo tùy tiện.
5. Chữ trên màn hình đọc được, tối giản, dùng tiếng Việt; không tự xuất hiện nhãn tiến trình sản xuất.
6. Nhạc và SFX không át voice; S17–S18 có khoảng lặng chủ ý; S24 fade out 2 giây.

---

## PHẦN D. SHOTLIST JSON (DỮ LIỆU THỜI GIAN ĐỂ DỰNG)

Để lấy dữ liệu: đọc chính phần code block JSON này rồi lưu nội dung thành `shotlist.json`. Dùng các trường `start_seconds`, `end_seconds`, `camera_action`, `scene_edit`, `scene_sound`.

```json
{
  "project": "Người bận rộn nhưng không tiến bộ",
  "target_duration_seconds": 480,
  "fps": 30,
  "width": 1920,
  "height": 1080,
  "total_scenes": 24,
  "total_shots": 120,
  "note": "Thời điểm shot là bố cục tham chiếu; trong quá trình dựng phải ưu tiên căn chính xác với file lời dẫn đã thu. Cho phép 7:45–8:30, không tăng tốc giọng quá mức.",
  "shots": [
    {
      "scene": "S01",
      "shot": "S01-01",
      "start_seconds": 0,
      "end_seconds": 3,
      "duration_seconds": 3,
      "camera_action": "ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-02",
      "start_seconds": 3,
      "end_seconds": 7,
      "duration_seconds": 4,
      "camera_action": "OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-03",
      "start_seconds": 7,
      "end_seconds": 11,
      "duration_seconds": 4,
      "camera_action": "CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-04",
      "start_seconds": 11,
      "end_seconds": 15,
      "duration_seconds": 4,
      "camera_action": "Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S01",
      "shot": "S01-05",
      "start_seconds": 15,
      "end_seconds": 20,
      "duration_seconds": 5,
      "camera_action": "Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'",
      "scene_sound": "Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",
      "scene_edit": "Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ."
    },
    {
      "scene": "S02",
      "shot": "S02-01",
      "start_seconds": 20,
      "end_seconds": 23,
      "duration_seconds": 3,
      "camera_action": "CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-02",
      "start_seconds": 23,
      "end_seconds": 27,
      "duration_seconds": 4,
      "camera_action": "ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-03",
      "start_seconds": 27,
      "end_seconds": 31,
      "duration_seconds": 4,
      "camera_action": "MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-04",
      "start_seconds": 31,
      "end_seconds": 35,
      "duration_seconds": 4,
      "camera_action": "POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S02",
      "shot": "S02-05",
      "start_seconds": 35,
      "end_seconds": 40,
      "duration_seconds": 5,
      "camera_action": "Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt",
      "scene_sound": "Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",
      "scene_edit": "Match-on-action qua các cử động tay."
    },
    {
      "scene": "S03",
      "shot": "S03-01",
      "start_seconds": 40,
      "end_seconds": 43,
      "duration_seconds": 3,
      "camera_action": "ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-02",
      "start_seconds": 43,
      "end_seconds": 47,
      "duration_seconds": 4,
      "camera_action": "MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-03",
      "start_seconds": 47,
      "end_seconds": 51,
      "duration_seconds": 4,
      "camera_action": "CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-04",
      "start_seconds": 51,
      "end_seconds": 55,
      "duration_seconds": 4,
      "camera_action": "Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S03",
      "shot": "S03-05",
      "start_seconds": 55,
      "end_seconds": 60,
      "duration_seconds": 5,
      "camera_action": "OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học",
      "scene_sound": "Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",
      "scene_edit": "Whip pan từ đồng hồ đêm sang báo thức sáng."
    },
    {
      "scene": "S04",
      "shot": "S04-01",
      "start_seconds": 60,
      "end_seconds": 63,
      "duration_seconds": 3,
      "camera_action": "WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-02",
      "start_seconds": 63,
      "end_seconds": 67,
      "duration_seconds": 4,
      "camera_action": "OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-03",
      "start_seconds": 67,
      "end_seconds": 71,
      "duration_seconds": 4,
      "camera_action": "CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-04",
      "start_seconds": 71,
      "end_seconds": 75,
      "duration_seconds": 4,
      "camera_action": "Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S04",
      "shot": "S04-05",
      "start_seconds": 75,
      "end_seconds": 80,
      "duration_seconds": 5,
      "camera_action": "Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp",
      "scene_sound": "Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",
      "scene_edit": "L-cut âm thanh giữa các khu vực văn phòng."
    },
    {
      "scene": "S05",
      "shot": "S05-01",
      "start_seconds": 80,
      "end_seconds": 83,
      "duration_seconds": 3,
      "camera_action": "MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-02",
      "start_seconds": 83,
      "end_seconds": 87,
      "duration_seconds": 4,
      "camera_action": "ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-03",
      "start_seconds": 87,
      "end_seconds": 91,
      "duration_seconds": 4,
      "camera_action": "Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-04",
      "start_seconds": 91,
      "end_seconds": 95,
      "duration_seconds": 4,
      "camera_action": "Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S05",
      "shot": "S05-05",
      "start_seconds": 95,
      "end_seconds": 100,
      "duration_seconds": 5,
      "camera_action": "Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày",
      "scene_sound": "Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.",
      "scene_edit": "Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
    },
    {
      "scene": "S06",
      "shot": "S06-01",
      "start_seconds": 100,
      "end_seconds": 103,
      "duration_seconds": 3,
      "camera_action": "OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-02",
      "start_seconds": 103,
      "end_seconds": 107,
      "duration_seconds": 4,
      "camera_action": "ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-03",
      "start_seconds": 107,
      "end_seconds": 111,
      "duration_seconds": 4,
      "camera_action": "CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-04",
      "start_seconds": 111,
      "end_seconds": 115,
      "duration_seconds": 4,
      "camera_action": "POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S06",
      "shot": "S06-05",
      "start_seconds": 115,
      "end_seconds": 120,
      "duration_seconds": 5,
      "camera_action": "MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng",
      "scene_sound": "Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",
      "scene_edit": "Montage 0.7-1.2 giây/cut bên trong shot #4."
    },
    {
      "scene": "S07",
      "shot": "S07-01",
      "start_seconds": 120,
      "end_seconds": 123,
      "duration_seconds": 3,
      "camera_action": "Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-02",
      "start_seconds": 123,
      "end_seconds": 127,
      "duration_seconds": 4,
      "camera_action": "ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-03",
      "start_seconds": 127,
      "end_seconds": 131,
      "duration_seconds": 4,
      "camera_action": "MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-04",
      "start_seconds": 131,
      "end_seconds": 135,
      "duration_seconds": 4,
      "camera_action": "OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S07",
      "shot": "S07-05",
      "start_seconds": 135,
      "end_seconds": 140,
      "duration_seconds": 5,
      "camera_action": "CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác",
      "scene_sound": "Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",
      "scene_edit": "Smash cut bảng kế hoạch đầy đủ -> canvas trống."
    },
    {
      "scene": "S08",
      "shot": "S08-01",
      "start_seconds": 140,
      "end_seconds": 143,
      "duration_seconds": 3,
      "camera_action": "ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-02",
      "start_seconds": 143,
      "end_seconds": 147,
      "duration_seconds": 4,
      "camera_action": "CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-03",
      "start_seconds": 147,
      "end_seconds": 151,
      "duration_seconds": 4,
      "camera_action": "MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-04",
      "start_seconds": 151,
      "end_seconds": 155,
      "duration_seconds": 4,
      "camera_action": "Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S08",
      "shot": "S08-05",
      "start_seconds": 155,
      "end_seconds": 160,
      "duration_seconds": 5,
      "camera_action": "ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ",
      "scene_sound": "Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",
      "scene_edit": "Graphic match tick -> ô bản nháp trống."
    },
    {
      "scene": "S09",
      "shot": "S09-01",
      "start_seconds": 160,
      "end_seconds": 163,
      "duration_seconds": 3,
      "camera_action": "CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-02",
      "start_seconds": 163,
      "end_seconds": 167,
      "duration_seconds": 4,
      "camera_action": "ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-03",
      "start_seconds": 167,
      "end_seconds": 171,
      "duration_seconds": 4,
      "camera_action": "OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-04",
      "start_seconds": 171,
      "end_seconds": 175,
      "duration_seconds": 4,
      "camera_action": "WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S09",
      "shot": "S09-05",
      "start_seconds": 175,
      "end_seconds": 180,
      "duration_seconds": 5,
      "camera_action": "CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài",
      "scene_sound": "Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.",
      "scene_edit": "5 inserts động; giảm nhạc ở cuối."
    },
    {
      "scene": "S10",
      "shot": "S10-01",
      "start_seconds": 180,
      "end_seconds": 183,
      "duration_seconds": 3,
      "camera_action": "Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-02",
      "start_seconds": 183,
      "end_seconds": 187,
      "duration_seconds": 4,
      "camera_action": "POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-03",
      "start_seconds": 187,
      "end_seconds": 191,
      "duration_seconds": 4,
      "camera_action": "MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-04",
      "start_seconds": 191,
      "end_seconds": 195,
      "duration_seconds": 4,
      "camera_action": "Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S10",
      "shot": "S10-05",
      "start_seconds": 195,
      "end_seconds": 200,
      "duration_seconds": 5,
      "camera_action": "Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống",
      "scene_sound": "Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",
      "scene_edit": "Match-cut tin nhắn nhỏ che khuất mục tiêu lớn."
    },
    {
      "scene": "S11",
      "shot": "S11-01",
      "start_seconds": 200,
      "end_seconds": 203,
      "duration_seconds": 3,
      "camera_action": "OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-02",
      "start_seconds": 203,
      "end_seconds": 207,
      "duration_seconds": 4,
      "camera_action": "Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-03",
      "start_seconds": 207,
      "end_seconds": 211,
      "duration_seconds": 4,
      "camera_action": "Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-04",
      "start_seconds": 211,
      "end_seconds": 215,
      "duration_seconds": 4,
      "camera_action": "Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S11",
      "shot": "S11-05",
      "start_seconds": 215,
      "end_seconds": 220,
      "duration_seconds": 5,
      "camera_action": "Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa",
      "scene_sound": "Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.",
      "scene_edit": "Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật."
    },
    {
      "scene": "S12",
      "shot": "S12-01",
      "start_seconds": 220,
      "end_seconds": 223,
      "duration_seconds": 3,
      "camera_action": "Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-02",
      "start_seconds": 223,
      "end_seconds": 227,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-03",
      "start_seconds": 227,
      "end_seconds": 231,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-04",
      "start_seconds": 231,
      "end_seconds": 235,
      "duration_seconds": 4,
      "camera_action": "Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S12",
      "shot": "S12-05",
      "start_seconds": 235,
      "end_seconds": 240,
      "duration_seconds": 5,
      "camera_action": "CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng",
      "scene_sound": "Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.",
      "scene_edit": "Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
    },
    {
      "scene": "S13",
      "shot": "S13-01",
      "start_seconds": 240,
      "end_seconds": 243,
      "duration_seconds": 3,
      "camera_action": "Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-02",
      "start_seconds": 243,
      "end_seconds": 247,
      "duration_seconds": 4,
      "camera_action": "OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-03",
      "start_seconds": 247,
      "end_seconds": 251,
      "duration_seconds": 4,
      "camera_action": "ECU lật trang nhanh: các checkbox nhỏ đều được tích",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-04",
      "start_seconds": 251,
      "end_seconds": 255,
      "duration_seconds": 4,
      "camera_action": "CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S13",
      "shot": "S13-05",
      "start_seconds": 255,
      "end_seconds": 260,
      "duration_seconds": 5,
      "camera_action": "Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành",
      "scene_sound": "Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",
      "scene_edit": "Match cut trang sổ -> màn hình folder."
    },
    {
      "scene": "S14",
      "shot": "S14-01",
      "start_seconds": 260,
      "end_seconds": 263,
      "duration_seconds": 3,
      "camera_action": "ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-02",
      "start_seconds": 263,
      "end_seconds": 267,
      "duration_seconds": 4,
      "camera_action": "CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-03",
      "start_seconds": 267,
      "end_seconds": 271,
      "duration_seconds": 4,
      "camera_action": "Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-04",
      "start_seconds": 271,
      "end_seconds": 275,
      "duration_seconds": 4,
      "camera_action": "MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S14",
      "shot": "S14-05",
      "start_seconds": 275,
      "end_seconds": 280,
      "duration_seconds": 5,
      "camera_action": "Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở",
      "scene_sound": "Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.",
      "scene_edit": "Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
    },
    {
      "scene": "S15",
      "shot": "S15-01",
      "start_seconds": 280,
      "end_seconds": 283,
      "duration_seconds": 3,
      "camera_action": "POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-02",
      "start_seconds": 283,
      "end_seconds": 287,
      "duration_seconds": 4,
      "camera_action": "OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-03",
      "start_seconds": 287,
      "end_seconds": 291,
      "duration_seconds": 4,
      "camera_action": "CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-04",
      "start_seconds": 291,
      "end_seconds": 295,
      "duration_seconds": 4,
      "camera_action": "Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S15",
      "shot": "S15-05",
      "start_seconds": 295,
      "end_seconds": 300,
      "duration_seconds": 5,
      "camera_action": "ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt",
      "scene_sound": "Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",
      "scene_edit": "Cut vào ánh sáng màn hình lạnh hơn."
    },
    {
      "scene": "S16",
      "shot": "S16-01",
      "start_seconds": 300,
      "end_seconds": 303,
      "duration_seconds": 3,
      "camera_action": "Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-02",
      "start_seconds": 303,
      "end_seconds": 307,
      "duration_seconds": 4,
      "camera_action": "OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-03",
      "start_seconds": 307,
      "end_seconds": 311,
      "duration_seconds": 4,
      "camera_action": "CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-04",
      "start_seconds": 311,
      "end_seconds": 315,
      "duration_seconds": 4,
      "camera_action": "POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S16",
      "shot": "S16-05",
      "start_seconds": 315,
      "end_seconds": 320,
      "duration_seconds": 5,
      "camera_action": "MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây",
      "scene_sound": "Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.",
      "scene_edit": "Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
    },
    {
      "scene": "S17",
      "shot": "S17-01",
      "start_seconds": 320,
      "end_seconds": 323,
      "duration_seconds": 3,
      "camera_action": "Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-02",
      "start_seconds": 323,
      "end_seconds": 327,
      "duration_seconds": 4,
      "camera_action": "ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-03",
      "start_seconds": 327,
      "end_seconds": 331,
      "duration_seconds": 4,
      "camera_action": "CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-04",
      "start_seconds": 331,
      "end_seconds": 335,
      "duration_seconds": 4,
      "camera_action": "OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S17",
      "shot": "S17-05",
      "start_seconds": 335,
      "end_seconds": 340,
      "duration_seconds": 5,
      "camera_action": "Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở",
      "scene_sound": "Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.",
      "scene_edit": "Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
    },
    {
      "scene": "S18",
      "shot": "S18-01",
      "start_seconds": 340,
      "end_seconds": 343,
      "duration_seconds": 3,
      "camera_action": "CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-02",
      "start_seconds": 343,
      "end_seconds": 347,
      "duration_seconds": 4,
      "camera_action": "Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-03",
      "start_seconds": 347,
      "end_seconds": 351,
      "duration_seconds": 4,
      "camera_action": "MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-04",
      "start_seconds": 351,
      "end_seconds": 355,
      "duration_seconds": 4,
      "camera_action": "ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S18",
      "shot": "S18-05",
      "start_seconds": 355,
      "end_seconds": 360,
      "duration_seconds": 5,
      "camera_action": "Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe",
      "scene_sound": "Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",
      "scene_edit": "Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều."
    },
    {
      "scene": "S19",
      "shot": "S19-01",
      "start_seconds": 360,
      "end_seconds": 363,
      "duration_seconds": 3,
      "camera_action": "Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-02",
      "start_seconds": 363,
      "end_seconds": 367,
      "duration_seconds": 4,
      "camera_action": "CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-03",
      "start_seconds": 367,
      "end_seconds": 371,
      "duration_seconds": 4,
      "camera_action": "MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-04",
      "start_seconds": 371,
      "end_seconds": 375,
      "duration_seconds": 4,
      "camera_action": "POV mở file thiết kế duy nhất, bỏ các tab không cần",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S19",
      "shot": "S19-05",
      "start_seconds": 375,
      "end_seconds": 380,
      "duration_seconds": 5,
      "camera_action": "CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối",
      "scene_sound": "Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",
      "scene_edit": "Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác."
    },
    {
      "scene": "S20",
      "shot": "S20-01",
      "start_seconds": 380,
      "end_seconds": 383,
      "duration_seconds": 3,
      "camera_action": "ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-02",
      "start_seconds": 383,
      "end_seconds": 387,
      "duration_seconds": 4,
      "camera_action": "OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-03",
      "start_seconds": 387,
      "end_seconds": 391,
      "duration_seconds": 4,
      "camera_action": "CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-04",
      "start_seconds": 391,
      "end_seconds": 395,
      "duration_seconds": 4,
      "camera_action": "Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S20",
      "shot": "S20-05",
      "start_seconds": 395,
      "end_seconds": 400,
      "duration_seconds": 5,
      "camera_action": "POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu",
      "scene_sound": "Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.",
      "scene_edit": "Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
    },
    {
      "scene": "S21",
      "shot": "S21-01",
      "start_seconds": 400,
      "end_seconds": 403,
      "duration_seconds": 3,
      "camera_action": "Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-02",
      "start_seconds": 403,
      "end_seconds": 407,
      "duration_seconds": 4,
      "camera_action": "OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-03",
      "start_seconds": 407,
      "end_seconds": 411,
      "duration_seconds": 4,
      "camera_action": "ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-04",
      "start_seconds": 411,
      "end_seconds": 415,
      "duration_seconds": 4,
      "camera_action": "CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S21",
      "shot": "S21-05",
      "start_seconds": 415,
      "end_seconds": 420,
      "duration_seconds": 5,
      "camera_action": "MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất",
      "scene_sound": "Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",
      "scene_edit": "Match cut trên hành động kéo layer của Minh."
    },
    {
      "scene": "S22",
      "shot": "S22-01",
      "start_seconds": 420,
      "end_seconds": 423,
      "duration_seconds": 3,
      "camera_action": "Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-02",
      "start_seconds": 423,
      "end_seconds": 427,
      "duration_seconds": 4,
      "camera_action": "POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-03",
      "start_seconds": 427,
      "end_seconds": 431,
      "duration_seconds": 4,
      "camera_action": "OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-04",
      "start_seconds": 431,
      "end_seconds": 435,
      "duration_seconds": 4,
      "camera_action": "CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S22",
      "shot": "S22-05",
      "start_seconds": 435,
      "end_seconds": 440,
      "duration_seconds": 5,
      "camera_action": "Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật",
      "scene_sound": "Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.",
      "scene_edit": "Montage ngắn nhiều cut, end một frame rõ portfolio."
    },
    {
      "scene": "S23",
      "shot": "S23-01",
      "start_seconds": 440,
      "end_seconds": 443,
      "duration_seconds": 3,
      "camera_action": "WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-02",
      "start_seconds": 443,
      "end_seconds": 447,
      "duration_seconds": 4,
      "camera_action": "MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-03",
      "start_seconds": 447,
      "end_seconds": 451,
      "duration_seconds": 4,
      "camera_action": "MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-04",
      "start_seconds": 451,
      "end_seconds": 455,
      "duration_seconds": 4,
      "camera_action": "OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S23",
      "shot": "S23-05",
      "start_seconds": 455,
      "end_seconds": 460,
      "duration_seconds": 5,
      "camera_action": "CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút",
      "scene_sound": "Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.",
      "scene_edit": "Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
    },
    {
      "scene": "S24",
      "shot": "S24-01",
      "start_seconds": 460,
      "end_seconds": 463,
      "duration_seconds": 3,
      "camera_action": "Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-02",
      "start_seconds": 463,
      "end_seconds": 467,
      "duration_seconds": 4,
      "camera_action": "Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-03",
      "start_seconds": 467,
      "end_seconds": 471,
      "duration_seconds": 4,
      "camera_action": "Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-04",
      "start_seconds": 471,
      "end_seconds": 475,
      "duration_seconds": 4,
      "camera_action": "ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    },
    {
      "scene": "S24",
      "shot": "S24-05",
      "start_seconds": 475,
      "end_seconds": 480,
      "duration_seconds": 5,
      "camera_action": "Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s",
      "scene_sound": "Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",
      "scene_edit": "Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend)."
    }
  ]
}
```

---

## PHẦN E. SHOTLIST CSV (BẢN ĐỐI CHIẾU)

```csv
scene,shot,start_seconds,end_seconds,duration_seconds,camera_action,scene_sound,scene_edit
S01,S01-01,0,3,3,ECU đồng hồ 23:48: kim giây bật ba nhịp; snap zoom 12% rồi dừng,"Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-02,3,7,4,"OTS laptop: Minh gõ phím nhanh, bàn tay chuyển qua chuột, 5 checkbox được tích liên tiếp","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-03,7,11,4,"CU mặt Minh: chớp mắt, dụi trán, nhìn từ màn hình sang cuốn sổ còn mở","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-04,11,15,4,"Top-down checklist: lịch dày đặc các ô đỏ; mục 'HỒ SƠ NĂNG LỰC' vẫn trống, tay gập sổ","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S01,S01-05,15,20,5,"Wide góc phòng: Minh nhỏ giữa bàn làm việc; camera dolly-out nhanh 8%, freeze 0.4 giây ở 'đứng yên'","Gấp, căng. Âm điện tử ticking; bass hit tại 'đứng yên'.",Jump cut có nhịp 3-4 giây; cú match-cut đồng hồ.
S02,S02-01,20,23,3,"CU cổ tay gõ phím, ngón tay di chuyển theo bàn phím; camera trượt ngang 20cm","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-02,23,27,4,ECU cốc cà phê nguội: giọt nước bám; tay Minh đẩy cốc sang bên,"Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-03,27,31,4,"MS góc ba phần tư: Minh xoay cổ, căng vai rồi quay lại bàn làm việc","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-04,31,35,4,"POV màn hình 5 tab: chuột lần lượt đóng tab, không dùng hiệu ứng danh sách ảo quá lâu","Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S02,S02-05,35,40,5,Profile MS Minh khép laptop mạnh vừa phải; màn hình tối phản chiếu đôi mắt mệt,"Bàn phím, quạt laptop, cà phê chạm mặt bàn; tiếng màn hình tắt.",Match-on-action qua các cử động tay.
S03,S03-01,40,43,3,ECU 06:30: báo thức rung; tay Minh quơ chạm nút tắt trong 0.3 giây,"Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-02,43,47,4,"MS toàn thân Minh bật khỏi giường, bước nhanh về phía bàn, tóc và áo có follow-through","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-03,47,51,4,"CU tay quơ lấy balo/điện thoại, xoay người và đi khỏi cửa","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-04,51,55,4,"Tracking side-view: Minh sải bước nhanh trên vỉa hè, người phía xa parallax","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S03,S03-05,55,60,5,"OTS trên xe buýt: tai nghe, clip học online phát, ngón tay nhấn lưu lại bài học","Báo thức sắc, giày chạm đất, tiếng khóa cửa, xe xa; nhạc gõ nhịp.",Whip pan từ đồng hồ đêm sang báo thức sáng.
S04,S04-01,60,63,3,"WS văn phòng: Minh bước vội qua đồng nghiệp, kéo ghế ngồi trong một động tác","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-02,63,67,4,"OTS bàn phím: Minh sửa báo cáo, nhấn lưu, chuyển cửa sổ bằng phím tắt","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-03,67,71,4,"CU điện thoại rung; Minh nhận và lướt báo việc mới, ngón tay di chuyển rõ","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-04,71,75,4,"Side tracking Minh đi qua phòng họp, đặt tập giấy lên bàn rồi kéo ghế ngồi","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S04,S04-05,75,80,5,"Top-down lịch kín màu; camera xoay 8 độ, ô mục tiêu riêng bị che bởi lịch họp","Âm tin nhắn ngắn, tiếng kéo ghế, trao đổi văn phòng không rõ lời; nhạc pulse.",L-cut âm thanh giữa các khu vực văn phòng.
S05,S05-01,80,83,3,"MS Minh ngồi làm việc, liếc sang tấm hình tham khảo thiết kế trên bảng ghim","Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-02,83,87,4,ECU folder 'HỒ SƠ NĂNG LỰC' được tạo mới bằng cú click dứt khoát,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-03,87,91,4,"Push-in vào folder mở; hai file trắng hiện ra, con trỏ dừng một nhịp","Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-04,91,95,4,Thought bubble 2.5D: Minh phiên bản tương lai đang đi nhanh vào studio thiết kế riêng,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S05,S05-05,95,100,5,Return MS: Minh mỉm cười bằng đôi mắt và đóng folder để quay lại việc thường ngày,"Tiếng thành phố xa dần; nhạc hy vọng nhỏ, ánh vàng trong thought bubble.","Iris / reveal từ màn hình làm việc sang vùng tưởng tượng, không chuyển style."
S06,S06-01,100,103,3,"OTS Minh kéo ghế ngồi, click khóa học, tay chống cằm một nhịp rồi dùng bút ghi","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-02,103,107,4,"ECU tab mới bật ra, Minh kéo chuột nhanh từ link này sang link khác","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-03,107,111,4,"CU mắt Minh di chuyển trái-phải liên tục, bàn tay bấm next lesson","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-04,111,115,4,"POV 12 tab mọc liên tục; 4 micro-cut 1 giây, một ngăn folder nảy theo nhịp","Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S06,S06-05,115,120,5,MS Minh gập sổ 'HỌC XONG' tự hào; phía sau canvas sản phẩm vẫn trắng,"Chuột click, video tua, notification nhỏ; tăng nhịp trống nhẹ.",Montage 0.7-1.2 giây/cut bên trong shot #4.
S07,S07-01,120,123,3,"Top-down bàn: hai tay Minh xếp giấy, đặt sticky notes vào cột rất nhanh","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-02,123,127,4,"ECU bàn phím: gõ đổi tên folder; tay kéo thả file thật, không bay tự động","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-03,127,131,4,"MS Minh đẩy ghế, đứng dậy chỉnh bảng lộ trình treo tường rồi ngồi xuống","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-04,131,135,4,"OTS phần mềm thiết kế mở; canvas trống, chuột lượn ba lần không chọn","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S07,S07-05,135,140,5,"CU mắt lo lắng của Minh; tay rút lại khỏi chuột, click vào một bài hướng dẫn khác","Giấy kéo soạt, click đổi tên folder, ticking; nhạc tối dần.",Smash cut bảng kế hoạch đầy đủ -> canvas trống.
S08,S08-01,140,143,3,"ECU email: Minh chọn đánh dấu đã đọc, tay chuyển trackpad dứt khoát","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-02,143,147,4,"CU giấy kế hoạch: tích 'dọn bàn', 'xem tài liệu', 'lập kế hoạch' mỗi 0.4 giây","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-03,147,151,4,"MS Minh vươn vai hài lòng và xoay ghế nửa vòng, rồi liếc đến canvas trống","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-04,151,155,4,"Split-screen: một bên nút tick nhảy nhanh, một bên Minh cầm bút do dự","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S08,S08-05,155,160,5,"ECU tờ giấy trắng, bút hạ xuống rồi nhấc lên; camera đứng 0.5 giây ở điểm sợ","Click checkbox lặp 3 lần; âm click cuối cùng rỗng, âm trầm tăng.",Graphic match tick -> ô bản nháp trống.
S09,S09-01,160,163,3,CU tờ ghi 'HỒ SƠ: 60 PHÚT' Minh đặt vào 19:00 trên lịch,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-02,163,167,4,ECU điện thoại rung; tay Minh chụp điện thoại và xoay cổ nhìn ngay,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-03,167,171,4,"OTS Minh mở bảng việc gấp, kéo thả ba file, gõ bàn phím liên tục",Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-04,171,175,4,"WS đồng hồ chạy nhanh, ánh cửa sổ chuyển vàng -> đêm; Minh đổi tư thế làm việc",Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S09,S09-05,175,180,5,CU tay Minh dùng bút dời tờ ghi '60 PHÚT' qua cột 'NGÀY MAI' rồi thở dài,Thông báo chồng lớp có giới hạn; âm click chuyển sang mệt mỏi.,5 inserts động; giảm nhạc ở cuối.
S10,S10-01,180,183,3,Top-down hai thẻ: 'GẤP' bé nhưng nhấp nháy; 'QUAN TRỌNG' lớn đứng yên,"Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-02,183,187,4,POV Minh vươn tay bấm thẻ GẤP; thẻ QUAN TRỌNG dịch ra sau theo chiều sâu,"Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-03,187,191,4,"MS Minh chạy vội giữa hai màn hình, thay giấy liên tục, áo và tay hoạt hình rõ","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-04,191,195,4,"Close-up bảng hiển thị 7 việc nhỏ hoàn tất, dự án chính 0%","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S10,S10-05,195,200,5,"Dolly back: lớp thông báo lấp đầy tiền cảnh rồi tan hết, để lại folder trống","Âm trống dồn, tiếng tick nhấp; giảm còn tiếng một cảnh quan trọng.",Match-cut tin nhắn nhỏ che khuất mục tiêu lớn.
S11,S11-01,200,203,3,"OTS Minh vẽ hai hình khối, chuột kéo thực sự trên canvas",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-02,203,207,4,"Whip pan CU điện thoại sáng; Minh nghiêng người với tay nhận, đầu xoay ngay",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-03,207,211,4,Jump cut POV email; tay gõ trả lời rất nhanh rồi ấn gửi,Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-04,211,215,4,"Whip pan trở lại màn thiết kế; mắt Minh đảo, con trỏ đứng yên 0.6 giây",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S11,S11-05,215,220,5,"Profile MS Minh vuốt trán, nghiêng người rồi thử vẽ lại từ đầu; layer lỡ tay bị xóa",Âm ping ngắt quãng và thiết kế đang làm; không quá nhiều tiếng hiệu ứng.,Whip-pan hai lần; mỗi lần phải quay lại tay nhân vật.
S12,S12-01,220,223,3,"Top-down lịch tháng 1 Minh gạch ngày, lật trang bằng tay có va chạm","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-02,223,227,4,"Same-angle MS tháng 2: Minh vừa uống cà phê vừa mở laptop, trời đổi sáng-tối","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-03,227,231,4,"Same-angle MS tháng 3: Minh gõ máy rồi đổi tư thế, màn hình bật-tắt","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-04,231,235,4,"Same-angle MS tháng 5: Minh xếp sách, tháo tai nghe, chớp mắt mệt mỏi","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S12,S12-05,235,240,5,"CU tháng 6 folder vẫn hiện 0 dự án, ngón tay Minh chậm lại rồi ngừng","Tiếng giấy lật có nhịp, 3 chu kỳ ngày đêm, bass note cuối.","Time-lapse có nhân vật diễn động tác khác nhau, KHÔNG đứng im."
S13,S13-01,240,243,3,"Low angle cạnh bàn: Minh cúi nhặt cuốn sổ rơi khỏi kệ, tay với xuống","Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-02,243,247,4,"OTS Minh mở sổ, ngón tay lần theo hàng mục tiêu năm thiết kế","Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-03,247,251,4,ECU lật trang nhanh: các checkbox nhỏ đều được tích,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-04,251,255,4,CU đôi mắt Minh chững lại khi đọc mục tiêu lớn chưa tích,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S13,S13-05,255,260,5,Top-down một mục tiêu lớn ở trang cuối; bút chưa từng chạm vào ô hoàn thành,"Tiếng giở trang, nhạc tối giản; một nhịp im trước câu kết.",Match cut trang sổ -> màn hình folder.
S14,S14-01,260,263,3,ECU thông báo dự án thiết kế quán cà phê bật lên ở góc màn hình,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-02,263,267,4,CU Minh ngẩng đầu nhanh; ánh mắt mở lớn và vai duỗi thẳng,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-03,267,271,4,Thought bubble: ba bảng quảng cáo quán cà phê lật ra theo chiều sâu 2.5D,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-04,271,275,4,"MS Minh quay ghế về màn, kéo folder hồ sơ năng lực vào giữa màn hình","Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S14,S14-05,275,280,5,Push-in con trỏ nhấp đúp folder; nhạc đứt ngay khi mở,"Nhạc mở rộng, âm tin nhắn tích cực, beat tăng nhẹ.","Reveal ánh vàng trong màn hình, cut nhanh cuối đoạn."
S15,S15-01,280,283,3,"POV thư mục toàn file tham khảo, 3 bản nháp chưa hoàn thành","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-02,283,287,4,"OTS Minh kéo chuột chọn 'portfolio_final' nhưng file không tồn tại, tay khựng","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-03,287,291,4,"CU mắt Minh nhìn lại hàng tên file, chớp liên tục rồi cúi xuống","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-04,291,295,4,"Wide phòng tối: Minh bật cả hai màn hình, kéo cửa sổ tìm kiếm qua lại","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S15,S15-05,295,300,5,"ECU Minh thả tay khỏi chuột; con trỏ nằm trên folder trống, ánh sáng tắt bớt","Âm click khô, khoảng lặng 0.5s, tiếng quạt máy.",Cut vào ánh sáng màn hình lạnh hơn.
S16,S16-01,300,303,3,Top-down tay Minh phác khung poster trên giấy 2-3 đường bút thật,"Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-02,303,307,4,"OTS Minh đặt hình vào canvas, kéo lệch rồi Ctrl+Z, nhịp nhanh","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-03,307,311,4,"CU đồng hồ chuyển 20:00 -> 22:00; Minh tháo áo khoác, lăn vai mệt","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-04,311,315,4,POV tin 'DỰ ÁN ĐÃ CÓ NGƯỜI LÀM' hiện dưới dạng giao diện không có bóng thoại,"Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S16,S16-05,315,320,5,"MS Minh đứng khựng, lùi ghế rồi ngồi xuống chậm hơn nhịp chung 0.7 giây","Đồng hồ thúc giục, âm bàn phím, một tiếng thông báo kết thúc.","Montage thiết kế cố gắng thật nhưng lúng túng, không tự động AI hoàn thành."
S17,S17-01,320,323,3,"Wide 5s: Minh ngồi bất động tương đối nhưng vẫn thở, bàn tay thả khỏi bàn",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-02,323,327,4,"ECU 3s: mười hai tab học, cuốn sổ và kế hoạch nối nhau bằng 3 flash cut 1s",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-03,327,331,4,"CU 4s: tay Minh chạm sổ ghi kế hoạch, vuốt qua các dấu tích",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-04,331,335,4,"OTS 4s: màn hình folder sản phẩm ít, Minh cầm đầu bằng một tay",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S17,S17-05,335,340,5,"Slow push 4s CU đôi mắt rũ xuống; không tắt mọi chuyển động, giữ chuyển động hít thở",Nhạc gần như tắt; tiếng máy tính và 1 nốt piano xa.,"Shot dài hơn, chỉ tại đây cho phép 5-6 giây để có cao trào."
S18,S18-01,340,343,3,"CU tay Minh mở khóa học rồi do dự, ngón tay dừng cách click 1cm","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-02,343,347,4,"Split-screen: một bên bảng kế hoạch hoàn mỹ, bên kia bản vẽ lỗi thật","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-03,347,351,4,"MS Minh đứng dậy, hai bước đến bảng kế hoạch rồi quay phắt lại laptop","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-04,351,355,4,ECU Minh xóa một ghi chú 'HỌC THÊM' và đặt bút lên bản thiết kế dang dở,"Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S18,S18-05,355,360,5,"Wide bóng Minh trước cánh cửa tưởng tượng, ánh sáng vàng lọt qua khe","Bass nhẹ, rồi âm piano cô độc; ánh sáng co hẹp.",Hình ẩn dụ cánh cửa rất ngắn không thần bí hóa quá nhiều.
S19,S19-01,360,363,3,"Top-down Minh vò bớt 4 tờ kế hoạch, ném vào giỏ trong một động tác","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-02,363,367,4,"CU tay viết '1 KẾT QUẢ HÔM NAY', gạch chân đúng một nét","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-03,367,371,4,"MS Minh dán giấy bên mép màn hình, bước lùi kiểm tra rồi ngồi vào ghế","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-04,371,375,4,"POV mở file thiết kế duy nhất, bỏ các tab không cần","Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S19,S19-05,375,380,5,CU đôi mắt Minh tập trung; tay đặt đúng lên chuột và bắt đầu kéo hình khối,"Âm xé giấy, tiếng bút; nhạc lạc quan có tiết chế.",Chuyển từ chật hẹp sang bố cục sạch; 4 cuts rõ động tác.
S20,S20-01,380,383,3,"ECU đồng hồ bắt đầu 45:00, ngón tay Minh chạm start dứt khoát","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-02,383,387,4,"OTS Minh tạo bố cục, tay chuột kéo 3 hình ảnh vào frame trong 3 giây","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-03,387,391,4,CU ánh mắt chuyển từ mẫu sang canvas; nhân vật nghiêng đầu rồi chỉnh khoảng cách,"Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-04,391,395,4,"Side MS Minh thử màu, nhấn Undo, chọn lại; hai tay và vai chuyển thật","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S20,S20-05,395,400,5,"POV nút export, thanh render chạy hợp lý, file 'poster_01.png' được lưu","Nhịp đều 105 BPM, click theo hành động; âm xác nhận xuất file.","Các chuyển động rig nhanh, không zoom kéo dài 10 giây."
S21,S21-01,400,403,3,"Wide Minh về nhà, tháo balo, đặt lên móc rồi ngồi xuống trong 2 giây","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-02,403,407,4,"OTS hai phiên bản hình xuất hiện, Minh kéo before/after bằng chuột","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-03,407,411,4,"ECU phản hồi trên màn hình: 'CHỮ KHÓ ĐỌC', 'TƯƠNG PHẢN THẤP' không có chat bubble","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-04,411,415,4,"CU tay Minh thay font, tăng contrast, chỉnh lề; nhân vật nghiêng đầu kiểm tra","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S21,S21-05,415,420,5,"MS Minh thả lỏng vai, lưu file v2; cốc cà phê vẫn ở vị trí đồng nhất","Nhạc êm nhưng có rhythm, tiếng bàn phím rõ, chuông nhỏ phản hồi.",Match cut trên hành động kéo layer của Minh.
S22,S22-01,420,423,3,"Top-down lịch 4 tuần Minh gạch từng tuần bằng tay, không chỉ hiệu ứng tự bay","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-02,423,427,4,"POV folder mở hiện thiết kế 1, 2, 3: mỗi sản phẩm có thumbnail riêng","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-03,427,431,4,"OTS Minh kéo ba sản phẩm vào trang portfolio, chỉnh kích thước bằng chuột","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-04,431,435,4,"CU Minh nhìn lại file đầu, bật bảng so sánh tiến bộ; mắt đổi sang tập trung","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S22,S22-05,435,440,5,"Wide trở lại bàn cũ, vẫn đồ đạc cũ nhưng folder portfolio hiện ba sản phẩm thật","Nhạc hơi nâng, ba âm lưu file, không tiếng pháo hay ăn mừng lố.","Montage ngắn nhiều cut, end một frame rõ portfolio."
S23,S23-01,440,443,3,"WS một người làm ca tối đang đóng cửa tiệm, hành động tắt đèn và khóa cửa","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-02,443,447,4,"MS nhân vật phụ chăm sóc người thân bằng hành động đặt cốc nước, không thoại","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-03,447,451,4,"MS Minh nằm nghỉ trên giường sau ca dài, mắt nhắm, thở tự nhiên","Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-04,451,455,4,OTS Minh khoanh tròn 1 ô thời gian nhỏ thực sự có thể chủ động,"Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S23,S23-05,455,460,5,CU câu hỏi trên giấy 'QUAN TRỌNG HAY CHỈ DỄ TÍCH?' xuất hiện bằng nét bút,"Nhạc giữ mức thấp, nhịp thong thả hơn 10% nhưng không ì ạch.","Cắt cảnh minh họa rất ngắn, không áp đặt giá trị người lao động."
S24,S24-01,460,463,3,"Side profile Minh chạy nhanh trên máy chạy bộ, chân vận động rõ 2 bước/giây","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-02,463,467,4,"Top-down băng máy chạy, mồ hôi và bước chân chuyển động; camera giữ đứng yên để thấy vẫn cùng chỗ","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-03,467,471,4,"Smash cut Minh rời máy chạy, đứng trước cánh cửa sáng, với tay tới nắm","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-04,471,475,4,"ECU bàn tay thật sự xoay nắm cửa, cánh cửa mở dần, ánh sáng tràn vào","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).
S24,S24-05,475,480,5,"Match cut bàn làm việc 23:48 cũ nhưng folder có sản phẩm; camera pull back ngắn, fade black 2s","Motif máy chạy bộ, nhạc lắng xuống; piano kết + 2s room tone.",Cắt hình ẩn dụ rồi trở lại đúng góc mở đầu (visual bookend).

```

---

## PHẦN F. NGUỒN NGHIÊN CỨU

# Nguồn nghiên cứu dùng trong kịch bản

Các dẫn chứng liên quan thói quen phân bổ thời gian và chuyển đổi nhiệm vụ; chúng không thể chứng minh mọi người bận rộn đều không tiến bộ.

1. Zhu, Meng; Yang, Yang; Hsee, Christopher K. (2018). **The Mere Urgency Effect**. *Journal of Consumer Research*, 45(3), 673–690. DOI: https://doi.org/10.1093/jcr/ucy008. Minh họa việc đôi khi ưu tiên việc trông có vẻ khẩn cấp hơn việc quan trọng.
2. Mills et al. (2026). **Brief Commentary: An Independent Replication Study of the Mere Urgency Effect**. *Journal of Consumer Research*. DOI: https://doi.org/10.1093/jcr/ucag026. Một thử nghiệm độc lập trên 2.374 người ghi nhận hiệu ứng vẫn tồn tại trong các thiết kế được kiểm tra, dù yếu hơn khi bổ sung biện pháp kiểm soát một số yếu tố nhiễu.
3. Sophie Leroy (2009). **Why Is It So Hard to Do My Work? The Challenge of Attention Residue When Switching Between Work Tasks**. *Organizational Behavior and Human Decision Processes*, 109(2), 168–181. DOI: https://doi.org/10.1016/j.obhdp.2009.04.002. Liên quan sự chú ý còn lại ở nhiệm vụ trước khi chuyển việc.

**Lưu ý sản xuất:** không hiện số liệu bịa; không biến nghiên cứu thành lời khẳng định tuyệt đối về nhân vật hư cấu Minh. Có thể ghi các nguồn này trong phần mô tả YouTube.

---

## PHẦN G. HAI ẢNH GỐC THAM CHIẾU — DỮ LIỆU NHÚNG

Đây là hai ảnh tham chiếu **đúng phong cách người dùng đã chốt**, được nén kích thước để dễ chuyển giao trong một file văn bản. Codex phải trích xuất bằng Python ở phần đầu, KHÔNG cho model đọc chuỗi base64 và KHÔNG coi ảnh gốc như các frame sẵn.

### thumbnail_style_mac_ket.jpg

SHA-256: `9ed0dd90e38a83e26323db4b8f30c173d0df7bdeaac27fde09fc6abb6bf6a3ef` — 84471 bytes

[Extracted JPEG asset]

### thumbnail_style_tinh_di.jpg

SHA-256: `e18d5944f310bef135e5a7e1a889daaf73d930abfd7aaa5b2d71f31a6de25e1d` — 61304 bytes

[Extracted JPEG asset]
