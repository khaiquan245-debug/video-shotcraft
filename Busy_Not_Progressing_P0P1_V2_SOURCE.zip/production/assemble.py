from pathlib import Path
import json,wave,subprocess,hashlib,re
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'output';idx=json.loads((B/'manifests/film.json').read_text());assert len(idx['scenes'])==24 and idx['shots']==120
for name,ch in [('mix',2),('voice',1)]:
 with wave.open(str(O/(name+'-full.wav')),'wb')as out:
  out.setnchannels(ch);out.setsampwidth(2);out.setframerate(48000)
  for s in idx['scenes']:
   p=B/f'scenes/{s["scene"]:02}/{name}.wav'
   with wave.open(str(p))as r:assert r.getnframes()==s['frames']*1600;out.writeframes(r.readframes(r.getnframes()))
assert hashlib.sha256((O/'voice-full.wav').read_bytes()).hexdigest()==hashlib.sha256((B/'audio/voice-full.wav').read_bytes()).hexdigest(),'Narration changed'
lines=[]
for s in idx['scenes']:
 n=s['scene'];p=B/f'scenes/{n:02}/picture.mp4';assert(B/f'scenes/{n:02}/rendered.json').exists()
 h=hashlib.sha256()
 for f in ['production/render.mjs','production/visuals.mjs','characters/rig.mjs','backgrounds/locations.mjs','backgrounds/bus.mjs',f'manifests/scene-{n:02}.json']:h.update((B/f).read_bytes())
 assert json.loads((B/f'scenes/{n:02}/rendered.json').read_text())['sourceHash']==h.hexdigest(),f'Stale render scene{n}'
 q=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(p)]))['streams'][0];assert q['r_frame_rate']=='30/1'and int(q['nb_frames'])==s['frames'];lines.append("file '"+p.as_posix()+"'")
(O/'concat.txt').write_text('\n'.join(lines));p=O/'Busy_Not_Progressing_P0P1_V2_1080p.mp4'
subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(O/'concat.txt'),'-i',str(O/'mix-full.wav'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','medium','-crf','17','-threads','8','-pix_fmt','yuv420p','-af','loudnorm=I=-14:TP=-2.3:LRA=8','-ar','48000','-c:a','aac','-b:a','192k','-movflags','+faststart',str(p)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_packets','-show_streams','-show_format','-of','json',str(p)]));v=next(s for s in info['streams']if s['codec_type']=='video');a=next(s for s in info['streams']if s['codec_type']=='audio');assert v['width']==1920 and v['height']==1080 and v['r_frame_rate']=='30/1'and int(v['nb_read_packets'])==idx['frames'];assert v['pix_fmt']=='yuv420p'and v['codec_name']=='h264'and a['codec_name']=='aac';assert 465<=float(info['format']['duration'])<=510
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],stderr=open(B/'logs/final-decode.log','w'),check=True)
r=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vn','-af','ebur128=peak=true','-f','null','-'],stderr=subprocess.PIPE,text=True,check=True);(B/'qa/loudness.txt').write_text(r.stderr);summary=r.stderr.rsplit('Summary:',1)[-1];lufs=float(re.search(r'I:\s*(-?[\d.]+) LUFS',summary)[1]);peak=float(re.search(r'Peak:\s*(-?[\d.]+) dBFS',summary)[1]);assert -14.5<=lufs<=-13.5 and peak<=-1,(lufs,peak)
with wave.open(str(O/'voice-full.wav'))as w:x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
rms=np.sqrt(np.mean(x[:len(x)//480*480].reshape(-1,480)**2,axis=1));run=longest=0
for quiet in rms<.0025:run=run+1 if quiet else 0;longest=max(longest,run)
assert longest*.01<=3
reports=[]
for s in idx['scenes']:
 r=json.loads((B/f'scenes/{s["scene"]:02}/rendered.json').read_text());assert r['rig']['unreachable']==0 and r['rig']['maxBoneError']<1e-6;reports.append(r)
assert sum(r['shotCount']for r in reports)==120
sha=hashlib.sha256(p.read_bytes()).hexdigest();report={'render_complete':True,'aesthetic_acceptance':'Revision produced; not a claim that every P1 requirement has passed subjective review','actual_scenes':24,'actual_shots':120,'frames':idx['frames'],'duration':float(info['format']['duration']),'video_bit_rate':int(v['bit_rate']),'video_rate_control':'CRF17 VBR; native1920x1080/30fps, complete film','bytes':p.stat().st_size,'sha256':sha,'lufs':lufs,'true_peak_dbfs':peak,'max_narration_quiet_seconds':longest*.01,'streams':info,'decode':'Complete FFmpeg decode passed','rig_reports':reports,'voice_sha256':hashlib.sha256((O/'voice-full.wav').read_bytes()).hexdigest(),'narration':'One voice Minh Đức, VieNeu-TTS v3 Turbo ONNX CPU local, native speech speed; exact all24 source paragraphs','qa_scope':'Rig, pose contacts and sampled encoded shots; numerical motion test with camera fixed. Browser playback is muted technical playback, not human listening or aesthetic approval.'};(B/'qa/final.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(O/'SHA256SUMS.txt').write_text(sha+'  '+p.name+'\n');print({k:report[k]for k in ['duration','bytes','frames','lufs','true_peak_dbfs','max_narration_quiet_seconds','sha256']},flush=True)
