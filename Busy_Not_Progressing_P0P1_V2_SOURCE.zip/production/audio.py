from pathlib import Path
import numpy as np,json,wave,hashlib
B=Path(__file__).resolve().parents[1];R=48000;events=[]
with wave.open(str(B/'audio/voice-full.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
idx=json.loads((B/'manifests/film.json').read_text());assert len(raw)==idx['frames']*1600

def save(p,a):
 with wave.open(str(p),'wb')as w:w.setnchannels(1 if a.ndim==1 else a.shape[1]);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.98,.98)*32767).astype('<i2').tobytes())
def fx(kind,d):
 t=np.arange(round(d*R))/R;noise=np.random.default_rng(716+len(kind)).normal(0,1,len(t))
 if kind=='key':return(.45*noise+np.sin(t*2*np.pi*980))*np.exp(-t/.008)
 if kind=='click':return(.2*noise+np.sin(t*2*np.pi*1500))*np.exp(-t/.012)
 if kind=='step':return(.15*noise+np.sin(t*2*np.pi*85))*np.exp(-t/.028)
 if kind=='notify':return(np.sin(t*2*np.pi*740)+.4*np.sin(t*2*np.pi*1110))*np.exp(-t/.12)
 if kind=='cup':return(np.sin(t*2*np.pi*440)+.4*np.sin(t*2*np.pi*720))*np.exp(-t/.07)
 a=np.convolve(noise,np.ones(21)/21,'same');return a*np.sin(np.pi*t/d)**2
for item in idx['scenes']:
 n=item['scene'];s=json.loads((B/f'manifests/scene-{n:02}.json').read_text());N=s['frames']*1600;start=round(s['global_start']*R);vraw=raw[start:start+N];V=vraw.astype(np.float32)/32768;T=np.arange(N)/R;M=np.zeros(N,np.float32);F=np.zeros((N,2),np.float32)
 sparse=n in[17,18];freqs=[146.83,174.61,220,261.63]if n<19 else[130.81,164.81,196,261.63]
 if sparse:
  for at,f in[(.8,146.83),(s['duration']*.77,174.61)]:
   k=round(at*R);t=np.arange(min(N-k,R*4))/R;M[k:k+len(t)]+=.004*np.sin(t*2*np.pi*f)*np.exp(-t/1.6)
 else:
  for j,f in enumerate(freqs):M+=.0025*np.sin(T*2*np.pi*f+np.sin(T*.17+j)*.15)
  tempo=104 if n<14 else 84 if n<19 else 96
  for k,at in enumerate(np.arange(0,s['duration'],60/tempo*2)):
   i=round(at*R);t=np.arange(min(N-i,R*2))/R;M[i:i+len(t)]+=.006*np.sin(t*2*np.pi*freqs[k%4])*np.exp(-t/.7)
 rms=np.sqrt(np.mean(V[:N//480*480].reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.008).astype(float),np.ones(13)/13,'same');duck=np.interp(np.arange(N),np.arange(len(gate))*480,1-gate*(1-10**(-15/20)));M*=duck
 def add(at,kind,amp=.03,d=.2):
  i=round(at*R)
  if i<0 or i>=N:return
  a=fx(kind,d)[:N-i]*amp;F[i:i+len(a),:]+=a[:,None];events.append({'scene':n,'local':at,'time':s['global_start']+at,'kind':kind,'amplitude':amp})
 for sh in s['shots']:
  a=sh['start'];d=sh['duration'];act=sh['action']
  if act in['type','reply']:
   for off in np.arange(0,min(1.4,d-.12),1/4.2):add(a+float(off),'key',.025,.045)
  if act in['phone','interrupt','alarm']:add(a+.05,'notify',.028 if act!='alarm'else .045,.36)
  if act in['receive','brief','papers','help','handover','drafts','book','pages','compare','sort','find_book','search_box','feedback','three_works']:add(a+.6,'paper',.075,.25)
  if act in['layout','color','rename','search','close_tabs','save','first_result','close_laptop','timer']:add(a+.55,'click',.035,.07)
  if act in['design','rush_design','revise','one_result','reserve']:add(a+.6,'pen',.045,.4);add(a+min(1.55,d-.4),'pen',.04,.4)
  if act in['walk','arrive','rush','return','tired_return','late','cafe_arrive','month1','four_weeks','treadmill','enter_door']:
   for off in np.arange(.0,max(.1,d-.1),.5):add(a+float(off),'step',.034,.13)
  if act in['cup','care']:add(a+1.1,'cup',.035,.25)
  if act in['sit_loss','rise','sit_learn']:add(a+.8,'chair',.055,.35)
  if act in['turn_handle','close_shop']:add(a+(.62+5.35 if act=='turn_handle'and d>6 else .62),'door',.06,.5)
  if act=='turn_handle'and d>6:
   for off in np.arange(0,5.35,.5):add(a+float(off),'step',.028,.13)
  if act=='other_designer':add(a+.8,'paper',.045,.25)
  if act in['send_hesitate','lost_message']:
   lo=round((a+.7)*R);hi=min(N,round((a+1.35)*R));M[lo:hi]=0
 if sparse:F*=.35
 if n==24:
  fade=np.minimum(1,np.maximum(0,(N-1-np.arange(N))/(R*2)));M*=fade;F*=fade[:,None]
 M*=np.minimum(1,np.minimum(np.arange(N)/(R*.12),(N-1-np.arange(N))/(R*.12)))
 out=B/f'scenes/{n:02}';out.mkdir(exist_ok=True)
 with wave.open(str(out/'voice.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(vraw.tobytes())
 save(out/'mix.wav',np.stack([V+M,V+M],1)+F);save(out/'music.wav',M);save(out/'sfx.wav',F);print('AUDIO',n,flush=True)
(B/'manifests/sound-events.json').write_text(json.dumps(events,indent=2));print('Narration PCM preserved exactly. SFX events',len(events))
