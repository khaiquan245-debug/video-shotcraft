from pathlib import Path
import hashlib,json,time,subprocess
B=Path(__file__).resolve().parents[1];t0=time.time();previous=-1
while True:
 ready=0
 for n in range(1,25):
  h=hashlib.sha256()
  for f in ['production/render.mjs','production/visuals.mjs','characters/rig.mjs','backgrounds/locations.mjs','backgrounds/bus.mjs',f'manifests/scene-{n:02}.json']:h.update((B/f).read_bytes())
  p=B/f'scenes/{n:02}/rendered.json'
  if p.exists()and json.loads(p.read_text()).get('sourceHash')==h.hexdigest():ready+=1
 if ready!=previous:print('Current renders',ready,'/24',flush=True);previous=ready
 if ready==24:break
 if time.time()-t0>1200:raise TimeoutError('Render barrier; inspect logs')
 time.sleep(2)
for cmd in [['python','production/assemble.py'],['python','production/demos.py'],['python','production/report.py'],['python','production/package.py']]:
 print('RUN',cmd,flush=True);subprocess.run(cmd,cwd=B,check=True)
