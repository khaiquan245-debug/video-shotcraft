import{actor,hand,ik,box,ell,line,poly,text,grad,glow,C,E,L,beat}from'../characters/rig.mjs';import{location,chair,table,cup,paper,artwork,sky}from'../backgrounds/locations.mjs';import{busScene}from'../backgrounds/bus.mjs';
const mix=(a,b,u)=>a.map((v,i)=>L(v,b[i],u));
function wrist(p,i){let q=p.hands[i],r=p.lean||0,b=Math.sin(p.t*(p.slow?1.8:2.5))*1.1;return[p.x+(Math.cos(r)*q[0]-Math.sin(r)*(q[1]-165))*(p.s||1),p.y+b+(165+Math.sin(r)*q[0]+Math.cos(r)*(q[1]-165))*(p.s||1)]}
function target(p,world){let r=p.lean||0,b=Math.sin(p.t*(p.slow?1.8:2.5))*1.1,s=p.s||1,x=(world[0]-p.x)/s,y=(world[1]-p.y-b)/s-165;return[Math.cos(r)*x+Math.sin(r)*y,165-Math.sin(r)*x+Math.cos(r)*y]}
function step(t,start=.2,d=.6){return E((t-start)/d)}
export function pose(sh,t){let a=sh.action,env=sh.environment;if(a==='close_laptop')a='close_lid';if(a==='postpone')a='phone_down';if(a==='resist')a='hesitate';let seated=['study','home','office','meeting'].includes(env)&&!['board','find_book','hold_book','discard','pin','clear','search_box','other_designer','window','dream','ending'].includes(a);let p={x:500,y:seated?315:245,s:1,t,action:'idle',hands:[[-39,184],[39,184]],feet:seated?[[-23,265],[70,265]]:[[-23,335],[23,335]],lean:0,head:0,look:0,mood:'neutral',shoulderDrop:0,frontHands:[],seated};let u=step(t),v=step(t,1.3,.55),w=step(t,2.4,.55);
 if(['type','reply','close_tabs','rename','rush_design','revise','design'].includes(a)){let gate=t%2.4<1.4?1:.1;p.hands=[[-28,150+4*Math.cos(t*Math.PI*4.2)*gate],[58,150-4*Math.cos(t*Math.PI*4.2)*gate]];p.lean=.035;p.look=.6;p.head=.04;}
 if(['design','rush_design','revise'].includes(a)){let phase=C((t-.3)/1.35);p.hands=[[-27,152],[82+20*Math.sin(phase*Math.PI*2),133+14*Math.sin(phase*Math.PI*4)]];p.lean=.1;p.head=.07;}
 if(['fatigue','neck','exhale','small','exhaustion','recognize','worry','question','lost_focus','realize','clock_reaction','avoid','fear','defer','relief','focus','save_relief','resolve','hope','decision','eyes'].includes(a)){
  p.lean=.06+.13*u;p.shoulderDrop=6*u;p.mood=['hope','resolve','focus','save_relief','decision','relief'].includes(a)?'neutral':'sad';p.head=.05+.10*u;p.look=-.4+1.1*u;
  if(['fatigue','exhaustion','worry','clock_reaction','neck'].includes(a)){p.hands[1]=mix([48,175],[20,-15],u*(1-v*.7));p.frontHands=[1];p.head=.12*u;}
  if(a==='neck'){p.hands[1]=mix([48,175],[20,44],u);p.head=-.15*u+.15*v;}
  if(a==='eyes'){p.hands[1]=mix([48,175],[13,30],u*(1-v));p.frontHands=[1];}
  if(a==='exhale'||a==='small'){p.hands=[mix([-30,150],[-46,180],u),mix([58,150],[46,180],u)];p.shoulderDrop=11*u;}
  if(a==='hope'||a==='resolve'){p.lean=.12*(1-u);p.shoulderDrop=7*(1-u);p.head=-.08*u;p.mood='surprise';}
  if(a==='relief'||a==='save_relief'){p.head=-.04*u;p.lean=.04;p.shoulderDrop=6*u;p.look=.4;}
  if(a==='decision'||a==='focus'){p.lean=.17*(1-u)+.04*u;p.shoulderDrop=8*(1-u);p.hands[1]=mix([46,175],[85,135],u);p.head=.1*(1-u);}
  if(a==='avoid'||a==='defer'){p.head=-.16*u;p.look=-u;p.hands[1]=mix([95,135],[45,179],u);}
 }
 if(['phone','interrupt','lesson','save','lost_message','phone_down','send_hesitate','timer'].includes(a)){p.hands[1]=mix([47,178],[65,80],step(t,.18,.36));p.head=.09*step(t,.18,.34);p.look=.8;
  if(a==='lesson'||a==='save'){p.hands[0]=mix([-46,180],[50,80],step(t,.75,.34));}
  if(a==='phone_down'||a==='timer'){p.hands[1]=mix([65,80],[85,148],step(t,.2,.55));p.lean=.15*u;p.mood='sad';}
  if(a==='lost_message'){p.hands[0]=mix([-46,180],[-30,160],u);p.head=.12*u;p.mood='sad';p.shoulderDrop=9*step(t,.8,.8);}
  if(a==='send_hesitate'){p.hands[0]=mix([-46,180],[47,82],u);p.hands[0][0]-=8*step(t,1.5,.45);p.head=.08;p.mood='sad';}
 }
 if(a==='cup'){p.hands[1]=target(p,[L(625,780,u),453]);p.lean=.10*u;}
 if(a==='close_lid'){p.lean=.25*step(t,.12,.4);let close=step(t,.8,.6),goal=target(p,[640,337+130*close]);p.hands[1]=mix([47,175],goal,step(t,.2,.5));p.head=.1*u;p.mood='sad';}
 if(['book','pages','goal_book','hold_book','pile','stack','papers','help','listen','receive','brief','drafts','feedback','three_works'].includes(a)){p.hands=[[-35,145],[55,132]];p.head=.04;p.look=.65;if(a==='pages'||a==='book')p.hands[1]=[55-65*beat(t,.3,.8),132];if(a==='hold_book'){p.hands=[[-23,140],[24,140]];p.mood='sad';p.head=.08;}if(a==='stack'||a==='pile')p.hands[1]=mix([50,178],[85,132],u);}
 if(['check','done','one_result','reserve','urgent','compare','blank','untouched','feedback','unfinished','month6'].includes(a)){p.hands=[[-32,152],[82+12*Math.sin(C((t-.2)/.6)*Math.PI),135+15*u]];p.lean=.06;p.head=.08;if(a==='blank')p.hands[1]=mix([85,135],[50,176],v);}
 if(['hesitate','restart'].includes(a)){p.hands[1]=mix([40,175],[94,130],u);p.head=.07;p.mood='sad';if(a==='hesitate')p.hands[1]=mix(p.hands[1],[43,177],step(t,1.5,.6));else p.hands[1]=mix([20,-15],[94,130],step(t,1,.6));p.frontHands=t<1&&a==='restart'?[1]:[];}
 if(['collapse','open_hand','sit_loss'].includes(a)){let k=step(t,.15,a==='collapse'?2.1:.9);p.lean=.06+.32*k;p.shoulderDrop=12*k;p.head=.12*k;p.mood='sad';p.slow=true;p.hands=[mix([-30,150],[-44,180],k),mix([58,150],[45,178],k)];}
 if(a==='find_book'||a==='search_box'){p.seated=false;p.y=245;p.feet=[[-23,335],[23,335]];p.lean=.2+.4*beat(t,.2,1.4);p.hands[1]=mix([45,178],[60,160],u);p.head=.08;}
 if(['board','pin','choose','hang_works','discard','clear','sort'].includes(a)){p.y=245;p.seated=false;p.feet=[[-23,335],[23,335]];p.hands[1]=mix([45,180],[105,56],u);p.hands[0]=mix([-46,180],[-22,120],u);p.head=-.04*u;}
 if(a==='window'){p.y=245;p.feet=[[-23,335],[23,335]];p.hands[1]=mix([45,180],[85,90],u);p.look=1;p.head=-.03;p.seated=false;}
 if(['walk','late','arrive','return','tired_return','cafe_arrive','dream','rush','month1','four_weeks','treadmill','enter_door'].includes(a)){p.y=249;p.action='walk';p.hands=null;p.feet=null;p.profile=1;p.walkSpeed=80;p.x=370+80*t;if(a==='late'||a==='tired_return'){p.mood='sad';p.head=.1;p.shoulderDrop=7}if(a==='dream')p.x=360+80*t;if(a==='cafe_arrive')p.x=300+80*Math.min(t,2.5);if(a==='four_weeks')p.coat=Math.floor(t)%2===1;if(a==='treadmill'){p.x=640;p.walkSpeed=64;}if(a==='enter_door'){p.x=950+64*t;p.walkSpeed=64;p.back=true;p.profile=0;}}
 if(a==='sit_learn'||a==='bag'){p.hands[1]=mix([45,180],[80,70],u);p.head=.04;if(a==='bag'){p.y=245;p.feet=[[-23,335],[23,335]];}}
 if(a==='month3'){p.coat=true;p.shoulderDrop=3;p.hands=[[-30,150],[58,150+3*Math.cos(t*12)]];}
 if(a==='month5'){p.y=315;p.hands[1]=mix([47,175],[20,44],u);p.lean=.12*u;p.mood='sad';}
 if(a==='ending'){p.x=780;p.y=245;p.feet=[[-23,335],[23,335]];p.hands=[[-40,150],[85,145]];p.back=true;p.head=.04;}

 if(['check','done','feedback','reserve','timer'].includes(a)){p.lean=.08;p.hands[1]=target(p,mix([550,485],[605,450],step(t,.18,.36)));p.head=.08;}
 if(['close_tabs','rename','search'].includes(a)){p.lean=.06;p.hands[1]=target(p,[575+30*Math.sin(t*2),462]);p.head=.06;p.look=.7;}
 if(a==='cup'){p.lean=.14;let q=[L(610,646,step(t,.65,.45)),445];p.hands[1]=t<.6?mix([46,180],target(p,[610,445]),step(t,.15,.45)):t<1.3?target(p,q):mix(target(p,[646,445]),[46,180],step(t,1.3,.6));}
 if(a==='close_lid'){p.lean=.25*step(t,.15,.4);let q=[640,337+128*step(t,.65,.55)];p.hands[1]=mix([46,180],target(p,q),step(t,.2,.4));p.head=.1;}
 if(['design','rush_design','revise','restart','decision','focus','blank','hesitate'].includes(a)){p.lean=.1;let q=t<1.3?[L(565,640,step(t,.3,.6)),434]:[L(565,600,step(t,1.3,.5)),L(434,467,step(t,1.3,.5))];if(['blank','hesitate'].includes(a)){q=[595,450-7*beat(t,.25,.8)];p.mood='sad'}p.hands[1]=target(p,q);p.head=.1;}
 if(['book','pages','hold_book','goal_book','feedback','drafts','untouched','one_result','brief','compare','three_works'].includes(a)){p.hands=[[-36,155],[78,140]];p.head=.08;p.look=.45;}
 if(['stack','help','handover'].includes(a)){p.lean=.08;p.hands[1]=target(p,mix([645,410],[595,450],step(t,.75,.5)));p.head=.04;}
 if(a==='papers'){p.action='walk';p.y=249;p.seated=false;p.hands=null;p.feet=null;p.walkSpeed=45;p.profile=1;p.head=.05;p.x=420+45*t;}
 if(['sort','clear','discard'].includes(a)){p.lean=.08;p.hands=[[-30+18*Math.sin(t*2.4),150],[75+18*Math.sin(t*2.4+1),145]];p.head=.1;}
 if(['board','pin','hang_works','choose'].includes(a)){p.y=245;p.feet=[[-23,335],[23,335]];p.seated=false;p.hands[1]=mix([46,180],[110,65],step(t,.2,.55)*(1-step(t,1.2,.5)));p.head=-.05;}
 if(a==='open_hand'){p.lean=.2;p.hands=[[-40,178],[45,177]];p.shoulderDrop=9;p.mood='sad';p.slow=true;}
 if(a==='contrast'){p.x=620;p.y=245;p.feet=[[-23,335],[23,335]];p.hands=[[-42,175],[78,135]];p.lean=.2*step(t,.8,1.2);p.head=.1;p.mood='sad';}
 if(a==='distracted'){p.head=.1*Math.sin(t*3);p.look=Math.sin(t*4);p.hands[1]=mix([46,180],[65,100],step(t,.2,.3));}
 if(a==='month6'){p.lean=.13;p.hands[1]=mix([78,140],[45,180],step(t,.4,.8));p.mood='sad';}
 if(a==='postpone'){p.lean=.1+.15*step(t,.3,1);p.hands[1]=mix([60,100],[46,180],step(t,.3,.9));p.mood='sad';p.head=.1;}
 if(a==='tired_return'){p.x=380+65*t;p.walkSpeed=65;}
 if(a==='cafe_arrive')p.x=300+80*t;
 if(a==='imagine'){p.x=520;p.y=245;p.feet=[[-23,335],[23,335]];p.hands=[[-45,180],[85,90]];p.head=-.07;}
 if(a==='bag'){p.hands[1]=mix([46,180],[55,65],step(t,.2,.45));}
 if(a==='sit_learn'){p.hands=[[-28,150],[78,135]];p.head=.08;}
 if(a==='ending'){p.x=830;p.y=245;p.feet=[[-23,335],[23,335]];p.hands[1]=target(p,mix([915,390],[900,420],step(t,.3,.6)));if(t>1.1)p.hands[1]=mix(target(p,[900,420]),[46,180],step(t,1.1,.6));}
 if(a==='search'){p.lean=.08;p.hands=[[-28,150],[82+18*Math.sin(t*2.8),150]];p.head=.03+.045*Math.sin(t*2);p.look=Math.sin(t*1.4)*.7;}if(a==='step_off'){p.x=640+80*t;p.y=249;p.action='walk';p.hands=null;p.feet=null;p.walkSpeed=80;p.profile=1;}
 if(a==='fear'){p.lean=.12;p.mood='sad';p.slow=true;p.hands[1]=mix([85,135],[46,180],step(t,1.4,.7));if(t>3)p.hands[1]=mix([46,180],[85,135],step(t,3.3,.8));p.hands[0]=mix([-46,180],[-4,35],step(t,.6,.7)*(1-step(t,3.5,.7)));p.frontHands=[0];p.look=t>3?.6:-.8;p.head=.08+.07*step(t,1.5,.6);p.shoulderDrop=6+3*Math.sin(t*.8)}
 if(a==='exhaustion'){p.lean=.2+.08*step(t,2.2,1.2);p.slow=true;p.mood='sad';p.hands[1]=mix([46,180],[20,-15],step(t,.4,.65)*(1-step(t,2.5,1.0)));p.frontHands=[1];p.head=.1+.08*step(t,2.5,1);p.shoulderDrop=9+Math.sin(t*1.4)}
 if(p.action==='walk')p.seated=false;if(['layout','color'].includes(sh.action)){p.lean=.06;p.hands=[[-28,151],target(p,[600+28*Math.sin(t*2),465])];p.head=.08}if(sh.action==='first_result'){p.hands=[[-35,153],[78,135]];p.head=.02;p.lean=.02}
 return p;
}
function phone(c,q,state='normal'){box(c,q[0]-26,q[1]-80,56,92,7,'#102b3b','#aebdb3',1.3);box(c,q[0]-21,q[1]-73,46,71,3,state==='lost'?'#acbcb2':'#c4d0bc');let words=state==='lost'?['DỰ ÁN','ĐÃ CÓ','NGƯỜI LÀM']:state==='send'?['HỒ SƠ','GỬI']:['VIỆC MỚI'];words.forEach((s,i)=>text(c,s,q[0]+2,q[1]-59+i*16,7,'#284b58','center'));}
function keyboard(c){box(c,425,455,175,18,3,'#789595','#aab7aa',1);for(let i=0;i<13;i++)for(let j=0;j<3;j++)box(c,430+i*12,457+j*5,9,3,1,'#3e6173');ell(c,610,465,14,8,'#9eb3aa')}
function screen(c,t,mode='blank',lid=0){let h=130*(1-lid);box(c,620,467-h,270,h+3,5,'#183747','#91a69f',2);if(h>20){box(c,627,475-h,256,h-13,3,'#557780');if(mode==='draft')artwork(c,670,488-h,140,Math.max(1,h-34),0,false);if(mode==='complete')artwork(c,670,488-h,140,Math.max(1,h-34),1,true);if(mode==='search'){for(let i=0;i<3;i++)paper(c,665+i*75,480-h*.5,50,55,'draft')}if(mode==='urgent')text(c,'VIỆC MỚI',750,480-h*.55,19,'#d6dcc6','center');if(mode==='zero'){text(c,'HỒ SƠ',750,480-h*.7,19,'#d6dcc6','center');text(c,'0%',750,480-h*.4,30,'#d8b287','center')}}poly(c,[[610,470],[905,470],[930,485],[590,485]],'#718b8a','#acb8a9',1.5)}
function pen(c,q){line(c,[[q[0]-6,q[1]+3],[q[0]+16,q[1]-29]],'#17364a',5);line(c,[[q[0]-6,q[1]+3],[q[0]-10,q[1]+9]],'#c3b38b',3)}
function shoulderPaper(c,a,kind='draft',size=70){let q=a.wrists[1];paper(c,q[0]+10,q[1]-23,size,size*1.25,kind);}
function forearm(c,q,left=false,penOn=false){let a=[left?780:430,790],k=ik(a,q,348,342,left?-1:1);line(c,[a,k,q],'#445d6c',30);line(c,[a,k,q],'#c2cec3',24);hand(c,...q,0,2.5);if(penOn)pen(c,q)}
function top(c,sh,t){let a=sh.action,u=step(t,.2,.7);c.fillStyle=grad(c,0,0,0,720,['#45636f','#779086','#2c4b5c']);c.fillRect(0,0,1280,720);paper(c,650,355,520,360,a==='goal_book'?'goal':'draft');let q=[L(490,780,u),420];
 if(a==='sort'||a==='rename'){for(let i=0;i<4;i++){let x=440+i*105+(i===2?40*u:0);paper(c,x,275+(i%2)*70,85,110,'draft')}q=[L(650,690,u),350]}
 if(a==='brief'){text(c,'POSTER · QUÁN CÀ PHÊ',650,240,27,'#2b4f5d','center');artwork(c,565,300,160,130,0,false);q=[L(500,720,u),442]}
 if(a==='compare'){artwork(c,405,210,205,275,0,false);artwork(c,690,210,205,275,1,true);q=[L(550,800,u),465]}
 if(a==='urgent'){paper(c,500+130*u,300,150,190,'draft');paper(c,810,350,150,200,'goal');text(c,'GẤP',500+130*u,280,23,'#8b5c4b','center');q=[500+130*u,360]}
 if(a==='one_result'){c.save();c.beginPath();c.rect(430,210,410*u,150);c.clip();text(c,'1 KẾT QUẢ',650,250,33,'#2b4d5b','center');text(c,'HÔM NAY',650,300,33,'#2b4d5b','center');c.restore();line(c,[[460,380],[L(460,840,step(t,1,.35)),380]],'#345765',3);q=[L(470,840,u),t<1?330:380]}
 if(a==='three_works'){for(let i=0;i<3;i++)artwork(c,350+i*200,230,150,210,i,true);q=[L(470,790,u),475]}
 if(a==='drafts'||a==='pages'){for(let i=0;i<3;i++)paper(c,510+i*120+(i===2?90*u:0),310+i*25,180,240,'draft');q=[L(740,830,u),470]}
 if(a==='reserve'){text(c,'60 PHÚT',650,265,33,'#345765','center');c.beginPath();c.ellipse(650,310,170,85,0,0,Math.PI*2*u);c.strokeStyle='#566f61';c.lineWidth=3;c.stroke();q=[650+170*Math.cos(Math.PI*2*u),310+85*Math.sin(Math.PI*2*u)]}
 forearm(c,q,false,['one_result','reserve','check','done','feedback'].includes(a));if(['sort','drafts','compare','three_works'].includes(a))forearm(c,[470,470],true);}
function studyProps(c,sh,t,p,a){let act=sh.action;let closed=act==='close_laptop'?step(t,.8,.6):0;let mode=act==='unfinished'||act==='deadline'?'zero':['search'].includes(act)?'search':['design','rush_design','revise'].includes(act)?'draft':['bookend_progress','ending','save_relief'].includes(act)?'complete':act==='interrupt'?'urgent':'blank';table(c);screen(c,t,mode,closed);keyboard(c);if(act!=='cup')cup(c,970,455);for(let q of a.wrists)hand(c,...q,0,1);let q=a.wrists[1];
 if(['phone','interrupt','send_hesitate','lost_message','phone_down','timer'].includes(act)){if((act==='phone_down'||act==='timer')&&t>.8)box(c,565,453,80,15,4,'#153448','#7f9b9e',1);else phone(c,q,act==='lost_message'?'lost':act==='send_hesitate'?'send':'normal');if(act==='send_hesitate')hand(c,...a.wrists[0],0,1)}
 if(['type','reply','close_tabs'].includes(act)){}
 if(['layout','color'].includes(act)){let u=step(t,.3,1.5);c.save();c.beginPath();c.rect(627,342,256,125);c.clip();artwork(c,650,350,105,110,act==='color'&&t>1.1?1:0,true);poly(c,[[L(775,745,u),375],[L(800,770,u),410],[L(760,730,u),410]],'#abc3ad');c.restore();ell(c,...q,13,8,'#95aea6');hand(c,...q);}
 if(act==='first_result'){paper(c,q[0]+15,q[1]-25,110,145,'draft');}
 if(act==='one_result'){paper(c,605,445,140,90,'blank');c.save();c.beginPath();c.rect(550,408,110*step(t,.2,.9),70);c.clip();text(c,'1 KẾT QUẢ',605,425,11,'#315765','center');c.restore();pen(c,q);}

 if(act==='deadline'){text(c,'23:48',745,328,31,'#d2bf97','center');}
 if(['design','rush_design','revise','restart','focus','decision','blank','hesitate','fear','untouched'].includes(act)){paper(c,600,460,150,100,'draft');if(!['blank','hesitate','fear','untouched'].includes(act)){line(c,[[555,443],[555+75*step(t,.3,.6),443]],'#3e6573',2);if(t>1.3)line(c,[[555,443],[L(555,590,step(t,1.3,.5)),476]],'#3e6573',2)}pen(c,q)}
 if(['check','done','feedback','reserve'].includes(act)){paper(c,600,450,130,105,'goal');pen(c,q)}
 if(act==='pile'||act==='stack'){for(let i=0;i<5;i++)paper(c,860+i*2,435-i*5,100,45,'draft');shoulderPaper(c,a)}
 if(act==='book'||act==='pages'||act==='goal_book'||act==='hold_book')shoulderPaper(c,a,act==='goal_book'?'goal':'draft',90);
 if(act==='cup')cup(c,t<.6?628:t<1.1?q[0]+18:664,445,.9)
}
function doorway(c,t,progress){location(c,'hall',t,24);c.save();c.beginPath();c.rect(835,100,430,490);c.clip();location(c,'studio',t,24);c.restore();box(c,825,95,290,505,2,'rgba(0,0,0,0)','#c0b58f',8);let width=268*Math.cos(progress*1.22);poly(c,[[834,105],[834+width,105+progress*25],[834+width,590-progress*25],[834,590]],grad(c,834,0,1100,0,['#355464','#61776b']),'#9ca893',2);let knob=[834+width-24,355];ell(c,...knob,7,7,'#d2be8d');line(c,[knob,[knob[0]+18*Math.cos(progress*1.5),knob[1]+18*Math.sin(progress*1.5)]],'#d8c598',5);return knob;}
export function stage(c,sh,t,p,d,n){let act=sh.action,env=sh.environment;if(act==='close_laptop')act='close_lid';if(act==='postpone')act='phone_down';
 if(sh.camera==='TOP'){top(c,sh,t);return}
 if(env==='bus'){busScene(c,t);return}
 location(c,env,t,n);
 let P=pose(sh,t);P.back=['OTS','BACK'].includes(sh.camera);if(['PROFILE','SIDE','TRACK'].includes(sh.camera)&&P.action!=='walk'){P.profile=1;P.look=.7}if(sh.camera==='OTS'||sh.camera==='BACK')P.back=true;if(['SIDE','PROFILE','TRACK'].includes(sh.camera))P.profile=1;
 if(act==='month3')P.coat=true;if(act==='month5'){P.x=800;P.y=315;P.seated=true;P.feet=[[-23,265],[70,265]];P.hands[1]=mix([39,184],[20,46],step(t,.2,.7));P.head=.12;P.mood='sad';}if(['month1','month3','month5','month6','four_weeks'].includes(act)){box(c,85,100,155,150,5,'#b8c5b4','#e5dfbf',2);box(c,85,100,155,34,3,'#3f6374');text(c,act==='four_weeks'?'4 TUẦN':'THÁNG '+({month1:1,month3:3,month5:5,month6:6}[act]),162,143,22,'#274e61','center');for(let i=0;i<21;i++)box(c,99+(i%7)*19,184+Math.floor(i/7)*17,7,5,1,'#6f8c86');}

 if(act==='bag'||act==='tired_return'){if(act==='tired_return'){P=pose({...sh,action:'walk'},t);P.shoulderDrop=7;P.head=.10;}let a=actor(c,P);let q=a.wrists[1];box(c,q[0]-20,q[1]+3,68,90,12,'#294b63','#83a29d',2);line(c,[[q[0]-6,q[1]+8],[q[0]-6,q[1]-8],[q[0]+24,q[1]-8],[q[0]+24,q[1]+8]],'#99ada3',3);return}
 if(['receive','brief'].includes(act)){P.x=560;P.y=245;P.feet=[[-23,335],[23,335]];P.hands[0]=[-39,184];P.x=580;P.y=245;P.feet=[[-23,335],[23,335]];P.hands[1]=mix([46,180],target(P,[660,390]),step(t,.2,.4));let q=wrist(P,1),owner={...P,x:740,t:t+.4,hands:[[-39,184],[39,184]],shirt:'#9b9d7b'};owner.hands[0]=target(owner,t<.6?[660,390]:mix([660,390],[698,425],step(t,.7,.45)));let b=actor(c,owner);let a=actor(c,P);paper(c,...(t<.6?[660,390]:q),85,110,'brief');hand(c,...a.wrists[1]);return}
 if(act==='drafts'){P.hands[0]=[-32,152];let q=mix([615,450],[630,395],step(t,.2,.55));q=mix(q,[630,450],step(t,1.2,.6));P.hands[1]=target(P,q);P.head=.09;let A=actor(c,P);table(c);paper(c,615,473,110,100,'draft');paper(c,825,473,110,100,'draft');paper(c,A.wrists[1][0],A.wrists[1][1]-25,110,130,'draft');hand(c,...A.wrists[1]);return;}
 if(act==='clear'){P.y=245;P.seated=false;P.feet=[[-23,335],[23,335]];P.lean=.08;let q=mix([595,410],[610,400],step(t,.25,.6));P.hands[1]=target(P,q);if(t>1.1)P.hands[1]=mix(P.hands[1],[39,184],step(t,1.1,.6));actor(c,P);box(c,590,455,150,100,5,'#3d626d','#9aaea2',2);paper(c,690,477,60,65,'draft');paper(c,...(t<1.1?q:mix([610,400],[650,480],step(t,1.1,.45))),70,85,'draft');hand(c,...wrist(P,1));return;}
 if(act==='other_designer'){P.x=395;P.y=245;P.seated=false;P.feet=[[-23,335],[23,335]];P.hands=[[-46,180],[65,100]];P.mood='sad';P.head=.12;P.look=.9;actor(c,P);c.save();c.beginPath();c.rect(620,90,640,440);c.clip();location(c,'cafe',t,n);let giver={x:900,y:245,s:1,t,action:'idle',hands:[[-39,184],[39,184]],shirt:'#819e92',lean:0},receiver={x:1030,y:245,s:1,t:t+.3,action:'idle',hands:[[-39,184],[39,184]],shirt:'#b6aa87',lean:0};let q=t<.8?[950,420]:mix([950,420],[985,425],step(t,.8,.45));giver.hands[1]=target(giver,t<.8?[950,420]:mix([950,420],[946,425],step(t,.8,.45)));receiver.hands[0]=target(receiver,q);actor(c,giver);actor(c,receiver);artwork(c,q[0],q[1]-120,120,170,1,true);hand(c,...q);c.restore();line(c,[[620,90],[620,530]],'#a7b8ac',9);line(c,[[940,90],[940,530]],'#a7b8ac',5);c.globalAlpha=.12;poly(c,[[620,120],[760,90],[1240,450],[1130,530]],'#dbe1d0');c.globalAlpha=1;return}
 if(['alarm','morning','rise','rest'].includes(act)){if(act==='alarm'){box(c,465,440,210,90,5,'#547680');box(c,485,363,155,77,8,'#1b3b4d','#a2b6a6',2);text(c,'06:30',563,383,32,'#d9debf','center');let u=step(t,.18,.3);forearm(c,[L(700,558,u),430-4*beat(t,.42,.25)],true);if(t<.5)ell(c,626,375,4,4,'#b5be82');return}let u=act==='rest'?0:step(t,.2,.85);c.save();c.translate(L(680,800,u),L(440,315,u));c.rotate(-Math.PI*.5*(1-u));actor(c,{x:0,y:0,t,hands:[[-20,120],[20,120]],eyesClosed:act==='rest',slow:true,head:.03,feet:u>.98?[[-23,265],[70,265]]:[[-23,335],[23,335]]});c.restore();if(act==='rest')box(c,730,432,380,65,18,'#547a88');return}
 if(act==='turn_handle'){let delay=sh.duration>6?5.35:0;if(t<delay){doorway(c,t,0);actor(c,{x:760+35*t,y:249,t,action:'walk',walkSpeed:35,profile:1});return;}let tt=t-delay,k=doorway(c,t,step(tt,.6,.85));P.x=950;P.y=245;P.feet=[[-23,335],[23,335]];P.lean=.04;P.hands[1]=mix([46,180],target(P,k),step(tt,.15,.4));let a=actor(c,P);if(tt>.55)hand(c,...k,step(tt,.3,.35)*1.2,1);return}
 if(act==='enter_door'){doorway(c,t,1);P=pose(sh,t);let a=actor(c,P);line(c,[[825,95],[825,600]],'#b4b799',11);box(c,1119,0,161,720,0,'#213f50');return}
 if(act==='step_off'){box(c,350,574,430,38,10,'#335467','#8caaa4',2);line(c,[[760,580],[760,330],[700,320]],'#8ba6a4',8);P.x=640+80*Math.max(0,t-.4);P.y=249;P.action=t<.4?'idle':'walk';P.t=Math.max(0,t-.4);P.hands=t<.4?[[-39,184],[39,184]]:null;P.feet=null;P.walkSpeed=80;actor(c,P);return}
 if(act==='treadmill'){box(c,350,574,570,38,10,'#335467','#8caaa4',2);line(c,[[900,580],[900,330],[840,320]],'#8ba6a4',8);for(let i=0;i<9;i++)line(c,[[360+(i*63-t*64+1000)%550,589],[380+(i*63-t*64+1000)%550,589]],'#78958e',2);actor(c,P);return}
 if(act==='care'){chair(c,850,480);actor(c,{x:850,y:315,t,mood:'sad',hands:[[-40,178],[40,178]],feet:[[-23,265],[70,265]],shirt:'#91a694'});P.x=720;P.y=275;P.feet=[[-23,305],[23,305]];P.seated=false;P.lean=.06;let q=t<1.2?mix([766,455],[790,435],step(t,.2,.6)):mix([790,435],[811,387],step(t,1.3,.55));P.hands[1]=target(P,q);let A=actor(c,P);cup(c,t<.8?A.wrists[1][0]+18:808,t<.8?A.wrists[1][1]:435);return}
 if(act==='close_shop'){c.fillStyle='rgba(5,18,32,.35)';c.fillRect(0,0,1280,720);box(c,865,175,280,335,2,'#b2aa83');let h=335*step(t,.2,.7);box(c,865,175,280,h,1,'#335568','#93aaa3',2);for(let yy=195;yy<175+h;yy+=20)line(c,[[870,yy],[1140,yy]],'#6e8d91',2);if(t<2){P.x=1020;P.y=245;P.feet=[[-23,335],[23,335]];P.hands[1]=mix([46,180],target(P,[1075,350]),step(t,.8,.35)*(1-step(t,1.4,.4)));actor(c,P)}else actor(c,{x:1020+64*(t-2),y:249,t:t-2,action:'walk',walkSpeed:64,profile:1,shirt:'#9da590'});return}
 if(P.seated)chair(c,P.x,480);let A=actor(c,P);if(env==='meeting'){table(c);paper(c,680,475,130,75,'draft')}
 let seatedWork=P.seated&&(['study','office'].includes(env)||(env==='home'&&['cup','collapse','clear','phone_down','check','phone','send_hesitate'].includes(act)));
 if(seatedWork)studyProps(c,sh,t,p,A);
 else{
  if(['papers','help','listen','drafts','goal_book','pages','hold_book','brief','pile','stack','feedback','choose','hang_works'].includes(act))shoulderPaper(c,A,act==='goal_book'?'goal':act==='brief'?'brief':'draft',act==='ending'?100:75);
  if(['phone','lost_message','interrupt','save'].includes(act))phone(c,A.wrists[1],act==='lost_message'?'lost':'normal');
 }
 if(act==='find_book'||act==='search_box'){box(c,600,510,160,90,5,'#3e606e','#91a89e',2);shoulderPaper(c,A,'goal',90)}
 if(act==='board'||act==='pin'){box(c,560,250,280,120,3,'#416a79','#9bb1a5',2);if(t<1.1)paper(c,A.wrists[1][0]+20,A.wrists[1][1]-25,80,95,'goal');else paper(c,630,285,80,95,'goal');hand(c,...A.wrists[1]);}
 if(act==='hang_works'||act==='imagine'||act==='dream'||act==='bookend_progress'){for(let i=0;i<3;i++){let u=step(t,i*.33,.5);if(act==='hang_works'&&i===2){let q=A.wrists[1];artwork(c,q[0]-50,q[1]-60,100,140,2,true)}else artwork(c,610+i*170,160,130,190,i,true)}}
 if(act==='discard'){let q=A.wrists[1],u=step(t,.6,.5);ell(c,L(q[0],860,u),L(q[1],560,u)-110*Math.sin(Math.PI*u),10,10,'#b6c3ad');box(c,825,560,80,60,7,'#355b68','#839f9b',2)}
 if(act==='open_hand'){let q=A.wrists[1],u=step(t,.4,1.2);hand(c,...q,0,1);for(let i=0;i<4;i++)line(c,[[q[0]+(i-1.5)*3,q[1]-6],[q[0]+(i-1.5)*(3+4*u),q[1]-8-18*u*(1-Math.abs(i-1.5)*.12)]],'#1c3141',4.5)}
 if(act==='return')shoulderPaper(c,A,'brief',75);
 if(act==='ending'){paper(c,...(t<1.1?A.wrists[1]:[900,420]),130,90,'draft');}
}
export function camera(sh,t,p){let a=sh.action,cam=sh.camera,cx=620,cy=370,width=1280;if(cam==='MS'){width=900;cx=620;cy=380}if(cam==='CU'){width=460;cx=530;cy=325}if(cam==='ECU'){width=a==='deadline'?650:280;cx=a==='deadline'?730:530;cy=a==='deadline'?400:315}if(cam==='BACK'){width=950-90*E(p);cx=600;cy=380}if(cam==='LOW'){width=900;cx=620;cy=440}if(cam==='HAND'||cam==='DETAIL'){width=['lost_message','send_hesitate','timer'].includes(a)?260:610;cx=['lost_message','send_hesitate','timer'].includes(a)?565:655;cy=['lost_message','send_hesitate','timer'].includes(a)?360:440}if(cam==='OTS'){width=920;cx=660;cy=380}if(cam==='BACK'){width=1000-100*E(p);cx=610;cy=385}if(cam==='PROFILE'||cam==='SIDE'){width=1050;cx=620;cy=390}if(cam==='TRACK'){let P=pose(sh,t);width=1080;cx=P.x+100;cy=370}if(a==='turn_handle'){let z=sh.duration>6?step(t,4.75,1.4):1;cx=L(640,1010,z);cy=L(360,355,z);width=L(1280,480,z)}if(a==='enter_door'){cx=900;cy=350;width=1150}if(a==='other_designer'){cx=730;cy=355;width=1280}if(a==='open_hand'){cx=548;cy=476;width=380}if(['receive','brief'].includes(a)){cx=660;cy=390;width=600}if(a==='small'){width=1150+130*E(p);cx=650;cy=375}if(a==='alarm'){cx=570;cy=405;width=440}if(['morning','rise','rest'].includes(a)){cx=860;cy=430;width=1100}if(['lost_message','send_hesitate','timer'].includes(a)&&['HAND','DETAIL'].includes(cam)){let q=wrist(pose(sh,t),1);cx=q[0];cy=q[1]-35;width=360;if(a==='timer'&&t>.8){cx=605;cy=465}}return{cx:C(cx,width/2,1280-width/2),cy:C(cy,width*9/32,720-width*9/32),width};}
