import fs from'node:fs';import{createCanvas,actor}from'../characters/rig.mjs';import{pose}from'./visuals.mjs';
const c=createCanvas(1,1).getContext('2d');let max=0,samples=0;
for(let action of['walk','papers','late','return','month1','dream','enter_door'])for(let foot=0;foot<2;foot++)for(let cycle=0;cycle<3;cycle++){
 const base=cycle+(foot?.5:0)+.02;
 let previous=null;
 for(let i=0;i<130;i++){let t=base+i/300,p=pose({action,environment:action==='enter_door'?'hall':'street',camera:'TRACK'},t),r=actor(c,p),q=r.feet[foot];if(previous)max=Math.max(max,Math.hypot(q[0]-previous[0],q[1]-previous[1]));previous=q;samples++;}
}
if(max>1e-8)throw Error('Planted foot drift '+max);
fs.writeFileSync(new URL('../qa/footing.json',import.meta.url),JSON.stringify({scope:'Canonical final walking/papers/door rig stance at world speed. Not a visual/aesthetic acceptance test, nor a guarantee of every prop collision.',samples,max_world_distance_change_between_stance_samples:max,units:'1280x720 design pixels'},null,2));console.log('Footing',samples,max);
