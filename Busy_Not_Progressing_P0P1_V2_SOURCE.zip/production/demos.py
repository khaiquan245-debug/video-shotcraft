from pathlib import Path
import subprocess,wave,json
B=Path(__file__).resolve().parents[1];O=B/'output';Q=B/'qa'
film=json.loads((B/'manifests/film.json').read_text())
def run(args):subprocess.run(['ffmpeg','-v','error','-y',*args],check=True)
def demo(name,scenes,start,duration,picture=None):
 paths=[B/f'scenes/{n:02}/picture.mp4'for n in scenes]
 if picture:paths=[O/picture]
 lst=O/(name+'.concat.txt');lst.write_text('\n'.join("file '"+str(p)+"'" for p in paths))
 wav=O/(name+'.mix.wav')
 with wave.open(str(wav),'wb')as w:
  w.setnchannels(2);w.setsampwidth(2);w.setframerate(48000)
  for n in scenes:
   with wave.open(str(B/f'scenes/{n:02}/mix.wav'))as r:w.writeframes(r.readframes(r.getnframes()))
 out=O/(name+'.mp4')
 run(['-f','concat','-safe','0','-i',str(lst),'-i',str(wav),'-ss',str(start),'-t',str(duration),'-map','0:v','-map','1:a','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-af','loudnorm=I=-14:TP=-2:LRA=8','-ar','48000','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out)])
 folder=Q/(name+'_1fps');folder.mkdir(exist_ok=True)
 run(['-i',str(out),'-vf','fps=1,scale=960:540',str(folder/'%02d.jpg')])
 print(name,out.stat().st_size,flush=True)
demo('Demo_Mo_Dau_15s',[1],0,15,'demo-opening-picture.mp4')
demo('Demo_Co_Hoi_04m45_20s',[14,15],285-film['scenes'][13]['global_start'],20)
demo('Demo_Mat_Co_Hoi_20s',[16,17],315-film['scenes'][15]['global_start'],20)
demo('Demo_Cao_Trao_18s',[17],0,18)
