from pathlib import Path
import json,hashlib,csv,subprocess
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';Q=B/'qa';old=B.parent/'busy_not_progressing'
film=O/'Busy_Not_Progressing_P0P1_V2_1080p.mp4';r=json.loads((Q/'final.json').read_text());shots=json.loads((B/'manifests/shotlist-revised.json').read_text())
with (O/'Shotlist_P0P1_V2.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['Shot','Start_seconds','Duration_seconds','Location','Camera','Action','Story_purpose'])
 for s in shots:w.writerow([s['shot'],round(s['global_start'],3),s['duration'],s['environment'],s['camera'],s['action'],s['meaning']])
(O/'Shotlist_P0P1_V2.json').write_text(json.dumps(shots,ensure_ascii=False,indent=2))
for folder in sorted(Q.glob('Demo*_1fps')):
 files=sorted(folder.glob('*.jpg'));imout=Image.new('RGB',(1200,((len(files)+3)//4)*188),'#15212b');draw=ImageDraw.Draw(imout)
 for i,path in enumerate(files):
  frame=Image.open(path).resize((300,169));x=i%4*300;y=i//4*188;imout.paste(frame,(x,y));draw.text((x+5,y+170),f'{i:02}s',fill='white')
 imout.save(folder.with_suffix('.jpg'))
times=[5,45,65,110,170,230,270,285,300,320,340,360,400,470,500];out=Image.new('RGB',(1280,len(times)*205),'#142331');d=ImageDraw.Draw(out)
for i,t in enumerate(times):
 for col,(tag,p)in enumerate([('Truoc',old/'output/Busy_Not_Progressing_1080p.mp4'),('Sau',film)]):
  dest=Q/f'compare-{t:03}-{tag}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(p),'-frames:v','1','-vf','scale=640:360',str(dest)],check=True)
  im=Image.open(dest).resize((320,180));x=col*640;out.paste(im,(x,i*205));d.text((x+325,i*205+12),f'{tag} {t//60:02}:{t%60:02}',fill='white')
  if col:d.text((x+325,i*205+40),next(s['environment']+' / '+s['camera']for s in shots if s['global_start']<=t<s['global_start']+s['duration']),fill='white')
out.save(Q/'Before_After.jpg')
# A literal phone-sized frame for readability, rather than merely listing font metrics.
subprocess.run(['ffmpeg','-v','error','-y','-ss','300','-i',str(film),'-frames:v','1','-vf','scale=360:202',str(Q/'phone-360.jpg')],check=True)
voicehash=hashlib.sha256((B/'audio/voice-full.wav').read_bytes()).hexdigest();oldhash=hashlib.sha256((old/'output/voice-full.wav').read_bytes()).hexdigest();assert voicehash==oldhash
report=f'''# Bản sửa P0/P1 — Người bận rộn nhưng không tiến bộ

## Kết quả có thật
- Video: `{film.name}`; {r['duration']:.3f} giây; 1920×1080, 30 fps, H.264/yuv420p + AAC stereo48 kHz.
- Đã render 24 phân đoạn, 120 shot, {r['frames']}frame. Mã hóa cuối CRF 17 VBR để giảm dung lượng, giữ đủ nội dung và độ phân giải. Đây là hoạt hình vector có rig và đồ vật riêng; không phải ảnh tham chiếu phóng to/slideshow.
- Lời kể PCM gốc giữ nguyên từng byte, một giọng Minh Đức/VieNeu-TTS v3 Turbo ONNX CPU từ bản hiện tại; không đổi sang giọng khác, không tăng tốc VO. SHA256: `{voicehash}`.
- Nhạc/SFX mới được tổng hợp local bằng oscillator/noise; không dùng nhạc thương mại, API trả phí hay cloud inference.
- Loudness thực tế: {r['lufs']}LUFS; peak {r['true_peak_dbfs']}dBTP. Khoảng yên tối đa trong VO theo ngưỡngRMS: {r['max_narration_quiet_seconds']:.2f}s.
- FFmpeg giải mã toàn bộ tệp thành công. Rig không có đích IK ngoài tầm trong các frame đã render; xem `qa/final.json`. Con số này không chứng minh diễn xuất hay hoặc không xuyên vật thể ở mọi pixel. Đã sửa tay đi bộ hạ xuống tự nhiên hơn và gắn bước chân khi mang giấy với vận tốc tịnh tiến; kiểm tra chân trụ riêng lưu ở `qa/footing.json`.
- Bản cũ được giữ nguyên trong `busy_not_progressing/`; bản sửa ở thư mục mới `busy_not_progressing_v2/`.

## Giới hạn nghiệm thu
Đây là bản sửa hoạt hình 2D đã render, không tự chấm đạt toàn bộ P1. Diễn xuất, bàn tay và góc nghiêng vẫn giản lược; không có xoay camera 3D thực, chưa căn phụ đề từng từ và chưa duyệt cảm xúc âm thanh bằng tai. Cảnh công việc vẫn cần một số bàn/laptop, nhưng đã giảm các poster UI toàn màn hình.

## P0 trước, rồi P1
| Ưu tiên | Thay đổi thực tế | Bằng chứng / giới hạn |
|---|---|---|
|P0 lặp cảnh|Tách nền nhà đêm, góc học, văn phòng sáng nhiều người, phố, xe buýt, café, giường, gia đình, hành lang và studio.|120 ảnh bố cục trong `qa/V2-*.jpg`; vẫn có motif bàn máy tính vì nội dung công việc, không tuyên bố đã bỏ toàn bộ.|
|P0 diễn xuất|Thêm xoa trán, bóp cổ, thả vai/tay, khép laptop, đẩy cốc, đi bộ, trao brief, nhấc/lật/đặt giấy, chạm/xoay tay nắm.|Các khớp được giải IK cố định chiều dài. Tay là hình bàn tay đơn giản, không phải bàn tay giải phẫu có từng ngón rig riêng.|
|P0 mất cơ hội|S14café/brief → S15ba bản nháp/ngập ngừng GỬI → S16người khác nhận poster sau kính và tin dự án đã có người làm.|Demo 04:45–05:05 và demo mất cơ hội. Đã sửa crop điện thoại sau lần kiểm tra đầu.|
|P0 cao trào|S17sau lưng tiến gần, vai gục, bàn tay mở, xoa trán rồi buông; S18chần chừ trước bản nháp.|Không dùng UI0% trong S17–S18. Shot khoảng5.7–7.6 giây, động tác được chia theo giai đoạn.|
|P1 nhịp|Mở đầu10 shot / 18 giây; xen cận/chi tiết/góc rộng ở phần giữa, giữ VO; tâm lý dài hơn.|Giữ tổng thời lượng8:29.8 để không đổi lời kể; không phải tua nhanh toàn phim. Chưa có microcut0.7–1.2 giây xuyên mọi montage.|
|P1 góc máy|CU/ECU tay–mắt, OTS/BACK, top-down, side/profile, tracking và push-in.|Là hoạt hình2D vector; góc nghiêng giản lược, không phải xoay camera3D quanh nhân vật.|
|P1 phụ đề|Tăng chữ36–42đơn vị thiết kế (54–63px ở1080p), đo chiều rộng để xuống dòng; kiểm tra frame360 px.|Nội dung/timing gốc giữ nguyên. Canh theo cụm nghĩa/chunk TTS và năng lượng, chưa phải forced alignment từng từ.|
|P1 âm thanh|Nhạc duck 15 dB khi có VO; giảm gần im ởS17/S18; giảm click lặp, SFX gắn mốc chạm.|Đo kỹ thuật và phát thử trình duyệt đã thực hiện. **Chưa thẩm định bằng tai người ở1×**, không đánh dấu yêu cầu này đạt.|
|P1 tiến bộ/kết|So sánh bản1/bản2; ba poster khác nhau; tay xoay cửa, bước qua ngưỡng và cắt sang studio sáng thật.|XemS20–S24 và ảnh trước–sau. Không chỉ đổi màu cánh cửa.|

## Demo và QA hình ảnh
- `Demo_Mo_Dau_15s.mp4`:15giây đầu.
- `Demo_Co_Hoi_04m45_20s.mp4`:04:45–05:05trên timeline.
- `Demo_Mat_Co_Hoi_20s.mp4`:20giây quanh việc nhận poster/tin mất cơ hội.
- `Demo_Cao_Trao_18s.mp4`:vai gục, tay mở, xoa trán.
- Mỗi demo có thư mục `qa/<ten_demo>_1fps/` và contact sheet, trích từ MP4 đã encode.
- `Before_After.jpg`:đối chiếu15mốc. Mở đầu nhanh hơn; buổi sáng/văn phòng khác ánh đêm; phần giữa xen thao tác/ngoại cảnh; café có quầy máy pha, bàn, đèn; cao trào bỏ0%; cuối bước sang studio.
- Đã sửa trong quá trình kiểm tra:lỗi audio block không chia hết480sample, crop camera gây mép đen, titlebrief trùng chữ, cốc trùng, khép laptop không chạy, crop mất phần trên tin nhắn, cảnh bản nháp chỉ giữ một tờ.

## Giới hạn nghiệm thu
Đây là bản sửa đã xuất đầy đủ, không phải tuyên bố đạt chất lượng điện ảnh cao cấp ở mọi shot. Một số động tác nhỏ và gương mặt vẫn theo rig vector tối giản; một vài insert giấy/màn hình còn cần người xem đánh giá độ cuốn hút. Chưa xác nhận bằng tai cảm xúc TTS/nhạc và chưa đối chiếu lời–hình tới từng từ. Việc phát trình duyệt tắt tiếng chỉ xác nhận tệp chơi được. Số shot và số pixel thay đổi không được dùng thay cho đánh giá kể chuyện.

## Chạy lại miễn phí
Python3 + NumPy/Pillow, Node + @napi-rs/canvas, FFmpeg. FontNunito giữ kèmOFL.
1.`python production/catalog.py` (tạoshotlist; không sửa thoại).
2.`python production/audio.py` (dùng lại audio/voice-full.wav, không TTS lại).
3.`node production/render.mjs --preflight`.
4.`node production/render.mjs --range 1 24` (checkpoint theo hash nguồn).
5.`python production/assemble.py` rồi `python production/report.py`.
Không cầnGPU trả phí. Trọng sốTTS ở ngoàiGit, không đóng trong gói video.
'''
(O/'QA_report.md').write_text(report);(O/'Before_After.jpg').write_bytes((Q/'Before_After.jpg').read_bytes());print('REPORT WRITTEN',flush=True)
