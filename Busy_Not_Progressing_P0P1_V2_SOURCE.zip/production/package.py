from pathlib import Path
import zipfile,hashlib,json
B=Path(__file__).resolve().parents[1];O=B/'output'
master=O/'Busy_Not_Progressing_P0P1_V2_1080p.mp4'
assert master.is_file()and (B/'qa/final.json').is_file()
files=[master,O/'Busy_Not_Progressing_Vietnamese.srt',O/'QA_report.md',O/'CREDITS.md',O/'Shotlist_P0P1_V2.csv',O/'Shotlist_P0P1_V2.json',O/'SHA256SUMS.txt',*sorted(O.glob('Demo_*.mp4'))]
files += [B/'qa/final.json',B/'qa/Before_After.jpg',B/'qa/phone-360.jpg',*sorted((B/'qa').glob('Demo*_1fps.jpg'))]
for folder in sorted((B/'qa').glob('Demo*_1fps')):files+=sorted(folder.glob('*.jpg'))
p=O/'Busy_Not_Progressing_P0P1_V2_DOWNLOAD.zip'
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for f in files:z.write(f, f.relative_to(B)if f.is_relative_to(B/'qa')else f.name)
with zipfile.ZipFile(p)as z:
 assert z.testzip()is None
 h=hashlib.sha256(z.read(master.name)).hexdigest();assert h==hashlib.sha256(master.read_bytes()).hexdigest()
print(json.dumps({'zip':str(p),'bytes':p.stat().st_size,'master_sha256':h,'members':len(files)},indent=2),flush=True)
# Fully editable source checkpoint, weights excluded. The frozen voice is included so no re-synthesis is needed.
src=O/'Busy_Not_Progressing_P0P1_V2_SOURCE.zip'
with zipfile.ZipFile(src,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for f in ['package.json','requirements.txt']:z.write(B/f,f)
 for directory in ['assets','characters','backgrounds','production','manifests','sources','audio','references']:
  for f in sorted((B/directory).rglob('*')):
   if f.is_file()and '__pycache__'not in str(f):z.write(f,f.relative_to(B))
print('Source ZIP',src.stat().st_size,flush=True)
