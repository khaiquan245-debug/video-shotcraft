import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(fileURLToPath(new URL('..',import.meta.url)));let req=createRequire(root+'/package.json');let canvas;try{canvas=req('@napi-rs/canvas')}catch{canvas=createRequire('/workspace/video-shotcraft/workbench/package.json')('@napi-rs/canvas')}
export const {createCanvas,GlobalFonts}=canvas;GlobalFonts.registerFromPath(root+'/assets/Nunito.ttf','Nunito');
export const C=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),E=v=>{v=C(v);return v*v*(3-2*v)},L=(a,b,t)=>a+(b-a)*t,QA={samples:0,unreachable:0,maxBoneError:0};
export function box(c,x,y,w,h,r,col,stroke=null,lw=1){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=col;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke()}}
export function ell(c,x,y,rx,ry,col,stroke=null,lw=1){c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);if(col){c.fillStyle=col;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke()}}
export function line(c,p,col,w=2){c.beginPath();p.forEach((q,i)=>i?c.lineTo(...q):c.moveTo(...q));c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.stroke()}
export function poly(c,p,col,stroke=null,w=1){c.beginPath();p.forEach((q,i)=>i?c.lineTo(...q):c.moveTo(...q));c.closePath();c.fillStyle=col;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke()}}
export function grad(c,x,y,z,w,cols){let g=c.createLinearGradient(x,y,z,w);cols.forEach((v,i)=>g.addColorStop(i/(cols.length-1),v));return g}
export function radial(c,x,y,r,cols){let g=c.createRadialGradient(x,y,0,x,y,r);cols.forEach((v,i)=>g.addColorStop(i/(cols.length-1),v));return g}
export function text(c,s,x,y,size=22,col='#e6e9dc',align='left',weight=800){c.font=`${weight} ${size}px Nunito`;c.textAlign=align;c.textBaseline='top';c.fillStyle=col;c.fillText(s,x,y)}
export function glow(c,x,y,rx,ry,col){c.save();c.translate(x,y);c.scale(1,ry/rx);c.fillStyle=radial(c,0,0,rx,[col,'rgba(0,0,0,0)']);c.fillRect(-rx,-rx,rx*2,rx*2);c.restore()}
export function ik(a,b,l1,l2,sign=1){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>l1+l2+.001||d<Math.abs(l1-l2)-.001){QA.unreachable++;throw Error('IK unreachable '+JSON.stringify({a,b,d,l1,l2}))}let ang=Math.atan2(dy,dx)+sign*Math.acos(C((l1*l1+d*d-l2*l2)/(2*l1*Math.max(d,.001)),-1,1));let k=[a[0]+Math.cos(ang)*l1,a[1]+Math.sin(ang)*l1];QA.samples++;QA.maxBoneError=Math.max(QA.maxBoneError,Math.abs(Math.hypot(k[0]-a[0],k[1]-a[1])-l1),Math.abs(Math.hypot(b[0]-k[0],b[1]-k[1])-l2));return k}
export const TIMING={reactionLatency:.17,headTurn:.33,followThrough:.1,tap:.32,tapHold:.09,pageFlip:.42,stepsPerSecond:2,sit:.85,stand:.85,typingHz:4.2,workSpeedMultiplier:1.5};
export function beat(t,start=.2,d=.32){let q=t-start,hold=Math.min(.09,d*.4),edge=(d-hold)/2;if(q<0||q>d)return 0;if(q<edge)return E(q/edge);if(q<=edge+hold)return 1;return 1-E((q-edge-hold)/edge)}
export function move(t,start,d,a,b){return L(a,b,E((t-start)/d))}
export function hand(c,x,y,angle=0,scale=1){c.save();c.translate(x,y);c.rotate(angle);c.scale(scale,scale);ell(c,0,0,8.5,10.5,grad(c,-8,-8,8,8,['#3c4655','#111d2b']),'#71818b',.6);ell(c,6,-5,3.5,5,'#243140');c.restore()}
// Fixed stance anchors in world distance. Each swing lasts 0.5 s, stance 0.5 s.
export function walkFeet(t,speed=64){let phase=t%1,feet=[];for(let i=0;i<2;i++){let p=(phase+i*.5)%1;if(p<.5){feet.push([speed*(.25-p),331])}else{let q=(p-.5)/.5;feet.push([L(-speed*.25,speed*.25,E(q)),331-23*Math.sin(Math.PI*q)])}}return feet}
export function actor(c,{x=500,y=245,s=1,t=0,action='idle',look=0,mood='neutral',back=false,profile=0,walkSpeed=64,feet=null,hands=null,head=0,lean=0,shirt='#dce2dc',seated=false,eyesClosed=false,slow=false,coat=false,shoulderDrop=0,frontHands=[]}={}){
 const requested=action;const aliases={fast_walk:'walk',phone_reach:'phone',head_turn:'turn',hand_to_forehead:'forehead',reaction_surprise:'turn',reaction_regret:'drop',open_door:'reach'};action=aliases[action]||action;if(requested==='reaction_surprise')mood='surprise';if(requested==='reaction_regret')mood='sad';
 let breathing=Math.sin(t*(slow?1.8:2.5))*1.1,localHands=hands??[[-46,180],[46,180]],localFeet=feet??(seated?[[-18,265],[76,265]]:[[-23,335],[23,335]]);let turn=look,shoulder=breathing+shoulderDrop;
 if(action==='sit'||action==='stand'){let u=E((t-.17)/.85),q=action==='sit'?u:1-u;y+=70*q;localFeet=[[-23,335-70*q],[23,335-70*q]];localHands=[[-47,165-25*q],[47+8*q,165-20*q]];}
 if(action==='page_flip'){let u=beat(t%1.2,.17,.84);localHands=[[-47,160],[47+48*u,165-65*u]];}
 if(action==='type'){let gate=t%2.4<1.8?1:.15;localHands=[[-29,146+4*Math.cos(t*2*Math.PI*2.1)*gate],[57,148+4*-Math.cos(t*2*Math.PI*2.1)*gate]];shoulder+=Math.sin(t*15)*.65*gate;}
 if(action==='mouse')localHands=[[-43,153],[64+Math.sin(t*2.5)*10,145-4*beat(t%1.4,.2,.32)]];
 if(action==='forehead'){let u=E((t-.17)/.33);localHands=[[-47,160],[L(47,20,u),L(160,-18,u)]];head=-.08*u;}
 if(action==='turn'){turn=move(t,.17,.33,0,1);head+=turn*.12+Math.sin(C((t-.5)/.1)*Math.PI)*.025;}
 if(action==='stretch'){let u=beat(t%2.8,.2,1.2);localHands=[[-48-32*u,160-130*u],[48+32*u,160-130*u]];head=Math.sin(t*3)*.08*u;}
 if(action==='phone'){let u=E((t-.17)/.33);localHands=[[-46,160],[L(47,65,u),L(165,75,u)]];turn=u*.65;}
 if(action==='walk'){localFeet=walkFeet(t,walkSpeed);let a=Math.sin(t*Math.PI*2)*.5;localHands=[[-42-10*a,180+4*a],[42+10*a,180-4*a]];breathing=-Math.abs(Math.sin(t*Math.PI*2))*2;}
 if(action==='drop'){let u=E((t-.2)/.8);localHands=[[-45,145+20*u],[50,140+25*u]];head=.1*u;}
 if(action==='reach')localHands=[[-47,160],[move(t,.17,.33,47,105),move(t,.17,.33,160,80)]];
 localFeet=localFeet.map(q=>[q[0],q[1]-breathing]);
 c.save();c.translate(x,y+breathing);c.scale(s,s);let joints={neck:[0,45],hip:[0,165],shoulders:[],elbows:[],wrists:[],knees:[],feet:localFeet};
 // Pants and shoes remain under torso; separate left/right limbs with a fixed knee bend direction.
 for(let i=0;i<2;i++){let a=[i?18:-18,164],b=localFeet[i],k=ik(a,b,85,90,(action==='sit'||action==='stand'||b[1]<300)?-1:(i?-1:1));joints.knees.push(k);line(c,[a,k,b],'#101b29',16);line(c,[a,k,b],i?'#223342':'#1b2b39',11);ell(c,b[0]+7,b[1]+1,15,5,'#142130','#70838a',1);line(c,[[b[0]-7,b[1]+5],[b[0]+18,b[1]+5]],'#aab6b6',1.7)}
 c.save();c.translate(0,165);c.rotate(lean);c.translate(0,-165);
 poly(c,[[-32,48+shoulderDrop*.3],[-47,72+shoulderDrop],[-40,155],[-15,167],[16,167],[40,155],[47,72+shoulderDrop],[32,48+shoulderDrop*.3]],grad(c,-45,55,48,163,[coat?'#3f586e':shirt,coat?'#375367':'#afc0c1',coat?'#1e354a':'#718a96']),'#a1b5b9',1.4);
 line(c,[[-32,49],[-47,72],[-40,151]],'#ead9b4',1.8);line(c,[[0,67],[0,154]],'#718b96',1.2);
 for(let i=0;i<2;i++){let a=[i?39:-39,72+shoulder],b=localHands[i],k=ik(a,b,58,57,i?-1:1);joints.shoulders.push(a);joints.elbows.push(k);joints.wrists.push(b);line(c,[a,k,b],'#405764',20);line(c,[a,k,b],grad(c,a[0],a[1],b[0],b[1],[coat?'#3f586e':shirt,coat?'#324e64':'#91a9af']),16);let cuff=[L(k[0],b[0],.85),L(k[1],b[1],.85)];line(c,[cuff,b],'#e0e4dc',17);hand(c,b[0],b[1],Math.atan2(b[1]-k[1],b[0]-k[0])-.8)}
 if(!back){poly(c,[[-28,49],[-13,70],[0,57],[-7,46]],'#eff0e5');poly(c,[[28,49],[13,70],[0,57],[7,46]],'#cbd9d6');poly(c,[[-5,64],[5,64],[7,120],[0,130],[-7,120]],'#263f50');for(let yy of[88,110,142])ell(c,11,yy,1.2,1.2,'#5b7480')}
 line(c,[[0,31],[0,49]],'#1e2d3b',17);c.save();c.rotate(head+Math.sin(t*1.1)*.008);c.translate(turn*3,shoulder*.45);
 ell(c,0,0,50,50,radial(c,-20,-24,93,['#3a4653','#1d2b3b','#101b2a']),'#9dafb3',1.25);c.save();c.beginPath();c.arc(0,0,50,0,Math.PI*2);c.clip();line(c,[[-49,-22],[-35,-47],[-4,-53]],'#dcc49a',2);c.restore();
 poly(c,[[-33,-35],[-27,-48],[-17,-43],[-5,-50],[6,-45],[17,-46],[34,-34]],'#162434');line(c,[[-29,-40],[-15,-44],[2,-47]],'#627483',1.1);
 if(!back){let blink=eyesClosed?1:Math.exp(-(((t%3.2-2.7)/.065)**2)),sad=mood==='sad'||slow,rx=profile?2.6:4.2;
  for(let xx of[-16,16]){let ex=xx+turn*6;if(profile&&xx<0)continue;let hy=sad?2.0: mood==='surprise'?6.5:4.5;ell(c,ex,2+sad*2,rx,Math.max(.5,hy*(1-blink)),'#f2efe0');if(sad)line(c,[[ex-6,-8],[ex+5,-11]],'#9eafb1',1.2)}
 }
 c.restore();for(let i of frontHands){line(c,[joints.elbows[i],localHands[i]],coat?'#375367':'#c5d1cc',16);hand(c,...localHands[i],0,1)}if(action==='forehead'){line(c,[joints.elbows[1],localHands[1]],'#c5d1cc',16);hand(c,...localHands[1],0,1)}c.restore();c.restore();return {heading:turn,headAngle:head,wrists:localHands.map(q=>[x+(Math.cos(lean)*q[0]-Math.sin(lean)*(q[1]-165))*s,y+breathing+(165+Math.sin(lean)*q[0]+Math.cos(lean)*(q[1]-165))*s]),feet:localFeet.map(q=>[x+q[0]*s,y+breathing+q[1]*s]),joints};
}
