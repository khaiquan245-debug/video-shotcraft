from pathlib import Path
import wave,json,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;S=json.loads((B/'manifests/story-times.json').read_text());meta=json.loads((B/'manifests/voice.json').read_text());D=S['end'];N=round(D*R);T=np.arange(N)/R;rng=np.random.default_rng(740)
with wave.open(str(B/'audio/narration-final.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768;assert w.getframerate()==R
V=np.zeros(N,np.float32);i=round(meta['offset']*R);assert i+len(raw)<=N;V[i:i+len(raw)]=raw
F=np.zeros((N,2),np.float32);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;n=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='wood':a=(np.sin(2*np.pi*390*t)+.4*np.sin(2*np.pi*780*t)+.2*n)*np.exp(-t/.026)
 elif kind=='grass':a=np.convolve(n,np.ones(30)/30,'same')*env
 elif kind=='sweep':a=np.convolve(n,np.ones(10)/10,'same')*env*(.7+.3*np.sin(2*np.pi*16*t))
 elif kind=='saw':a=np.convolve(n,np.ones(7)/7,'same')*env*(.25+.75*np.sin(2*np.pi*4.5*t)**2)
 elif kind=='chisel':a=(np.sin(2*np.pi*710*t)+.34*np.sin(2*np.pi*1260*t)+.2*n)*np.exp(-t/.021)
 elif kind=='cloth':a=(n-np.convolve(n,np.ones(21)/21,'same'))*.5*env
 elif kind=='air':a=np.convolve(n,np.ones(45)/45,'same')*env
 elif kind=='ceramic':a=(np.sin(2*np.pi*650*t)+.3*np.sin(2*np.pi*1420*t))*np.exp(-t/.045)
 elif kind=='hinge':a=(np.sin(2*np.pi*(155*t+43*t*t))+.3*np.sin(2*np.pi*440*t))*env
 elif kind=='chime':a=(np.sin(2*np.pi*659.25*t)+.3*np.sin(2*np.pi*987.77*t))*np.exp(-t/.22)
 elif kind=='bird':a=np.sin(2*np.pi*(1500*t+180*t*t)+6*np.sin(2*np.pi*7*t))*env*(.55+.45*np.sin(2*np.pi*11*t))
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 start=round(at*R);assert 0<=start<N
 a=fx(kind,d)[:N-start]*gain;F[start:start+len(a),0]+=a*np.sqrt((1-pan)/2);F[start:start+len(a),1]+=a*np.sqrt((1+pan)/2)
 events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,5),'duration':min(d,(N-start)/R),'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'provenance':'Original oscillator/noise synthesis in production/audio.py','rights':'self-created, no external recording'})
for at in np.arange(.1,1.8,1/3.8):add(float(at),'grass',.08,.14,-.3,'Boot contacts forest ground while approaching hollow tree')
add(1.95,'wood',.035,.10,0,'Hand touches hollow entrance bark')
add(S['decide']+.9,'wood',.065,.16,-.3,'Axe handle rests on stump; no chopping of the tree')
for at in np.arange(S['clean']+.25,S['widen']-.05,.5):add(float(at),'sweep',.11,.35,.1,'Broom pushes rotten wood across the floor')
add(S['widen']+.08,'saw',.10,S['dark']-S['widen']-.16,.1,'Hand-held saw enlarges the entrance with repeated cutting strokes')
for at in np.arange(S['windows']+.222,S['floor']-.04,2/9):add(float(at),'chisel',.075,.14,-.25 if at<S['windows']+(S['floor']-S['windows'])/2 else .3,'Hammer/chisel contact at a window opening')
def inv_e(y):
 a,z=0.,1.
 for _ in range(30):
  x=(a+z)/2
  if x*x*(3-2*x)<y:a=x
  else:z=x
 return(a+z)/2
for j in range(8):add(S['floor']+(S['bed']-S['floor']-.1)*inv_e((j+1)/8),'wood',.035,.12,-.1+j*.035,'Floor plank settles onto the supporting floor at its authored landing time')
for at in[S['bed']+.18,S['bed']+.4,S['bed']+.65]:add(at,'wood',.075,.14,.25,'Hammer assembles the bed frame')
add(S['bed']+.55,'cloth',.035,.35,.25,'Mattress and blanket roll onto the finished bed')
for at in[S['problem']+.35,S['stuffy']+.3]:add(at,'cloth',.025,.2,0,'Leaf fan moves near the characters face in the stuffy room')
for j in range(4):add(S['vents']+.18+j*.35,'chisel',.08,.14,.12,'Upper ventilation slot opens after tool contact')
add(S['vents']+.65,'air',.07,1.1,.1,'Fresh air enters through new upper slots')
for at in[S['door']+.23,S['door']+.48,S['door']+1.13,S['door']+1.43]:add(at,'wood',.07,.12,-.1,'Hammer fixes the upper then lower door hinge')
add(S['decorate']+.58,'ceramic',.036,.13,-.15,'Plant pot settles onto the small interior table')
add(S['decorate']+.68,'chime',.021,.45,.35,'Warm lamp turns on in the finished room')
add(S['final']+.15,'hinge',.035,.7,-.05,'New door swings open as character takes its handle')
for at in[S['final']+.15+1/4.2,S['final']+.15+2/4.2]:add(at,'wood',.03,.13,0,'Shoes step over the new wooden threshold')
for at,pan in[(.1,-.6),(8.5,.6),(17.5,-.6),(D-1.3,.55)]:add(at,'bird',.006,.45,pan,'Distant forest bird; restrained location ambience')
# An original light major-key plucked score; lower notes during the two short obstacle passages.
M=np.zeros(N,np.float32);notes=[261.626,329.628,391.995,523.251,440,391.995,329.628,293.665]
for k,at in enumerate(np.arange(.04,D-.25,.492)):
 start=round(at*R);d=min(.65,(N-start)/R);tt=np.arange(round(d*R))/R;f=notes[k%8]
 if S['dark']<=at<S['windows']or S['problem']<=at<S['vents']:f*=.5
 a=(np.sin(2*np.pi*f*tt)+.3*np.sin(2*np.pi*f*2*tt)+.1*np.sin(2*np.pi*f*3*tt))*np.exp(-tt/.18);M[start:start+len(a)]+=.021*a
 if k%4==0:M[start:start+len(a)]+=.008*np.sin(2*np.pi*f/2*tt)*np.exp(-tt/.28)
noise=rng.normal(0,1,N).astype(np.float32);A=.008*np.convolve(noise,np.ones(70)/70,'same');A*=np.where((T>=S['dark'])&(T<S['windows']),.25,1.)
rms=np.sqrt(np.mean(V[:N//480*480].reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(17)/17,'same');M*=np.interp(np.arange(N),np.arange(len(gate))*480,1-.66*gate)
fade=np.minimum(1,np.minimum(T/.05,(D-T)/.3));M*=fade;A*=fade;F*=fade[:,None]
stereo=np.column_stack((V+M+A,V+M+A*.96))+F;pre_gain=min(1.,.98/float(np.max(np.abs(stereo))));stereo*=pre_gain

def save(name,a):
 with wave.open(str(B/'audio'/name),'wb')as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',A),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
caps=json.loads((B/'manifests/captions.json').read_text())
def ts(s):
 ms=round(s*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Than_Cay_Rong_Thanh_Nha.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}'for i,q in enumerate(caps)),encoding='utf-8')
(B/'manifests/sound-events.json').write_text(json.dumps({'events':events,'music':'Original major-key plucked melody,122BPM, synthesized locally, no third-party track','ambience':'Original synthesized soft forest air and sparse bird chirps','pre_master_gain':pre_gain,'paid_apis':False},ensure_ascii=False,indent=2));print('AUDIO',D,'s',len(events),'events','preGain',pre_gain)
