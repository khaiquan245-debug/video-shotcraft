from pathlib import Path
import json,hashlib,wave,csv
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';r=json.loads((B/'qa/final.json').read_text());v=json.loads((B/'manifests/voice.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());sound=json.loads((B/'manifests/sound-events.json').read_text())
script=' '.join((B/'audio/script-approved.txt').read_text().split());assert script==' '.join(q['text']for q in caps);assert len(script.split())==149
with wave.open(str(B/'audio/voice-timeline.wav'))as w:x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
active=np.where(np.abs(x)>.005)[0];a=x[active[0]:active[-1]+1];n=len(a)//480;energy=np.sqrt(np.mean(a[:n*480].reshape(-1,480)**2,axis=1));best=run=0
for q in energy<.003:run=run+1 if q else 0;best=max(best,run)
summary={'script_units':149,'units_per_video_second':149/r['duration'],'max_internal_quiet_seconds':best/100,'caption_cues':len(caps),'foley_events':len(sound['events']),'source_native_sha256':v['native_sha256'],'final_mp4_sha256':r['sha256'],'paid_apis':False,'unmodified_script':True}
(B/'qa/pacing.json').write_text(json.dumps(summary,indent=2))
(O/'README.md').write_text('''# Biến một thân cây rỗng thành ngôi nhà

Video 30 giây, 1080×1920, 30 fps, hoạt hình 2D có nhân vật và đồ vật chuyển động. Mở `Than_Cay_Rong_Thanh_Ngoi_Nha_30s_1080x1920.mp4` hoặc `index.html`.

Giữ nguyên 149 tiếng của lời kể người dùng, gồm ngôi “anh ta”. Dựng theo nhịp Shorts đã chốt: gần 5 tiếng/giây, các thao tác nối nhau, kết gọn. Có phụ đề tiếng Việt, nhạc nguyên tác và SFX.

Giọng thực tế: VieNeu-TTS v3 Turbo chạy ONNX CPU offline, preset Hải Đăng; Minh Quân là alias của preset trong adapter hiện tại. File native dài 33,9 giây được giữ nguyên. Bản dựng thu gọn khoảng nghỉ và xử lý tốc độ khoảng 1,024×, giữ cao độ.

Phim dùng góc ngoài thân cây xen với mặt cắt minh họa nội thất. Khúc gỗ đặt rìu thuộc lớp ngoài, được ẩn khi nhìn mặt cắt bên trong. Các phần cửa, cửa sổ, sàn, giường và khe thông gió được giữ theo tiến độ câu chuyện.

ZIP có MP4, SRT, source Canvas/FFmpeg, các WAV, metadata giọng, font/giấy phép và QA. Không đóng gói model weights hoặc video tham khảo. Không API trả phí.

Muốn dựng lại, tạo bản sao dự án ở thư mục mới trước khi chạy; giữ các WAV đã duyệt. Source dùng @napi-rs/canvas đã cài tại `/workspace/video-shotcraft/workbench/package.json`:

```bash
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
```

Đọc `Production_Report.md` để xem kiểm tra thật và giới hạn. Mốc phụ đề trong câu được ước lượng theo cụm nghĩa, chưa forced-align từng từ. Kiểm tra kỹ thuật phát trình duyệt tắt tiếng không thay cho duyệt giọng bằng tai người.
''',encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn

Lời kể do người dùng cung cấp; giữ nguyên trong bản phim này. Nhân vật kế thừa bản FAST V2 của dự án. Bối cảnh và trạng thái ngôi nhà, dụng cụ, giường, cửa, cửa sổ và chuyển động được vẽ/diễn hoạt riêng bằng vector trong production/film.mjs. Không ghép khung hình hoặc soundtrack của video mẫu.

Giọng: VieNeu-TTS v3 Turbo, Apache-2.0, ONNX CPU local; preset thực tế Hải Đăng (alias Minh Quân). Nguồn model: https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo . Trọng số model nằm ngoài Git và gói tải.

Nhạc và Foley rừng/gỗ/cưa/đục/chân/cửa/gió/chậu cây được tự tổng hợp bằng oscillator/noise trong production/audio.py, không dùng bản thu bên thứ ba. Font Nunito theo SIL OFL, kèm assets/OFL-Nunito.txt. Không API trả phí hoặc cloud inference.
''',encoding='utf-8')
report=f'''# Kết quả sản xuất thực tế

**Biến một thân cây rỗng thành ngôi nhà — 30 giây, 9:16.** Lời kể giữ nguyên149tiếng tách theo khoảng trắng, đạt{149/r['duration']:.2f}tiếng/giây trên toàn phim. Đây là cách đếm gần đúng theo khoảng trắng tiếng Việt, không phải đo âm tiết ngữ âm hoặc điểm chất lượng.

Phim thật có hình và tiếng, 1080×1920,30fps,900frame. Nhân vật, dụng cụ, đồ vật và góc máy chuyển động; không dựng từ slideshow ảnh tĩnh.

## Diễn hoạt và bố cục

Các khối kể: tìm cây → đặt rìu xuống → quét dọn gỗ mục → cưa rộng cửa → phòng tối → tạo hai cửa sổ → lát sàn → dựng giường → nóng/ngột ngạt → đục khe trên cao → lắp bản lề/cửa → đặt chậu cây/bật đèn → mở cửa và giới thiệu ngôi nhà.

Dùng nhiều góc cận theo tay và dụng cụ, hai góc cửa sổ nối bằng cut, khung cao cho công việc thông gió, mặt cắt cho nội thất và góc kéo rộng khi hoàn thiện. Mặt cắt là quy ước minh họa: lớp vỏ phía trước và khúc gỗ đặt rìu ở ngoài được bỏ khi nhìn phòng; đây không phải sự biến mất của đồ vật trong cốt truyện.

Đã sửa trong nháp: đặt rìu lệch khỏi mặt; đưa nhân vật ra khỏi vùng khúc gỗ khi lắp bản lề; điều chỉnh tư thế và tay cầm búa theo bản lề trên/dưới; đưa khúc gỗ ra khỏi lớp nhìn nội thất; chỉnh tay/chậu cây/mặt bàn; đặt chân lên mặt giàn công tác; chuyển bước trên giàn và qua cửa theo nhịp chân. Dụng cụ bám theo cổ tay, không dùng cánh tay phụ.

## Giọng và âm thanh

Model thực tế: **VieNeu-TTS v3 Turbo**, **ONNX CPU offline**. Giọng thực tế **Hải Đăng**; **Minh Quân** là alias trong adapter. Native{v['native_duration']}giây được bảo toàn; biên câu giữ đệm40/45ms, nối45ms; bản ghép{v['compacted_duration']:.3f}giây, FFmpeg atempo={v['pitch_preserving_tempo']:.6f}, giữ cao độ, thành{v['vo_duration']:.3f}giây. Không cắt/thêm lời, không ghi đè narration của dự án cũ.

{len(caps)}cụm phụ đề một dòng; mốc câu theo đoạn TTS đã đo, biên cụm trong câu ước lượng, chưa forced alignment từng từ. {len(sound['events'])}sự kiện Foley có vật thể/va chạm/địa điểm trong spotting list; nhạc pluck tự sáng tác và ambience rừng tự tổng hợp, phối ưu tiên giọng.

## Kiểm tra tệp đã render

- MP4{r['duration']:.3f}giây, H.264 yuv420p/AAC stereo48kHz; giải mã toàn bộ thành công.
- Âm lượng{r['lufs']}LUFS, true peak{r['true_peak_dbfs']}dBTP.
- Khoảng yên dài nhất trên track giọng RMS<0,003:{r['narration_max_quiet_seconds']:.2f}giây; phần giữa các đoạn có lời:{best/100:.2f}giây.
- Rig:{r['rig']['samples']}mẫu tay/chân, {r['rig']['unreachable']}đích ngoài tầm; sai số chiều dài xương tối đa{r['rig']['maxBoneError']:.3g}.
- SHA-256:`{r['sha256']}`; dung lượng{r['bytes']}bytes.

Xem ảnh trích từ MP4 thật ở các nhịp công cụ và các chuyển cảnh; phát thử trình duyệt1× để kiểm tra kỹ thuật. Phiên phát kiểm tra tắt tiếng; chưa có duyệt phát âm/độ dễ nghe bằng tai người. Các số đo không bảo đảm mọi che khuất hoặc diễn xuất đều hoàn hảo, không tự chứng nhận tương đương thẩm mỹ với mẫu hay sự duyệt của người dùng.

Bản phim cũ và installed skills không bị sửa. Model weights ở ngoài Git. Không dùng paid API, cloud inference hay subscription mới. Dự án mới: `{B}`.
'''
for a,z in [('nguyên149','nguyên 149'),('đạt4','đạt 4'),('giây,30','giây, 30'),('1920,30','1920, 30'),('fps,900','fps, 900'),('Native33','Native 33'),('đệm40','đệm 40'),('nối45','nối 45'),('ghép30','ghép 30'),('thành29','thành 29'),('MP430','MP4 30'),('lượng-','lượng -'),('peak-','peak -'),('003:','003: '),('Rig:','Rig: '),('đa4','đa 4'),('lượng6','lượng 6'),('trình duyệt1×','trình duyệt 1×')]:report=report.replace(a,z)
import re
report=re.sub(r'(\d+(?:[.,]\d+)?)(tiếng|giây|ms|fps|frame|cụm|sự kiện|LUFS|dBTP|mẫu|đích|bytes)',r'\1 \2',report)
(O/'Production_Report.md').write_text(report,encoding='utf-8')
with(O/'Shot_Timeline.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['action','start_seconds','end_seconds']);keys=sorted(S,key=S.get)
 for i,k in enumerate(keys[:-1]):w.writerow([k,S[k],S[keys[i+1]]])
(B/'qa/asset-origin.json').write_text(json.dumps({'film_source_sha256':hashlib.sha256((B/'production/film.mjs').read_bytes()).hexdigest(),'origin':'Original project vector artwork; previous own character identity reused','reference_video_pixels_or_sound_in_final':False,'native_voice_sha256':v['native_sha256'],'weights_in_project':False,'paid_apis':False},indent=2))
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));w,h=180,320;board=Image.new('RGB',(6*w,5*(h+24)),'#183e38');d=ImageDraw.Draw(board)
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((w,h));x=i%6*w;y=i//6*(h+24);board.paste(im,(x,y));d.text((x+5,y+h+5),f'{i+.5:.1f}s',fill='#fff3d0')
board.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
print('REPORT',r['sha256'],summary)
