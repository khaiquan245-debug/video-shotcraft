from pathlib import Path
import json,wave,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;OFFSET=.04
m=json.loads((B/'audio/narration-native.json').read_text());assert m['inference_offline']
with wave.open(str(B/'audio/narration-native.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy();assert w.getframerate()==R
parts=[];cursor=0;spans=[];trims=[]
for q in m['captions']:
 x=raw[round(q['start']*R):round(q['end']*R)];ws=480;k=len(x)//ws;v=x[:k*ws].astype(float)/32768;energy=np.sqrt(np.mean(v.reshape(-1,ws)**2,axis=1));aidx=np.where(energy>max(.004,float(np.max(np.abs(v)))*.013))[0];assert len(aidx)
 a=max(0,int(aidx[0])*ws-round(.04*R));z=min(len(x),(int(aidx[-1])+1)*ws+round(.045*R));start=cursor/R;parts.append(x[a:z]);cursor+=z-a;spans.append({'text':q['text'],'start':start,'end':cursor/R});trims.append({'sentence':q['text'],'leading_removed':a/R,'trailing_removed':(len(x)-z)/R});parts.append(np.zeros(round(.045*R),dtype='<i2'));cursor+=round(.045*R)
parts.pop();cursor-=round(.045*R);compact=np.concatenate(parts);tempo=max(1.,len(compact)/R/29.55)
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-final.wav')],check=True)
with wave.open(str(B/'audio/narration-final.wav'))as w:vo_d=w.getnframes()/R
factor=(len(compact)/R)/vo_d
for s in spans:s.update(start=OFFSET+s['start']/factor,end=OFFSET+s['end']/factor)
D=math.ceil((OFFSET+vo_d+.35)*10)/10
phrases=[['Anh ta tìm thấy','một thân cây khổng lồ','đã rỗng ruột.'],['Thay vì chặt bỏ nó,','anh ta quyết định','biến nó thành','một ngôi nhà.'],['Đầu tiên,','anh ta dọn sạch','toàn bộ phần gỗ mục','bên trong.'],['Sau đó,','anh ta mở rộng','cửa ra vào','để có thể','đi vào dễ dàng.'],['Nhưng bên trong','quá tối','để có thể sinh hoạt.'],['Vì vậy,','anh ta tạo thêm','một vài ô cửa sổ nhỏ.'],['Tiếp theo,','anh ta lát sàn gỗ','và dựng','một chiếc giường.'],['Nhưng vẫn còn','một vấn đề.'],['Không khí bên trong','rất ngột ngạt.'],['Thế là anh ta','tạo thêm những khe','thông gió ở phía trên.'],['Cuối cùng,','anh ta lắp','một cánh cửa','và trang trí lại','toàn bộ không gian.'],['Một thân cây','tưởng như vô dụng','giờ đã trở thành','một ngôi nhà nhỏ','giữa rừng.']]
caps=[]
for s,ps in zip(spans,phrases):
 assert ' '.join(ps)==s['text']
 n=sum(len(p.split())for p in ps);a=s['start']
 for j,p in enumerate(ps):
  z=s['end']if j==len(ps)-1 else a+(s['end']-s['start'])*len(p.split())/n
  caps.append({'text':p,'start':a,'end':z,'emphasis':any(k in p for k in ['quá tối','ngột ngạt','ngôi nhà nhỏ'])});a=z
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
keys=['discover','decide','clean','widen','dark','windows','floor','problem','stuffy','vents','door','final'];S={k:s['start']for k,s in zip(keys,spans)};S['discover']=0.;S['bed']=S['floor']+(S['problem']-S['floor'])*.57;S['decorate']=S['door']+(S['final']-S['door'])*.55;S['end']=D
(B/'manifests/story-times.json').write_text(json.dumps(S,indent=2));(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
meta={'duration':D,'vo_duration':vo_d,'native_duration':m['duration'],'compacted_duration':len(compact)/R,'offset':OFFSET,'pitch_preserving_tempo':tempo,'native_sha256':m['wav_sha256'],'voice_sha256':hashlib.sha256((B/'audio/narration-final.wav').read_bytes()).hexdigest(),'trim_log':trims,'sentence_spans':spans,'space_units':len((B/'audio/script-approved.txt').read_text().split()),'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'offline':True}
(B/'manifests/voice.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(B/'manifests/project.json').write_text(json.dumps({'title':'Biến một thân cây rỗng thành ngôi nhà','duration':D,'resolution':[1080,1920],'fps':30,'aspect':'9:16','style':'Original full-color2D cutaway cartoon; previous character identity','script':'Exact user narration, third-person wording preserved','pacing_profile':'/workspace/outputs/production_rules/shorts-fast-profile.json','paid_apis':False},ensure_ascii=False,indent=2))
print('VOICE',json.dumps({k:meta[k]for k in ['native_duration','compacted_duration','vo_duration','duration','pitch_preserving_tempo','space_units']}));print('STORY',S)
