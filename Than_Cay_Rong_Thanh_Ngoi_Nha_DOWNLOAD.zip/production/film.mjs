import fs from'node:fs';import path from'node:path';import{fileURLToPath}from'node:url';import{createRequire}from'node:module';import{spawn}from'node:child_process';import{once}from'node:events';
const require=createRequire('/workspace/video-shotcraft/workbench/package.json');const{createCanvas,GlobalFonts}=require('@napi-rs/canvas');
export const B=path.resolve(fileURLToPath(new URL('..',import.meta.url)));GlobalFonts.registerFromPath(B+'/assets/Nunito.ttf','Nunito');
const S=JSON.parse(fs.readFileSync(B+'/manifests/story-times.json'));export const W=720,H=1280,D=S.end;export const QA={samples:0,unreachable:0,maxBoneError:0};
const K='#40383a',C=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),E=x=>{x=C(x);return x*x*(3-2*x)},L=(a,b,u)=>a+(b-a)*u,U=(t,a,d)=>E((t-a)/d),mix=(a,b,u)=>a.map((v,i)=>L(v,b[i],u));
function stroke(c,col=K,w=4){c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.stroke()}
function line(c,pts,col=K,w=4){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));stroke(c,col,w)}
function poly(c,pts,col,edge=K,w=4){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.fillStyle=col;c.fill();if(edge)stroke(c,edge,w)}
function ellipse(c,x,y,rx,ry,col,edge=null,w=3){c.beginPath();c.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),0,0,Math.PI*2);if(col){c.fillStyle=col;c.fill()}if(edge)stroke(c,edge,w)}
function box(c,x,y,w,h,r,col,edge=null,lw=4){c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle=col;c.fill();if(edge)stroke(c,edge,lw)}
function grad(c,x,y,xx,yy,colors){let g=c.createLinearGradient(x,y,xx,yy);colors.forEach((s,i)=>g.addColorStop(i/(colors.length-1),s));return g}
function txt(c,s,x,y,size=44,col='#fff',align='center'){c.font=`900 ${size}px Nunito`;c.textAlign=align;c.textBaseline='middle';c.fillStyle=col;c.fillText(s,x,y)}
function shape(c,draw,col,edge=K,w=4){c.beginPath();draw(c);c.fillStyle=col;c.fill();if(edge)stroke(c,edge,w)}
function ik(a,b,l1,l2,sign){let dx=b[0]-a[0],dy=b[1]-a[1],d=Math.hypot(dx,dy);if(d>l1+l2+.01||d<Math.abs(l1-l2)-.01){QA.unreachable++;throw Error('IK '+JSON.stringify({a,b,d,l1,l2}))}let ang=Math.atan2(dy,dx)+sign*Math.acos(C((l1*l1+d*d-l2*l2)/(2*l1*Math.max(.001,d)),-1,1));let q=[a[0]+l1*Math.cos(ang),a[1]+l1*Math.sin(ang)];QA.samples++;QA.maxBoneError=Math.max(QA.maxBoneError,Math.abs(Math.hypot(q[0]-a[0],q[1]-a[1])-l1),Math.abs(Math.hypot(b[0]-q[0],b[1]-q[1])-l2));return q}
function hand(c,q,angle=0){c.save();c.translate(...q);c.rotate(angle);ellipse(c,0,0,7,8,'#f8bd83',K,2.5);ellipse(c,5,-3,3,4,'#ffd3a0',K,1.5);c.restore()}
function project(p,q){let r=p.lean||0,x=q[0],y=q[1]-125;return[p.x+x*Math.cos(r)-y*Math.sin(r),p.y+125+x*Math.sin(r)+y*Math.cos(r)]}
function gait(t,speed=100,cadence=2.6,ground=215){let period=2/cadence;return[0,1].map(i=>{let phase=(t/period+i*.5)%1;if(phase<.5)return[speed*period*(.25-phase),ground];let u=(phase-.5)*2;return[L(-speed*period*.25,speed*period*.25,E(u)),ground-25*Math.sin(Math.PI*u)]})}
function actor(c,p){let t=p.time||0,breath=Math.sin(t*2.7)*.7,p0={...p,y:p.y+breath},arms=p.hands||[project(p0,[-29,132]),project(p0,[29,132])],feet=p.feet||[[p.x-15,p.y+220],[p.x+18,p.y+220]],hips=[project(p0,[-11,123]),project(p0,[11,123])];
 for(let i=0;i<2;i++){let q=ik(hips[i],feet[i],50,52,i?-1:1);line(c,[hips[i],q,feet[i]],K,19);line(c,[hips[i],q,feet[i]],i?'#3d6479':'#325569',13);let f=feet[i];box(c,f[0]-10,f[1]-9,30,12,5,'#d9a747',K,3);line(c,[[f[0]-8,f[1]+3],[f[0]+19,f[1]+3]],'#f7d877',3)}
 const P=q=>project(p0,q);shape(c,ctx=>{ctx.moveTo(...P([-24,43]));ctx.quadraticCurveTo(...P([-35,55]),...P([-30,112]));ctx.quadraticCurveTo(...P([0,132]),...P([31,112]));ctx.lineTo(...P([31,56]));ctx.lineTo(...P([24,43]));ctx.closePath()},grad(c,p.x-35,p.y,p.x+40,p.y,['#ffcb63','#ed9c40','#da7e31']),K,4);
 line(c,[P([0,49]),P([0,119])],'#ba7439',2);line(c,[P([-17,90]),P([-10,102]),P([10,102]),P([17,90])],'#b37438',2);line(c,[P([-8,51]),P([-8,70])],'#fff0ba',2);line(c,[P([8,51]),P([8,70])],'#fff0ba',2);
 let elbows=[];for(let i=0;i<2;i++){let a=P([i?25:-25,55]),b=arms[i],q=ik(a,b,40,39,i?-1:1);elbows.push(q);line(c,[a,q,b],K,20);line(c,[a,q,b],i?'#eea241':'#ffc45b',14);let cuff=mix(q,b,.82);line(c,[cuff,b],'#f5c99b',13);hand(c,b)}
 let hd=P([0,0]);c.save();c.translate(...hd);c.rotate(p.head||0);ellipse(c,-33,4,8,10,'#f0b480',K,3);ellipse(c,33,4,8,10,'#f0b480',K,3);
 shape(c,ctx=>{ctx.moveTo(-33,-15);ctx.bezierCurveTo(-40,24,-18,42,2,39);ctx.bezierCurveTo(28,37,41,14,33,-17);ctx.bezierCurveTo(19,-40,-20,-40,-33,-15)},'#ffd3a1',K,4);
 shape(c,ctx=>{ctx.moveTo(-35,4);ctx.bezierCurveTo(-46,-22,-28,-43,-7,-40);ctx.lineTo(4,-51);ctx.lineTo(9,-38);ctx.bezierCurveTo(29,-38,44,-25,34,0);ctx.lineTo(24,-14);ctx.lineTo(16,-8);ctx.lineTo(7,-20);ctx.lineTo(-4,-11);ctx.lineTo(-11,-18);ctx.bezierCurveTo(-22,-6,-26,-6,-35,4)},'#413238',K,3);
 let blink=Math.exp(-(((t%3.7-3.25)/.055)**2)),smile=p.mood==='happy',worried=p.mood==='worried',sleep=p.mood==='sleep';
 for(let i=0;i<2;i++){let xx=i?14:-13;if(p.profile&&i===0)continue;let yy=4,rx=worried?6:5,ry=worried?8:6;if(blink>.75||sleep)line(c,[[xx-5,yy],[xx,yy+2],[xx+5,yy]],K,2.5);else{ellipse(c,xx,yy,rx,ry,'#fff8e7',K,2);ellipse(c,xx+(p.look||0)*2,yy,2.5,3.8,'#443339');ellipse(c,xx+1,yy-2,1,1,'#fff')}
  line(c,[[xx-6,-10+(worried?(i?-3:3):0)],[xx+5,-10+(worried?(i?3:-3):0)]],'#49363b',2.2)}
 ellipse(c,0,15,3,2,'#e7a677');ellipse(c,-23,18,7,3,'#eea58d');ellipse(c,23,18,7,3,'#eea58d');if(worried)ellipse(c,3,27,5,6,'#683b3b',K,1.7);else if(smile){shape(c,ctx=>{ctx.moveTo(-9,23);ctx.quadraticCurveTo(1,32,11,22);ctx.quadraticCurveTo(3,39,-9,23)},'#814b4e',K,1.5);line(c,[[-5,25],[7,25]],'#fff2d9',2)}else line(c,[[-6,26],[2,28],[8,25]],'#754d43',2.2);
 c.restore();for(let i of(p.frontHands||[])){line(c,[elbows[i],arms[i]],K,20);line(c,[elbows[i],arms[i]],'#f1aa48',14);hand(c,arms[i]);}return{wrists:arms,feet,head:hd,elbows};}
const caps=JSON.parse(fs.readFileSync(B+'/manifests/captions.json'));
function hero(c,x,y,t,o={}){c.save();c.translate(x,y);if(o.scale)c.scale(o.scale,o.scale);returnActor(c,t,o);c.restore()}
function returnActor(c,t,o){return actor(c,{x:0,y:0,time:t,lean:o.lean||0,head:o.head||0,mood:o.mood||'neutral',look:o.look||0,hands:o.hands||[[-35,124],[35,124]],feet:o.feet||[[-17,220],[22,220]],frontHands:o.frontHands||[]})}
function hpoint(x,y,p){return[x+p[0],y+p[1]]}
function leaf(c,x,y,a=0,s=1,col='#89ad70'){c.save();c.translate(x,y);c.rotate(a);c.scale(s,s);shape(c,q=>{q.moveTo(-48,0);q.quadraticCurveTo(-10,-45,50,-5);q.quadraticCurveTo(7,25,-48,0)},col,K,3);line(c,[[-40,0],[39,-5]],'#557a51',2);c.restore()}
function arch(c,x,y,w,h,color,edge=K,lw=5){shape(c,q=>{q.moveTo(x,y+h);q.lineTo(x,y+w*.35);q.bezierCurveTo(x,y-w*.13,x+w,y-w*.13,x+w,y+w*.35);q.lineTo(x+w,y+h);q.closePath()},color,edge,lw)}
function bole(c){shape(c,q=>{q.moveTo(410,986);q.bezierCurveTo(540,900,500,660,590,315);q.bezierCurveTo(640,95,580,-170,508,-415);q.lineTo(595,-460);q.bezierCurveTo(690,-260,725,-200,740,-80);q.bezierCurveTo(795,-290,732,-535,750,-820);q.lineTo(1005,-850);q.bezierCurveTo(1050,-615,1020,-310,1075,-85);q.bezierCurveTo(1150,-300,1280,-440,1375,-530);q.lineTo(1450,-445);q.bezierCurveTo(1295,-255,1260,-40,1298,230);q.bezierCurveTo(1360,560,1320,830,1490,985);q.bezierCurveTo(1320,1015,1260,969,1175,986);q.lineTo(650,986);q.bezierCurveTo(560,1004,470,1009,410,986)},grad(c,500,-300,1410,1000,['#c49668','#af7956','#936447','#79553f']),K,7);
 for(let i=0;i<25;i++){let x=560+i*31;line(c,[[x+Math.sin(i)*20,180+(i%4)*60],[x-12,470],[x+9,705],[x-14,952]],i%2?'#8c6045':'#b28459',3)}
 for(let q of[[655,225,21,42],[1222,468,24,56],[1080,135,18,33],[560,770,15,45]]){ellipse(c,...q,null,'#79563f',4);ellipse(c,q[0],q[1],q[2]*.45,q[3]*.55,null,'#bc8d5d',3)}
 for(let q of[[530,-420,230,160],[735,-695,250,165],[1020,-700,260,185],[1370,-440,245,170],[1130,-280,270,140],[770,-300,270,180]]){ellipse(c,...q,'#8eac7a',K,5);ellipse(c,q[0]-30,q[1]-35,q[2]*.73,q[3]*.68,'#afc58e')}
 line(c,[[560,400],[572,500],[550,610],[563,710]],'#6f8655',5);for(let i=0;i<12;i++){let y=418+i*23;ellipse(c,565+(i%2?13:-13),y,16,6,i%2?'#91ad69':'#7d995d',K,1)}
}
function forest(c,t){c.fillStyle=grad(c,0,-1400,0,2600,['#c7dfd0','#e9e9be','#adb988']);c.fillRect(-5000,-5000,12000,12000);
 for(let layer=0;layer<3;layer++)for(let i=-8;i<18;i++){let x=i*220+layer*77,s=1+layer*.2;shape(c,q=>{q.moveTo(x-24*s,965);q.lineTo(x+9*s,-650);q.lineTo(x+65*s,-650);q.lineTo(x+95*s,965)},['#b3c6ae','#9eb59c','#879f87'][layer],null);ellipse(c,x+35,-230+layer*120,200,300,['#bbcfaa','#aac398','#9bb78a'][layer]);line(c,[[x+44,370],[x-45,190]],['#b3c6ae','#9eb59c','#879f87'][layer],14)}
 c.fillStyle='#91a46f';c.fillRect(-5000,946,12000,42);c.fillStyle=grad(c,0,970,0,2200,['#bb976a','#a88564','#8e7158']);c.fillRect(-5000,982,12000,6000);line(c,[[-5000,982],[7000,982]],'#6f855e',5);
 for(let i=0;i<120;i++){let x=-2000+(i*197)%7000,y=1000+(i*137)%1200;ellipse(c,x,y,3+i%4,2,'#c6aa7c')}
 for(let x of[170,410,1500,1660]){line(c,[[x,970],[x-17,875]],'#688956',4);leaf(c,x-23,912,-.6,.55);leaf(c,x+12,932,.45,.48);ellipse(c,x-18,865,10,8,'#e9c884',K,2)}
 // Sun shafts and motes are layered in the forest, independent of the house facade.
 c.save();c.globalAlpha=.11;for(let i=0;i<3;i++)poly(c,[[1280+i*140,-900],[1450+i*170,-900],[700+i*170,1100],[520+i*160,1100]],'#fff1b7',null);c.restore();for(let i=0;i<28;i++){let x=250+(i*113)%1300+Math.sin(t*.6+i)*20,y=150+(i*191+t*13)%800;ellipse(c,x,y,1.5,2,'rgba(255,246,202,.55)')}
}
function roomPath(c){c.beginPath();c.moveTo(590,960);c.lineTo(590,600);c.bezierCurveTo(600,305,1255,300,1280,600);c.lineTo(1280,960);c.closePath()}
function wid(t){return U(t,S.widen+.28,(S.dark-S.widen)*.75)}
function opening(c,t){let u=wid(t),w=L(95,190,u),x=910-w/2,y=L(720,680,u);arch(c,x,y,w,960-y,'#29342d',K,6);arch(c,x+9,y+10,w-18,950-y,grad(c,x,y,x+180,960,['#3d4734','#63543d']),null);line(c,[[x+6,958],[x+w-6,958]],t>S.floor?'#cfaf76':'#796946',7)}
function windowArt(c,x,t,progress=1){c.save();c.beginPath();c.rect(x-71,530,142*C(progress),184);c.clip();box(c,x-65,535,130,175,18,'#3c4b3b',K,5);box(c,x-52,548,104,144,13,grad(c,x,548,x,692,['#b7d5c8','#e6e6b4']),K,3);line(c,[[x,548],[x,690]],'#d9b87b',7);line(c,[[x-51,620],[x+51,620]],'#d9b87b',7);box(c,x-76,699,152,17,6,'#c8a16b',K,3);if(t>S.bed+.65){c.save();c.globalAlpha=.7;line(c,[[x-48,672],[x+47,672]],'#6e9ea2',10);c.restore()}c.restore()}
function windows(c,t){let d=S.floor-S.windows;if(t<S.windows)return;windowArt(c,710,t,U(t,S.windows+.15,d*.32));windowArt(c,1150,t,U(t,S.windows+d*.55,d*.35))}
function vents(c,t){if(t<S.vents)return;for(let i=0;i<4;i++){let q=U(t,S.vents+.18+i*.35,.22);if(!q)continue;c.save();c.beginPath();c.rect(829+i*55,390,49*q,62);c.clip();box(c,830+i*55,396,40,55,8,'#31483c',K,3);for(let y=405;y<445;y+=12)line(c,[[833+i*55,y],[868+i*55,y]],'#b09c68',4);c.restore()}}
function floor(c,t){if(t<S.floor)return;let u=U(t,S.floor,S.bed-S.floor-.1);for(let i=0;i<8;i++){let at=i/8;if(u<at)continue;let v=E(C((u-at)*8)),x=610+i*80,y=L(920,959,v);box(c,x,y,78,16,3,'#c7a16b',K,3);line(c,[[x+8,y+7],[x+68,y+7]],'#a78152',1.5)}}
function bed(c,t){if(t<S.bed)return;let u=U(t,S.bed,.8);for(let x of[960,1205]){let v=U(t,S.bed+(x===960?0:.2),.25);line(c,[[x,953],[x,953-110*v]],'#876446',17)}if(u>.2)box(c,940,832,290,34,8,'#b68d5f',K,4);if(u>.6){let v=U(t,S.bed+.52,.27);box(c,945,815,282*v,34,11,'#d5dfbf',K,4);box(c,963,799,80*v,29,12,'#f0e2b8',K,2);if(v>.7){shape(c,q=>{q.moveTo(1050,812);q.lineTo(1223,812);q.lineTo(1223,886);q.quadraticCurveTo(1130,870,1050,880)},'#83aaa9',K,3);for(let x=1067;x<1220;x+=25)line(c,[[x,817],[x,877]],'#b5cec0',2)}}}
function scaffold(c,x,top,width=160){for(let xx of[x-width/2+15,x+width/2-15])line(c,[[xx,top+14],[xx+(xx<x?-28:28),960]],'#8a6d4e',13);box(c,x-width/2,top,width,16,4,'#c1a16b',K,4);for(let y=top+66;y<945;y+=70)line(c,[[x-width/2+8,y],[x+width/2-8,y]],'#a38559',8);line(c,[[x-width/2,top+25],[x+width/2+17,952]],'#9e8157',6)}
function wood(c,x,y,a=0,s=1){c.save();c.translate(x,y);c.rotate(a);box(c,-35*s,-10*s,70*s,20*s,5,'#876448',K,3);for(let i=0;i<3;i++)line(c,[[-27*s,-6*s+i*6*s],[28*s,-6*s+i*6*s]],'#b18c5d',2);c.restore()}
function debris(c,t){let u=U(t,S.clean+.12,S.widen-S.clean-.25);for(let i=0;i<10;i++){let p=C((u-i*.07)/.37),x=L(940+i*27,1360+(i%3)*30,p),y=945-55*Math.sin(p*Math.PI);wood(c,x,y,(i*.5+p*3),.65+(i%3)*.15)}if(t<S.clean+.4)for(let i=0;i<12;i++)ellipse(c,660+i*47,947+(i%2)*8,6,3,'#745b41')}
function axe(c,q){c.save();c.translate(...q);c.rotate(-.5);line(c,[[0,30],[0,-110]],K,11);line(c,[[0,30],[0,-110]],'#a38358',7);poly(c,[[-5,-125],[55,-119],[52,-80],[-5,-91]],'#91a7a1',K,4);line(c,[[52,-117],[50,-82]],'#d8dfc7',4);c.restore()}
function hammer(c,q,a=0){c.save();c.translate(...q);c.rotate(a);line(c,[[0,8],[10,-25]],K,10);line(c,[[0,8],[10,-25]],'#a67b51',6);box(c,-7,-33,37,16,4,'#91a29a',K,3);c.restore()}
function saw(c,q,phase){let d=6*Math.sin(phase*2*Math.PI);poly(c,[[q[0]-17,q[1]-7],[q[0]-115,q[1]-7],[q[0]-115,q[1]+14],[q[0]-17,q[1]+14]],'#aebeb1',K,3);for(let i=0;i<10;i++)poly(c,[[q[0]-24-i*9,q[1]+14],[q[0]-28-i*9,q[1]+20],[q[0]-32-i*9,q[1]+14]],'#aebeb1',K,1);box(c,q[0]-18,q[1]-16,35,42,8,'#c69d61',K,4);box(c,q[0]-8,q[1]-5,15,21,4,'#6c644b',K,2)}
function chips(c,x,y,t,amp=1){for(let i=0;i<7;i++){let v=(t*2.5+i*.14)%1;wood(c,x+(i-3)*15*v,y-35*Math.sin(Math.PI*v)+55*v*v,v*4,.11*amp)}}
function plant(c,x,y){box(c,x-27,y,54,43,8,'#bf8d64',K,3);box(c,x-31,y-4,62,12,4,'#d3a576',K,2);for(let i=0;i<5;i++){let xx=x+(i-2)*13,yy=y-38-(i%2)*15;line(c,[[x,y],[xx,yy]],'#65865a',3);leaf(c,xx,yy,i%2?.4:-.4,.32,'#94b776')}}
function decor(c,t){if(t<S.decorate)return;let u=U(t,S.decorate+.08,.5);box(c,684,895,85,14,4,'#b99665',K,3);for(let x of[693,760])line(c,[[x,907],[x,960]],'#8c6d4c',7);plant(c,725,L(830,852,u));if(t>S.decorate+.6){let x=1170,y=750;line(c,[[x,678],[x,y-25]],'#5f6247',3);box(c,x-19,y-20,38,50,9,'#d9bc6a',K,3);box(c,x-11,y-12,22,33,5,'#ffeda5');let g=c.createRadialGradient(x,y,5,x,y,260);g.addColorStop(0,'rgba(255,221,131,.30)');g.addColorStop(1,'rgba(255,221,131,0)');c.fillStyle=g;c.fillRect(x-260,y-260,520,520)}}
function doorPanel(c,t){if(t<S.door)return;let enter=t>=S.final,open=enter?U(t,S.final+.15,.7):0,width=L(190,28,open);arch(c,815,680,width,280,'#b9905b',K,5);for(let j=0;j<5;j++){let x=815+(j+.5)*width/5;line(c,[[x,730],[x,952]],'#8d6b48',2)}box(c,825,750,Math.max(4,width-22),90,10,'#c6ac76','#94754c',2);ellipse(c,815+width*.82,825,8,8,'#e6d088',K,2);for(let y of[735,900])box(c,812,y,18,9,3,'#77887a',K,2)}
function air(c,t){if(t<S.vents+.6)return;for(let j=0;j<4;j++){let u=(t*.6+j*.23)%1,x=840+j*55,y=420+u*330;c.beginPath();c.moveTo(x,410);c.bezierCurveTo(x-50,490,x+80,580,x+10,y);stroke(c,`rgba(204,228,209,${.16*(1-u)})`,3)}for(let i=0;i<8;i++){let u=(t*.2+i*.12)%1;ellipse(c,650+u*600,580+Math.sin(u*8+i)*70,2,1,'rgba(230,244,214,.55)')}}
function room(c,t){roomPath(c);c.fillStyle=grad(c,650,400,1150,960,t<S.windows?['#3b4133','#242e28','#514b35']:['#b4a271','#c9b985','#a38f64']);c.fill();stroke(c,K,7);c.save();roomPath(c);c.clip();for(let i=0;i<14;i++)line(c,[[620+i*48,440],[610+i*48,956]],t<S.windows?'#414735':'#a48e63',2);windows(c,t);if(t>=S.windows+.5){c.save();c.globalAlpha=.13;poly(c,[[660,550],[755,550],[1130,960],[790,960]],'#fff0b4',null);poly(c,[[1100,550],[1200,550],[1260,960],[1050,960]],'#fff0b4',null);c.restore()}floor(c,t);bed(c,t);decor(c,t);air(c,t);c.restore();}
function inside(t){return(t>=S.clean&&t<S.widen)||(t>=S.dark&&t<S.windows)||(t>=S.floor&&t<S.vents)||(t>=S.decorate&&t<S.final)}
function drawActorAction(c,t){let x=810,y=740,hands=[[-35,124],[35,124]],feet=[[-17,220],[22,220]],mood='neutral',head=0,tool=null;
 if(t<S.decide){let u=C(t/1.8);x=L(520,810,u);y=747;feet=t<1.8?gait(t,290/1.8,3.8,213):[[-17,213],[22,213]];hands=[[-35,124],[L(35,55,U(t,1.6,.3)),L(124,95,U(t,1.6,.3))]];mood='worried';tool='axe';}
 else if(t<S.clean){let u=U(t,S.decide+.2,.6);hands=[[-35-20*u,124],[48,105]];mood='happy';if(t<S.decide+.9)tool='axe';}
 else if(t<S.widen){let p=U(t,S.clean,S.widen-S.clean),wave=Math.sin((t-S.clean)*Math.PI*4);x=L(820,1000,C((t-S.clean)/(S.widen-S.clean)));y=800;feet=gait(t-S.clean,180/(S.widen-S.clean),2.6,160);hands=[[-35,95],[30+6*wave,110+3*wave]];tool='broom';head=.05;}
 else if(t<S.dark){let wave=Math.sin((t-S.widen)*Math.PI*9);x=1040;hands=[[-25,110],[-20+6*wave,105]];tool='saw';head=.04;}
 else if(t<S.windows){x=895;hands=[[-50,96],[45,75]];mood='worried';head=.04*Math.sin(t*4);}
 else if(t<S.floor){let local=t-S.windows,half=(S.floor-S.windows)/2,j=local<half?0:1;x=j?1050:610;y=535;hands=[[35,75],[45,100-12*Math.max(0,Math.sin(local*Math.PI*9))]];tool='window';scaffold(c,x,755,160);mood='happy';}
 else if(t<S.bed){let u=U(t,S.floor,.6);x=890;y=L(740,800,u);feet=[[-25,960-y],[30,960-y]];hands=[[-34,110],[42,120]];tool='floor';}
 else if(t<S.problem){x=890;hands=[[42,85],[50,115-10*Math.max(0,Math.sin((t-S.bed)*Math.PI*9))]];tool='bed';mood='happy';}
 else if(t<S.vents){x=895;let p=.5+.5*Math.sin((t-S.problem)*Math.PI*4);hands=[[-36,115],[50,25+35*p]];mood='worried';head=.04;tool='fan';}
 else if(t<S.door){let u=C((t-S.vents)/1.4);x=805+165*u;y=337;feet=u<1?gait(t-S.vents,165/1.4,3.8,218):[[-17,218],[22,218]];hands=[[35,73],[45,98-10*Math.max(0,Math.sin((t-S.vents)*Math.PI*10))]];scaffold(c,900,555,310);tool='vent';mood='happy';}
 else if(t<S.decorate){let half=(S.decorate-S.door)/2,u=U(t,S.door+half-.12,.26);x=L(850,890,u);y=L(740,812,u);feet=[[-22,960-y],[28,960-y]];hands=[mix([-35,22],[-75,115],u),mix([-35,35],[-35,93],u)];tool='hinge';mood='happy';}
 else if(t<S.final){let u=U(t,S.decorate+.08,.5);x=815;y=740;feet=[[-23,220],[29,220]];let release=U(t,S.decorate+.62,.3);hands=[mix([-63,100+22*u],[-35,124],release),[35,124]];mood='happy';}
 else{let u=U(t,S.final+.15,.7);y=747;feet=u>0&&u<1?gait(t-S.final-.15,190,4.2,213):[[-17,213],[22,213]];x=815+L(190,28,u)*.82+60;let step=U(t,S.final+1,.65);x=L(x,905,step);hands=[mix([-60,78],[-35,124],step),[45,35-25*Math.sin(t*9)*U(t,S.final+1.1,.2)]];mood='happy';head=.03;}
 hero(c,x,y,t,{hands,feet,mood,head});
 if(tool==='axe'){axe(c,hpoint(x,y,hands[0]));hand(c,hpoint(x,y,hands[0]));}
 if(tool==='broom'){let a=hpoint(x,y,hands[0]),b=hpoint(x,y,hands[1]),tip=[b[0]+(b[0]-a[0])*2,b[1]+(b[1]-a[1])*2];line(c,[[a[0]-20,a[1]-5],tip],K,9);line(c,[[a[0]-20,a[1]-5],tip],'#a98b56',5);poly(c,[[tip[0]-8,tip[1]-4],[tip[0]+15,tip[1]-6],[tip[0]+42,962],[tip[0]-18,962]],'#c2b178',K,3);for(let i=0;i<7;i++)line(c,[[tip[0]+i*3-5,tip[1]+2],[tip[0]-10+i*7,960]],'#8d8655',1.6);hand(c,a);hand(c,b)}
 if(tool==='saw'){let q=hpoint(x,y,hands[1]);saw(c,q,t);hand(c,q);let edge=910+L(95,190,wid(t))/2;chips(c,edge,846,t)}
 if(tool==='window'||tool==='vent'){let q=hpoint(x,y,hands[1]);hammer(c,q,-.76);hand(c,q);let a=hpoint(x,y,hands[0]);line(c,[[a[0],a[1]-9],[a[0]+2,a[1]+20]],'#8d9d8c',4);hand(c,a);chips(c,a[0],a[1],t,.5)}
 if(tool==='floor'){let q=hpoint(x,y,hands[1]),u=1-U(t,S.floor+.65,.2);if(u>.01){c.save();c.globalAlpha=u;box(c,q[0]-85,q[1]-8,175,17,4,'#caaa72',K,3);c.restore();hand(c,q)}}
 if(tool==='bed'){let q=hpoint(x,y,hands[1]);hammer(c,q,.2);hand(c,q)}
 if(tool==='hinge'){let q=hpoint(x,y,hands[0]);hammer(c,q,-.32);hand(c,q)}
 if(tool==='fan'){let q=hpoint(x,y,hands[1]);leaf(c,q[0]+12,q[1]-15,-.2,.52);line(c,[q,[q[0]+12,q[1]-15]],'#a08751',4);hand(c,q);ellipse(c,x-27,y-21,4,10,'#9ccbc9',K,1)}
 if(t>=S.decide+.9&&!inside(t)){box(c,690,895,95,65,11,'#9a754f',K,4);ellipse(c,737,895,48,12,'#c7a36d',K,3);axe(c,[755,865]);}
}
export function world(c,t){forest(c,t);bole(c);let cut=inside(t);if(cut)room(c,t);else{opening(c,t);windows(c,t);vents(c,t);doorPanel(c,t)}
 if(t>=S.clean)debris(c,t);drawActorAction(c,t);
 if(t>=S.dark&&t<S.windows){c.save();roomPath(c);c.clip();c.fillStyle='rgba(18,27,23,.30)';c.fillRect(580,360,710,600);c.restore()}
 if(t>=S.final){for(let x of[710,1150]){plant(c,x,704);let g=c.createRadialGradient(x,620,10,x,620,140);g.addColorStop(0,'rgba(255,225,138,.15)');g.addColorStop(1,'rgba(255,225,138,0)');c.fillStyle=g;c.fillRect(x-140,480,280,280)}}
 // Foreground fern layer and soft moving leaf shadows give depth without a static-image zoom.
 for(let x of[320,1500]){for(let i=0;i<5;i++)leaf(c,x+(i-2)*15,978-i*7,-.9+i*.4,.35,'#6c8f60')}
}
export function camera(t){let cx=900,cy=760,width=850;
 if(t<S.decide){cx=L(700,900,U(t,0,1.8));cy=750;width=L(1320,1020,U(t,.1,2.0))}
 else if(t<S.clean){cx=900;cy=780;width=L(1000,900,U(t,S.decide,2))}
 else if(t<S.widen){cx=L(960,1110,U(t,S.clean,S.widen-S.clean));cy=850;width=860}
 else if(t<S.dark){cx=990;cy=835;width=640}
 else if(t<S.windows){cx=895;cy=760;width=680}
 else if(t<S.floor){let half=(S.floor-S.windows)/2;cx=t<S.windows+half?685:1125;cy=660;width=620}
 else if(t<S.bed){cx=950;cy=855;width=760}
 else if(t<S.problem){cx=1035;cy=825;width=680}
 else if(t<S.vents){cx=895;cy=760;width=L(720,600,U(t,S.problem,S.vents-S.problem))}
 else if(t<S.door){cx=920;cy=470;width=760}
 else if(t<S.decorate){cx=855;cy=825;width=700}
 else if(t<S.final){cx=920;cy=800;width=860}
 else{cx=940;cy=L(740,760,U(t,S.final,D-S.final));width=L(880,1280,U(t,S.final,D-S.final))}return{cx,cy,width};}
const cv=createCanvas(1080,1920),ctx=cv.getContext('2d');
export function draw(t,{caption=true}={}){let c=ctx,cam=camera(t);c.resetTransform();c.clearRect(0,0,1080,1920);c.scale(1.5,1.5);c.save();let z=720/cam.width;c.translate(360,610);c.scale(z,z);c.translate(-cam.cx,-cam.cy);world(c,t);c.restore();let v=c.createRadialGradient(360,550,250,360,640,950);v.addColorStop(0,'rgba(56,42,31,0)');v.addColorStop(1,'rgba(56,42,31,.10)');c.fillStyle=v;c.fillRect(0,0,720,1280);
 if(caption){let q=caps.find(q=>t>=q.start&&t<q.end);if(q){let s=q.text.toLocaleUpperCase('vi-VN');c.font='900 44px Nunito';let m=c.measureText(s);if(m.width>650||m.actualBoundingBoxAscent>80)throw Error('Caption '+s+' width'+m.width);c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';c.strokeStyle='#343436';c.lineWidth=8;c.strokeText(s,360,975);c.fillStyle=/tối|ngột ngạt|ngôi nhà|thông gió/.test(q.text)?'#ffe48b':'#fff8e9';c.fillText(s,360,975)}}return cv;}
export async function render({draft=false,start=0,duration=D,out=null}={}){let ow=draft?540:1080,oh=draft?960:1920,dc=draft?createCanvas(ow,oh):cv,dctx=draft?dc.getContext('2d'):null;out=out||B+'/output/'+(draft?'draft-home.mp4':'Hollow_Tree_Home_Picture.mp4');let total=Math.round(duration*30);let ff=spawn('ffmpeg',['-v','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',`${ow}x${oh}`,'-framerate','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf',draft?'22':'17','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',out+'.part.mp4'],{stdio:['pipe','inherit','inherit']}),done=once(ff,'close');for(let f=0;f<total;f++){let im;try{im=draw(start+f/30);if(draft){dctx.drawImage(im,0,0,ow,oh);im=dc}}catch(e){ff.kill();throw Error(`Frame${f} time${start+f/30} ${e.message}`)}if(!ff.stdin.write(im.data()))await once(ff.stdin,'drain');if(f%150===0)console.log('FRAME',f,total)}ff.stdin.end();let[code]=await done;if(code)throw Error('encode'+code);fs.renameSync(out+'.part.mp4',out);fs.writeFileSync(B+'/qa/'+(draft?'draft':'final')+'-rig.json',JSON.stringify(QA,null,2));console.log('RENDERED',out)}
if(process.argv.includes('--preflight')){let ev=Object.entries(S).filter(q=>q[0]!=='end').sort((a,b)=>a[1]-b[1]);for(let i=0;i<ev.length;i++){let[n,t]=ev[i],end=ev[i+1]?.[1]||D;for(let u of[.02,.2,.45,.7,.95]){let tt=t+(end-t)*u;try{let im=draw(tt);if(u===.45)fs.writeFileSync(B+`/qa/scene-${String(i).padStart(2,'0')}-${n}.jpg`,im.toBuffer('image/jpeg',{quality:90}))}catch(e){throw Error(n+' '+tt+' '+e.message)}}}for(let q of caps)draw((q.start+q.end)/2);fs.writeFileSync(B+'/qa/preflight.json',JSON.stringify(QA,null,2));console.log('PREFLIGHT',QA)}
if(process.argv.includes('--draft'))await render({draft:true});if(process.argv.includes('--full'))await render();
