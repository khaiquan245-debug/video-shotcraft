from pathlib import Path
import json,wave,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000
S=json.loads((B/'manifests/story-times.json').read_text());vm=json.loads((B/'manifests/voice.json').read_text());D=S['end'];N=round(D*R);T=np.arange(N)/R;rng=np.random.default_rng(20261121)
with wave.open(str(B/'audio/narration-final.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768;assert w.getframerate()==R
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==vm['native_sha256']
V=np.zeros(N,np.float32);i=round(vm['offset']*R);V[i:i+len(raw)]=raw
F=np.zeros((N,2),np.float32);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;n=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='key':a=(np.sin(2*np.pi*880*t)+.2*np.sin(2*np.pi*1320*t))*env
 elif kind=='chip':a=(np.sin(2*np.pi*1760*t)+.3*np.sin(2*np.pi*2350*t))*env
 elif kind=='motor':a=(.4*np.sin(2*np.pi*110*t)+.2*np.sin(2*np.pi*220*t)+.4*np.convolve(n,np.ones(21)/21,'same'))*env
 elif kind=='paper':a=(n-np.convolve(n,np.ones(22)/22,'same'))*.25*env
 elif kind=='click':a=(np.sin(2*np.pi*620*t)+.35*n)*np.exp(-t/.014)
 elif kind=='tray':a=(.7*np.sin(2*np.pi*185*t)+.2*np.sin(2*np.pi*390*t)+.1*n)*np.exp(-t/.04)
 elif kind=='confirm':a=(np.sin(2*np.pi*(659.25+220*(t>d*.45))*t)+.3*np.sin(2*np.pi*1318.5*t))*env
 elif kind=='whoosh':a=np.convolve(n,np.ones(19)/19,'same')*env
 elif kind=='step':a=(np.sin(2*np.pi*120*t)+.2*np.convolve(n,np.ones(9)/9,'same'))*np.exp(-t/.027)
 elif kind=='rub':a=(n-np.convolve(n,np.ones(19)/19,'same'))*.18*env*(.65+.35*np.sin(2*np.pi*18*t))
 elif kind=='erase':a=(.25*np.convolve(n,np.ones(13)/13,'same')+.25*np.sin(2*np.pi*(520*t-230*t*t)))*env
 elif kind=='crumble':a=(np.convolve(n,np.ones(35)/35,'same')*2+.2*np.sin(2*np.pi*90*t))*np.exp(-t/.12)
 elif kind=='tap':a=(np.sin(2*np.pi*215*t)+.2*np.convolve(n,np.ones(8)/8,'same'))*np.exp(-t/.02)
 elif kind=='fall':a=(np.convolve(n,np.ones(19)/19,'same')+.12*np.sin(2*np.pi*(350*t-150*t*t)))*env
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 i=round(at*R);assert 0<=i<N
 x=fx(kind,d)[:N-i]*gain;F[i:i+len(x),0]+=x*np.sqrt((1-pan)/2);F[i:i+len(x),1]+=x*np.sqrt((1+pan)/2)
 events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,6),'duration':d,'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'source':'Original local oscillator/noise Foley in production/audio.py','rights':'Self-created'})
A=json.loads((B/'manifests/action-cues.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());cue=lambda s:next(q['start']for q in caps if q['text']==s)
EV={'pickup':.65,'table':cue('cả chiếc bàn')+.13,'chair':S['chair_gone']+.13,'trash':S['cleanup']+.07,'boxes':A['boxes']+.05,'cabinet':A['cabinet']+.05,'yard':A['yard_scrub']+.05,'climb':A['stair_ready']+.05}
add(EV['pickup'],'tap',.045,.08,-.2,'Fingers pick up the one eraser from the floor')
for at in [S['stain']+.2,S['stain']+.62,S['table_gone']+.08,S['chair_try']+.18,S['chair_try']+.56]:add(at,'rub',.055,.18,.05,'Visible eraser strokes touch tabletop or damaged chair')
for key in ['table','chair','trash','boxes','cabinet','yard']:add(EV[key],'erase',.065,.27,.05,'Object erasure progresses from the actual contact: '+key)
for at in np.arange(S['power']+1.3,S['cleanup']-.06,.34):add(float(at),'step',.028,.08,-.1,'Boy crosses room toward remaining clutter')
for at in np.arange(S['yard']+.03,S['yard']+.98,1/4.6):add(float(at),'step',.036,.08,-.05,'Running out into the same yard')
for at in [S['slip']+.25,S['slip']+.65]:add(at,'rub',.04,.16,.1,'Eraser rubs barrel before it slips')
add(A['release'],'tap',.04,.07,.1,'Eraser leaves wrist-bound hold')
add(A['drop_end'],'tap',.055,.10,.1,'Dropped eraser reaches road')
# Tumble impacts follow the same piecewise distance/time trajectory as the picture.
pts=[(A['drop_end'],1064),(S['damage'],1440),(A['step_erase'],2050),(A['earth_erase'],2290),(A['grab'],2419)]
for xx in np.arange(1064+np.pi*18,2419,np.pi*18):
 i=next(i for i in range(len(pts)-1)if pts[i][1]<=xx<=pts[i+1][1]);at=pts[i][0]+(pts[i+1][0]-pts[i][0])*(xx-pts[i][1])/(pts[i+1][1]-pts[i][1]);add(float(at),'tap',.021,.065,.12,'Short rubber tumble contact, tied to distance along slope')
add(A['drop_end'],'paper',.014,A['grab']-A['drop_end'],.1,'Low rolling friction under the short impacts')
add(A['step_erase'],'erase',.045,.19,.1,'Road steps disappear after the eraser reaches them')
add(A['earth_erase'],'crumble',.07,.32,0,'Road surface opens into the growing pit behind the eraser')
for at in np.arange(S['chase']+.03,S['catch']-.02,.24):add(float(at),'step',.04,.09,-.1,'Panicked chase toward intact edge')
add(A['jump'],'whoosh',.055,.3,-.05,'Boy dives from left bank')
add(A['grab'],'tap',.065,.09,.1,'Same eraser transfers into right hand at catch point')
add(S['unsupported']+.15,'crumble',.045,.23,0,'He notices the missing ground beneath his feet')
add(S['fall']+.03,'fall',.055,.72,0,'Camera follows the boy down the cross-section')
add(S['hold']-.1,'tray',.05,.15,0,'Soft landing on pit floor')
for at in [S['escape']+.13,S['escape']+.45,S['escape']+.78]:add(at,'rub',.045,.16,-.1,'Wrist-bound eraser rubs left wall to open an escape')
add(A['stair_ready']-.16,'crumble',.048,.24,-.1,'Carved stair path becomes readable')
dur=S['pocket']-.15-EV['climb']
for j in range(1,9):add(EV['climb']+j*dur/8-.035,'step',.025,.075,-.1,'Crawling contact completes one stair transfer')
add(S['pocket']+.85,'paper',.027,.22,-.05,'Eraser lowers into hoodie pocket')
add(cue('một bên giày'),'tap',.05,.11,-.12,'Comic accent as bare foot is finally revealed')
# Original playful plucked score; tension follows the slip and fall, relief follows escape.
M=np.zeros(N,np.float32);notes=[293.665,349.228,440,523.251,440,391.995,349.228,261.626]
for k,at in enumerate(np.arange(.03,D-.2,60/130)):
 i=round(at*R);d=min(.62,(N-i)/R);tt=np.arange(round(d*R))/R;f=notes[k%8]*(.5 if A['release']<at<S['hold']else 1);z=(np.sin(2*np.pi*f*tt)+.22*np.sin(2*np.pi*f*2*tt)+.08*np.sin(2*np.pi*f*3*tt))*np.exp(-tt/.13);M[i:i+len(z)]+=.016*z
 if A['release']<at<A['grab']and k%2==0:M[i:i+len(z)]+=.006*np.sin(2*np.pi*110*tt)*np.exp(-tt/.05)
noise=rng.normal(0,1,N).astype(np.float32);AUDIOBED=.0035*np.convolve(noise,np.ones(35)/35,'same');AUDIOBED*=np.where(T<S['yard'],.55,1)
rms=np.sqrt(np.mean(V.reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(17)/17,'same');M*=np.interp(np.arange(N),np.arange(len(gate))*480,1-.68*gate)
fade=np.minimum(1,np.minimum(T/.035,(D-T)/.23));M*=fade;AUDIOBED*=fade;F*=fade[:,None];stereo=np.column_stack((V+M+AUDIOBED,V+M+.97*AUDIOBED))+F;pre=min(1.,.98/float(np.max(np.abs(stereo))));stereo*=pre

def save(name,a):
 with wave.open(str(B/'audio'/name),'wb')as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',AUDIOBED),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
def ts(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Cuc_Tay_Xoa_Moi_Thu.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}'for i,q in enumerate(caps)),encoding='utf-8')
(B/'manifests/sound-events.json').write_text(json.dumps({'events':events,'music':'Original130BPM playful/tension/relief score, locally synthesized','sources':'Original oscillator/noise Foley and music; no reference recordings or commercial music used','reference_scope':'Action-sound cadence and restrained transitions inspired by the uploaded straw-fort reference; no claim of identical samples or human-ear source identification','pre_master_gain':pre,'paid_apis':False},ensure_ascii=False,indent=2));print('AUDIO',D,'s',len(events),'action cues',flush=True)
