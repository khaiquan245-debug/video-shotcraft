from pathlib import Path
import json,hashlib,zipfile,shutil
B=Path(__file__).resolve().parents[1];O=B/'output';q=json.loads((B/'qa/final.json').read_text());p=Path(q['file']);h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest();assert h(p)==q['sha256']
pbf=B/'qa'/p.name.replace('.mp4','-playback.json');pb=json.loads(pbf.read_text());assert pb['sha256']==q['sha256']and pb['rate']==1 and pb['samples'][-1]['ended'];assert not any(v['error']for v in pb['samples'])
m=json.loads((B/'audio/narration-native.json').read_text());assert h(B/'audio/narration-native.wav')==m['wav_sha256'];assert ' '.join(c['text']for c in json.loads((B/'manifests/captions.json').read_text()))==' '.join((B/'audio/script-approved.txt').read_text().split())
assert h(Path('/workspace/outputs/phone-to-past-20261120/output/Dien_Thoai_Goi_Ve_Qua_Khu_34s_1080x1920.mp4'))=='955e59cb587aaf408575169c7774ed428be5151f57ef5e390684c4f324978e0e'
files=[(O/n,n)for n in [p.name,'Cuc_Tay_Xoa_Moi_Thu.vi.srt','README.md','CREDITS.md','Production_Report.md','SHORTS_NHIP_KE_NHANH.md','Shot_Timeline.csv','SHA256SUMS.txt','index.html']]
files += [(B/'audio'/n,'audio/'+n)for n in ['script-approved.txt','narration-native.wav','narration-final.wav','mix.wav','music.wav','sfx.wav','ambience.wav','voice-timeline.wav']]
files += [(B/'assets'/n,'assets/'+n)for n in ['Nunito.ttf','OFL-Nunito.txt']]
files += [(src,'manifests/'+src.name)for src in (B/'manifests').glob('*.json')]
files += [(B/'production'/n,'production/'+n)for n in ['prepare.py','audio.py','film.mjs','finish.py','report.py','serve.py','browser-test.cjs','transcribe_local.py','package.py']]
files += [(B/'qa'/n,'qa/'+n)for n in ['final.json','final-rig.json','pacing-comparison.json','asset-origin.json','continuity.json','Encoded_Contact_Sheet.jpg','asr-comparison.json','narration-asr.json']]
files += [(pbf,'qa/browser-playback.json')]
keys=['engine','package_version','actual_backend','session_providers','inference_offline','model_source','canonical_voice','voice_metadata','preset_sha256','speed_method','language','requested_voice','speed','text','duration','sample_rate','channels','pcm_bits','execution_provider','start_offset','captions','alignment','peak_before_gain','gain','wav_sha256'];public_m={k:m[k]for k in keys if k in m}
zpath=O/'Cuc_Tay_Xoa_Moi_Thu_DOWNLOAD.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for src,name in files:
  assert src.is_file()and src.stat().st_size<100*1024*1024,src;z.write(src,name)
 z.writestr('audio/narration-native.json',json.dumps(public_m,ensure_ascii=False,indent=2))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None;assert hashlib.sha256(z.read(p.name)).hexdigest()==q['sha256'];assert not any(n.endswith(('.onnx','.safetensors','.pt','.pth','.bin'))for n in z.namelist())
repo=Path('/tmp/magic-eraser-download');repo.mkdir(exist_ok=False)
for n in [p.name,zpath.name,'README.md','CREDITS.md','Production_Report.md','SHORTS_NHIP_KE_NHANH.md','SHA256SUMS.txt','Cuc_Tay_Xoa_Moi_Thu.vi.srt','Shot_Timeline.csv','index.html']:shutil.copy2(O/n,repo/n)
report={'zip':str(zpath),'zip_bytes':zpath.stat().st_size,'zip_sha256':h(zpath),'mp4_sha256':q['sha256'],'mp4_bytes':p.stat().st_size,'entries':len(files)+1,'crc':'passed','model_weights_in_zip':False,'previous_phone_mp4_unchanged':True,'publication_repo':str(repo)};assert zpath.stat().st_size<100*1024*1024;(B/'qa/package.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
