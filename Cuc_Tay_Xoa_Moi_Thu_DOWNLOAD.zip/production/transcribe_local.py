from pathlib import Path
import json,wave,numpy as np
from faster_whisper import WhisperModel
B=Path(__file__).resolve().parents[1];model=Path('/workspace/local-models/whisper/models--Systran--faster-whisper-small/snapshots/536b0662742c02347bc0e980a01041f333bce120')
with wave.open(str(B/'qa/narration-16k.wav'))as w:
 assert w.getframerate()==16000 and w.getnchannels()==1
 audio=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
m=WhisperModel(str(model),device='cpu',compute_type='int8',cpu_threads=6,local_files_only=True)
segments,info=m.transcribe(audio,language='vi',beam_size=5,word_timestamps=True,vad_filter=True)
out=[]
for s in segments:
 r={'start':s.start,'end':s.end,'text':s.text,'words':[{'start':w.start,'end':w.end,'word':w.word,'probability':w.probability}for w in s.words]};out.append(r);print(f'{s.start:.2f}–{s.end:.2f}: {s.text}',flush=True)
(B/'qa/narration-asr.json').write_text(json.dumps({'model':'Systran/faster-whisper-small','device':'CPU int8, local files only','language':info.language,'segments':out,'scope':'Machine transcription, may contain recognition errors; not human listening approval. WAV decoded by FFmpeg and passed as NumPy because PyAV19 removed metadata_errors argument.'},ensure_ascii=False,indent=2))
