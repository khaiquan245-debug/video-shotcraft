from pathlib import Path
import json,wave,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;OFFSET=.04
m=json.loads((B/'audio/narration-native.json').read_text());assert m['inference_offline']
with wave.open(str(B/'audio/narration-native.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy();assert w.getframerate()==R
parts=[];cursor=0;spans=[];trims=[]
for i,q in enumerate(m['captions']):
 x=raw[round(q['start']*R):round(q['end']*R)];ws=480;k=len(x)//ws;v=x[:k*ws].astype(float)/32768;energy=np.sqrt(np.mean(v.reshape(-1,ws)**2,axis=1));active=np.where(energy>max(.004,float(np.max(np.abs(v)))*.013))[0];assert len(active)
 a=max(0,int(active[0])*ws-round(.04*R));z=min(len(x),(int(active[-1])+1)*ws+round(.045*R));start=cursor/R;parts.append(x[a:z]);cursor+=z-a;spans.append({'text':q['text'],'start':start,'end':cursor/R});trims.append({'sentence':i,'leading_removed':a/R,'trailing_removed':(len(x)-z)/R})
 if i<len(m['captions'])-1:
  gap=.15 if i==len(m['captions'])-2 else .045
  parts.append(np.zeros(round(gap*R),dtype='<i2'));cursor+=round(gap*R)
compact=np.concatenate(parts);tempo=max(1.,len(compact)/R/50.0)
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-final.wav')],check=True)
with wave.open(str(B/'audio/narration-final.wav'))as w:vo_d=w.getnframes()/R
factor=len(compact)/R/vo_d
for s in spans:s.update(start=OFFSET+s['start']/factor,end=OFFSET+s['end']/factor)
D=math.ceil((OFFSET+vo_d+.35)*10)/10
phrases=[['Một cậu bé','vô tình tìm được','cục tẩy có thể xóa','bất cứ thứ gì','ngoài đời thực.'],['Ban đầu,','cậu chỉ định xóa','một vết bẩn','trên bàn.'],['Nhưng vừa chà nhẹ','vài cái,','cả chiếc bàn','đột nhiên biến mất!'],['Cậu kinh ngạc','thử tiếp với','chiếc ghế bị hỏng.'],['Chiếc ghế','cũng biến mất','ngay lập tức.'],['Nhận ra khả năng','đặc biệt này,','cậu bắt đầu xóa','tất cả những thứ','không cần thiết','trong nhà.'],['Từ đống rác,','những chiếc hộp cũ','cho đến','chiếc tủ hỏng.'],['Chỉ vài phút sau,','căn phòng sạch bong!'],['Quá phấn khích,','cậu chạy ra ngoài','và tiếp tục','dọn sạch','đống rác ở sân.'],['Nhưng khi đang xóa','một chiếc thùng cũ,','cục tẩy bất ngờ','tuột khỏi tay.'],['Nó lăn thẳng','xuống con dốc!'],['Những nơi cục tẩy','chạm vào','bắt đầu biến mất.'],['Gạch lát đường,','bậc thềm,','rồi cả một đoạn','mặt đất!'],['Cậu hoảng hốt','đuổi theo.'],['Ngay trước khi','cục tẩy lăn xuống cống,','cậu lao tới','chụp được nó.'],['Nhưng mặt đất','dưới chân','đã biến mất.'],['Cậu rơi thẳng xuống','một hố sâu!'],['May mắn thay,','cậu vẫn giữ được','cục tẩy.'],['Cậu lập tức xóa','một phần thành hố','để tạo đường','thoát ra ngoài.'],['Cuối cùng,','cậu cũng bò lên','được mặt đất.'],['Cậu thở phào','rồi cất cục tẩy','vào túi.'],['Nhưng khi','nhìn xuống...'],['Cậu phát hiện','một bên giày','của mình','đã biến mất','từ lúc nào!']]
assert len(phrases)==len(spans);caps=[]
for s,ps in zip(spans,phrases):
 assert ' '.join(ps)==s['text'],(ps,s['text']);total=sum(len(p.split())for p in ps);a=s['start']
 for j,p in enumerate(ps):
  z=s['end']if j==len(ps)-1 else a+(s['end']-s['start'])*len(p.split())/total
  caps.append({'text':p,'start':a,'end':z,'emphasis':any(k in p for k in ['biến mất','cục tẩy','tuột khỏi','một bên giày','hố sâu'])});a=z
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
keys=['find','stain','table_gone','chair_try','chair_gone','power','cleanup','room_clean','yard','slip','roll','damage','tiles','chase','catch','unsupported','fall','hold','escape','climb','pocket','look','reveal'];S={k:s['start']for k,s in zip(keys,spans)};S['find']=0;S['end']=D
C={k:next(q['start']for q in caps if q['text']==p)for k,p in {'release':'tuột khỏi tay.','grab':'chụp được nó.','boxes':'những chiếc hộp cũ','cabinet':'chiếc tủ hỏng.','yard_scrub':'đống rác ở sân.','step_erase':'bậc thềm,','earth_erase':'mặt đất!'}.items()};C['grab']+=.18;C['jump']=C['grab']-.75;C['drop_end']=min(C['release']+.35,S['roll']+.1);C['stair_ready']=S['escape']+1.15
for name,obj in [('story-times',S),('action-cues',C),('captions',caps)]:
 (B/f'manifests/{name}.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2))
meta={'duration':D,'vo_duration':vo_d,'native_duration':m['duration'],'compacted_duration':len(compact)/R,'offset':OFFSET,'pitch_preserving_tempo':tempo,'native_sha256':m['wav_sha256'],'voice_sha256':hashlib.sha256((B/'audio/narration-final.wav').read_bytes()).hexdigest(),'trim_log':trims,'sentence_spans':spans,'space_units':252,'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'offline':True}
(B/'manifests/voice.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(B/'manifests/project.json').write_text(json.dumps({'title':'Cục tẩy có thể xóa mọi thứ','preset':'phone-to-past-2d-v1','duration':D,'resolution':[1080,1920],'fps':30,'aspect':'9:16','style':'Original full-color2D character animation, orange-hoodie continuity','script':'Exact user narration, original order, no additions','paid_apis':False},ensure_ascii=False,indent=2))
print('VOICE',json.dumps({k:meta[k]for k in ['native_duration','compacted_duration','vo_duration','duration','pitch_preserving_tempo','space_units']}));print('STORY',S);print('CUES',C)
