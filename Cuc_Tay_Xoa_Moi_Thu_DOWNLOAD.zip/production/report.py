from pathlib import Path
import json,wave,hashlib,csv,subprocess,math,unicodedata,difflib,re,shutil
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';r=json.loads((B/'qa/final.json').read_text());v=json.loads((B/'manifests/voice.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());A=json.loads((B/'manifests/action-cues.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());sounds=json.loads((B/'manifests/sound-events.json').read_text());m=json.loads((B/'audio/narration-native.json').read_text())
script=' '.join((B/'audio/script-approved.txt').read_text().split());assert ' '.join(q['text']for q in caps)==script;assert len(script.split())==252
with wave.open(str(B/'audio/voice-timeline.wav'))as w:x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
rms=np.sqrt(np.mean(x.reshape(-1,480)**2,axis=1));active=np.where(rms>.003)[0];run=best=0
for quiet in rms[active[0]:active[-1]+1]<.003:run=run+1 if quiet else 0;best=max(best,run)
summary={'reference_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','reference_duration':38.220045,'reference_transcript_units':191,'reference_units_per_video_second':191/38.220045,'script_units':252,'duration':r['duration'],'units_per_video_second':252/r['duration'],'max_internal_quiet_seconds':best/100,'caption_cues':len(caps),'sfx_events':len(sounds['events']),'mp4_sha256':r['sha256'],'note':'Vietnamese space-delimited units are approximate. Reference ASR boundaries and isolated-stem RMS silence are not equivalent measurements. Exact reference voice/music/SFX have not been identified by listening.'}
(B/'qa/pacing-comparison.json').write_text(json.dumps(summary,indent=2))
# Check immutable prior movie and current source narration.
old=Path('/workspace/outputs/phone-to-past-20261120/output/Dien_Thoai_Goi_Ve_Qua_Khu_34s_1080x1920.mp4');assert hashlib.sha256(old.read_bytes()).hexdigest()=='955e59cb587aaf408575169c7774ed428be5151f57ef5e390684c4f324978e0e';assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==m['wav_sha256']
sem={'script_and_caption_text_identical':True,'script_units':252,'single_eraser_schedule':{'floor_before':.65,'held_until':A['release'],'free_until':A['grab'],'held_again_until':S['look'],'pocketed_after':S['look']},'catch_center_handoff_error':r['rig']['handoffError'],'catch_before_intact_drain':{'catch_x':2419,'drain_start_x':2550},'deleted_room_objects_do_not_return':True,'barrel_partially_remains_after_slip':True,'pit_opens_behind_rolling_eraser':True,'stairs_world_path':{'bottom':[2290,1830],'upper_tread':[1765,1087.5],'bank':[1680,1074]},'barefoot_reveal_at':S['reveal'],'shoe_hidden_during_pocket_and_look_closeup':True,'previous_phone_mp4_unchanged':True,'scope':'Source state/coordinates plus sampled encoded frames. Fixed bone lengths and endpoint handoff checks do not certify perfect acting, contact at every frame, or physical simulation.'}
(B/'qa/continuity.json').write_text(json.dumps(sem,indent=2))
# Compare local ASR as an imperfect additional content check, never as human listening approval.
asr_note='Không dùng nhận dạng giọng để tự chứng nhận phát âm hoàn hảo.'
asrp=B/'qa/narration-asr.json'
if asrp.exists():
 ar=json.loads(asrp.read_text());actual=' '.join(s['text']for s in ar['segments']);norm=lambda s:re.findall(r'\w+',unicodedata.normalize('NFC',s).lower());aa=norm(script);bb=norm(actual);seq=difflib.SequenceMatcher(None,aa,bb,autojunk=False);diff=[{'type':tag,'expected':' '.join(aa[i:j]),'recognized':' '.join(bb[k:l])}for tag,i,j,k,l in seq.get_opcodes()if tag!='equal'];qa={'model':ar['model'],'device':ar['device'],'reference':'Exact user script','recognized':actual,'token_similarity':seq.ratio(),'differences':diff,'scope':'Machine ASR may misrecognize Vietnamese homophones and accents; mismatches cannot by themselves prove TTS pronunciation errors. No human listening approval.'};(B/'qa/asr-comparison.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2));asr_note=f"Đã nhận dạng kiểm tra bổ sung bằng faster-whisper-small local CPU; độ tương đồng token {seq.ratio():.1%}. Có sai khác ASR, lưu nguyên văn trong qa/asr-comparison.json; chưa dùng tai người để phân biệt lỗi nhận dạng với lỗi phát âm."
(O/'README.md').write_text('''# Cục tẩy xóa mọi thứ

MP4 hoàn chỉnh 50,4 giây, 1080×1920, 30 fps, có narration tiếng Việt, phụ đề, SFX và nhạc gốc. Mở `Cuc_Tay_Xoa_Moi_Thu_50_4s_1080x1920.mp4` hoặc `index.html`.

Giữ nguyên kịch bản 252 tiếng theo khoảng trắng, nhịp toàn phim 5 tiếng/giây theo mẫu “Biến đống rơm thành căn cứ”. Camera theo hành động, cục tẩy lăn xuống dốc, chụp lại, rơi xuống hố và leo ra. Có chuyển động nhân vật/đồ vật và trạng thái bối cảnh liên tục.

Voice thực tế: VieNeu-TTS v3 Turbo, ONNX CPU offline, preset Hải Đăng (alias Minh Quân trong adapter). WAV native được giữ nguyên. Bản dựng thu gọn khoảng yên và dùng atempo 1,0786× giữ cao độ.

ZIP có MP4, SRT, WAV native/đã dựng, stem mix/nhạc/SFX, source Canvas/FFmpeg, font/giấy phép, timeline và QA. Không kèm trọng số model hoặc video/audio tham khảo. Không API trả phí.

Dựng lại trong bản sao thư mục mới để giữ bản đã duyệt. Môi trường hiện tại cần `@napi-rs/canvas` qua `/workspace/video-shotcraft/workbench/package.json`, FFmpeg, Python với NumPy/Pillow. Nếu chuyển máy, sửa đường dẫn createRequire sang nơi cài Canvas của bạn; không cần model TTS để render lại từ WAV kèm ZIP.

```bash
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
python production/serve.py
```

Preview local: http://127.0.0.1:8839/ . Mở MP4 tải về bằng trình phát video thông thường cũng được. Biên phụ đề theo cụm nghĩa trong câu đã đo, chưa forced-align từng từ. Phạm vi QA và giới hạn nghe/xem ghi trong Production_Report.md.
''',encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn và công cụ

Lời kể do người dùng cung cấp, giữ nguyên thứ tự. Thiết kế nhân vật áo cam kế thừa phim “Điện thoại gọi về quá khứ” của chính dự án. Bối cảnh nhà, sân, đường dốc, thùng, cống, hố và bậc thoát, cục tẩy và hiệu ứng biến mất được vẽ/diễn hoạt trong production/film.mjs. Không dùng ảnh/slideshow hoặc lấy frame từ video mẫu.

Giọng: VieNeu-TTS v3 Turbo, Apache-2.0, ONNX CPU local, https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo . Preset thực tế Hải Đăng, alias Minh Quân trong adapter. Metadata WAV ghi rõ provider, nguồn và SHA. Model weights nằm ngoài Git/ZIP.

Nhạc nền 130 BPM và 79 sự kiện SFX/Foley được tự tổng hợp bằng oscillator/noise với NumPy. Các cue lăn nhẹ cũng được tính riêng; không phải 79 loại âm thanh. Không lấy soundtrack, giọng hoặc tiếng động của video mẫu. Audio theo hướng chà/xóa/lăn/sụt đất/chụp/rơi/leo/phản ứng, nhạc có ducking dưới lời dẫn.

Font Nunito: SIL Open Font License, kèm assets/OFL-Nunito.txt. Render bằng @napi-rs/canvas và FFmpeg, TTS local CPU. Không API trả phí hoặc cloud inference.
''',encoding='utf-8')
report=f'''# Kết quả thực tế — Cục tẩy xóa mọi thứ

Tệp MP4 thật **{r['duration']:.3f} giây**, **1080×1920**, **30 fps**, **{r['frames']} frame**, H.264 yuv420p + AAC stereo 48 kHz, **{r['bytes']:,} byte**. Kịch bản đầu vào và phụ đề giữ nguyên 252 tiếng theo khoảng trắng, không thêm lời hoặc đổi thứ tự. Đây là hoạt hình vector 2D có khớp tay/chân, chuyển động đồ vật và camera.

## Nhịp theo tham chiếu

Tệp người dùng gửi lại trùng SHA-256 của bản tham chiếu 38,220 giây đã phân tích. Lời dựng lại từ mẫu có khoảng 191 tiếng, gần 5,00 tiếng/giây. Phim mới có 252 tiếng / 50,4 giây = 5,00 tiếng/giây. Nhịp thông tin, nhịp chuyển động và nhịp cắt máy được xét riêng; không ép một cut theo mọi cụm phụ đề.

Native WAV {v['native_duration']:.3f} giây được bảo toàn. Sau cắt yên ở biên câu với đệm 40/45 ms, nối 45 ms (trước câu cuối 150 ms), bản ghép {v['compacted_duration']:.3f} giây được xử lý atempo={v['pitch_preserving_tempo']:.6f} giữ cao độ, ra giọng {v['vo_duration']:.3f} giây. Khoảng yên lớn nhất giữa phần có lời theo RMS<0,003 là **{best/100:.2f} giây**; lớn nhất gồm cả đuôi phim **{r['narration_max_quiet_seconds']:.2f} giây**. Mốc ASR của mẫu không tương đương phép đo RMS trên stem riêng, nên không tuyên bố từng khoảng dừng giống hệt mẫu.

Camera theo cục tẩy xuống dốc; đổi cỡ cảnh khi đồ vật biến mất và cậu phản ứng; theo trục dọc khi rơi, kéo rộng cho thấy đường thoát, vào cận giấu chân trước cú lộ giày cuối. Trước cú nhảy, khung hình giữ cả cậu bé, cục tẩy và miệng cống. Không dùng dissolve dài hoặc intro logo.

## Diễn hoạt và liên tục

Cùng nhân vật áo cam, mặt/tóc/đồng phục giữ ổn định. Tay/chân dùng IK hai đoạn cố định, có cúi nhặt, chà, bước/chạy, thu người lấy đà, nhảy chụp, rơi, cầm kiểm tra, xóa vách, leo từng bậc và cất cục tẩy. Một cục tẩy chuẩn bám cổ tay khi cầm, chỉ tách thành free sprite trong pha rơi/lăn. Tại mốc chụp {A['grab']:.3f} giây, tâm sprite tự do và cục tẩy trong tay trùng nhau, sai số **{r['rig']['handoffError']}** đơn vị thế giới.

Bàn/ghế/rác/hộp/tủ đã xóa không trở lại. Thùng chỉ bị xóa một phần trước khi tuột tay. Gạch/bậc/đất mất theo quỹ đạo cục tẩy; hố mở phía sau nó. Điểm chụp x=2419 trước cống x=2550. Bậc thoát nối từ đáy hố lên bờ trái, được mở từ điểm chà vách. Cục tẩy được cất trước cảnh giày mất; cận thân che chân trước cú lộ. Chuyển động và không gian là diễn hoạt hoạt hình, không mô phỏng vật lý hoàn chỉnh.

## Âm thanh và phụ đề

Model thực tế **VieNeu-TTS v3 Turbo**, backend **ONNX CPU offline**, preset **Hải Đăng**, alias được yêu cầu **Minh Quân**. Native SHA không đổi. Nhạc nguyên tác 130 BPM cùng **{len(sounds['events'])} cue SFX** (có nhiều tiếp xúc lăn nhẹ) tự tổng hợp local; nhạc hạ dưới giọng. SFX theo nhặt/chà/xóa/tuột/lăn/sụt/chụp/rơi/leo/cất và nhấn cú giày cuối.

**{len(caps)} cụm phụ đề** giữ nguyên chữ, một dòng có viền; thời điểm trong câu phân bổ theo cụm nghĩa và thời lượng câu đã đo, chưa forced-align từng từ. {asr_note}

## QA thực tế và phạm vi

- FFprobe xác nhận codec, 1080×1920, 30 fps, 1512 packet hình; giải mã toàn MP4 không lỗi.
- Âm lượng **{r['lufs']} LUFS**, true peak **{r['true_peak_dbfs']} dBTP**.
- Rig trên toàn 1512 frame: **{r['rig']['samples']} phép giải**, **{r['rig']['unreachable']} đích ngoài tầm**, sai số chiều dài xương tối đa **{r['rig']['maxBoneError']:.3g}**.
- Đã xem ảnh lấy từ draft và MP4 full ở các nhịp chính; sửa khung trước cú chụp và nét chân ở cảnh giày mất. File QA ghi phạm vi kiểm tra.
- Phát Chromium 1× tắt tiếng đến cuối, kiểm tra SHA khớp tệp final. Đây là kiểm tra giải mã/phát, không thay cho người dùng nghe đánh giá nhạc, SFX và phát âm.
- MP4 SHA-256: `{r['sha256']}`.

Không xác nhận danh tính giọng/nhạc/SFX gốc hoặc tự nhận đã nghe bằng tai người, cũng không chứng nhận chất lượng giống hệt video mẫu. Preset 2D “Điện thoại gọi về quá khứ” giữ theo lựa chọn hiện hành; dự án 3D rác thành vàng vẫn dừng. Dự án cũ và installed skills được giữ nguyên; checksum MP4 điện thoại cũ đã xác minh. Không paid API, trọng số ngoài Git.

Thư mục: `{B}`.
'''
(O/'Production_Report.md').write_text(report,encoding='utf-8')
shutil.copy2('/workspace/outputs/production_rules/SHORTS_NHIP_KE_NHANH.md',O/'SHORTS_NHIP_KE_NHANH.md')
with (O/'Shot_Timeline.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['action','start_seconds','next_event_seconds']);keys=sorted(S,key=S.get)
 for i,k in enumerate(keys[:-1]):w.writerow([k,S[k],S[keys[i+1]]])
(B/'qa/asset-origin.json').write_text(json.dumps({'film_source_sha256':hashlib.sha256((B/'production/film.mjs').read_bytes()).hexdigest(),'origin':'Original vector backgrounds, props, camera and rig animation; own preceding orange-hoodie character design','reference_video_pixels_or_audio_in_final':False,'weights_in_project':False,'paid_apis':False},indent=2))
(O/'SHA256SUMS.txt').write_text(r['sha256']+'  '+Path(r['file']).name+'\n')
# Actual encoded frames, nearest frame to each declared sample time.
ts=[.3,.9,4.5,7.5,10.8,13.2,16.1,17,17.9,19.2,21,22.9,24.5,26.1,28.8,30.3,31.9,33.8,35.6,36.8,38.5,39.7,41.6,42.7,44.1,45.8,46.9,48.2,49.8]
folder=B/'qa/encoded-key';folder.mkdir(exist_ok=True);cw,ch=180,344;board=Image.new('RGB',(6*cw,math.ceil(len(ts)/6)*ch),'#263b31');d=ImageDraw.Draw(board)
for i,t in enumerate(ts):
 p=folder/f'{t:.1f}.jpg';subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',r['file'],'-frames:v','1','-vf','scale=180:320',str(p)],check=True);xx=i%6*cw;yy=i//6*ch;board.paste(Image.open(p),(xx,yy));d.text((xx+4,yy+322),f'{t:.1f}s',fill='white')
board.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=92)
print(json.dumps(summary,indent=2),flush=True)
