# Demo tủ lạnh V4

| Khung | Máy | Hành động |
|---|---|---|
| 0–149 | track | Enter room behind rack |
| 150–235 | over-shoulder | Track past shoulder to mother |
| 236–336 | dolly-in | Dolly toward hand and refrigerator |
| 337–384 | pov | See the reaction from inside the fridge |
| 385–449 | dolly-out | Pull back to the shared plate |