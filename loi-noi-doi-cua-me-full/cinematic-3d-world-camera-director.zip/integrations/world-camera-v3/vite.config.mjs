import {fileURLToPath} from 'node:url';
export default {
 root:fileURLToPath(new URL('../pixijs-environment/',import.meta.url)),
 server:{host:'127.0.0.1',port:8893,strictPort:true,hmr:false,fs:{allow:[fileURLToPath(new URL('../../',import.meta.url))]}},
 build:{target:'es2022'},
};
