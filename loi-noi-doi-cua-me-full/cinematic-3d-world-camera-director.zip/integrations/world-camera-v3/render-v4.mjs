process.env.WORLD_CAMERA_VERSION='4';
await import('./render.mjs');
