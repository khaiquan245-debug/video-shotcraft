from pathlib import Path
import io
import subprocess
from PIL import Image, ImageDraw
ROOT=Path('/workspace/outputs/loi-noi-doi')
before=ROOT/'v3'/'Demo_Tu_Lanh_15s.mp4'
after=ROOT/'v4'/'Demo_Tu_Lanh_V4_1080x1920.mp4'
frames=[43,114,178,249,307,330,357,429]
w,h=164,291
def extract(video,frame):
    raw=subprocess.check_output([
        'ffmpeg','-v','error','-i',str(video),'-vf',f'select=eq(n\\,{frame}),scale={w}:{h}',
        '-frames:v','1','-f','image2pipe','-vcodec','png','-threads','1','-'
    ])
    return Image.open(io.BytesIO(raw)).convert('RGB')
def make(title, videos):
    margin=16
    images=Image.new('RGB',(8*(w+4)+margin*2,42+len(videos)*(h+30)+margin),'#1b242d')
    d=ImageDraw.Draw(images)
    d.text((margin,14),title,fill='#e9dac4',font_size=19)
    for row,(label,video) in enumerate(videos):
        y=42+row*(h+30)
        for i,frame in enumerate(frames):
            x=margin+i*(w+4)
            images.paste(extract(video,frame),(x,y))
            d.text((x,y+h+5),f'{label}   {frame/30:.2f}s',fill='#e9dac4',font_size=13)
    return images
make('DEMO TU LANH / V3 vs V4', [('V3',before),('V4',after)]).save(after.parent/'V3_V4_Contact_Sheet.jpg',quality=92)
make('DEMO TU LANH / V4',[('V4',after)]).save(after.parent/'V4_Contact_Sheet.jpg',quality=92)
