"""Join native V3 front scenes with the V4 kitchen at the authored location cut."""
from pathlib import Path
import json
import subprocess

ROOT=Path('/workspace/outputs/loi-noi-doi')
out=ROOT/'master'
manifest=json.loads((out/'scene-manifest.json').read_text())
start=next(s['startFrame'] for s in manifest['environments'] if s['id']=='kitchen')
sources=[ROOT/'v3/Loi_Noi_Doi_Cua_Me_V3.mp4',ROOT/'v4/V4_Kitchen_Native.mp4']
for file,count in zip(sources,[manifest['frames'],manifest['frames']-start],strict=True):
    meta=json.loads(subprocess.check_output([
        'ffprobe','-v','error','-select_streams','v:0',
        '-show_entries','stream=width,height,avg_frame_rate,nb_frames','-of','json',str(file)
    ]))['streams'][0]
    assert meta['width']==1080 and meta['height']==1920 and int(meta['nb_frames'])==count and meta['avg_frame_rate']=='30/1',meta
graph=(f'[0:v]trim=end_frame={start},setpts=PTS-STARTPTS[a];'
       '[1:v]setpts=PTS-STARTPTS[b];[a][b]concat=n=2:v=1:a=0,'
       'fps=30,setsar=1,eq=contrast=1.025:saturation=1.01[out]')
subprocess.run([
    'ffmpeg','-v','error','-y','-i',str(sources[0]),'-i',str(sources[1]),
    '-i',str(out/'audio-final/audio-master.wav'),'-filter_complex',graph,
    '-map','[out]','-map','2:a:0','-c:v','libx264','-preset','fast','-crf','17',
    '-c:a','aac','-b:a','192k','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',
    str(out/'Loi_Noi_Doi_Cua_Me_Full_1080x1920.mp4')
],check=True)
