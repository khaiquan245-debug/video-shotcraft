"""Verify MP4 integrity and report track metadata without editing the render."""
from pathlib import Path
import json
import subprocess
import sys

video = Path(sys.argv[1])
frames = int(sys.argv[2])
width = int(sys.argv[3])
audio_expected = len(sys.argv) > 4
probe = json.loads(subprocess.check_output([
    'ffprobe','-v','error','-show_entries','stream=codec_type,width,height,avg_frame_rate,nb_frames:format=duration',
    '-of','json',str(video)
]))
picture = next(s for s in probe['streams'] if s['codec_type'] == 'video')
assert (picture['width'], picture['height']) == (width, width * 16 // 9)
assert picture['avg_frame_rate'] == '30/1' and int(picture['nb_frames']) == frames
assert abs(float(probe['format']['duration']) - frames/30) < 0.05
assert any(s['codec_type']=='audio' for s in probe['streams']) == audio_expected
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(video),'-f','null','-'],check=True)
def audio_hash(path):
    return subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-map','0:a:0','-f','md5','-'],text=True).strip()
if audio_expected:
    probe['decoded_audio'] = audio_hash(video)
    if sys.argv[4] != '--audio':
        assert probe['decoded_audio'] == audio_hash(sys.argv[4])
video.with_suffix('.verification.json').write_text(json.dumps(probe,indent=2)+'\n')
print(json.dumps(probe,indent=2))
