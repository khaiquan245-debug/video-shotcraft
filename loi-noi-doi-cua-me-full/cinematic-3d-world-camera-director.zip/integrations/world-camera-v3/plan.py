"""Build a frame-authored shot manifest from approved narration spans."""
from pathlib import Path
import json
import math

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent / 'pixijs-environment'
ROOT = Path('/workspace/outputs/loi-noi-doi')
OUT = ROOT / 'v3'
OUT.mkdir(exist_ok=True)
film = json.loads((ROOT / 'manifests/film.json').read_text())
# Global editorial story beats; all coordinates are metres in each set's reference frame.
# Each route specifies start/end camera position and start/end look target.
P = [
 (0,'room','Premise / bank-phone close-up','phone','dolly-in',[(.47,1.56,3.8),(.37,1.02,.91)],[(.01,1.12,0),(.31,.86,.09)],39),
 (1,'cafe','Borrow money / introduce friend','wallet','over-shoulder',[(.30,1.51,3.7),(.59,1.47,3.25)],[(.23,1.19,-.24),(.33,1.10,-.27)],43),
 (2,'cafe','Friend shows empty wallet','wallet','dolly-in',[(.59,1.47,3.25),(.69,1.39,2.67)],[(.33,1.10,-.27),(.34,1.05,-.15)],43),
 (3,'cafe','Deposit confirms the lie','phone','dolly-in',[(.69,1.39,2.67),(.47,1.35,2.10)],[(.34,1.05,-.15),(.0,1.10,.04)],43),
 (4,'cafe','He realizes he can exploit it','hero','reaction',[(.47,1.35,2.10),(.03,1.46,2.73)],[(.0,1.10,.04),(-.28,1.24,0)],43),
 (5,'road','Interview multiple pedestrians','mic','track', [(-1.25,1.55,4.55),(.5,1.61,4.55)], [(-.76,1.22,-.17),(.78,1.21,-.32)],45),
 (6,'road','Repeat payments / street movement','phone','truck',[(.5,1.61,4.55),(1.46,1.70,4.58)],[(.78,1.21,-.32),(1.03,1.17,-.31)],45),
 (7,'exterior','Reveal sports car and estate','car','reveal',[(-.66,1.73,5.75),(1.05,2.58,9.28)],[(-.47,1.02,-1.18),(.07,1.64,-2.1)],47),
 (8,'villa','Wealth feels uncomfortable','hero','track',[(-.97,1.68,4.60),(-.34,1.57,4.07)],[(.0,1.24,-.38),(-.21,1.24,-.19)],46),
 (9,'villa','Old friend claims loyalty','friend','pan',[(-.34,1.57,4.07),(-.39,1.56,3.94)],[(-.21,1.24,-.19),(-.49,1.25,-.39)],46),
 (10,'villa','Girlfriend makes a promise','guest','pan',[(-.39,1.56,3.94),(.51,1.57,4.10)],[(-.49,1.25,-.39),(.28,1.26,-.29)],46),
 (11,'villa','He announces bankruptcy','hero','track',[(.51,1.57,4.10),(.88,1.68,4.91)],[(.28,1.26,-.29),(.04,1.18,-.37)],46),
 (12,'villa','Guests crowd around him','guests','orbit',[(.88,1.68,4.91),(.60,1.6,4.08)],[(.04,1.18,-.37),(.05,1.20,-.27)],46),
 (13,'villa','Notifications reveal the lies','phone','dolly-in',[(.60,1.6,4.08),(.29,1.45,2.53)],[(.05,1.20,-.27),(-.10,1.12,-.01)],46),
 (14,'village','Return home at dusk','door','track',[(-1.30,1.64,6.0),(.30,1.61,4.85)],[(-.77,1.14,-1),(.20,1.19,-1.53)],45),
 (15,'kitchen','Enter kitchen past foreground rack','mother','track',[(-2.30,1.53,4.51),(-.75,1.59,3.98)],[(-1.14,1.12,-.34),(-.71,1.21,-.55)],46),
 (16,'kitchen','Ask his mother about the money','mother','over-shoulder',[(-.75,1.59,3.98),(-.31,1.56,3.62)],[(-.71,1.21,-.55),(-.68,1.23,-.70)],46),
 (17,'kitchen','Mother shakes her head','mother','pan',[(-.31,1.56,3.62),(-.09,1.55,3.54)],[(-.68,1.23,-.70),(-.70,1.27,-.70)],46),
 (18,'kitchen','Silence / no deposit','phone','hold',[(-.09,1.55,3.54),(-.09,1.55,3.54)],[(-.70,1.27,-.70),(-.70,1.27,-.70)],46),
 (19,'kitchen','Mother insists she already ate','mother','hold',[(-.09,1.55,3.54),(-.08,1.55,3.51)],[(-.70,1.27,-.70),(-.69,1.27,-.70)],46),
 (20,'kitchen','Follow face to the fridge handle','fridge','dolly-in',[(-.08,1.55,3.51),(1.53,1.55,2.80)],[(-.69,1.27,-.70),(1.18,1.26,-1.0)],46),
 (21,'kitchen','Empty shelves / reaction from inside','hero','pov',[(1.58,1.74,-1.76),(1.58,1.74,-1.74)],[(.83,1.46,-.25),(.82,1.46,-.24)],66),
 (22,'kitchen','Return to mother, share the food','plate','dolly-out',[(.49,1.45,3.27),(.29,1.59,4.24)],[(-.47,1.12,-.51),(-.54,1.11,-.72)],46),
 (23,'kitchen','Pull back from the pair','plate','dolly-out',[(.29,1.59,4.24),(.06,1.69,5.05)],[(-.54,1.11,-.72),(-.53,1.16,-.72)],46),
]
def make_shot(row, start, end, text):
    i, env, reason, prop, move, pos, target, lens = row
    midpoint = lambda ends: [(a + b) / 2 for a, b in zip(*ends)]
    return dict(id=i, environment=env, narrativePurpose=reason, actor='mother' if prop=='mother' else 'hero',
                action=text, prop=prop, camera=move, startFrame=start, endFrame=end, lens=lens,
                position=[pos[0],midpoint(pos),pos[1]], target=[target[0],midpoint(target),target[1]],
                focus=prop, lighting=env, transition='cut' if i in (1,5,7,8,14,15,21,22) else 'continuous',
                soundEvents=[e for e in film['events'] if start <= round(e['time']*30) < end])
shots = []
for row, beat in zip(P, film['shots'], strict=True):
    i = row[0]
    start = math.ceil(beat['start']*30)
    end = math.ceil(film['shots'][i+1]['start']*30) if i+1<len(P) else film['frames']
    shots.append(make_shot(row, start, end, beat['text']))
# Standalone visual proof uses held sections from the same set with bespoke, slower motion.
D = [
 ((15,'kitchen','Enter room behind rack','hero','track',[(-2.39,1.55,4.55),(-.80,1.56,3.98)],[(-1.20,1.15,-.40),(-.71,1.20,-.52)],46),0,150),
 ((16,'kitchen','Track past shoulder to mother','mother','over-shoulder',[(-.8,1.56,3.98),(-.31,1.56,3.62)],[(-.71,1.20,-.52),(-.68,1.23,-.70)],46),150,236),
 ((20,'kitchen','Dolly toward hand and refrigerator','fridge','dolly-in',[(-.31,1.56,3.62),(1.53,1.55,2.80)],[(-.68,1.23,-.70),(1.18,1.26,-1.0)],46),236,337),
 ((21,'kitchen','See the reaction from inside the fridge','hero','pov',[(1.58,1.74,-1.76),(1.58,1.74,-1.74)],[(.83,1.46,-.25),(.82,1.46,-.24)],66),337,385),
 ((22,'kitchen','Pull back to the shared plate','plate','dolly-out',[(.49,1.45,3.27),(.06,1.69,5.05)],[(-.47,1.12,-.51),(-.53,1.16,-.72)],46),385,450),
]
payload=dict(fps=30,frames=film['frames'],shots=shots,captionCues=film['captionCues'],
             events=film['events'],demo=[make_shot(row,a,b,row[2]) for row,a,b in D])
(OUT/'shot-manifest.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
(PROJECT/'public/loi-noi-doi-v3.json').write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
(OUT/'Storyboard.md').write_text('# Lời nói dối của mẹ — V3\n\n| Frame start–end | Set | Story beat | Camera |\n| --- | --- | --- | --- |\n' +
    '\n'.join(f"| {s['startFrame']}–{s['endFrame']-1} | {s['environment']} | {s['narrativePurpose']} | {s['camera']} |" for s in shots),encoding='utf-8')
