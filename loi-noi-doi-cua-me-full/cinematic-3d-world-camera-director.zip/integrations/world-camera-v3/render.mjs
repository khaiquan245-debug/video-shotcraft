import {chromium} from '../pixijs-environment/browser.mjs';
import fs from 'node:fs/promises';
import {spawn,spawnSync} from 'node:child_process';
import {once} from 'node:events';
const version=process.env.WORLD_CAMERA_VERSION==='4'?4:3;
const out='/workspace/outputs/loi-noi-doi/v'+version;
const manifest=JSON.parse(await fs.readFile(out+'/shot-manifest.json','utf8'));
const demo=process.argv.includes('--demo'),proof=process.argv.includes('--proof');
const frames=demo?450:manifest.frames;
const pov=process.argv.includes('--pov')?manifest.demo.find(s=>s.camera==='pov'):null;
const kitchen=!demo&&process.argv.includes('--kitchen');
const from=kitchen?manifest.shots.find(s=>s.environment==='kitchen').startFrame:0;
const pool=pov?1:demo||kitchen?3:5;
const mode=pov?'pov':demo?'demo':kitchen?'kitchen':'full';
const size=Number(process.env.FRAME_WIDTH|| (proof ? 540 : 1080));
const height=process.env.FRAME_HEIGHT;
const path=out+'/'+mode+'-'+size+(height?'x'+height:'');
await fs.mkdir(path,{recursive:true});
const url='http://127.0.0.1:8893/loi-noi-doi-v'+version+'.html?w='+size+(height?'&h='+height:'')+(demo?'&demo=1':'')+(process.env.FX==='0'?'&fx=0':'');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
async function open(){
 const p=await browser.newPage();p.on('pageerror',e=>console.error('page',e.stack));p.on('console',v=>{if(v.type()==='error')console.error(v.text())});
 await p.goto(url);await p.waitForFunction(()=>window.ready,null,{timeout:25000});return p;
}
async function sample(p,frame,count){
 return p.evaluate(({frame,count})=>Array.from({length:count},(_,i)=>{
  const state=movie.setTime((frame+i)/30);
  return {jpg:movie.app.canvas.toDataURL('image/jpeg',.93).split(',')[1],state};
 }),{frame,count});
}
try{
 if(proof){
  const p=await open();
  const indices=demo?[0,61,120,173,225,274,315,335,338,360,388,430]:[0,70,152,200,328,400,449,510,534,760,860,910,1030,1160,1287,1320,1450,1500];
  const meta=[];
  for(const frame of indices){
   const [{jpg,state}]=await sample(p,frame,1);
   await fs.writeFile(path+'/'+String(frame).padStart(4,'0')+'.jpg',Buffer.from(jpg,'base64'));meta.push(state);
  }
  await fs.writeFile(path+'/samples.json',JSON.stringify(meta,null,2));
 }else{
  await Promise.all(Array.from({length:pool},(_,part)=>(async()=>{
   const start=pov?.startFrame??(from+Math.floor((frames-from)*part/pool)),end=pov?.endFrame??(from+Math.floor((frames-from)*(part+1)/pool)),name=path+'/part-'+part+'.mp4';
   try{await fs.access(name+'.done');const st=await fs.stat(name);if(st.size>0){console.log('Resume',part);return}}catch{}
   const p=await open();
   const ff=spawn('ffmpeg',['-v','error','-y','-f','image2pipe','-vcodec','mjpeg','-framerate','30','-i','pipe:0','-threads','2','-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-an',name],{stdio:['pipe','inherit','inherit']});
   const done=once(ff,'close');
   try{
    for(let i=start;i<end;i+=5){
     for(const {jpg} of await sample(p,i,Math.min(5,end-i)))if(!ff.stdin.write(Buffer.from(jpg,'base64')))await once(ff.stdin,'drain');
     if((i-start)%75===0)console.log('Part',part,i,end);
    }
   }finally{ff.stdin.end();await p.close();}
   if((await done)[0])throw new Error('Encode failed part '+part);
   await fs.writeFile(name+'.done',''+(end-start));console.log('Complete part',part);
  })()));
  const list=path+'/concat.txt';
  await fs.writeFile(list,Array.from({length:pool},(_,i)=>"file 'part-"+i+".mp4'").join('\n'));
  const suffix=height?'_'+size+'x'+height:'';
  const base=kitchen?'V4_Kitchen_Native':pov?'V4_POV_Native':demo?(version===4?'Demo_Tu_Lanh_V4_15s':'Demo_Tu_Lanh_15s'):'Loi_Noi_Doi_Cua_Me_V'+version;
  const name=out+'/'+base+suffix+'.mp4';
  const audio=demo||kitchen?[]:['-i',out+'/../v2/Loi_Noi_Doi_Cua_Me_V2_Chieu_Sau.mp4'];
  const maps=demo||kitchen?[]:['-map','0:v:0','-map','1:a:0'];
  const result=spawnSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i',list,...audio,...maps,'-c','copy','-movflags','+faststart',name],{stdio:'inherit'});
  if(result.status)throw new Error('Mux failed');
  console.log(name);
 }
}finally{await browser.close();}
