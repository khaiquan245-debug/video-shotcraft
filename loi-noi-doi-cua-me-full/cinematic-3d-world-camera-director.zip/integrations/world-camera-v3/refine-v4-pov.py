"""Replace exactly the re-rendered POV frames in the checked V4 draft."""
from pathlib import Path
import json
import subprocess

out=Path('/workspace/outputs/loi-noi-doi/v4')
manifest=json.loads((out/'shot-manifest.json').read_text())
pov=next(shot for shot in manifest['demo'] if shot['camera']=='pov')
start,end=pov['startFrame'],pov['endFrame']
before=out/'Demo_Tu_Lanh_V4_15s.mp4'
replacement=out/'V4_POV_Native.mp4'
result=out/'Demo_Tu_Lanh_V4_1080x1920.mp4'
count=subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-of','csv=p=0',str(replacement)],text=True)
assert int(count.strip().split(',')[0])==end-start
graph=(f'[0:v]split[a][b];[a]trim=end_frame={start},setpts=PTS-STARTPTS[p];'
       f'[b]trim=start_frame={end},setpts=PTS-STARTPTS[q];'
       '[1:v]setpts=PTS-STARTPTS[r];[p][r][q]concat=n=3:v=1:a=0,'
       'fps=30,setsar=1[out]')
subprocess.run([
    'ffmpeg','-v','error','-y','-i',str(before),'-i',str(replacement),
    '-filter_complex',graph,'-map','[out]','-c:v','libx264','-preset','fast',
    '-crf','16','-threads','4','-pix_fmt','yuv420p','-movflags','+faststart',str(result),
],check=True)
