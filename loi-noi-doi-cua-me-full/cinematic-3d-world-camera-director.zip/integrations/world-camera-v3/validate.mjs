import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import * as T from '../../workbench/node_modules/three/build/three.module.js';
import {createCameraDirector} from '../pixijs-environment/projects/loi-noi-doi-v3/camera.mjs';
const output='/workspace/outputs/loi-noi-doi/v3';
const file=process.argv[2]??output+'/shot-manifest.json';
const manifest=JSON.parse(await fs.readFile(file));
const results=[];
for(const [label,shots,frames] of [['full',manifest.shots,manifest.frames],['demo',manifest.demo,450]]){
 let next=0,previous=null,maxStep=0,maxRotation=0,cuts=0;
 for(const shot of shots){
  assert.equal(shot.startFrame,next,'Shot boundary '+shot.id);
  assert(shot.endFrame>next);
  assert(shot.position.length>=3&&shot.target.length>=3);
  assert([shot.lens,...shot.position.flat(),...shot.target.flat()].every(Number.isFinite));
  assert(shot.lens>=28&&shot.lens<=75);
  next=shot.endFrame;
 }
 assert.equal(next,frames);
 const director=createCameraDirector(shots),camera=new T.PerspectiveCamera(46,9/16,.08,70);
 for(let i=0;i<frames;i++){
  const {shot,position,focus}=director.sample(i,camera);
  assert(position.distanceTo(focus)>.4&&position.y>.1);
  assert(Math.abs(camera.quaternion.length()-1)<1e-6);
  if(previous){
   const step=position.distanceTo(previous.position),rotation=camera.quaternion.angleTo(previous.q);
   const boundary=shot!==previous.shot;
   if(boundary&&shot.transition==='cut')cuts++;
   else{
    assert(step<.32,`Unexpected camera travel at ${label} frame ${i}: ${step}`);
    assert(rotation<.13,`Unexpected camera rotation at ${label} frame ${i}: ${rotation}`);
    maxStep=Math.max(maxStep,step);maxRotation=Math.max(maxRotation,rotation);
   }
  }
  previous={position,shot,q:camera.quaternion.clone()};
 }
 results.push({label,frames,shotCount:shots.length,cuts,maxStep,maxRotation});
}
await fs.writeFile(path.join(path.dirname(file),'camera-validation.json'),JSON.stringify({scope:'Frame continuity, finite camera transforms, lens range and declared cuts',results},null,2));
console.log(results);
