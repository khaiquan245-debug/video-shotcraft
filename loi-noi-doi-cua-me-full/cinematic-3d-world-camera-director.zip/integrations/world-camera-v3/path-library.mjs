const add=(point,offset)=>point.map((v,i)=>v+offset[i]);
const move=(start,end,target,finish=target,lens=46)=>({
 position:[start,start.map((v,i)=>(v+end[i])/2),end],
 target:[target,target.map((v,i)=>(v+finish[i])/2),finish],lens
});
const three=(start,mid,end,target,lens)=>({position:[start,mid,end],target:[target,target,target],lens});
export function makePath(name,{subject,other=subject,radius=4,lens=46}){
 const p=(x,y,z)=>add(subject,[x,y,z]);
 const track=(x,y,z)=>add(other,[x,y,z]);
 switch(name){
  case 'dolly-in': return move(p(0,.28,radius),p(0,.13,radius*.62),subject,subject,lens);
  case 'dolly-out': return move(p(0,.13,radius*.61),p(0,.28,radius),subject,other,lens);
  case 'truck-left': return move(p(.52,.22,radius),p(-.52,.22,radius),subject,subject,lens);
  case 'truck-right': return move(p(-.52,.22,radius),p(.52,.22,radius),subject,subject,lens);
  case 'track': return move(p(-.3,.24,radius),track(-.3,.24,radius),subject,other,lens);
  case 'orbit': return three(p(-.34*radius,.28,.94*radius),p(0,.31,radius),p(.34*radius,.28,.94*radius),subject,lens);
  case 'pan': case 'tilt': case 'rack-focus': return move(p(0,.25,radius),p(0,.25,radius),subject,other,lens);
  case 'crane': return move(p(.24,.13,radius),p(.45,1.6,radius+.36),subject,other,lens);
  case 'over-shoulder': return move(p(.51,.28,radius),p(.38,.28,radius*.91),other,other,lens);
  case 'pov': return move(subject,subject,other,other,lens);
  case 'close-up': case 'reaction': return move(p(.15,.13,radius*.59),p(.05,.15,radius*.53),subject,subject,lens);
  case 'extreme-close-up': return move(p(.15,.10,radius*.32),p(.07,.10,radius*.27),subject,subject,lens);
  case 'reveal': return move(p(-.27,.16,radius*.64),p(.54,.55,radius),subject,other,lens);
  case 'match-cut': return {...move(p(0,.25,radius),p(0,.25,radius),subject,subject,lens),transition:'cut'};
  case 'hold': return move(p(0,.25,radius),p(0,.25,radius),subject,subject,lens);
  default: throw new RangeError('Unknown camera movement '+name);
 }
}
