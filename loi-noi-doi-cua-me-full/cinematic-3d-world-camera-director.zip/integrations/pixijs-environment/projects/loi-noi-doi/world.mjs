import {T,set} from '../life-remote/world.mjs';
import {populateEstate} from './villa-estate.mjs';
export {T};
export function world(name){
 const scene=set(name==='kitchen'?'room':name);
 function box(parent,x,y,z,w,h,d,color){
  const mesh=new T.Mesh(new T.BoxGeometry(w,h,d),new T.MeshStandardMaterial({color,roughness:.7}));
  mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
 }
 function shape(parent,x,y,z,top,base,height,color){
  const mesh=new T.Mesh(new T.CylinderGeometry(top,base,height,28),new T.MeshStandardMaterial({color}));
  mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
 }
 function table(x,z,w){
  box(scene,x,.77,z,w,.09,.71,0xa9744d);
  for(const dx of [-w*.41,w*.41])for(const dz of [-.25,.25])box(scene,x+dx,.37,z+dz,.07,.74,.07,0x6a4634);
 }
 if(name==='room'){
  const mat=shape(scene,.02,.009,-.78,.92,.92,.014,0x87a19a);
  mat.scale.set(1.27,1,.67);
  table(1.39,-1.66,.68);
  shape(scene,1.39,.90,-1.58,.07,.05,.16,0xd2a767);
 }
 if(name==='road'){
  for(const x of [-2.49,1.87]){
   shape(scene,x,.76,-1.27,.035,.055,1.52,0x4b5a5d);
   box(scene,x,1.43,-1.27,.39,.55,.05,0x3b6b63);
   box(scene,x,1.43,-1.235,.28,.43,.014,0xeddbc1);
   for(let j=0;j<4;j++)box(scene,x,1.56-j*.064,-1.22,.20-(j%2)*.033,.014,.01,0x819a86);
  }
 }
 if(name==='exterior')populateEstate(scene,box,shape);
 if(name==='kitchen'){
  const x=1.51,z=-1.48;
  box(scene,x,1,z-.42,1.04,2,.12,0x839d9d);
  for(const dx of [-.50,.50])box(scene,x+dx,1,z-.08,.075,2,.7,0x98acac);
  for(const y of [.11,.53,.99,1.43,1.92])box(scene,x,y,z-.08,1.02,.075,.73,0xb5c3c3);
  const door=new T.Group();door.position.set(x+.52,0,z+.30);scene.add(door);
  box(door,-.52,1,0,1.06,2,.10,0x96acaf);
  box(door,-.52,1.54,.052,1.03,.014,.008,0x627c85);
  box(door,-.93,1.22,.09,.044,.25,.085,0xe5dbb1);
  scene.userData.door=door;
  table(-.65,-1.24,1.70);
  box(scene,-1.95,.48,-2.84,2.1,.96,.49,0x7d9c8d);
  box(scene,-1.95,.985,-2.84,2.18,.064,.55,0xe1c7a2);
  for(let k=0;k<4;k++) {
   const x=-2.76+k*.53;
   box(scene,x,.47,-2.58,.48,.81,.04,0x91ac9c);
   box(scene,x+.13,.70,-2.55,.13,.022,.04,0xb99362);
  }
  for(let r=0;r<3;r++)for(let j=0;j<13;j++)box(scene,-3.12+j*.176,1.04+r*.173,-3.05,.166,.163,.028,(r+j)%2?0xe8d7b7:0xd5c7aa);
  for(let j=0;j<4;j++)shape(scene,-2.79+j*.21,1.10,-2.72,.064,.075,.20,[0xc57658,0xe4c77b,0x658d84,0xa56b4b][j]);
  for(let j=0;j<6;j++)box(scene,-1.77+j*.35,.015,-.55,.32,.010,.51,j%2?0xbd8c69:0xc79b7a);
  const food=new T.Group();scene.add(food);scene.userData.food=food;
  shape(food,-.63,.84,-1.15,.27,.20,.075,0xe9e7da);
  shape(food,-.63,.89,-1.15,.22,.15,.044,0xeab46b);
  for(let i=0;i<8;i++)shape(food,-.74+(i%4)*.071,.928,-1.21+Math.floor(i/4)*.10,.028,.024,.035,i%3?0x8b6240:0x637d40);
  shape(food,-1.20,.91,-1.15,.096,.063,.20,0x89adae);
  for(let i=0;i<2;i++){const stick=box(food,-.26+i*.04,.86,-1.19,.017,.019,.32,0xbb915b);stick.rotation.y=-.21;}
 }
 if(name==='villa'){
  const rug=shape(scene,.24,.007,-.52,1.18,1.18,.013,0x7f6353);
  rug.scale.set(1.38,1,.77);
  const inset=shape(scene,.24,.013,-.52,1.10,1.10,.008,0xaa7860);
  inset.scale.copy(rug.scale);
  shape(scene,.18,2.94,-2.00,.022,.022,.74,0x927449);
  shape(scene,.18,2.57,-2.00,.18,.18,.078,0xe8c993);
  for(let j=0;j<5;j++){
   const angle=j*Math.PI*.4;
   const x=.18+.32*Math.cos(angle),z=-2+.32*Math.sin(angle);
   const arm=box(scene,(x+.18)/2,2.58,(z-2)/2,.34,.022,.021,0xb78c56);
   arm.rotation.y=-angle;
   shape(scene,x,2.62,z,.04,.066,.10,0xffe09f);
  }
  table(.10,-1.66,1.47);
  shape(scene,.12,.85,-1.60,.29,.22,.06,0xf2e8c8);
  shape(scene,.12,.95,-1.60,.23,.22,.19,0xeb9d7e);
  shape(scene,.12,1.055,-1.60,.23,.23,.045,0xf7dfbb);
  for(let i=0;i<5;i++)shape(scene,-.04+i*.08,1.12,-1.60,.011,.011,.14,i%2?0x718fa8:0xbd5961);
  for(let i=0;i<8;i++){
   const y=2.71-Math.sin(i/7*Math.PI)*.30;
   const b=box(scene,-1.75+i*.5,y,-2.85,.20,.24,.025,[0xe7977e,0xf0c272,0x77a9a9][i%3]);b.rotation.z=(i-3.5)*.12;
  }
 }
 return scene;
}
