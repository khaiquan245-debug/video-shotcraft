import {T} from '../life-remote/world.mjs';
function materialTexture(kind){
 const size=256,canvas=document.createElement('canvas');canvas.width=canvas.height=size;
 const ctx=canvas.getContext('2d');
 ctx.fillStyle='#f0ece2';ctx.fillRect(0,0,size,size);
 let seed=284;
 const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
 for(let i=0;i<8500;i++){
  ctx.fillStyle=i%3?'rgba(79,70,61,.055)':'rgba(255,255,250,.22)';
  ctx.fillRect(rand()*size,rand()*size,1+rand()*(kind==='timber'?14:2),kind==='timber'?.65:2);
 }
 if(kind==='timber'){
  ctx.strokeStyle='rgba(105,79,58,.12)';
  for(let i=0;i<36;i++){
   const y=rand()*size;
   ctx.beginPath();ctx.moveTo(0,y);ctx.bezierCurveTo(80,y+4,160,y-3,size,y);ctx.stroke();
  }
 }else{
  ctx.strokeStyle='rgba(136,116,90,.18)';ctx.lineWidth=1.1;
  ctx.strokeRect(.5,.5,size-1,size-1);
 }
 const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;
 map.anisotropy=4;
 return map;
}
function reflectionMap(){
 const canvas=document.createElement('canvas');canvas.width=512;canvas.height=256;
 const ctx=canvas.getContext('2d'),sky=ctx.createLinearGradient(0,0,0,256);
 for(const [offset,color] of [[0,'#61869f'],[.44,'#b4d2de'],[.5,'#e1ddd0'],[.52,'#8c8c73'],[.75,'#787268'],[1,'#635e56']])sky.addColorStop(offset,color);
 ctx.fillStyle=sky;ctx.fillRect(0,0,512,256);
 const light=ctx.createRadialGradient(118,61,2,118,61,52);
 light.addColorStop(0,'#fff4d5');light.addColorStop(1,'#fff4d500');
 ctx.fillStyle=light;ctx.fillRect(0,0,512,256);
 const texture=new T.CanvasTexture(canvas);texture.mapping=T.EquirectangularReflectionMapping;
 texture.colorSpace=T.SRGBColorSpace;return texture;
}
const paint=new T.MeshPhysicalMaterial({color:0xb82c29,metalness:.38,roughness:.28,clearcoat:1,clearcoatRoughness:.22,side:T.DoubleSide});
const glass=new T.MeshStandardMaterial({color:0x364b54,metalness:.41,roughness:.20,side:T.DoubleSide});
export function populateEstate(scene,box,shape){
 for(const object of [...scene.children])if(!object.isLight&&!(object instanceof T.Object3D&&object.type==='Object3D'))scene.remove(object);
 scene.background=new T.Color(0xa9c9d8);
 scene.environment=reflectionMap();
 scene.environmentIntensity=.39;
 scene.fog=new T.Fog(0xb0cdd8,21,47);
 const shell=0xe7dfcf,trim=0xf3ebda,shadow=0x444648,oak=0xa4724d;
 const stone=materialTexture('stone'),timber=materialTexture('timber');
 function wall(x,y,z,w,h,d,c=shell){
  const mesh=box(scene,x,y,z,w,h,d,c);
  if(c===shell||c===trim||c===oak||c===0xc5ad92){
   const map=(c===oak?timber:stone).clone();
   map.wrapS=map.wrapT=T.RepeatWrapping;map.repeat.set(Math.max(1,w/.58),Math.max(1,(h>.06?h:d)/.58));map.needsUpdate=true;
   mesh.material.map=map;mesh.material.roughness=c===oak?.63:.82;
  }
  return mesh;
 }
 wall(0,-.12,-4,24,.22,22,0x879f65);
 wall(0,-.026,0,11,.045,12,0xc5ad92);
 for(let i=-9;i<=9;i++)wall(i*.55,.001,-.22,.010,.008,7.4,0x9d8b7e);
 for(let i=-5;i<7;i++)wall(0,.001,-.11+i*.55,10.5,.008,.011,0x9d8b7e);
 wall(-.82,1.45,-5.05,5.5,2.90,2.47);
 wall(-1.12,3.32,-5.25,4.72,1.56,2.22);
 wall(-1.12,4.14,-5.21,5.04,.19,2.59,trim);
 wall(-1.02,2.55,-3.66,5.46,.17,.65,trim);
 wall(-.26,.84,-3.73,1.22,1.68,.09,shadow);
 for(let j=0;j<2;j++){
  wall(-.54+j*.56,.85,-3.66,.51,1.51,.048,oak);
  wall(-.39+j*.20,.86,-3.629,.025,.34,.023,0xecbe77);
 }
 for(let j=0;j<3;j++)wall(-.27,.055+j*.075,-3.16-j*.24,1.79,.11,.58,0xa5958b);
 for(const x of [-1.19,.64]){
  wall(x,1.15,-3.28,.17,2.3,.19,trim);
  wall(x,.12,-3.28,.25,.22,.25);
 }
 wall(-.27,2.35,-3.26,2.06,.19,.68,trim);
 function glazing(x,y,z,w,h){
  wall(x,y,z,w+.11,h+.12,.07,shadow);
  wall(x,y,z+.04,w,h,.025,0x7babb6);
  const tint=wall(x,y,z+.057,w*.99,h*.99,.012,0x829ca5);
  tint.material.metalness=.30;tint.material.roughness=.20;
  const streak=wall(x-w*.20,y,z+.065,w*.12,h*.92,.010,0xaac1c4);
  streak.material.transparent=true;streak.material.opacity=.28;
  wall(x,y,z+.07,.035,h,.044,shadow);
  wall(x,y-.13,z+.069,w,.028,.041,shadow);
  wall(x,y-h*.5-.047,z+.077,w+.20,.063,.19,trim);
  for(const side of [-1,1])wall(x+side*w*.28,y-h*.12,z+.063,w*.11,h*.64,.009,0x8d9991);
 }
 glazing(-2.21,1.43,-3.77,1.26,1.39);
 glazing(1.11,1.36,-3.77,.97,1.3);
 glazing(-1.94,3.18,-4.09,1.39,1.10);
 glazing(-.24,3.18,-4.09,1.25,1.10);
 wall(-1.07,2.61,-3.72,4.2,.14,.78,trim);
 wall(-1.07,3.02,-3.39,4.1,.045,.049,shadow);
 for(let j=0;j<15;j++)wall(-3.07+j*.284,2.84,-3.39,.022,.37,.028,shadow);
 function crown(x,y,z,s){
  const mesh=new T.InstancedMesh(new T.IcosahedronGeometry(1,1),new T.MeshStandardMaterial({roughness:.9}),62);
  const dummy=new T.Object3D();
  for(let j=0;j<62;j++){
   const a=j*2.39996,r=(.14+.65*((j*17)%31)/31)*s;
   dummy.position.set(x+Math.cos(a)*r,y+Math.sin(j*2.3)*r*.60,z+Math.sin(a)*r);
   dummy.scale.setScalar(s*(.19+.07*Math.sin(j*3.2)));dummy.rotation.set(j*.7,j*.3,j*.2);dummy.updateMatrix();
   mesh.setMatrixAt(j,dummy.matrix);mesh.setColorAt(j,new T.Color([0x556a3f,0x758352,0x919458,0x4f613b][j%4]));
  }
  mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);
 }
 for(const [x,z,s] of [[-3.52,-3.8,1.07],[3.14,-3.65,1.21],[-3.72,-.9,.64],[2.63,-.72,.48],[-2.79,-2.34,.43]]){
  const small=s<.7;
  shape(scene,x,small?.14:.82,z,small?.16:.09,small?.13:.13,small?.28:1.64,small?0x9c654a:0x785943);
  crown(x,small?.48:1.95,z,s);
 }
 // Set back the neighborhood and skyline on separate geometry planes.
 wall(0,-.14,-23,85,.24,41,0x92a478);
 for(const [x,z,w,h,c] of [[-15,-33,17,9,0x849bad],[10,-32,17,8.6,0x839eae],[-8,-24,11,6.4,0x77969b],[8,-25,13,6.9,0x729597]]){
  const ridge=new T.Mesh(new T.SphereGeometry(1,24,12),new T.MeshStandardMaterial({color:c,roughness:1}));
  ridge.position.set(x,-2.1,z);ridge.scale.set(w,h,4.4);scene.add(ridge);
 }
 for(const [x,z,w,h,tone] of [[-6.4,-10.4,2.6,2.7,0xcab99f],[4.8,-10.9,2.4,3.05,0xd5c4a9],[8,-13,3,2.9,0xc3b5a7],[-9.7,-14,2.8,3.22,0xd1bbae]]){
  wall(x,h/2,z,w,h,1.45,tone);
  const roof=new T.Mesh(new T.CylinderGeometry(.08,1,1.13,4),new T.MeshStandardMaterial({color:0x7e7072}));
  roof.rotation.y=Math.PI/4;roof.scale.set(w*.77,1,1.83);roof.position.set(x,h+.49,z);scene.add(roof);
  for(const j of [-1,1])glazing(x+j*w*.19,h*.64,z+.75,.42,.63);
  wall(x,.64,z+.75,.52,1.25,.043,0x8c7771);
 }
 for(const [x,z,y,s] of [[-5,-8,2.88,1.02],[2.82,-7.1,3.85,1.08],[.45,-8.3,4.52,1.10],[5.95,-9.7,2.6,1.0],[-8,-12,3.12,.91],[7.1,-14,3.45,1.23]]){
  shape(scene,x,(y-.25)*.5,z,.061,.12,y-.25,0x786d54);
  crown(x,y,z,s);
 }
 for(const x of [-4.0,3.4]){
  wall(x,.22,-3.1,.27,.44,5.6,0xb2a590);
  wall(x,.46,-3.1,.34,.06,5.7,0xd8c6aa);
  for(let j=0;j<5;j++)wall(x,.66,-5.4+j*1.08,.082,.46,.081,0x696e65);
  wall(x,.89,-3.24,.055,.045,4.96,0x6e736b);
 }
 const markers=new T.InstancedMesh(new T.BoxGeometry(.043,.055,.03),new T.MeshStandardMaterial({color:0x6a7051}),58);
 const stem=new T.Object3D();
 for(let i=0;i<58;i++){
  stem.position.set((i%2?1:-1)*(2.45+i%7*.078),.016,-.65-i%19*.186);
  stem.rotation.set(.25*Math.sin(i),i,Math.sin(i*3)*.47);stem.updateMatrix();markers.setMatrixAt(i,stem.matrix);
 }
 scene.add(markers);
 sportsCar(scene,box,shape);
}
function sportsCar(scene,box,shape){
 const car=new T.Group();car.position.set(.35,.014,-1.83);car.rotation.y=.39;scene.add(car);
 function surface(stations,material){
  const vertices=[],faces=[];
  const profile=[[-1,0],[-.99,.55],[-.87,.87],[-.60,1],[0,1.06],[.60,1],[.87,.87],[.99,.55],[1,0],[.81,-.07],[-.81,-.07]];
  for(const [x,w,lo,hi] of stations)for(const [s,y] of profile)vertices.push(x,lo+y*(hi-lo),w*s);
  const n=profile.length;
  for(let j=1;j<stations.length;j++)for(let k=0;k<n;k++){
   const a=(j-1)*n+k,b=(j-1)*n+(k+1)%n,c=b+n,d=a+n;faces.push(a,b,d,b,c,d);
  }
  for(let k=1;k<n-1;k++)faces.push(0,k+1,k,(stations.length-1)*n,(stations.length-1)*n+k,(stations.length-1)*n+k+1);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vertices,3));g.setIndex(faces);g.computeVertexNormals();
  const m=new T.Mesh(g,material);m.castShadow=m.receiveShadow=true;car.add(m);
 }
 surface([[-1.92,.66,.21,.40],[-1.81,.81,.19,.50],[-1.51,.91,.18,.58],[-1.04,.92,.18,.61],[-.50,.87,.18,.60],[.41,.88,.19,.63],[1.01,.95,.19,.68],[1.52,.92,.20,.64],[1.79,.79,.26,.56]],paint);
 surface([[-.81,.64,.56,.62],[-.46,.61,.58,.83],[-.19,.57,.60,.98],[.23,.55,.60,.99],[.56,.58,.61,.91],[1.03,.62,.62,.65]],glass);
 surface([[-.25,.42,.936,.973],[-.16,.46,.947,1.002],[.21,.45,.95,1.008],[.35,.39,.94,.98]],paint);
 for(const x of [-1.14,1.05])for(const side of [-1,1]){
  const z=.88*side;
  const tire=shape(car,x,.36,z,.355,.355,.23,0x22272d);tire.rotation.x=Math.PI/2;
  const rim=shape(car,x,.36,z+side*.124,.242,.242,.048,0xc4d2dc);rim.rotation.x=Math.PI/2;
  const hub=shape(car,x,.36,z+side*.157,.092,.092,.035,0x60707c);hub.rotation.x=Math.PI/2;
  for(let i=0;i<5;i++) {
   const a=i*2*Math.PI/5;
   const spoke=box(car,x+.142*Math.cos(a),.36+.142*Math.sin(a),z+side*.151,.137,.032,.025,0x536371);spoke.rotation.z=a;
  }
 }
 for(const z of [-.53,.53]){
  const lamp=box(car,-1.77,.444,z,.21,.044,.27,0xf5f1d8);lamp.rotation.y=z*.59;
  box(car,1.77,.471,z,.047,.041,.28,0xff9b6f);
  box(car,-1.826,.296,z,.058,.075,.23,0x29353a);
  box(car,-.45,.701,z*1.54,.24,.073,.132,0xe46a50);
 }
 box(car,-1.908,.291,0,.041,.108,.55,0x283237);
 box(car,1.43,.644,0,.13,.074,1.35,0x522b2c);
 for(const z of [-.73,.73])box(car,.26,.593,z,.20,.025,.024,0x6d3030);
}
