import {T} from '../life-remote/world.mjs';

export function addAtmosphere(scene,outdoors){
 const count=72,positions=new Float32Array(count*3),anchors=[],phase=new Float32Array(count);
 for(let i=0;i<count;i++){
  const near=i%3===0;
  const z=near?1.05+((i*19)%31)/20:-.20-((i*41)%55)/12;
  anchors.push([((i*31)%73)/10-3.6,.20+((i*43)%61)/23,z]);
  phase[i]=i*2.39996;
 }
 const geometry=new T.BufferGeometry();
 geometry.setAttribute('position',new T.BufferAttribute(positions,3));
 geometry.setAttribute('phase',new T.BufferAttribute(phase,1));
 const material=new T.ShaderMaterial({
  uniforms:{time:{value:0},tint:{value:new T.Color(outdoors?0xffefbd:0xffdfad)}},
  vertexShader:`
   attribute float phase;
   uniform float time;
   varying float opacity;
   void main() {
    vec4 p=modelViewMatrix*vec4(position,1.);
    float depth=-p.z;
    gl_Position=projectionMatrix*p;
    gl_PointSize=clamp((16.+6.*sin(phase))/depth,1.2,7.);
    opacity=(.17+.23*(1.-smoothstep(3.,10.,depth)))*(.72+.28*sin(phase+time*.8));
   }`,
  fragmentShader:`
   varying float opacity;
   uniform vec3 tint;
   void main(){
    float edge=length(gl_PointCoord-.5)*2.;
    gl_FragColor=vec4(tint,(1.-smoothstep(.05,1.,edge))*opacity);
   }`,
  transparent:true,depthWrite:false
 });
 const cloud=new T.Points(geometry,material);
 cloud.frustumCulled=false;scene.add(cloud);
 return t=>{
  material.uniforms.time.value=t;
  for(let i=0;i<count;i++){
   const [x,y,z]=anchors[i],p=phase[i],j=i*3;
   positions[j]=x+.18*Math.sin(t*.55+p);
   positions[j+1]=y+.14*Math.sin(t*.72+p*1.41);
   positions[j+2]=z+.12*Math.cos(t*.38+p);
  }
  geometry.attributes.position.needsUpdate=true;
 };
}
