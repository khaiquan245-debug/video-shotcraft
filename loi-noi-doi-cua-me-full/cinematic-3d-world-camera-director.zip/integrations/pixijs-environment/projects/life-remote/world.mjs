import * as T from '../../../../workbench/node_modules/three/build/three.module.js';
import {RoundedBoxGeometry} from '../../../../workbench/node_modules/three/examples/jsm/geometries/RoundedBoxGeometry.js';
export {T};
let seed=6612;
const rnd=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
const wood=texture('wood'),stone=texture('stone'),cloth=texture('cloth');
function texture(kind){
 const c=document.createElement('canvas');c.width=c.height=192;const g=c.getContext('2d');
 g.fillStyle='#ded9cb';g.fillRect(0,0,192,192);
 for(let i=0;i<9000;i++){let u=rnd(),x=rnd()*192,y=rnd()*192;g.fillStyle=u>.54?'rgba(255,241,210,.22)':'rgba(88,70,63,.13)';g.fillRect(x,y,kind==='wood'?2+u*8:1+u,1);}
 if(kind==='wood')for(let j=0;j<33;j++){
  let y=rnd()*192;g.strokeStyle='rgba(92,68,48,.15)';g.beginPath();g.moveTo(0,y);g.bezierCurveTo(72,y+5,138,y-5,192,y+3);g.stroke();
 }
 const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;return t;
}
const palettes={
 room:[0xcbb08e,0xd7b68f,0x3a7777],office:[0xa8bdb5,0xa58a74,0x608285],
 school:[0xd5c398,0xae9380,0x568174],gym:[0xa4b5ac,0x838f8e,0x44636f],
 villa:[0xe2ceb2,0xbfae94,0x7d7163],mirror:[0xa3aea9,0xbcb5ab,0x597b83],
 road:[0xc8b297,0xb6a681,0x577e79],exterior:[0xdac6a4,0xb6b19f,0x609581]
};
export function set(kind){
 const scene=new T.Scene(),[wall,floor,accent]=palettes[kind];
 scene.background=new T.Color(kind==='road'||kind==='exterior'?0xaaccdc:0xc1b6aa);
 const outside=kind==='road'||kind==='exterior';
 scene.add(new T.HemisphereLight(kind==='mirror'?0xc9e5f4:0xe4efff,0x9c7662,1.55));
 const light=new T.DirectionalLight(kind==='mirror'?0xe4e7ff:0xffdaaa,2.5);
 light.position.set(-3.8,5.2,4.8);light.castShadow=true;light.shadow.mapSize.set(512,512);light.shadow.normalBias=.028;light.shadow.bias=-.0006;
 light.shadow.camera.left=-8;light.shadow.camera.right=8;light.shadow.camera.top=8;light.shadow.camera.bottom=-8;scene.add(light,light.target);
 function mesh(g,c,x,y,z,map=null){
  const m=new T.Mesh(g,new T.MeshStandardMaterial({color:c,roughness:.81,map}));m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;scene.add(m);return m;
 }
 function box(x,y,z,a,b,d,c,map=null,rounded=false){
  return mesh(rounded?new RoundedBoxGeometry(a,b,d,2,Math.min(.075,a*.18,b*.18,d*.18)):new T.BoxGeometry(a,b,d),c,x,y,z,map);
 }
 function ring(x,y,z,r,t,c){return mesh(new T.TorusGeometry(r,t,8,24),c,x,y,z);}
 function ball(x,y,z,a,b,c,color){
  let m=mesh(new T.SphereGeometry(1,14,10),color,x,y,z);m.scale.set(a,b,c);return m;
 }
 function tube(x,y,z,r,h,c){return mesh(new T.CylinderGeometry(r,r,h,17),c,x,y,z);}
 function plate(label,x,y,z,w,h,color='#345d5a'){
  const c=document.createElement('canvas');c.width=640;c.height=200;let g=c.getContext('2d');
  g.fillStyle=color;g.fillRect(0,0,640,200);g.strokeStyle='#d6ba89';g.lineWidth=6;g.strokeRect(13,13,614,174);
  g.font='bold 68px Arial';g.textAlign='center';g.textBaseline='middle';g.fillStyle='#ffecc5';g.fillText(label,320,101,565);
  const m=new T.CanvasTexture(c);m.colorSpace=T.SRGBColorSpace;
  const o=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:m}));o.position.set(x,y,z);scene.add(o);
 }
 function shelf(x,y,z,w){
  box(x,y,z,w,.082,.53,0x8f654d,wood);
  for(let j=0;j<7;j++){
   const h=.13+rnd()*.17;
   box(x-w*.43+j*w*.12,y+h/2+.045,z,.084,h,.22,[0xd1a06d,0x708e85,0xa5756a,0x8d97a9][j%4],cloth,true);
   box(x-w*.43+j*w*.12,y+.09+h*.4,z+.116,.055,.018,.008,0xe2c8a0);
  }
 }
 function plant(x,z,scale=1){
  mesh(new T.CylinderGeometry(.16*scale,.115*scale,.23*scale,14),0xae775a,x,.115*scale,z,stone);
  for(let i=0;i<13;i++){
   const a=i*2.4,r=.08+rnd()*.17;
   ball(x+r*Math.cos(a)*scale,(.24+rnd()*.38)*scale,z+r*Math.sin(a)*scale,.083*scale,.142*scale,.057*scale,[0x498259,0x6c9562,0x82a671][i%3]).rotation.z=.59*Math.sin(a);
  }
 }
 function window(x,y,z,w,h){
  box(x,y,z,w+.14,h+.12,.087,0x897b6b,wood);
  box(x,y,z+.049,w,h,.024,0x668692);
  for(let i=0;i<6;i++){
   const bh=.14+rnd()*.24,bx=x-w*.42+i*w*.15;
   box(bx,y-h*.47+bh/2,z+.069,w*.105,bh,.014,[0x819397,0x566c78,0x9ba6a4][i%3]);
   for(let j=0;j<2;j++)box(bx-w*.021,y-h*.423+j*.085,z+.081,w*.026,.03,.008,0xcdb389);
  }
  box(x,y,z+.10,.045,h,.038,0xe0ccaa);
  box(x,y-.14,z+.11,w,.045,.036,0xe0ccaa);
  box(x,y-h*.5-.037,z+.17,w+.23,.063,.27,0xc39b74,wood);
 }
 function desk(x,z,w=1.19){
  box(x,.74,z,w,.09,.61,0xa87958,wood,true);
  for(let dx of [-1,1])for(let dz of [-1,1])box(x+dx*(w*.43),.36,z+dz*.242,.054,.72,.05,0x775644,wood);
 }
 function chair(x,z,c=accent){
  box(x,.43,z,.38,.079,.39,c,cloth,true);
  box(x,.716,z-.175,.39,.259,.06,c,cloth,true);
  for(let dx of [-1,1])for(let dz of [-1,1])box(x+dx*.163,.211,z+dz*.156,.038,.42,.038,0x67534b);
 }
 box(0,-.115,0,18,.23,18,floor,outside?stone:wood);
 for(let i=-12;i<13;i++)box(i*.42,.003,1,.009,.005,12,kind==='villa'?0xa39480:0x9f8d7a);
 if(!outside){
  box(0,1.69,-3.9,14,3.4,.18,wall,stone);
  box(-4.4,1.6,-1.4,.16,3.38,5.5,wall,stone);
  box(0,.095,-3.77,12,.16,.107,0x9e8270,wood);
  box(0,3.40,-1.6,12,.12,6,0xd8c8b6);
  box(0,3.29,-3.76,12,.09,.076,0xe4d2b6);
 }
 if(kind==='room'){
  window(-1.19,2.11,-3.72,1.65,1.29);
  box(-1.19,.38,-2.57,2.25,.59,.80,accent,cloth,true);
  box(-1.19,.76,-2.86,2.24,.61,.24,accent,cloth,true);
  for(let j=0;j<3;j++)box(-1.88+j*.67,.68,-2.49,.57,.134,.59,0x82a098,cloth,true);
  desk(1.12,-2.65,1.18);shelf(1.12,1.71,-3.55,1.20);
  plant(1.83,-2.51,1.16);
  for(let side of [-1,1])for(let j=0;j<13;j++)box(-1.19+side*(.67+j*.033),2.1,-3.55,.036,1.56,.050,0xb36e66,cloth,true);
 }
 if(kind==='road'){
  box(0,.009,-1.17,17,.022,3.08,0x728187,stone);
  for(let k=0;k<7;k++){
   const x=-7.8+k*2.52,h=3.3+k%3*.52;
   box(x,h*.5,-4.5,2.36,h,1.26,[0xcfa57e,0x94ada1,0xcb9e8f,0xc4b6a1][k%4],stone);
   box(x,h,-3.88,2.42,.13,.19,0xdcc6a5);
   for(let j=0;j<2;j++)for(let k of [-1,1])window(x+k*.51,1.79+j*.76,-3.84,.52,.52);
   box(x,.55,-3.83,1.54,1.12,.1,0x728d8b);
  }
  for(const x of [-2.54,.31])tube(x,1.0,-.94,.037,2,0x557271);
  box(-1.115,1.995,-.81,3.13,.11,.62,0x4c7773,stone);
  box(-1.115,1.06,-1.046,2.84,1.64,.041,0x9db5ae).material.transparent=true;
  const glass=scene.children.at(-1);glass.material.opacity=.25;glass.material.depthWrite=false;
  box(-1.1,.465,-.82,2.08,.09,.37,0xa97957,wood);
  for(const x of [-1.96,-.21])box(x,.26,-.83,.065,.47,.052,0x687c75);
  plate('TRẠM XE BUÝT',-1.12,1.91,-.43,2.81,.35);
  for(let j=0;j<8;j++)box(-5+j*1.5,.029,-2.38,.81,.022,.052,0xe8d1a2);
  plant(1.6,-.88,1.27);
  const bus=new T.Group();scene.add(bus);
  const objects=[];
  const add=o=>{bus.add(o);objects.push(o);return o;};
  add(box(0,.82,0,3.5,1.36,.73,0x739992,null,true));add(box(0,.535,.373,3.47,.17,.042,0xe2b96f));
  for(let j=0;j<5;j++)add(box(-1.36+j*.61,1.026,.38,.49,.398,.034,0x355b69,null,true));
  for(const x of [-1.1,1.13]){
   const tire=add(mesh(new T.CylinderGeometry(.287,.287,.16,18),0x333946,x,.30,.34));tire.rotation.x=Math.PI/2;
   const wheel=add(mesh(new T.CylinderGeometry(.122,.122,.17,14),0xb4c5c4,x,.30,.35));wheel.rotation.x=Math.PI/2;
  }
  bus.position.set(-6,0,-2.12);scene.userData.bus=bus;
 }
 if(kind==='office'){
  window(-1.05,2.22,-3.76,2.2,1.44);
  desk(-1.26,-1.0,1.56);desk(1.15,-1.65,1.44);chair(-1.25,-1.48);chair(1.10,-2.0);
  for(const x of [-1.46,1.11]){
   box(x,.927,-1.52,.077,.32,.064,0x576772);
   box(x,1.13,-1.54,.56,.344,.066,0x3a4c56,null,true);box(x,1.13,-1.499,.496,.274,.013,0x82abb0);
   for(let j=0;j<3;j++)box(x-.10,1.19-j*.048,-1.488,.218-j*.017,.011,.005,0xc6ded1);
  }
  shelf(1.71,1.96,-3.59,1.53);
  box(2.39,.73,-2.61,.67,1.45,.64,0x8b9a91,stone,true);
  for(let k=0;k<4;k++)box(2.39,.33+k*.23,-2.28,.21,.023,.028,0xc0b9a1);
  plant(-2.38,-2.25,1.12);
 }
 if(kind==='school'){
  box(0,1.94,-3.72,3.34,1.17,.101,0x495b51,wood);
  for(let j=0;j<3;j++)box(-.58,2.21-j*.16,-3.66,1.44-j*.37,.019,.014,0xc3c9a3);
  shelf(2.3,1.64,-3.45,.91);
  for(const x of [-1.52,1.29]){desk(x,-1.56,1.03);chair(x,-1.86);}
  window(-2.64,2.04,-3.72,.71,1.14);
 }
 if(kind==='gym'){
  box(-.82,1.55,-3.72,2.31,1.56,.054,0x587b83,stone);
  for(let j=0;j<4;j++)box(-1.66+j*.55,1.55,-3.675,.021,1.55,.018,0xc4d3c7);
  for(let i=0;i<6;i++){
   const x=-1.76+i*.58;
   const grip=tube(x,.46,-2.5,.035,.39,0x9ea99f);grip.rotation.z=Math.PI/2;
   for(const side of [-1,1]){let p=tube(x+side*.16,.46,-2.5,.112+.009*i,.068,0x3e5358);p.rotation.z=Math.PI/2;}
  }
  box(-.15,.36,-2.50,3.69,.083,.36,0x64817d,stone);
  box(1.17,.40,-1.62,1.3,.085,.41,0x53676d,cloth,true);
  for(const x of [.66,1.68])box(x,.19,-1.62,.081,.38,.081,0x596263);
  plate('PHÒNG TẬP',1.44,2.34,-3.66,1.07,.27,'#536961');
 }
 if(kind==='exterior'){
  const xx=.5,d=-3.74;
  box(xx,1.52,d,4.55,3.04,1.9,0xd8c7aa,stone);box(xx,3.04,d,4.74,.16,2.07,0x9b7a5e);
  for(const x of [-1.05,.05,1.38])window(x,1.90,-2.75,.70,.93);
  for(const x of [-1.51,1.96])box(x,1.14,-2.48,.10,2.25,.102,0xc3b18d);
  box(.39,.79,-2.72,.96,1.61,.11,0x8a6c54,wood);
  box(.38,.87,-2.638,.019,1.58,.024,0xbea27e);
  for(let j=0;j<3;j++)box(.47,.037+j*.058,-2.28+j*.125,1.27,.078,.63,0xb4aa94,stone);
  plant(-1.89,-1.53,1.48);plant(2.09,-1.63,1.43);
  const carZ=-1.34,carX=1.29;
  box(carX,.37,carZ,1.86,.33,.84,0x9f5659,null,true);
  box(carX-.23,.625,carZ,.88,.345,.71,0x3f626c,null,true);
  box(carX-.08,.78,carZ,.58,.06,.74,0xaa6060,null,true);
  for(const dx of [-.62,.62]){
    let tire=mesh(new T.CylinderGeometry(.216,.216,.123,20),0x333b42,carX+dx,.22,carZ+.432);tire.rotation.x=Math.PI/2;
    let rim=mesh(new T.CylinderGeometry(.104,.104,.132,18),0xa6b3ad,carX+dx,.22,carZ+.441);rim.rotation.x=Math.PI/2;
  }
  box(carX+.87,.466,carZ+.34,.093,.072,.148,0xf4dcb3,null,true);
  box(carX-.89,.465,carZ+.34,.091,.070,.14,0xdc7770,null,true);
 }
 if(kind==='villa'){
  window(-.76,2.0,-3.74,2.4,1.58);
  box(-.78,.43,-2.46,2.75,.74,.88,0x9a8b78,cloth,true);box(-.78,.74,-2.82,2.74,.65,.27,0xa28e79,cloth,true);
  for(let j=0;j<3;j++)box(-1.59+j*.80,.667,-2.43,.69,.14,.59,0xa7a496,cloth,true);
  desk(1.71,-2.46,1.10);plant(2.16,-1.89,1.25);
  for(const x of [-2.13,.66])box(x,2.02,-3.54,.24,1.91,.11,0x9d806b,cloth,true);
  const lamp=tube(1.55,1.1,-2.56,.02,.57,0x96765f);
  mesh(new T.CylinderGeometry(.15,.24,.21,24),0xd1ae78,1.55,1.48,-2.56,cloth);
 }
 if(kind==='mirror'){
  box(.63,1.82,-3.66,1.57,1.74,.14,0x9e8163,wood,true);
  box(.63,1.82,-3.574,1.39,1.56,.037,0x799ba4);
  for(let i=0;i<5;i++){const r=box(.21+i*.155,1.76,-3.55,.036,1.11,.008,0x9fb6b3);r.rotation.z=-.3;}
  box(.63,.65,-3.32,1.62,.68,.50,0x8b9389,wood);box(.63,1.015,-3.31,1.68,.091,.57,0xd9d5bd,stone,true);
  ball(.62,1.065,-3.294,.263,.07,.178,0xb0beb0);
  let pipe=ring(.63,1.16,-3.438,.069,.014,0x8a9896);pipe.scale.y=.85;
  plant(-1.67,-2.30,1.12);
 }
 return scene;
}
