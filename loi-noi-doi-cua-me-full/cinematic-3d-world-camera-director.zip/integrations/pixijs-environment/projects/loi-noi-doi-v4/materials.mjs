import {T} from '../loi-noi-doi-v3/stage.mjs';
import {RoundedBoxGeometry} from '../../../../workbench/node_modules/three/examples/jsm/geometries/RoundedBoxGeometry.js';

function texture(kind){
 const c=document.createElement('canvas');c.width=c.height=256;
 const g=c.getContext('2d');g.fillStyle=kind==='wood'?'#d9bd9f':'#e4dfd5';g.fillRect(0,0,256,256);
 let seed=0x12883a;
 const random=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
 for(let i=0;i<4100;i++){
  const x=random()*256,y=random()*256,s=random();
  g.fillStyle=s>.5?'#fff6e129':'#55453c17';
  g.fillRect(x,y,kind==='wood'?2+s*13:1+s*3,kind==='wood'?.8:1+s*2);
 }
 if(kind==='wood')for(let i=0;i<60;i++){
  const y=random()*256;
  g.strokeStyle=i%3?'#63432422':'#f4e3cb38';g.lineWidth=i%4===0?1.5:.8;
  g.beginPath();g.moveTo(0,y);g.bezierCurveTo(72,y+Math.sin(i)*13,149,y-11,256,y+3);g.stroke();
 }
 if(kind==='enamel'){
  for(let i=0;i<12;i++){
   const x=random()*235,y=random()*235;
   const stain=g.createRadialGradient(x,y,0,x,y,12+i*.43);stain.addColorStop(0,'#8a73562b');stain.addColorStop(1,'#9a7b5e00');
   g.fillStyle=stain;g.fillRect(x-24,y-24,48,48);
  }
 }
 const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;map.anisotropy=4;return map;
}
const maps=new Map();
function normalFromHeight(source){
 const c=document.createElement('canvas');c.width=c.height=256;
 const context=c.getContext('2d');
 const height=source.image.getContext('2d').getImageData(0,0,256,256).data;
 const out=context.createImageData(256,256);
 const h=(x,y)=>height[4*((y&255)*256+(x&255))];
 for(let y=0;y<256;y++)for(let x=0;x<256;x++){
  const j=4*(y*256+x),dx=(h(x-1,y)-h(x+1,y))*.012,dy=(h(x,y+1)-h(x,y-1))*.012;
  const length=Math.hypot(dx,dy,1);
  out.data.set([128+127*dx/length,128+127*dy/length,128+127/length,255],j);
 }
 context.putImageData(out,0,0);
 return new T.CanvasTexture(c);
}
export function mat(color,finish='matte',options={}){
 const roughness={matte:.80,wood:.66,plaster:.92,enamel:.48,steel:.28,ceramic:.35,glass:.21}[finish];
 if(['wood','plaster','enamel'].includes(finish)&&!maps.has(finish)){
  const map=texture(finish);maps.set(finish,{map,normalMap:normalFromHeight(map)});
 }
 const mapsForFinish=maps.get(finish);
 return new T.MeshStandardMaterial({color,roughness,metalness:finish==='steel'?.68:finish==='enamel'?.10:0,
  ...mapsForFinish,normalScale:new T.Vector2(.24,.24),...options});
}
export function bevel(parent,x,y,z,w,h,d,col,finish='matte',radius=.025,options={}){
 const m=new T.Mesh(new RoundedBoxGeometry(w,h,d,2,Math.min(radius,w*.30,h*.30,d*.30)),mat(col,finish,options));
 m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;
}
export function lathe(parent,x,y,z,profile,col,finish='matte',options={}){
 const m=new T.Mesh(new T.LatheGeometry(profile.map(p=>new T.Vector2(...p)),28),mat(col,finish,options));
 m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;
}
export function tube(parent,points,r,col,finish='matte'){
 const line=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p)));
 const m=new T.Mesh(new T.TubeGeometry(line,12,r,8,false),mat(col,finish));parent.add(m);m.castShadow=true;return m;
}
export function oval(parent,x,y,z,a,b,c,col,finish='matte'){
 const m=new T.Mesh(new T.SphereGeometry(1,16,10),mat(col,finish));m.scale.set(a,b,c);
 m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;
}
