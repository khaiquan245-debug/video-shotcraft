const ink='#202127';
export function drawCharacter(g,face,steps,armSwing,blink,look={}){
 const line=(p,color,w)=>{g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.strokeStyle=color;g.lineWidth=w;g.lineCap='round';g.lineJoin='round';g.stroke()};
 const oval=(x,y,a,b,col,sw=0)=>{g.beginPath();g.ellipse(x,y,a,b,0,0,Math.PI*2);g.fillStyle=col;g.fill();if(sw){g.strokeStyle=ink;g.lineWidth=sw;g.stroke()}};
 const curve=(svg,fill,width=3)=>{let p=new Path2D(svg);g.fillStyle=fill;g.fill(p);if(width){g.strokeStyle=ink;g.lineWidth=width;g.lineJoin='round';g.stroke(p)}};

 for(let j=0;j<2;j++){
  const f=steps[j],hip=look.seated?[j?15:-14,-100]:[j?16:-18,-95],dx=f[0]-hip[0],dy=f[1]-hip[1],len=Math.hypot(dx,dy);
  const knee=look.seated?[hip[0]+25,-59]:
     [(f[0]+hip[0])/2+dy/len*Math.sqrt(Math.max(0,51**2-len**2/4)),(f[1]+hip[1])/2-dx/len*Math.sqrt(Math.max(0,51**2-len**2/4))];
  line([hip,knee,f],j?'#1e2227':'#3a373a',8);
  g.save();g.translate(f[0],f[1]+8);curve('M -8 -12 Q -13 -4 -10 0 Q 4 4 18 0 Q 23 -6 13 -9 L 2 -13 Z','#342d31',2);g.restore();
 }
 line([[-35,-165],[-56-armSwing*.19,-131],[-48-armSwing*.26,-100]],ink,8);
 oval(-48-armSwing*.26,-99,7,7,'#392e32',2);
 const wrist=look.hand||[56+armSwing*.52,-104];
 if(!look.externalArm)line([[30,-164],look.elbow||[53+armSwing*.15,-134],wrist],ink,8);
 curve('M -30 -182 Q -47 -167 -35 -111 Q -26 -92 17 -97 Q 40 -101 41 -144 Q 40 -177 21 -187 Z',look.shirt||'#386e65',4);
 curve('M -33 -178 Q -38 -160 -33 -136 L -29 -119 Q -23 -130 -20 -170 Z',look.light||'#64968a',0);
 for(let j=0;j<11;j++){const x=-22+j*5;line([[x,-170],[x+3,-109]],look.light||'#55857b',.9);}
 curve('M -18 -181 L 0 -165 L 17 -184 L 24 -178 L 0 -157 L -24 -174 Z','#f7e1bf',2);
 line([[-23,-107],[24,-104]],'#c2976c',4);
 g.save();
 g.translate(0,-173);g.rotate(look.nod||0);g.translate(0,173);
 const gaze=look.gaze||0,attention=look.attention||0,smile=look.smile??.58;
 const skin=g.createLinearGradient(-62,-270,62,-181);skin.addColorStop(0,'#fffdf1');skin.addColorStop(.75,'#fbf0da');skin.addColorStop(1,'#decbd3');
 oval(2,-230,63,58,skin,4);
 curve('M -60 -246 Q -52 -282 -19 -289 Q 16 -299 45 -274 L 64 -254 Q 45 -267 32 -258 L 18 -273 Q 8 -257 -9 -265 L -23 -270 L -43 -246 Z',look.hair||'#28232a',4);
 curve('M -43 -270 Q -8 -294 29 -280 L 31 -275 Q -1 -284 -43 -266 Z',look.hairLight||'#4b3d43',0);
 for(let i=0;i<5;i++){let x=-39+i*13;line([[x,-273+Math.abs(i-2)*3],[x-8,-263+Math.abs(i-2)*4]],look.hairLight||'#594950',1.3);}
 for(const [ex,ey,side] of [[-17,-229,-1],[23,-231,1]]){
  const brow=ey-15-8*attention+(side===1?-2*attention:0);
  line([[ex-10,brow+1],[ex+8,brow-2*side*attention]],ink,4.3);
  const open=(1-blink)*(4.6+6*attention);
  if(open<1.1)line([[ex-8,ey],[ex+8,ey]],ink,2.7);
  else {
   oval(ex,ey,9.4,open+1.5,'#fff9ee',1.9);
   oval(ex+gaze,ey+.6,4.2,Math.max(1.3,open*.69),ink);
   if(open>4)oval(ex+gaze+1.1,ey-1.5,1.1,1.15,'#fffaf0');
  }
 }
 const speaking=look.speaking||0;
 if(speaking>.07){
  oval(8,-202,8+4*speaking,2+8*speaking,'#633a41',2);
  if(speaking>.44)line([[3,-205],[12,-205]],'#f9e5ce',1.45);
 }else if(attention>.53&&smile<.37){
  oval(9,-202,3+4*attention,3.2+4*attention,'#70494a',2);
 }else{
  g.beginPath();g.moveTo(-4,-204);g.quadraticCurveTo(10,-203+15*smile,24,-204-5*smile);
  g.lineCap='round';g.strokeStyle=ink;g.lineWidth=3;g.stroke();
 }
 oval(39,-211,10,4,'#e4a8a4');
 if(look.helmet){
  curve('M -65 -229 Q -65 -285 -25 -300 Q 27 -319 62 -273 L 65 -241 Q 17 -252 -65 -229 Z',look.helmet,4);
  line([[-47,-258],[-22,-270],[6,-275]],'#fff0c3',3);
 }
 if(look.older){
  line([[-30,-204],[-21,-202]],'#a5807a',1.7);line([[27,-204],[36,-201]],'#a5807a',1.7);
  line([[3,-249],[12,-249]],'#b69a8a',1.4);
 }
 g.restore();
 if(look.remote){
  g.save();g.translate(wrist[0],wrist[1]);g.rotate(.28);
  curve('M -8 -23 Q -8 -28 -2 -28 H 11 Q 18 -28 18 -22 V 15 Q 18 20 12 20 H -2 Q -8 20 -8 14 Z','#354450',2.6);
  oval(5,-16,4.4,4.4,look.back?'#994f53':'#dfb073');
  for(let j=0;j<3;j++)oval(5,-4+j*6,2.1,1.7,'#91a8aa');
  g.restore();
 }
 if(!look.externalArm)oval(wrist[0],wrist[1],7,7,'#392e32',2);
}


