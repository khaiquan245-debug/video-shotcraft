import {T,buildWorld as v3world} from '../loi-noi-doi-v3/stage.mjs';
import {addAtmosphere} from '../loi-noi-doi/atmosphere.mjs';
import {bevel as B,tube,lathe,oval,mat} from './materials.mjs';
export {T};

const wood=0xb58b66,olive=0x87927d,brick=0xa98b75,ivory=0xe1d4bb;
const cylinder=(p,x,y,z,r,h,c,f='matte')=>lathe(p,x,y,z,[[0,0],[r,0],[r,h],[0,h]],c,f);
function flat(parent,canvas,x,y,z,w,h){
 const tex=new T.CanvasTexture(canvas);tex.colorSpace=T.SRGBColorSpace;
 const m=new T.Mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:tex}));
 m.position.set(x,y,z);parent.add(m);return m;
}
function paper(kind){
 const c=Object.assign(document.createElement('canvas'),{width:256,height:256}),g=c.getContext('2d');
 g.fillStyle='#e8dfc8';g.fillRect(0,0,256,256);
 if(kind==='calendar'){
  g.fillStyle='#a74538';g.fillRect(0,0,256,58);g.font='bold 27px sans-serif';g.fillStyle='#fff4dd';g.textAlign='center';g.fillText('THÁNG 11',128,39);
  g.fillStyle='#4c3b37';g.font='18px sans-serif';
  for(let i=0;i<30;i++)g.fillText(String(i+1),22+i%7*35,89+Math.floor(i/7)*31);
  g.strokeStyle='#a14435';g.lineWidth=3;g.strokeRect(108,183,32,26);
 }else{
  g.fillStyle='#8ba3a2';g.fillRect(0,0,256,180);g.fillStyle='#8e9c70';g.fillRect(0,172,256,84);
  for(const [x,y,r,color] of [[85,96,32,'#a45254'],[166,92,33,'#4f7d73'],[127,143,24,'#c29252']]){
   g.beginPath();g.ellipse(x,y+55,r*1.13,r*1.39,0,0,7);g.fillStyle=color;g.fill();
   g.beginPath();g.ellipse(x,y,r,r,0,0,7);g.fillStyle='#eaceac';g.fill();
   g.beginPath();g.ellipse(x,y-r*.55,r*.90,r*.48,0,0,7);g.fillStyle='#533d38';g.fill();
   g.fillRect(x-8,y-1,4,5);g.fillRect(x+7,y-1,4,5);
  }
 }
 return c;
}
function dishes(scene,x,y,z,r,color){
 lathe(scene,x,y,z,[[0,0],[r*.65,0],[r*.87,.02],[r,.065],[r-.012,.073],[r*.80,.033],[0,.031]],color,'ceramic',{side:T.DoubleSide});
}
function curtain(scene,x,y,z,right){
 const g=new T.PlaneGeometry(.56,.98,22,16);
 const m=new T.Mesh(g,mat(0xa66b58,'matte',{side:T.DoubleSide}));m.position.set(x,y,z);m.castShadow=true;scene.add(m);
 const pos=g.attributes.position,original=pos.array.slice();
 return t=>{
  for(let i=0;i<pos.count;i++){
   const j=i*3,u=(original[j]+.28)/.56,v=(.49-original[j+1])/.98;
   pos.setXYZ(i,original[j]+right*.035*Math.sin(v*3.14)*Math.sin(t*1.42+u*1.5)*v,original[j+1],Math.sin(u*21)*.028+v*.028*Math.sin(t*1.33+u*4));
  }
  pos.needsUpdate=true;g.computeVertexNormals();
 };
}
function windowView(scene){
 const x=-.43,y=2.02,z=-3.13;
 B(scene,x,y,z,1.74,1.01,.08,0x486875,'matte');
 for(let i=0;i<8;i++){
  const xx=x-.80+i*.223,zz=z+.045+(i%3)*.012,h=.18+(i%4)*.045;
  B(scene,xx,y-.47+h/2,zz,.22,h,.02,[0x6a7d7c,0x768680,0x637981][i%3]);
  const roof=B(scene,xx,y-.47+h,zz+.009,.25,.063,.024,0x5a6465);roof.rotation.z=(i%2?.13:-.12);
  for(let j=0;j<2;j++)B(scene,xx-.05+j*.084,y-.42+h*.42,zz+.019,.032,.049,.011,0xc1a376,'matte',.005,{emissive:0x352910});
 }
 const plant=new T.Group();plant.position.set(x+.48,y-.38,z+.106);scene.add(plant);
 tube(plant,[[0,-.09,0],[.016,.05,0],[.026,.21,.005]],.014,0x526947);
 for(let i=0;i<7;i++)oval(plant,Math.sin(i*3)*.103,.045+i*.025,0,.078,.031,.021,0x607c60).rotation.z=i*.73;
 for(const side of [-1,1]){
  B(scene,x+side*.91,y,z+.091,.09,1.09,.10,0x69523d,'wood');
  B(scene,x,y+side*.53,z+.091,1.86,.075,.105,wood,'wood');
 }
 B(scene,x,y,z+.10,.045,1.03,.078,wood,'wood');
 B(scene,x,y-.06,z+.104,1.72,.046,.078,wood,'wood');
 tube(scene,[[x-.99,y+.63,z+.23],[x,y+.63,z+.23],[x+.99,y+.63,z+.23]],.016,0x624536,'steel');
 const left=curtain(scene,x-.69,y+.089,z+.22,-1),right=curtain(scene,x+.69,y+.089,z+.22,1);
 return t=>{left(t);right(t+.53);plant.rotation.z=.11*Math.sin(t*.93);};
}
function fridge(scene){
 const root=new T.Group();root.position.set(1.50,0,-1.21);scene.add(root);
 const col=0xc0c7be,inside=0xc5cfcc;
 B(root,0,1,-.68,1.11,2,.13,col,'enamel',.068);
 for(const x of [-.52,.52])B(root,x,1,-.298,.094,2,.76,col,'enamel',.051);
 for(const y of [.05,1.98])B(root,0,y,-.31,1.08,.092,.751,col,'enamel',.05);
 for(const y of [.55,.97,1.29]){
  B(root,0,y,-.35,.996,.023,.64,inside,'enamel',.012);
  B(root,0,y+.009,-.024,1.00,.031,.041,0xaababa,'enamel',.012);
 }
 B(root,0,.18,-.35,.94,.235,.57,0xc7dad9,'glass',.04,{transparent:true,opacity:.51});
 B(root,0,.27,-.043,.88,.048,.045,0x98afad,'enamel',.015);
 const door=new T.Group();door.position.set(.54,0,.058);root.add(door);
 B(door,-.54,1.02,.009,1.09,2.038,.112,col,'enamel',.078);
 for(const y of [.095,1.94])B(door,-.54,y,-.055,.97,.032,.027,0x455554,'enamel',.011);
 for(const x of [-.07,-1.01])B(door,x,1.02,-.055,.031,1.85,.027,0x455554,'enamel',.011);
 for(const y of [.35,.78,1.37]){
  B(door,-.55,y,-.13,.87,.043,.147,0xc4d1ce,'enamel',.018);
  B(door,-.55,y+.065,-.21,.87,.137,.037,inside,'glass',.019,{transparent:true,opacity:.64});
 }
 for(const y of [.25,1.80])cylinder(door,.036,y,0,.040,.112,0x727a74,'steel');
 B(door,-.55,1.46,.072,1.00,.018,.015,0x7e8c86,'enamel',.006);
 tube(door,[[-.89,1.01,.083],[-.89,1.05,.15],[-.89,1.15,.178],[-.89,1.25,.15],[-.89,1.29,.083]],.025,0xe0d2b0,'enamel');
 const handle=new T.Object3D();handle.position.set(-.89,1.15,.18);door.add(handle);
 const light=B(root,-.44,1.70,-.37,.026,.126,.24,0xc8dbe0,'enamel',.012,{emissive:0xacc4ce,emissiveIntensity:.45});
 const bulb=new T.PointLight(0xc7e6ff,0,2,2);bulb.position.set(-.30,1.61,-.16);root.add(bulb);
 // Usage marks are restrained and placed on the lower front and near the handle.
 for(let i=0;i<9;i++){
  const scuff=B(door,-.93+(i*31%64)*.010,.13+(i*19%54)*.015,.067,.056+i%3*.020,.007,.006,0xb3b8ac,'enamel',.002);
  scuff.rotation.z=(i-4)*.035;
 }
 return {door,handle,bulb,light};
}
function details(scene,asset){
 const counterY=.925,counterZ=-2.61;
 B(scene,-1.26,.457,counterZ,3.15,.914,.61,olive,'enamel',.033);
 B(scene,-1.26,counterY,counterZ,3.20,.070,.67,wood,'wood',.024);
 for(let i=0;i<6;i++){
  const x=-2.58+i*.53;
  B(scene,x,.46,-2.29,.49,.76,.051,olive,'enamel',.025);
  B(scene,x,.68,-2.251,.152,.023,.045,0xa89264,'steel',.010);
 }
 asset(scene,'kitchenSink',-2.91,0,-2.61);
 for(let i=0;i<3;i++){
  const x=-2.60+i*.54;
  B(scene,x,2.03,-2.86,.49,.58,.34,olive,'enamel',.025);
  B(scene,x+.145,1.89,-2.666,.02,.146,.036,0xaa956a,'steel',.008);
 }
 // Two-burner gas stove and covered pot.
 B(scene,-1.80,.993,counterZ,.70,.103,.43,0x57605a,'steel',.041);
 for(const x of [-1.99,-1.63]){
  cylinder(scene,x,1.05,counterZ,.118,.021,0x323e3e,'steel');
  cylinder(scene,x,1.071,counterZ,.072,.026,0x6a7171,'steel');
  B(scene,x,.999,counterZ+.225,.045,.047,.05,0x2d3737,'matte',.013);
 }
 lathe(scene,-1.97,1.07,counterZ,[[0,0],[.111,0],[.151,.038],[.154,.175],[.149,.187],[.141,.18]],0xb0b5a9,'steel');
 lathe(scene,-1.97,1.25,counterZ,[[0,.045],[.052,.04],[.127,.016],[.157,0]],0xa3aba6,'steel');
 oval(scene,-1.97,1.302,counterZ,.032,.019,.032,0x56463c);
 for(const dx of [-.18,.18])B(scene,-1.97+dx,1.205,counterZ,.091,.03,.052,0x4e4137,'matte',.013);
 // Rice cooker with lid, hinge, button and panel.
 lathe(scene,-1.03,.961,counterZ,[[0,0],[.15,0],[.185,.041],[.193,.145],[.178,.221],[.157,.245],[0,.252]],0xc7c3a9,'enamel');
 lathe(scene,-1.03,1.186,counterZ,[[.173,0],[.169,.019],[.134,.048],[0,.057]],0x879887,'enamel');
 B(scene,-1.03,1.16,counterZ+.172,.12,.102,.035,0x779186,'enamel',.018);
 oval(scene,-1.03,1.16,counterZ+.192,.016,.016,.011,0x94795d,'enamel',{emissive:0x362013});
 tube(scene,[[-1.13,1.23,counterZ],[-1.10,1.29,counterZ],[-.96,1.29,counterZ],[-.93,1.23,counterZ]],.016,0x69766a,'enamel');
 for(let i=0;i<5;i++){
  const x=-.60+i*.141,r=.037+i%2*.007,h=.13+i%3*.028,color=[0x8c643a,0xc3a06c,0xa55f3e,0x7f9063,0xb49366][i];
  lathe(scene,x,.967,counterZ-.05,[[0,0],[r,0],[r,h-.031],[r*.55,h-.012],[r*.52,h]],color,'glass');
  cylinder(scene,x,.967+h,counterZ-.05,r*.62,.024,0x624c37,'enamel');
  B(scene,x,1.022,counterZ-.05+r,.056,.044,.008,0xd2bb90,'matte',.003);
 }
 dishes(scene,-.34,.977,counterZ+.14,.11,0xc7ccb0);
 dishes(scene,-.34,1.009,counterZ+.14,.098,0xd8c5aa);
 // Wall clock and electrical fittings.
 const clock=new T.Group();clock.position.set(.82,2.31,-3.02);scene.add(clock);
 const face=cylinder(clock,0,0,0,.173,.027,0x58473a,'wood');face.rotation.x=Math.PI/2;
 const paper=cylinder(clock,0,0,.026,.15,.006,ivory,'ceramic');paper.rotation.x=Math.PI/2;
 for(let i=0;i<12;i++){
  const a=i*Math.PI/6;
  const tick=B(clock,Math.sin(a)*.126,Math.cos(a)*.126,.04,.010,.021,.007,0x5e4c40);tick.rotation.z=-a;
 }
 const hand=new T.Group();hand.position.set(0,0,.043);clock.add(hand);B(hand,0,.045,0,.006,.098,.006,0xa25245);
 const minute=B(clock,-.032,.035,.043,.011,.084,.009,0x62524a);minute.rotation.z=.78;
 for(const [x,y] of [[.78,1.39],[1.13,.96]]){
  B(scene,x,y,-3.006,.126,.098,.025,0xd4c5a8,'enamel',.013);
  B(scene,x,y,-2.987,.045,.051,.009,0xaaa68a,'enamel',.005);
 }
 asset(scene,'pottedPlant',.61,0,-2.53);
 // Damp cloth lies over the cabinet handle.
 const cloth=B(scene,-2.37,.58,-2.23,.202,.247,.021,0x8d6d65,'matte',.018);cloth.rotation.z=-.087;
 for(let i=0;i<5;i++)B(scene,-2.445+i*.033,.575,-2.214,.010,.222,.004,0xa58275,'matte',.001);
 return t=>{hand.rotation.z=-t*.105;};
}
function table(scene,asset){
 const x=-.66,z=-.70;
 B(scene,x,.75,z,1.75,.082,.81,wood,'wood',.041);
 B(scene,x,.68,z,1.55,.105,.65,0x886343,'wood',.028);
 for(const dx of [-.73,.73])for(const dz of [-.28,.28]){
  const leg=B(scene,x+dx,.33,z+dz,.084,.66,.084,0x927050,'wood',.016);
  leg.rotation.z=dx*.039;
 }
 const chairs=[asset(scene,'chair_B_wood',-1.26,0,-1.20),asset(scene,'chair_B_wood',.02,0,-1.18)];
 for(const chair of chairs)chair.traverse(m=>{
  if(m.isMesh){m.material=m.material.clone();m.material.color.multiply(new T.Color(0xc9ab86));m.material.roughness=.72;}
 });
 dishes(scene,x,.80,z,.222,0xd3cbaf);
 dishes(scene,-1.11,.796,z-.039,.095,0xc0c8ac);dishes(scene,-.17,.796,z-.039,.097,0xc4baa2);
 for(let i=0;i<10;i++)oval(scene,x-.14+(i%5)*.067,.857,z-.07+Math.floor(i/5)*.114,.032,.014,.025,i%3===0?0x728153:0x886446);
 for(const edge of [-1.05,-.11])for(const shift of [0,.023])B(scene,edge+shift,.802,z+.147,.008,.009,.241,0x806244,'wood',.003);
 const basketX=-2.38,basketZ=-.87;
 lathe(scene,basketX,.755,basketZ,[[0,0],[.124,.01],[.153,.039],[.20,.111],[.211,.124],[.196,.124],[.148,.057],[0,.034]],0xa18755,'wood');
 for(let i=0;i<12;i++){
  const a=i*2.399;
  oval(scene,basketX+Math.cos(a)*.126,.905+(i%4)*.011,basketZ+Math.sin(a)*.113,.096,.025,.046,[0x557859,0x6d875a,0x879558][i%3]).rotation.y=a;
 }
 B(scene,-2.39,.706,basketZ,.56,.07,.45,wood,'wood',.032);
 for(const dx of [-.18,.18])for(const dz of [-.14,.14])B(scene,-2.39+dx,.34,basketZ+dz,.052,.69,.052,0x806147,'wood',.011);
}
function occlusion(scene){
 const c=document.createElement('canvas');c.width=c.height=96;
 const ctx=c.getContext('2d'),shade=ctx.createRadialGradient(48,48,8,48,48,48);
 shade.addColorStop(0,'rgba(36,27,24,.38)');shade.addColorStop(.57,'rgba(36,27,24,.20)');shade.addColorStop(1,'rgba(36,27,24,0)');
 ctx.fillStyle=shade;ctx.fillRect(0,0,96,96);
 const material=new T.MeshBasicMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false,toneMapped:false});
 for(const [x,z,w,d] of [[-.65,-.71,2.03,1.04],[1.45,-1.47,1.42,1.22],[-1.24,-2.61,3.70,1.1],[-2.42,1.8,.9,.66]]){
  const layer=new T.Mesh(new T.PlaneGeometry(w,d),material);
  layer.rotation.x=-Math.PI/2;layer.position.set(x,.006,z);scene.add(layer);
 }
}
function makeKitchen(asset){
 const scene=new T.Scene();scene.background=new T.Color(0x4b646c);
 for(let i=0;i<18;i++)B(scene,(i-8.5)*.51,-.061,-.11,.504,.12,11,[0x9e805e,0xa88765,0xa78b6d][i%3],'wood',.005);
 B(scene,0,1.57,-3.23,8.65,3.16,.15,0xc4b798,'plaster',.016);
 B(scene,-3.49,1.56,-.65,.14,3.14,5.1,0xb9aa8d,'plaster',.016);
 B(scene,3.81,1.56,-.65,.14,3.14,5.1,0xb9aa8d,'plaster',.016);
 B(scene,0,3.13,1.14,8.65,.14,8.72,0xbdb196,'plaster',.018);
 // Reverse wall completes the room for the camera looking out from the refrigerator.
 B(scene,0,1.57,5.48,8.65,3.16,.14,0xb2a58b,'plaster',.021);
 B(scene,0,.072,5.39,8.44,.14,.056,0x927253,'wood',.012);
 B(scene,-1.06,1.05,5.37,1.21,2.10,.095,0x7f624c,'wood',.047);
 B(scene,-1.06,1.04,5.31,1.00,1.99,.045,0x9a805e,'wood',.029);
 for(const [y,h] of [[.57,.55],[1.43,.79]]){
  B(scene,-1.06,y,5.283,.78,h,.035,0x846e54,'wood',.025);
  B(scene,-1.06,y,5.258,.71,h-.075,.029,0xa68a67,'wood',.024);
 }
 oval(scene,-.70,1.03,5.21,.039,.039,.044,0xa99870,'steel');
 for(let j=0;j<4;j++){
  const x=.31+j*.20;
  B(scene,x,1.92,5.34,.034,.13,.087,0x8f7c61,'steel',.013);
 }
 B(scene,.59,1.66,5.29,.24,.41,.049,0x8e6762,'matte',.033);
 for(let j=0;j<5;j++)B(scene,.48+j*.048,1.66,5.262,.009,.362,.009,0xa68878,'matte',.002);
 const spill=new T.PointLight(0xffdca5,16,5,2);
 spill.position.set(-.81,2.49,4.98);scene.add(spill);
 B(scene,0,.074,-3.139,8.36,.13,.057,wood,'wood',.013);
 for(let i=0;i<31;i++)for(let j=0;j<4;j++){
  if(i<23)B(scene,-2.94+i*.141,1.01+j*.133,-3.141,.134,.125,.022,(i+j)%3?0xc4c7ac:0xb1b39e,'enamel',.005);
 }
 B(scene,-2.36,1.30,1.83,.68,.08,.42,wood,'wood',.031);
 for(const x of [-2.65,-2.08])B(scene,x,.64,1.88,.048,1.30,.054,0x86684b,'wood',.012);
 for(const y of [.37,.82])B(scene,-2.36,y,1.83,.68,.067,.42,wood,'wood',.031);
 asset(scene,'pottedPlant',-2.31,1.344,1.83);
 dishes(scene,-2.42,.86,1.86,.116,0xc5afa0);
 const window=windowView(scene),clock=details(scene,asset);
 table(scene,asset);
 B(scene,1.34,2.27,-3.121,.335,.304,.054,0x71533e,'wood',.019);
 flat(scene,paper('photo'),1.34,2.27,-3.087,.286,.257);
 B(scene,-1.51,1.74,-3.12,.26,.30,.016,0x6c614d);
 flat(scene,paper('calendar'),-1.51,1.74,-3.105,.241,.281);
 const layout=fridge(scene);
 occlusion(scene);
 // A downward-facing practical keeps light off the ceiling.
 tube(scene,[[-.65,3.06,-.68],[-.65,2.75,-.68]],.012,0x443a33);
 lathe(scene,-.65,2.51,-.68,[[.255,0],[.247,.037],[.148,.225],[.071,.272],[.054,.272]],0x937a56,'enamel');
 cylinder(scene,-.65,2.523,-.68,.201,.012,0xe0c69e,'enamel').material.emissive.setHex(0x9b6c31);
 const key=new T.SpotLight(0xffdbac,75,8,Math.PI/4.5,.62,2);
 key.position.set(-.65,2.499,-.68);key.target.position.set(-.66,.76,-.63);key.castShadow=true;
 key.shadow.mapSize.set(768,768);key.shadow.bias=-.00035;key.shadow.normalBias=.013;key.shadow.radius=3;
 scene.add(key,key.target,new T.HemisphereLight(0xc3d7e3,0x947961,1.08));
 const windowLight=new T.DirectionalLight(0xb9ddf3,1.15);windowLight.position.set(.73,2.02,-3.02);windowLight.target.position.set(-.7,.9,-.3);scene.add(windowLight,windowLight.target);
 const bounce=new T.DirectionalLight(0xeac59c,.38);bounce.position.set(-2.4,1.02,2.25);scene.add(bounce);
 const ambient=new T.DirectionalLight(0xf3d7b0,.86);ambient.position.set(-2.1,2.3,3.1);scene.add(ambient);
 const drift=addAtmosphere(scene,false);
 return {scene,layout,drift(t){window(t);clock(t);drift(t);}};
}
export function buildWorld(name,asset){return name==='kitchen'?makeKitchen(asset):v3world(name,asset);}
