import {T} from '../loi-noi-doi/world.mjs';
import {drawCharacter} from '../life-remote/character.mjs';
const roles={
 hero:{shirt:'#386e65',light:'#64968a',hair:'#28232a',height:1.70},
 mother:{shirt:'#965956',light:'#c18577',hair:'#544851',hairLight:'#9a8990',older:true,height:1.54},
 friend:{shirt:'#826596',light:'#ab96b5',hair:'#412b25',height:1.70},
 guest:{shirt:'#b95965',light:'#d58180',hair:'#793c34',height:1.60},
 passer:{shirt:'#ae754b',light:'#c99466',hair:'#503b37',height:1.73},
 other:{shirt:'#67838e',light:'#93aab2',hair:'#3b2e30',height:1.58},
};
const cv=(w,h)=>Object.assign(document.createElement('canvas'),{width:w,height:h});
const shadow=cv(64,64),sg=shadow.getContext('2d');
const fade=sg.createRadialGradient(32,32,6,32,32,31);
fade.addColorStop(0,'rgba(34,22,24,.44)');fade.addColorStop(1,'rgba(34,22,24,0)');
sg.fillStyle=fade;sg.fillRect(0,0,64,64);
const shadowMap=new T.CanvasTexture(shadow);
const plane=new T.PlaneGeometry(1,1),clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function item(g,x,y,id,lit){
 g.save();g.translate(x,y);g.rotate(.20);
 const r=(x,y,w,h,c)=>{g.beginPath();g.roundRect(x,y,w,h,4);g.fillStyle=c;g.fill();g.lineWidth=2;g.strokeStyle='#252731';g.stroke()};
 if(id==='phone'){
  r(-7,-25,24,40,'#3d4957');r(-4,-21,18,30,lit?'#d0f4af':'#8cabae');
  g.fillStyle='#496e70';g.fillRect(0,-16,9,2);g.fillRect(0,-10,11,2);
 }
 if(id==='wallet'){r(-12,-20,36,24,'#80604e');r(-9,-17,30,13,'#593d36');}
 if(id==='mic'){r(1,-24,10,31,'#3c444d');r(-4,-30,20,15,'#5b6470');}
 g.restore();
}
export function createActor(scene,name){
 const role=roles[name],canvas=cv(224,328),ctx=canvas.getContext('2d'),texture=new T.CanvasTexture(canvas);
 texture.colorSpace=T.SRGBColorSpace;texture.generateMipmaps=false;texture.minFilter=T.LinearFilter;
 const mesh=new T.Mesh(plane,new T.MeshBasicMaterial({map:texture,alphaTest:.22,side:T.DoubleSide,toneMapped:false}));
 const person=new T.Group();person.add(mesh);scene.add(person);
 const sm=new T.Mesh(plane,new T.MeshBasicMaterial({map:shadowMap,transparent:true,depthWrite:false,toneMapped:false}));
 sm.rotation.x=-Math.PI/2;sm.position.y=.012;sm.scale.set(.58,.35,1);person.add(sm);
 const unit=role.height/290;
 mesh.scale.set(canvas.width*unit,canvas.height*unit,1);mesh.position.y=(canvas.height/2-12)*unit;
 return {person,pose({t,x,z,camera,walk=0,seat=0,handWorld,reach=0,speaking=0,look=0,yaw,prop,lit=false,mood=.5,nod=0,back=0}){
  person.position.set(x,0,z);
  const view=Math.atan2(camera.position.x-x,camera.position.z-z);
  mesh.rotation.y=yaw??(Math.abs(view)>1.42?view:clamp(view,-.57,.57));
  const motion=walk*22,phase=t*9.7,forward=walk<0?-1:1,stride=Math.sin(phase)*motion;
  const hand=[56+reach*15,-102-reach*69];
  if(handWorld){
   const dx=handWorld.x-x,dz=handWorld.z-z;
   hand[0]=clamp((dx*Math.cos(mesh.rotation.y)-dz*Math.sin(mesh.rotation.y))/unit,37,89);
   hand[1]=clamp(-handWorld.y/unit-seat*58,-187,-76);
  }
  const gaze=clamp(look,-5,5),attention=clamp(1-mood,0,1);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.save();ctx.translate(109,316+seat*58);
  if(name==='mother'){
   ctx.beginPath();ctx.ellipse(-39,-265,27,23,0,0,Math.PI*2);
   ctx.fillStyle='#51424c';ctx.fill();ctx.strokeStyle='#28242c';ctx.lineWidth=3;ctx.stroke();
  }
  const foot=(side)=>[side*20+stride*side+seat*27,-8-seat*58-Math.max(0,Math.cos(phase)*side*forward)*Math.abs(walk)*14];
  drawCharacter(ctx,'neutral',[foot(-1),foot(1)],Math.cos(phase)*motion,
   Math.max(0,1-Math.abs((t%3.71)-1.85)/.09),{
    ...role,hand,elbow:[Math.min(hand[0]+9,68),Math.min(-126,hand[1]+20)],
    speaking,smile:mood,attention,nod,gaze,seated:seat>.55
   });
  if(back>0){
   ctx.save();ctx.globalAlpha=back;
   ctx.beginPath();ctx.ellipse(2,-230,63,59,0,0,Math.PI*2);
   ctx.fillStyle=role.hair;ctx.fill();ctx.strokeStyle='#222529';ctx.lineWidth=4;ctx.stroke();
   ctx.beginPath();ctx.moveTo(-48,-250);ctx.quadraticCurveTo(-11,-285,37,-271);
   ctx.strokeStyle='#54474a';ctx.lineWidth=4;ctx.stroke();ctx.restore();
  }
  if(prop)item(ctx,...hand,prop,lit);
  if(name==='mother'){
   ctx.beginPath();ctx.moveTo(-20,-151);ctx.quadraticCurveTo(0,-142,23,-151);
   ctx.lineTo(25,-110);ctx.quadraticCurveTo(0,-101,-24,-109);ctx.closePath();
   ctx.fillStyle='#ddad86';ctx.fill();ctx.strokeStyle='#753f42';ctx.lineWidth=2;ctx.stroke();
  }
  ctx.restore();texture.needsUpdate=true;
 }};
}
