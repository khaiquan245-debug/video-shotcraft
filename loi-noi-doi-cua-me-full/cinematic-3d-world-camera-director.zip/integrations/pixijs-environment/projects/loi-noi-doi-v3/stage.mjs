import {world as v2world,T} from '../loi-noi-doi/world.mjs';
export {T};
import {addAtmosphere} from '../loi-noi-doi/atmosphere.mjs';

export const lightProfiles={
 room:[0xffe5c6,0xb5d1e4,1.69,.76],
 cafe:[0xffdfb3,0xbbd6e2,1.75,.66],
 road:[0xffebcd,0xbddeff,2.09,.88],
 exterior:[0xffe4bc,0xa7d5ff,2.36,.92],
 villa:[0xffd297,0x9dc4de,1.55,.60],
 village:[0xffb47b,0x809acf,1.23,.58],
 kitchen:[0xffd9a3,0xa6c5dc,1.48,.69],
};
export function material(color,options={}){
 return new T.MeshStandardMaterial({color,roughness:.78,...options});
}
const geometry=new T.BoxGeometry(1,1,1);
function box(parent,x,y,z,w,h,d,color,options={}){
 const mesh=new T.Mesh(geometry,material(color,options));mesh.position.set(x,y,z);mesh.scale.set(w,h,d);
 mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;
}
function cylinder(parent,x,y,z,top,bottom,h,color){
 const mesh=new T.Mesh(new T.CylinderGeometry(top,bottom,h,24),material(color));
 mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh;
}
function orb(parent,x,y,z,a,b,c,color){
 const mesh=new T.Mesh(new T.SphereGeometry(1,14,9),material(color));mesh.position.set(x,y,z);mesh.scale.set(a,b,c);
 mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;
}
function surface(scene,x,y,z,width,depth,color){
 box(scene,x,y,z,width,.076,depth,color);
 for(const dx of [-.41,.41])for(const dz of [-.39,.39])box(scene,x+width*dx,y/2,z+depth*dz,.065,y,.068,0x614336);
}
function lighting(scene,name){
 const [keyColor,bounce,power,fill]=lightProfiles[name];
 const original=scene.children.filter(o=>o.isLight);
 for(const light of original)scene.remove(light);
 const key=new T.DirectionalLight(keyColor,power);
 key.position.set(-3.3,5.3,3.45);key.castShadow=true;
 key.shadow.mapSize.set(512,512);key.shadow.radius=3;
 key.shadow.normalBias=.032;key.shadow.bias=-.00025;
 key.shadow.camera.left=-6;key.shadow.camera.right=6;key.shadow.camera.top=6;key.shadow.camera.bottom=-6;
 scene.add(key,key.target,new T.HemisphereLight(bounce,0xa48c76,fill));
 const rim=new T.DirectionalLight(bounce,.33);rim.position.set(2.4,3.1,-2.8);scene.add(rim);
 if(['kitchen','cafe','villa'].includes(name)){
  const local=new T.PointLight(keyColor,6.5,7,2);
  local.position.set(-.46,2.66,-.34);scene.add(local);
 }
 return key;
}
function pendant(scene,x,z){
 cylinder(scene,x,2.86,z,.012,.012,.55,0x4d3a32);
 cylinder(scene,x,2.58,z,.104,.23,.20,0xb58451);
 cylinder(scene,x,2.476,z,.10,.10,.018,0xffe8b1).material.emissive.setHex(0xf3b868);
}
function floorboards(scene,w,d){
 for(let i=0;i<22;i++){
  const x=(i-10.5)*w/22;
  box(scene,x,-.036,-.40,w/22-.006,.072,d,[0x8f7257,0xa18261,0xa98b65,0x9d7f60][i%4]);
 }
}
function casement(scene,x,y,z,w,h){
 box(scene,x,y,z,w+.10,h+.12,.12,0x695042);
 box(scene,x,y,z+.065,w,h,.038,0x3e5668);
 for(let i=0;i<5;i++){
  const sx=x-w*.45+i*w*.19;
  box(scene,sx,y-h*.30,z+.09,w*.13,h*(.16+(i%3)*.07),.009,0x73828b);
 }
 box(scene,x,y,z+.095,.035,h,.055,0x8e7461);box(scene,x,y+.05,z+.095,w,.037,.055,0x8e7461);
 box(scene,x,y-h*.53,z+.105,w+.16,.075,.23,0xb0926c);
}
function home(scene,asset){
 scene.background=new T.Color(0x4e6673);floorboards(scene,9,11);
 box(scene,0,1.58,-3.15,8.3,3.2,.19,0xbca88b);
 box(scene,-3.47,1.55,-.7,.13,3.1,5,0xb1a18b);
 box(scene,0,3.14,-.7,8.2,.11,5,0xc6b497);
 casement(scene,-.35,2.03,-3.04,1.42,1.02);
 for(let i=0;i<31;i++)for(let j=0;j<4;j++)box(scene,-2.86+i*.138,1.0+j*.126,-3.014,.131,.119,.027,(i+j)%3?0xc7c9ae:0xb3b59b);
 const west=-2.19;
 asset(scene,'kitchenSink',west,0,-2.59);
 asset(scene,'kitchenStove',west+.62,0,-2.59);
 box(scene,-.49,.46,-2.6,1.12,.91,.60,0x82765c);
 box(scene,-.49,.93,-2.6,1.16,.055,.63,0xbb9a6a);
 asset(scene,'kitchenMicrowave',-.45,.962,-2.58);
 for(const x of [-2.20,-1.50])asset(scene,'kitchenCabinetUpper',x,1.76,-2.79);
 const table={x:-.66,z:-.70};
 surface(scene,table.x,.745,table.z,1.73,.79,0x9c6944);
 asset(scene,'chair_B_wood',-1.26,0,-1.23);
 asset(scene,'chairCushion',.02,0,-1.19);
 const bowl=cylinder(scene,-.65,.804,-.71,.237,.165,.083,0xe6d5b3);
 bowl.material.roughness=.35;
 cylinder(scene,-.65,.850,-.71,.197,.157,.022,0xd6ae70);
 for(let i=0;i<10;i++)orb(scene,-.79+i%5*.065,.875,-.78+Math.floor(i/5)*.127,.033,.012,.024,i%3===0?0x758857:0x825840);
 for(const x of [-1.11,-.19]){
  cylinder(scene,x,.797,-.70,.095,.072,.033,0xc5b7a7);
  box(scene,x+.113,.791,-.71,.012,.012,.23,0x795340);
 }
 asset(scene,'pottedPlant',-2.40,0,2.30);
 box(scene,-2.42,.42,1.85,.62,.83,.32,0x84684c);
 for(const y of [.20,.56,.80])box(scene,-2.42,y,1.85,.64,.042,.46,0x997654);
 pendant(scene,-.64,-.70);
 const x=1.50,z=-1.21;
 const fridge=new T.Group();fridge.position.set(x,0,z);scene.add(fridge);
 box(fridge,0,1.02,-.67,1.08,2.04,.094,0x889d9e,{metalness:.18});
 for(const dx of [-.53,.53])box(fridge,dx,1.02,-.31,.075,2.04,.75,0x9badae,{metalness:.15});
 for(const y of [.07,.51,.99,1.34,1.92,2.00])box(fridge,0,y,-.31,1.07,.046,.74,0xc1ccca,{roughness:.49});
 const door=new T.Group();door.position.set(.54,0,.058);fridge.add(door);
 box(door,-.54,1.02,0,1.09,2.04,.085,0x9db1b4,{metalness:.21,roughness:.40});
 box(door,-.55,1.32,.046,1.0,.017,.014,0x5b777a);
 box(door,-.89,1.16,.112,.051,.24,.092,0xe8d9b7);
 const handle=new T.Object3D();handle.position.set(-.89,1.15,.165);door.add(handle);
 const bulb=new T.PointLight(0xc8e8f6,1.04,2.1,2);bulb.position.set(-.25,1.78,-.12);fridge.add(bulb);
 return {door,handle,bulb,table};
}
function cafe(scene,asset){
 scene.background=new T.Color(0x8eaaa5);floorboards(scene,10,14);
 box(scene,0,1.62,-3.46,9,3.3,.21,0xc3a78c);
 box(scene,-3.35,1.62,-1.5,.18,3.25,4,0xbaa28c);
 box(scene,0,3.24,-1.4,9,.1,5,0xc4b098);
 casement(scene,.19,1.91,-3.33,2.87,1.47);
 surface(scene,.14,.73,-.64,1.51,.71,0x94684e);
 asset(scene,'chair_B_wood',-.64,0,-1.13);
 asset(scene,'chairCushion',.68,0,-1.11);
 surface(scene,2.08,.93,-2.23,1.33,.62,0x8d6349);
 asset(scene,'kitchenCoffeeMachine',2.06,.976,-2.20);
 asset(scene,'pottedPlant',-1.99,0,-1.61);
 for(const x of [-.33,.52]){
  cylinder(scene,x,.784,-.50,.099,.094,.032,0xd8b698);
  cylinder(scene,x,.84,-.50,.065,.047,.115,0x62847f);
 }
 pendant(scene,.21,-.45);pendant(scene,1.54,-2);
}
function village(scene,asset){
 scene.background=new T.Color(0x738393);
 scene.fog=new T.Fog(0x7b8898,13,27);
 box(scene,0,-.09,-4,26,.18,26,0x7a8265);
 box(scene,-.3,.012,-.9,4.4,.032,8.0,0x978270);
 box(scene,-.12,1.42,-3.93,4.75,2.65,1.58,0xc1a680);
 for(const side of [-1,1]){
  const beam=box(scene,-.12+1.27*side,2.91,-3.94,2.82,.14,2.09,0x685855);
  beam.rotation.z=-side*.31;
 }
 box(scene,.32,.91,-3.09,.96,1.75,.11,0x7d664f);
 box(scene,.32,.91,-3.02,.72,1.58,.04,0xbe935f,{emissive:0x362015});
 casement(scene,-1.12,1.49,-3.07,1.04,.84);
 const warm=box(scene,-1.13,1.49,-2.97,.84,.65,.02,0xe1ab59,{emissive:0x7c4f23});
 warm.material.emissiveIntensity=.58;
 const porch=new T.PointLight(0xffba75,19,5,2);porch.position.set(.38,1.96,-2.77);scene.add(porch);
 for(let i=0;i<8;i++)asset(scene,'pottedPlant',-2.42+i*.72,0,-2.37+(i%3)*.06);
 for(let i=0;i<6;i++){
  const x=-8.5+i*3.05,z=-8-(i%3)*2;
  cylinder(scene,x,1.1,z,.11,.18,2.2,0x645b4d);orb(scene,x,2.5,z,.84,1.06,.73,0x54684c);
 }
}
export function buildWorld(name,asset){
 const custom=['cafe','kitchen','village'].includes(name);
 const scene=custom?new T.Scene():v2world(name);
 const layout=name==='kitchen'?home(scene,asset):{};
 if(name==='cafe')cafe(scene,asset);
 if(name==='village')village(scene,asset);
 if(name==='room')asset(scene,'televisionVintage',1.16,.78,-2.62);
 if(name==='villa')for(const x of [-1.45,1.65])asset(scene,'pottedPlant',x,0,-1.98);
 const key=lighting(scene,name);
 const drift=addAtmosphere(scene,['road','exterior','village'].includes(name));
 return {scene,layout,key,drift};
}
