import {T,buildWorld} from './stage.mjs';
import {createLibrary} from './assets.mjs';
import {createCameraDirector,smooth} from './camera.mjs';
import {createActor} from './actors.mjs';
import {kitchenMark,updateDoor} from './interaction.mjs';
import {EffectComposer,RenderPass,EffectPass,BloomEffect,DepthOfFieldEffect,ToneMappingEffect,ToneMappingMode}
 from '../../../world-camera-v3/node_modules/postprocessing/build/index.js';

const params=new URLSearchParams(location.search),demo=params.has('demo');
const width=Number(params.get('w')||1080),height=Number(params.get('h')||Math.round(width*16/9));
const renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});
renderer.setSize(width,height);renderer.outputColorSpace=T.SRGBColorSpace;
renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.20;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFShadowMap;renderer.shadowMap.autoUpdate=false;
const camera=new T.PerspectiveCamera(46,width/height,.09,70);
const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;document.body.appendChild(canvas);
const ctx=canvas.getContext('2d');
const [film,place]=await Promise.all([fetch('/loi-noi-doi-v3.json').then(r=>r.json()),createLibrary()]);
const director=createCameraDirector(demo?film.demo:film.shots),worlds=new Map();
const worldRoles={room:['hero'],cafe:['hero','friend'],road:['hero','passer','other','friend'],
 exterior:['hero'],villa:['hero','friend','guest','other'],village:['hero'],kitchen:['hero','mother']};
let previous=null,post=null;
function makePost(scene){
 const composer=new EffectComposer(renderer,{frameBufferType:T.HalfFloatType});
 const renderPass=new RenderPass(scene,camera);composer.addPass(renderPass);
 const dof=new DepthOfFieldEffect(camera,{focusDistance:2,focusRange:1.2,bokehScale:1.8,resolutionScale:.42});
 const bloom=new BloomEffect({luminanceThreshold:1.1,luminanceSmoothing:.21,intensity:.16,mipmapBlur:true,levels:3});
 composer.addPass(new EffectPass(camera,dof));
 composer.addPass(new EffectPass(camera,bloom,new ToneMappingEffect({mode:ToneMappingMode.ACES_FILMIC})));
 return {composer,renderPass,dof};
}
function environment(name){
 if(!worlds.has(name)){
  const world=buildWorld(name,place);
  world.actors=Object.fromEntries(worldRoles[name].map(role=>[role,createActor(world.scene,role)]));
  worlds.set(name,world);
 }
 return worlds.get(name);
}
function pose(world,name,t,fields){
 world.actors[name].pose({t,camera,...fields});
}
const talk=t=>Math.abs(Math.sin(t*17))*.64;
const mix=T.MathUtils.lerp;
function text(label,x,y,size,color='#fff3e2'){
 ctx.font='900 '+size+'px system-ui';ctx.textAlign='center';ctx.textBaseline='middle';
 while(ctx.measureText(label).width>632)ctx.font='900 '+(--size)+'px system-ui';
 ctx.lineWidth=5;ctx.strokeStyle='#212a31';ctx.lineJoin='round';ctx.strokeText(label,x,y);
 ctx.fillStyle=color;ctx.fillText(label,x,y);
}
function panel(x,y,w,h,color){
 ctx.beginPath();ctx.roundRect(x,y,w,h,19);ctx.fillStyle=color;ctx.fill();
}
function setTime(seconds){
 const frame=Math.min((demo?450:film.frames)-1,Math.max(0,Math.round(seconds*30)));
 const t=frame/30,{shot,u,focus}=director.sample(frame,camera),id=shot.id;
 const name=shot.environment,world=environment(name);
 const event=demo?null:film.events.findLast(e=>e.time<=t);
 const ago=event?t-event.time:99,lit=ago<.83;
 const hero=(fields={})=>pose(world,'hero',t,{x:-.27,z:.09,lit,mood:id>=8?.24:.66,...fields});
 world.drift(t);
 if(name==='room')hero({x:-.08,reach:.59,prop:'phone',look:3,mood:.52,lit:id===0&&u>.68});
 if(name==='cafe'){
  const reveal=id===2?smooth(u/.4):id===3?1-smooth(u):0;
  pose(world,'friend',t,{x:.57,z:-.57,seat:.77,look:-5,prop:'wallet',reach:.22+reveal*.61,speaking:id===2?talk(t):0,mood:.48});
  hero({x:-.37,z:.13,look:4,prop:'phone',reach:id===3?u*.57:.21,speaking:id===1?talk(t):0});
 }
 if(name==='road'){
  const p=id===5?smooth(u):1;
  const x=mix(-.98,.76,p);
  if(world.scene.userData.bus)world.scene.userData.bus.position.x=-7+(t-9.68)*2.45;
  pose(world,'passer',t,{x:-1.44,z:-.62,look:4,speaking:id===5&&u<.45?talk(t):0,mood:.56});
  pose(world,'other',t,{x:1.25,z:-.39,look:-5,speaking:id===5&&u>.58?talk(t):0,mood:.55});
  pose(world,'friend',t,{x:mix(1.35,-2.55,(t-9.68)/5),z:-1.63,walk:.85,mood:.63});
  hero({x,z:.12,walk:id===5?Math.sin(u*Math.PI):0,reach:id===5?.7:.47,prop:id===5?'mic':'phone',look:5});
 }
 if(name==='exterior')hero({x:-.98,z:.20,look:4,prop:'phone',mood:.74,reach:.24});
 if(name==='villa'){
  pose(world,'friend',t,{x:-.94+.14*Math.sin(t*.51),z:-.41,look:5,speaking:[9,12].includes(id)?talk(t):0,mood:.62,reach:id===9?.32:.08});
  pose(world,'guest',t,{x:.78,z:-.32,look:-4,speaking:[10,12].includes(id)?talk(t+.2):0,mood:.69,reach:id===10?.28:.05});
  pose(world,'other',t,{x:mix(1.08,.75,smooth((t-22)/3)),z:.85,look:-5,walk:Math.sin(Math.PI*smooth((t-22)/3))*.47,mood:.59});
  hero({x:-.12,z:.24,prop:'phone',reach:id===13?.25+.36*smooth(u):.14,speaking:id===11?talk(t):0,look:id===9?-4:4});
 }
 if(name==='village')hero({x:mix(-1.37,.19,smooth(u)),z:mix(.37,-1.99,smooth(u)),walk:Math.sin(Math.PI*u),mood:.24,look:4});
 if(name==='kitchen'){
  const mark=kitchenMark(id,u,demo),doorHandle=updateDoor(world.layout,mark);
  const settle=id>=22?smooth(u/.52):0;
  pose(world,'mother',t,{x:mix(-1.29,-1.20,settle),z:mix(-.93,-1.13,settle),seat:id>=22?settle:0,look:3,mood:.64,
   nod:id===17?Math.sin(u*10)*.14:.04*Math.sin(t*3),speaking:id===19?talk(t):0,reach:id>=22?.28:id===15?.31:0});
  const shoulder=id===16?Math.sin(Math.PI*u):0;
  hero({...mark,x:mark.x+.38*shoulder,z:mark.z+.78*shoulder,back:smooth(shoulder*1.4),prop:id===18||id===19?'phone':null,look:id===20||id===21?3:-4,mood:id===21?.12:id>=22?.41:.26,
   speaking:[16,19].includes(id)?talk(t)*.76:0,reach:id>=22?.47*mark.seat:id===20?smooth((u-.28)/.33):.15,
   handWorld:id===20&&u>.65&&u<.91?doorHandle:null});
 }
 const refresh=previous!==name||name==='kitchen'&&id===20;
 renderer.shadowMap.needsUpdate=refresh;
 if(params.get('fx')!=='0'&&([19,21].includes(id)||demo&&id===16)){
  if(!post)post=makePost(world.scene);
  post.renderPass.scene=world.scene;post.renderPass.camera=camera;
  post.dof.cocMaterial.focusDistance=camera.position.distanceTo(focus);
  renderer.toneMapping=T.NoToneMapping;post.composer.render(1/30);
 }else{
  renderer.toneMapping=T.ACESFilmicToneMapping;renderer.render(world.scene,camera);
 }
 previous=name;
 ctx.drawImage(renderer.domElement,0,0);
 const scale=Math.min(width/720,height/1280);ctx.save();ctx.translate((width-720*scale)/2,0);ctx.scale(scale,scale);
 if(lit){
  ctx.globalAlpha=smooth(ago/.12)*(1-smooth((ago-.55)/.28));panel(157,148,406,86,'#1d4b42e8');
  text('+100.000 ₫',360,192,46,'#dcf6ba');ctx.globalAlpha=1;
 }
 if(!demo){
  const cue=film.captionCues.find(c=>c.start<=t&&c.end>t);
  if(cue){panel(28,1036,664,88,'#16222ae1');text(cue.text.toLocaleUpperCase('vi'),360,1080,33);}
 }
 ctx.restore();
 return {frame,shot:id,name,camera:camera.position.toArray(),focus:focus.toArray(),door:world.layout.door?.rotation.y??null};
}
window.movie={app:{canvas},setTime};setTime(0);window.ready=true;
