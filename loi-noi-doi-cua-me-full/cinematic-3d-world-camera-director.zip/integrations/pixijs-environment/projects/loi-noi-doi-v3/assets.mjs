import {T} from '../loi-noi-doi/world.mjs';
import {GLTFLoader} from '../../../../workbench/node_modules/three/examples/jsm/loaders/GLTFLoader.js';

const origin='https://github.com/thuann-vn/claude-3d-animated-shorts/tree/f5b4c4aebfc5eeb7acc51fac1f29bfef10389ff5/engine/assets/props';
export const assets={
 chairCushion:['Furniture',.89,'Kenney','glb',true],
 chair_B_wood:['Furniture',.87,'KayKit','gltf',true],
 kitchenSink:['Appliances',.90,'Kenney','glb',true],
 kitchenStove:['Appliances',.9,'Kenney','glb',true],
 kitchenMicrowave:['Appliances',.29,'Kenney','glb',false],
 kitchenCabinetUpper:['Interior',.62,'Kenney','glb',false],
 kitchenCoffeeMachine:['Electronics',.31,'Kenney','glb',false],
 pottedPlant:['Nature',.58,'Kenney','glb',false],
 televisionVintage:['Electronics',.49,'Kenney','glb',false],
};
export const registry=Object.fromEntries(Object.entries(assets).map(([id,[category,height,author,format,interactive]])=>[id,{
 category,author,format,license:'CC0-1.0',source:origin+'/'+author.toLowerCase(),heightMetres:height,
 pivot:'ground-centered at load',material:'embedded glTF PBR',interactive
}]));
export const categories=['Furniture','Interior','Exterior','Architecture','Vehicles','Nature','Appliances','Food','Electronics','Construction','Tools','Interactive props'];
export async function createLibrary(ids=Object.keys(registry)){
 const loader=new GLTFLoader(),loaded=new Map();
 await Promise.all(ids.map(async id=>{
  const {format,heightMetres}=registry[id];
  const {scene}=await loader.loadAsync(new URL('./assets/'+id+'.'+format,import.meta.url).href);
  const bounds=new T.Box3().setFromObject(scene),center=bounds.getCenter(new T.Vector3());
  const pivot=new T.Group();scene.position.sub(new T.Vector3(center.x,bounds.min.y,center.z));
  pivot.add(scene);pivot.scale.setScalar(heightMetres/(bounds.max.y-bounds.min.y));
  scene.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});
  loaded.set(id,pivot);
 }));
 return (scene,id,x,y,z,yaw=0)=>{
  const group=loaded.get(id).clone(true);
  group.position.set(x,y,z);group.rotation.y=yaw;scene.add(group);return group;
 };
}
