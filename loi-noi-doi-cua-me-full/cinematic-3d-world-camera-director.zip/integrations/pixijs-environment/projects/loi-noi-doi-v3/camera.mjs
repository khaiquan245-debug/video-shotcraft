import * as T from '../../../../workbench/node_modules/three/build/three.module.js';

export const smooth = v => (v=Math.min(1,Math.max(0,v)),v*v*(3-2*v));
const vector=a=>new T.Vector3(...a);
const curve=points=>new T.CatmullRomCurve3(points.map(vector),false,'centripetal');
const orient=(p,t)=>new T.Quaternion().setFromRotationMatrix(
 new T.Matrix4().lookAt(p,t,new T.Vector3(0,1,0)));

export function createCameraDirector(plan){
 const routes=plan.map(shot=>({shot,rail:curve(shot.position),target:curve(shot.target)}));
 return {
  sample(frame,camera){
   const route=routes.find(v=>frame>=v.shot.startFrame&&frame<v.shot.endFrame);
   if(!route)throw new RangeError('No shot at frame '+frame);
   const {shot,rail,target}=route;
   const u=(frame-shot.startFrame)/Math.max(1,shot.endFrame-shot.startFrame-1);
   const a=smooth(u);
   const left=Math.floor(a*24)/24,right=Math.min(1,left+1/24);
   const p=rail.getPoint(a),f=target.getPoint(a);
   camera.position.copy(p);
   camera.quaternion.copy(orient(rail.getPoint(left),target.getPoint(left)))
    .slerp(orient(rail.getPoint(right),target.getPoint(right)),(a-left)*24);
   camera.fov=shot.lens;camera.near=shot.camera==='pov'?.035:.09;
   camera.updateProjectionMatrix();camera.updateMatrixWorld();
   return {shot,u,a,position:p,focus:f};
  }
 };
}
