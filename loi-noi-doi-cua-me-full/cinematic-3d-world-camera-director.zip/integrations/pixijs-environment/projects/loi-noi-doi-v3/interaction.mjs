import {T} from '../loi-noi-doi/world.mjs';
import {smooth} from './camera.mjs';
const lerp=T.MathUtils.lerp;
export function kitchenMark(id,u,demo){
 if(id===15)return {x:lerp(-2.22,-.32,smooth(u)),z:lerp(.91,.10,smooth(u)),walk:Math.sin(u*Math.PI),seat:0,door:0};
 if(id===20){
  const walk=smooth(u/.66);
  return {x:lerp(-.32,.85,walk),z:lerp(.10,-.37,walk),walk:Math.sin(Math.min(1,u/.66)*Math.PI),seat:0,door:smooth((u-.60)/.39)};
 }
 if(id===21)return {x:.85,z:-.37,walk:0,seat:0,door:1};
 if(id>=22){
  const settle=id>22?1:smooth(u/.42);
  return {x:lerp(.71,.01,settle),z:lerp(-.38,-1.18,settle),walk:Math.sin(settle*Math.PI),seat:smooth((settle-.67)/.31),door:1-.95*settle};
 }
 return {x:-.32,z:.45,walk:0,seat:0,door:0};
}
export function updateDoor(layout,mark){
 layout.door.rotation.y=mark.door*1.92;
 layout.bulb.intensity=mark.door*2.3;
 layout.door.updateWorldMatrix(true,true);
 return layout.handle.getWorldPosition(new T.Vector3());
}
