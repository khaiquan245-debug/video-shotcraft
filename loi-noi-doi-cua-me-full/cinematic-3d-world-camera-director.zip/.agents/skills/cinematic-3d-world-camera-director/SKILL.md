---
name: cinematic-3d-world-camera-director
description: Author 3D sets and camera paths for Shorts and long-form animation in Video Shotcraft. Use for depth, staging, glTF furniture, tracked subjects, refrigerator or doorway POV, lighting and a proof-to-full render.
---

# Cinematic 3D world and camera direction

Use the project runtime at `integrations/world-camera-v3/` and the example set implementation at `integrations/pixijs-environment/projects/loi-noi-doi-v3/`. Read the accompanying [README](README.md) for commands, licenses and implementation boundaries.

1. Measure and preserve approved narration and event times. Create a shot manifest with ordered half-open frame intervals, a narrative purpose, environment, actor, action, prop, focus, light profile and transition for every entry.
2. Define set scale in metres. Build enclosure, foreground blockers, doors, practical lights and contact surfaces before placing actors. Reuse environment IDs when returning to a location. Set foreground, midground and background at separate coordinates. Use assets from the registry with verified licenses.
3. Use `path-library.mjs` for a starting rail. In the shot manifest provide at least three world-space coordinates for position and target. Start and end adjacent continuous shots with matching coordinates. Use a declared cut only when staging justifies a discontinuity. Limit orbits for flat character artwork.
4. Run the camera validator, then use a proof shot to check perspective, occlusion, floor contact and prop alignment. Inspect mid-shot frames and boundaries. The camera validator checks transforms and continuity. Visual contact, collision and style still require review.
5. Render a short motion proof before the full MP4. Retain separately encoded parts as checkpoints. Decode and probe the final export and inspect encoded frames. Preserve the approved audio track unless an audio change is requested.

The example dispatches authored gestures and roles for one story. New scripts require their own action and set manifest. The runtime does not infer arbitrary blocking or lip sync from prose.
