# Cinematic 3D world and camera director

| Feature | Location |
| --- | --- |
| World, environments, materials and lighting | `integrations/pixijs-environment/projects/loi-noi-doi-v3/stage.mjs` |
| glTF registry, license, size and pivot normalization | `integrations/pixijs-environment/projects/loi-noi-doi-v3/assets.mjs` and `assets/` |
| Camera director and supported shot path presets | `camera.mjs` in the demo project and `integrations/world-camera-v3/path-library.mjs` |
| Shot planning and JSON validation | `integrations/world-camera-v3/plan.py`, `shot-manifest.schema.json`, `validate.mjs` |
| Character drawing, occlusion, prop and door control | `actors.mjs`, `interaction.mjs` and `main.mjs` in the demo project |
| Demo, full render and resumable chunks | `integrations/world-camera-v3/render.mjs` |

From the repository root, use the project's installed Chromium, FFmpeg, Vite and Three.js. Install the isolated effects dependency via the lockfile if needed.

```sh
npm ci --prefix integrations/world-camera-v3 --ignore-scripts
python integrations/world-camera-v3/plan.py
node integrations/world-camera-v3/validate.mjs
node integrations/pixijs-environment/node_modules/vite/bin/vite.js --config integrations/world-camera-v3/vite.config.mjs
```

Run the renderer in another shell. The visual proof is 15 seconds. The full render defaults to native 1080 × 1920, 30 frames per second. The demo creates no new narration.

```sh
node integrations/world-camera-v3/render.mjs --proof --demo
FRAME_WIDTH=720 node integrations/world-camera-v3/render.mjs --demo
node integrations/world-camera-v3/render.mjs --proof
node integrations/world-camera-v3/render.mjs
```

The example expects approved narration timing and V2 audio under `/workspace/outputs/loi-noi-doi`. It writes new files under that directory's `v3/` child. Completed chunks have a `.done` marker. Use a new output folder or remove only stale chunks when intentionally changing shot data.

The renderer uses Three.js r185 and pmndrs postprocessing for bloom and depth of field on selected shots. Lighting uses shadow maps plus contact shadow textures. Shot-defined depth focus is derived from camera-to-target distance. Actor art is drawn into upright 3D planes, with an additional rear head pose for the over-shoulder move. A depth buffer handles occlusion against furniture. Props anchored in the original drawing and the refrigerator door use separate authored controls. This setup has no general-purpose physics or full 3D skeleton solver.

## References and rights

- RicksClips animation skill, revision `d90c1b952320f0fe94e3bbe78fccb5d0028dbf51`, CC BY 4.0. Reviewed the camera and production workflow and ran its `tools/short_qa.py` on the exports. The original channel artwork and characters were not imported. [Source](https://github.com/NurMohammadDuari/ricksclips-animation-skill)
- Claude 3D Animated Shorts, revision `f5b4c4aebfc5eeb7acc51fac1f29bfef10389ff5`, MIT code. Reviewed its world/effects composition and reused verified furniture and appliances. Kenney Furniture Kit and KayKit Furniture Bits carry separate CC0 notices included beside the files. Claude-specific automation and remote voice services are unnecessary for this runtime. [Source](https://github.com/thuann-vn/claude-3d-animated-shorts)
- Three.js repository inspected at `c3c69abae1440acff276409de4544e2b943fe789`. Runtime pinned to `0.185.1`, MIT. [Source](https://github.com/mrdoob/three.js)
- pmndrs/postprocessing repository inspected at `a1f103559d15cf56cbcbb15d4373711b09418f3f`. Runtime pinned to `6.39.6`, zlib. [Source](https://github.com/pmndrs/postprocessing)
- The registry declares supported categories. These scenes use the licensed Kenney and KayKit subset plus original geometry. Poly Haven and Quaternius assets were not imported in this version.

For a landscape proof use `FRAME_WIDTH=1920 FRAME_HEIGHT=1080`. Camera rails and focus are composition inputs and should be checked again for the target aspect. Update the production dispatch to point to your own environment builders, cast and approved audio. Only the included Vietnamese project has a complete action planner and finish.

## V4 kitchen environment

`integrations/pixijs-environment/projects/loi-noi-doi-v4/stage.mjs` exports the V4 environment builder with a bounded working set. It returns a Three.js scene, an environmental motion update, and an interaction layout containing the refrigerator door, hinge-space handle anchor, emissive insert and light. It reuses the V3 asset loader and camera implementation. The V4 materials module builds repeatable base-color and tangent-space normal textures. Soft contact occlusion is baked with world-space gradient planes under furniture.

The V4 demo has independent camera and contact data and a native 1080 × 1920 render entry. Run it after the V3 Vite server starts.

```sh
node integrations/world-camera-v3/validate.mjs /workspace/outputs/loi-noi-doi/v4/shot-manifest.json
node integrations/world-camera-v3/render-v4.mjs --proof --demo
node integrations/world-camera-v3/render-v4.mjs --demo
```

The demonstrated arm follows the hinge anchor through the catch and pull phase and releases once the door is moving. This is an authored interaction with reused 2D character art and a 3D arm overlay, with placement specific to this kitchen. For a different set use its handle anchor, stage the actor near it, and review the elbow and hand in encoded frames.

For the full-film kitchen replacement, use `node integrations/world-camera-v3/render-v4.mjs --kitchen` and join native scenes with `master-film.py`. The master script expects the authored scene manifest and the approved-base Wyzowl mix under the production output folder. This sequence retains the locked audio timeline and native 1080p sources. The refrigerator POV checkpoint may be rendered separately with `render-v4-pov.mjs` for scoped repairs.
