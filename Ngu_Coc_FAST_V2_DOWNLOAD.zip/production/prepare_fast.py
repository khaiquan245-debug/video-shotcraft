from pathlib import Path
import wave,json,hashlib,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;D=31.2;OFFSET=.04;TARGET=30.6
m=json.loads((B/'audio/narration-native.json').read_text())
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==m['wav_sha256']
with wave.open(str(B/'audio/narration-native.wav')) as w:
 assert w.getframerate()==R
 raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy()
parts=[];cursor=0;spans=[];trimlog=[]
for i,q in enumerate(m['captions']):
 lo=round(q['start']*R);hi=round(q['end']*R);x=raw[lo:hi];ws=480;k=len(x)//ws;v=x[:k*ws].astype(float)/32768;rms=np.sqrt(np.mean(v.reshape(-1,ws)**2,axis=1));active=np.where(rms>max(.004,float(np.max(np.abs(v)))*.013))[0]
 assert len(active)
 a=max(0,int(active[0])*ws-round(.04*R));z=min(len(x),(int(active[-1])+1)*ws+round(.045*R));trim=x[a:z]
 spans.append({'old_start':q['start']+a/R+.06,'old_end':q['start']+z/R+.06,'compact_start':cursor/R,'compact_end':(cursor+len(trim))/R,'text':q['text']})
 parts.append(trim);cursor+=len(trim);trimlog.append({'sentence':i,'leading_removed':a/R,'trailing_removed':(len(x)-z)/R})
 if i<len(m['captions'])-1:parts.append(np.zeros(round(.04*R),dtype='<i2'));cursor+=round(.04*R)
compact=np.concatenate(parts);tempo=(len(compact)/R)/TARGET
assert 1<tempo<1.3,tempo
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-fast.wav')],check=True)
with wave.open(str(B/'audio/narration-fast.wav'))as w:duration=w.getnframes()/R
factor=(len(compact)/R)/duration
pairs=[{'old':0.,'new':0.}]
for s in spans:
 pairs.extend([{'old':s['old_start'],'new':OFFSET+s['compact_start']/factor},{'old':s['old_end'],'new':OFFSET+s['compact_end']/factor}])
pairs.append({'old':40.,'new':D})
assert all(a['old']<b['old'] and a['new']<b['new'] for a,b in zip(pairs,pairs[1:]))
def nt(t):return float(np.interp(t,[p['old']for p in pairs],[p['new']for p in pairs]))
old_caps=json.loads((B/'manifests/captions-source.json').read_text());caps=[{**q,'start':nt(q['start']),'end':nt(q['end']),'alignment':'Measured retained sentence spans, estimated semantic phrase boundaries; no word forced-alignment'}for q in old_caps]
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
source=json.loads((B/'manifests/story-times-source.json').read_text());story={k:nt(t)for k,t in source.items()}
(B/'manifests/story-times.json').write_text(json.dumps(story,indent=2));audio_pairs=pairs;visual_anchors=sorted(set(source.values())|{36.72,37.22,37.72});visual_pairs=[{'old':t,'new':nt(t)}for t in visual_anchors];(B/'manifests/clock-map.json').write_text(json.dumps({'pairs':visual_pairs,'audio_pairs':audio_pairs,'knocks':[nt(t)for t in [36.72,37.22,37.72]],'duration':D,'note':'Animation uses smooth story-block remapping; trimmed silence edges are not compressed into abrupt body teleports.'},indent=2))
report={'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'inference_offline':m['inference_offline'],'native_duration':m['duration'],'compacted_duration':len(compact)/R,'edited_duration':duration,'pitch_preserving_tempo':tempo,'offset':OFFSET,'duration':D,'words_unchanged':True,'space_units':154,'space_units_per_video_second':154/D,'native_sha256':m['wav_sha256'],'trim_log':trimlog,'join_before_tempo':.04,'padding_before_after': [.04,.045],'final_voice_sha256':hashlib.sha256((B/'audio/narration-fast.wav').read_bytes()).hexdigest()}
(B/'manifests/voice-fast.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
p=json.loads((B/'manifests/project-source.json').read_text());p.update(duration=D,revision_of='cereal-wakeup-20261120',pacing_profile='/workspace/outputs/production_rules/shorts-fast-profile.json');p['voice'].update(tempo=tempo,edited_duration=duration,offset=OFFSET);(B/'manifests/project.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k]for k in ['native_duration','compacted_duration','edited_duration','pitch_preserving_tempo','duration','space_units_per_video_second']},indent=2));print('KNOCKS',[nt(t)for t in [36.72,37.22,37.72]])
