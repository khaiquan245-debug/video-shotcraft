from pathlib import Path
import json, wave, hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;D=31.2;N=round(R*D)
S=json.loads((B/'manifests/story-times.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());m=json.loads((B/'audio/narration-native.json').read_text())
with wave.open(str(B/'audio/narration-fast.wav')) as w:
 assert w.getframerate()==R
 raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==m['wav_sha256']
V=np.zeros(N,np.float32);offset=round(.04*R);V[offset:offset+len(raw)]=raw
F=np.zeros((N,2),np.float32);rng=np.random.default_rng(2317);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;noise=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='splash':a=(np.convolve(noise,np.ones(8)/8,'same')+.18*np.sin(2*np.pi*(450*t+380*t*t)))*np.exp(-t/.13)
 elif kind=='whoosh':a=np.convolve(noise,np.ones(14)/14,'same')*env
 elif kind=='ceramic':a=(np.sin(2*np.pi*870*t)+.4*np.sin(2*np.pi*1422*t)+.18*noise)*np.exp(-t/.045)
 elif kind=='metal':a=(np.sin(2*np.pi*940*t)+.42*np.sin(2*np.pi*1632*t))*.3*np.exp(-t/.1)+.12*noise*np.exp(-t/.025)
 elif kind=='paw':a=(np.sin(2*np.pi*93*t)+.28*np.convolve(noise,np.ones(32)/32,'same'))*np.exp(-t/.065)
 elif kind=='cardboard':a=np.convolve(noise,np.ones(25)/25,'same')*env*(.65+.35*np.sin(2*np.pi*23*t))
 elif kind=='grain':a=(.35*noise+np.sin(2*np.pi*(310+35*rng.random())*t))*np.exp(-t/.018)
 elif kind=='rope':a=np.convolve(noise,np.ones(39)/39,'same')*env
 elif kind=='cloth':a=(noise-np.convolve(noise,np.ones(13)/13,'same'))*.45*env
 elif kind=='hinge':a=(np.sin(2*np.pi*(170*t+55*t*t))+.3*np.sin(2*np.pi*690*t))*env
 elif kind=='knock':a=(np.sin(2*np.pi*390*t)+.28*np.sin(2*np.pi*930*t)+.1*np.convolve(noise,np.ones(14)/14,'same'))*np.exp(-t/.035)
 elif kind=='glint':a=(np.sin(2*np.pi*659.25*t)+.3*np.sin(2*np.pi*987.77*t))*np.exp(-t/.3)
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 i=round(at*R);a=fx(kind,d)[:N-i]*gain
 F[i:i+len(a),0]+=a*np.sqrt((1-pan)/2);F[i:i+len(a),1]+=a*np.sqrt((1+pan)/2)
 events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,4),'duration':d,'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'source':'self-created oscillator/noise Foley in production/audio.py','rights':'original synthesis; no external recording'})
clock=json.loads((B/'manifests/clock-map.json').read_text())['pairs']
def nt(t):return float(np.interp(t,[p['old']for p in clock],[p['new']for p in clock]))
for ev in json.loads((B/'manifests/sound-events-source.json').read_text())['events']:
 at=nt(ev['time']);d=max(.07,min(ev['duration'],nt(ev['time']+ev['duration'])-at))
 add(at,ev['kind'],ev['gain_linear'],d,ev['pan'],ev['purpose'])
# Original evolving score: nimble plucked adventure, warm miniature home, then a restrained suspense ending.
M=np.zeros(N,np.float32);notes=[293.665,349.228,440,523.251,440,391.995,349.228,261.626]
for i,at in enumerate(np.arange(.04,nt(29.8),.43)):
 k=round(at*R);d=.65;t=np.arange(round(d*R))/R;f=notes[i%8];a=(np.sin(2*np.pi*f*t)+.32*np.sin(2*np.pi*2*f*t)+.10*np.sin(2*np.pi*3*f*t))*np.exp(-t/.14)
 M[k:k+len(a)]+=.021*a
 if i%4==0:M[k:k+len(a)]+=.011*np.sin(2*np.pi*(f/2)*t)*np.exp(-t/.22)
for at,chord in[(29.8,[261.626,329.628,391.995]),(31.4,[293.665,349.228,440]),(33.1,[261.626,329.628,391.995])]:
 at=nt(at)
 k=round(at*R);d=1.7;t=np.arange(round(d*R))/R;a=sum(np.sin(2*np.pi*f*t)*np.exp(-t/.62) for f in chord)*.008*np.minimum(1,t/.025);M[k:k+len(a)]+=a
# Music deliberately drops after the ordinary bowl line, leaving the knocks perceptually distinct.
T=np.arange(N)/R;M*=np.where(T<nt(35.2),1,np.maximum(0,1-(T-nt(35.2))/(nt(35.55)-nt(35.2))))
A=rng.normal(0,1,N).astype(np.float32);A=.0035*np.convolve(A,np.ones(16)/16,'same')+.0015*np.sin(2*np.pi*60*T)
A*=np.where(T<S['room'],1,.5);A*=np.minimum(1,np.minimum(T/.08,(D-T)/.45))
rms=np.sqrt(np.mean(V.reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(17)/17,'same');duck=np.interp(np.arange(N),np.arange(len(gate))*480,1-.67*gate);M*=duck
fade=np.minimum(1,np.minimum(T/.05,(D-T)/.35));M*=fade;F*=fade[:,None]
stereo=np.column_stack((V+M+A,V+M+A*.96))+F
assert np.max(np.abs(stereo))<1, 'Mix needs gain adjustment'
def save(name,a):
 with wave.open(str(B/'audio'/name),'wb') as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',A),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
(B/'manifests/sound-events.json').write_text(json.dumps({'provenance':'Original locally synthesized Foley and score, no external audio assets, no paid API','score_sections':[{'start':0,'end':nt(29.8),'purpose':'Nimble plucked physical-comedy adventure,139.5BPM'},{'start':nt(29.8),'end':nt(35.55),'purpose':'Warm furnished house reveal, original triads and fade'},{'start':nt(35.55),'end':D,'purpose':'Intentional music drop; room air and the three under-milk knocks remain'}],'events':events},ensure_ascii=False,indent=2))
def ts(s):
 ms=round(s*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Ngu_Coc_FAST_V2.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}' for i,q in enumerate(caps)),encoding='utf-8')
print('AUDIO:31.2s; original native voice preserved; silence trimmed and pitch-preserving tempo applied; captions',len(caps),'SFX',len(events),'mix raw peak',float(np.max(np.abs(stereo))))
