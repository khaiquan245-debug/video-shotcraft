from pathlib import Path
import json,hashlib,wave,csv
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';q=json.loads((B/'qa/final.json').read_text());v=json.loads((B/'manifests/voice-fast.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());source=json.loads((B/'manifests/story-times-source.json').read_text())
def longest_quiet(path,skip_tail=False):
 with wave.open(str(path))as w:x=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float)/32768
 if skip_tail:
  active=np.where(np.abs(x)>.005)[0];x=x[active[0]:active[-1]+1]
 n=len(x)//480;r=np.sqrt(np.mean(x[:n*480].reshape(-1,480)**2,axis=1));best=run=0
 for b in r<.003:run=run+1 if b else 0;best=max(best,run)
 return best/100
inside=longest_quiet(B/'audio/voice-timeline.wav',True)
comparison={'reference':{'duration':38.220045,'units':191,'units_per_video_second':191/38.220045,'source_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','note':'Transcript reconstructed from captions/local ASR. No equivalent isolated narration stem silence measurement.'},'original_cereal':{'duration':40,'units':154,'units_per_video_second':3.85,'max_quiet_seconds':2.45,'mp4_sha256':'83290cc47cebd94ceb461f8e1988c0041bd2f19bcad51e4a8f98821de1088aa3'},'fast_cereal':{'duration':q['duration'],'units':154,'units_per_video_second':154/q['duration'],'max_quiet_seconds':q['narration_max_quiet_seconds'],'max_internal_quiet_seconds':inside,'mp4_sha256':q['sha256']},'count_method':'Vietnamese approximate units separated by spaces; not a phonetic syllable count or quality score','audio_unchanged_native_sha256':v['native_sha256'],'words_unchanged':True,'paid_apis':False}
(B/'qa/pacing-comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2))
(O/'README.md').write_text('''# Tô ngũ cốc — FAST V2

Mở `Ngu_Coc_FAST_V2_31_2s_1080x1920.mp4`:31,2giây,1080×1920,30fps, có lời kể tiếng Việt, phụ đề, nhạc và SFX.

Giữ nguyên154tiếng của kịch bản và toàn bộ tạo hình. Mục tiêu nhịp theo mẫu người dùng: gần5tiếng/giây, hành động nối tiếp, không kéo dài phim để đủ40giây. Bản cũ40giây vẫn nguyên vẹn.

Giọng gốc VieNeu-TTS v3 Turbo, CPU ONNX offline, Hải Đăng (adapter gọi bằng alias Minh Quân). Tái sử dụng WAV native đã có; thu gọn khoảng yên ở biên câu và khoảng nối, tăng tốc giọng khoảng5,9% bằng FFmpeg atempo giữ cao độ. Không thu lại hoặc ghi đè giọng đã duyệt.

Hình được render lại ở30fps từ source với nhịp cảnh mới; camera, tiếp xúc và Foley theo cùng clock cảnh. Phụ đề theo clock audio. Không tăng tốc toàn bộ tệp MP4 cũ. Các chuyển động qua biên câu được nội suy theo khối hành động để tránh nhảy tư thế khi bỏ khoảng yên.

Xem `Comparison_Report.md`, `SHORTS_NHIP_KE_NHANH.md`, ảnh trích và QA trong ZIP. Chưa có duyệt bằng tai người; phụ đề trong câu dùng mốc cụm nghĩa ước lượng, không forced alignment từng từ. Không dùng API trả phí; model weights không nằm trong ZIP/Git.

Dựng lại trong Cloud hiện tại, với Canvas/FFmpeg đã cài:

```bash
python production/prepare_fast.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
```

Cần runtime @napi-rs/canvas từ `/workspace/video-shotcraft/workbench/package.json`; các font và nguồn giọng đã có trong gói. Không chạy lại TTS vào WAV native đã có.
''',encoding='utf-8')
report=f'''# So sánh nhịp kể — Tô ngũ cốc FAST V2

Đúng video người dùng vừa gửi đã được kiểm tra checksum và trùng mẫu phân tích trước. Áp dụng làm chuẩn Shorts của dự án, không gọi đó là quy định chính thức của YouTube.

| Chỉ số | Mẫu tham khảo | Ngũ cốc V1 | Ngũ cốc FAST V2 |
|---|---|---|---|
| Thời lượng | 38,22giây | 40giây | {q['duration']}giây |
| Tiếng tách theo khoảng trắng | 191 | 154 | 154, giữ nguyên |
| Mật độ lời trên toàn phim | ≈5,00/giây | 3,85/giây | {154/q['duration']:.2f}/giây |
| Khoảng yên dài nhất trên track giọng, RMS<0,003 | Không có track riêng tương đương | 2,45giây | {q['narration_max_quiet_seconds']:.2f}giây |

Trong phần có lời, khoảng yên liên tục lớn nhất của FAST V2 đo cùng ngưỡng là {inside:.2f}giây. Mật độ tiếng đếm theo khoảng trắng là gần đúng, không phải âm tiết ngữ âm hay điểm chất lượng. Không so trực tiếp khoảng hở ASR của mẫu với RMS của các track giọng riêng.

## Cách sửa

Bản cũ dành quá nhiều thời gian cho khoảng yên và phản ứng kết. Lời native {v['native_duration']}giây được giữ file gốc, chỉ xử lý vào tệp mới. Thu gọn biên câu với đệm40/45ms, đổi khoảng nối180ms thành40ms, cho bản ghép {v['compacted_duration']:.3f}giây; sau đó atempo={v['pitch_preserving_tempo']:.6f} cho giọng {v['edited_duration']:.3f}giây, giữ cao độ. Không xóa từ hoặc thêm lời mới.

Phim được render lại936frame ở30fps,1080×1920, từ cùng nhân vật/bối cảnh/rig. Nhịp các cảnh đổi theo câu đã chỉnh; giữ hành động qua biên câu mượt bằng clock cảnh riêng. Caption dùng clock audio. SFX được tổng hợp lại tại thời điểm tiếp xúc mới; nhạc chuyển sang ấm và ngắt trước cú hé lộ theo timeline mới. Ba tiếng gõ được đồng bộ với xung bàn tay/ripple ở clock thật.

Model thực tế:VieNeu-TTS v3 Turbo, ONNX CPU offline, giọng Hải Đăng; Minh Quân là alias trong adapter hiện tại. Không gọi model hoặc API mới trong lần chỉnh này. Không tái sử dụng soundtrack hoặc hình ảnh từ mẫu.

## Kiểm tra thật

- MP4 {q['duration']:.3f}giây, {q['frames']}frame, H.264/AAC48kHz; giải mã toàn bộ thành công.
- {q['lufs']}LUFS, true peak {q['true_peak_dbfs']}dBTP.
- Rig:{q['rig']['samples']}mẫu, {q['rig']['unreachable']}đích ngoài tầm, sai số chiều dài xương tối đa {q['rig']['maxBoneError']:.3g}.
- SHA-256:`{q['sha256']}`.
- Kiểm tra ảnh từ chính MP4 ở các nhịp thìa/mèo/hộp/dây/gõ; phát thử Chromium1× để kiểm tra kỹ thuật. Phiên phát tắt tiếng; không tự nhận đã duyệt cảm xúc hoặc độ dễ nghe bằng tai người.

Phụ đề có43cụm nghĩa; biên câu theo đoạn TTS thực tế, biên cụm trong câu ước lượng, chưa forced alignment từng từ. Không chứng nhận tương đương thẩm mỹ/giọng với mẫu. Bản40giây và WAV native giữ nguyên. Model weights nằm ngoài Git. Chuẩn dùng lại ở `/workspace/outputs/production_rules/SHORTS_NHIP_KE_NHANH.md`.
'''
(O/'Comparison_Report.md').write_text(report,encoding='utf-8')
(O/'CREDITS.md').write_text('''# Nguồn

Lời kể do người dùng cung cấp, giữ nguyên. Hình/nhân vật/diễn hoạt và Foley/nhạc nguyên tác từ dự án Cereal Wakeup được tái dựng theo nhịp mới. Không ghép hình hoặc soundtrack của video tham khảo.

VieNeu-TTS v3 Turbo, Apache-2.0, ONNX CPU offline; preset thực tế Hải Đăng, alias Minh Quân trong adapter. Tái sử dụng native WAV không ghi đè; metadata và checksum đi kèm. Không model weights trong gói.

Nhạc và âm thanh tự tổng hợp local bằng oscillator/noise trong production/audio.py. Font Nunito theo SIL OFL; giấy phép ở assets/OFL-Nunito.txt. Không API trả phí.
''',encoding='utf-8')
with (O/'Shot_Timeline.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.writer(f);w.writerow(['action','old_start','new_start']);w.writerows((k,source[k],S[k])for k in sorted(source,key=source.get))
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));tw,th=180,320;board=Image.new('RGB',(8*tw,4*(th+24)),'#183e40');d=ImageDraw.Draw(board)
for i,p in enumerate(files):
 im=Image.open(p);im.thumbnail((tw,th));x=i%8*tw;y=i//8*(th+24);board.paste(im,(x,y));d.text((x+5,y+th+5),f'{i+.5:.1f}s',fill='#fff6dc')
board.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
print('REPORT',q['sha256'],'max_internal_quiet',inside)
