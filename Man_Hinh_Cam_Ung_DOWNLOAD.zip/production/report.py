from pathlib import Path
import json,hashlib,csv,shutil,subprocess,io
import numpy as np
from PIL import Image,ImageDraw
B=Path(__file__).resolve().parents[1];O=B/'output';q=json.loads((B/'qa/final.json').read_text());vm=json.loads((B/'manifests/voice.json').read_text());S=json.loads((B/'manifests/story-times.json').read_text());caps=json.loads((B/'manifests/captions.json').read_text());snd=json.loads((B/'manifests/sound-events.json').read_text());p=Path(q['file'])
script=(B/'audio/script-approved.txt').read_text();assert len(script.split())==221
assert ' '.join(c['text']for c in caps)==' '.join(script.split())

def frame(t):
 data=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(p),'-frames:v','1','-f','image2pipe','-vcodec','png','pipe:1'])
 return np.asarray(Image.open(io.BytesIO(data)).convert('RGB')).astype(float)
def diff(a,b,roi):
 x,y,xx,yy=[round(z*1.5)for z in roi];return float(np.abs(frame(a)[y:yy,x:xx]-frame(b)[y:yy,x:xx]).mean())
unchanged=diff(S['glove']+.8,S['no_response']+.8,(235,280,335,410));opened=diff(.2,1.2,(235,280,335,410));drag=diff(S['swipe']+.2,S['gestures']-.2,(235,330,335,440))
zoom=next(x['start']for x in caps if x['text']=='hay phóng to');zoomdiff=diff(zoom+.02,zoom+.85,(235,280,465,430))
assert unchanged<2.5,unchanged
assert opened>5 and drag>2 and zoomdiff>2,(opened,drag,zoomdiff)
xx,yy=np.meshgrid(np.arange(8)/7,np.arange(10)/9);err=0.
for t in np.linspace(0,S['swipe']-S['coordinates'],100):
 u=.53+.12*np.sin(t*1.5);v=.46+.06*np.cos(t*1.4);w=np.exp(-((xx-u)**2+(yy-v)**2)/.018);cu=float((xx*w).sum()/w.sum());cv=float((yy*w).sum()/w.sum());err=max(err,float(np.hypot(u-cu,v-cv)))
assert err<.01
sem={'actual_encoded_phone_screen_crop_checks':{'ordinary_glove_picture_mean_absolute_rgb_difference':unchanged,'ordinary_glove_threshold':2.5,'recognized_opening_touch_difference':opened,'swipe_picture_difference':drag,'two_contact_zoom_difference':zoomdiff,'pixel_difference_scope':'Targeted picture-region evidence; not proof of overall creative quality.'},'coordinate_interpolation_example':{'grid':[8,10],'max_normalized_centroid_error':err,'note':'Illustrative weighted-neighbor interpolation; not a claim about proprietary phone firmware or actual electrode count.'},'two_contact_zoom':{'starting_separation_design_px':70,'ending_separation_design_px':float(np.hypot(160,44)),'image_scale':[1,1.65],'purpose':'Two resolved touch points separate while the photograph grows.'},'science_scope':'Common projected-capacitive touchscreen, simplified illustrations. Sensor measures capacitance change, not pressure in this illustration. Special pressure sensors and resistive touchscreens are outside scope. Ordinary gloves may fail; conductive touchscreen gloves may work. Bars show illustrative change magnitude, not physical measurements or universal change direction.','audio_scope':'Internal-signal sound effects are designed sonification, not recordings or claims of audible electrical arcing.'}
(B/'qa/semantic-checks.json').write_text(json.dumps(sem,ensure_ascii=False,indent=2))
pacing={'space_units':221,'film_seconds':q['duration'],'units_per_film_second':221/q['duration'],'reference_seconds':38.220045,'reference_units':191,'reference_units_per_second':191/38.220045,'native_seconds':vm['native_duration'],'compacted_seconds':vm['compacted_duration'],'edited_seconds':vm['vo_duration'],'tempo':vm['pitch_preserving_tempo'],'max_voice_quiet_seconds':q['narration_max_quiet_seconds'],'scope':'Personal fast-pacing convention, not a universal YouTube rule.'}
(B/'qa/pacing-comparison.json').write_text(json.dumps(pacing,ensure_ascii=False,indent=2))
origin={'characters':'Original established orange-hoodie chibi character, connected two-bone arms/legs; original close-up bare/gloved hand contours with five digit forms','artwork':'New original touchscreen, interior desk setting, incorrect-button hypothesis, transparent electrode layers, fields, controller, coordinates, gesture and fabric diagrams in production/film.mjs','animation':'Procedural 30fps native portrait animation: contact-bound actions, scan/measurement traces, picture drag/scroll/zoom, conditional non-response and field/capacitance change','reference_media':'Pacing reference only, not composited or redistributed','music_and_sfx':'Original oscillator/noise synthesis in production/audio.py','font':'Nunito, SIL Open Font License 1.1, included','tts':'VieNeu-TTS v3 Turbo Apache-2.0, stock preset Hải Đăng, requested adapter alias Minh Quân, local ONNX CPU offline','paid_apis':False,'previous_projects_modified':False,'installed_skill_modified':False,'model_weights_outside_git':True}
(B/'qa/asset-origin.json').write_text(json.dumps(origin,ensure_ascii=False,indent=2))
files=sorted((B/'qa/encoded-1fps').glob('*.jpg'));sheet=Image.new('RGB',(180*8,348*((len(files)+7)//8)),'#233a30');d=ImageDraw.Draw(sheet)
for i,f in enumerate(files):
 im=Image.open(f);im.thumbnail((178,318));x=i%8*180;y=i//8*348;sheet.paste(im,(x,y+25));d.text((x+4,y+4),f'~{i:02d}s',fill='white')
sheet.save(B/'qa/Encoded_Contact_Sheet.jpg',quality=90)
with (O/'Shot_Timeline.csv').open('w',newline='',encoding='utf-8-sig')as f:
 w=csv.writer(f);w.writerow(['stage','start_seconds','end_seconds','approved_narration']);keys=[k for k in S if k!='end']
 for i,(k,s)in enumerate(zip(keys,vm['sentence_spans'])):w.writerow([k,round(S[k],3),round(S[keys[i+1]]if i+1<len(keys)else S['end'],3),s['text']])
shutil.copy2('/workspace/outputs/production_rules/SHORTS_NHIP_KE_NHANH.md',O/'SHORTS_NHIP_KE_NHANH.md')
(O/'README.md').write_text(f'''# Màn hình biết ngón tay bạn ở đâu bằng cách nào?

Video hoàn chỉnh: **{q['duration']:.1f} giây · 1080×1920 · 9:16 · 30fps · H.264/AAC**.

- [{p.name}]({p.name}) — xem/tải MP4.
- [Gói đầy đủ](Man_Hinh_Cam_Ung_DOWNLOAD.zip).
- [Phụ đề tiếng Việt](Man_Hinh_Cam_Ung.vi.srt).
- [Báo cáo thực tế](Production_Report.md).

Giữ nguyên 221 tiếng theo cách đếm khoảng trắng của kịch bản. Nhịp khoảng5tiếng/giây, có chuyển động tay/nhân vật, điện cực và tín hiệu, kéo ảnh, cuộn trang, phóng to hai điểm, nhạc và {len(snd['events'])} SFX. Không phải slideshow ảnh.

**Đây là sơ đồ cảm ứng điện dung phổ biến được giản lược**, không đại diện mọi công nghệ màn hình. Găng tay thường có thể không hoạt động; găng tay cảm ứng có thể hoạt động. Thanh tín hiệu không phải số đo thực. Không tuyên bố mọi màn hình đều không có cảm biến lực.

Giọng: adapter Minh Quân, preset thực tế Hải Đăng, nam Bắc tự nhiên; VieNeu-TTS v3 Turbo, ONNX CPU ngoại tuyến. Không có API trả phí hoặc trọng số trong gói.

Xem bằng trình duyệt/VLC. Để dùng trang preview sau khi giải nén: tạo thư mục `output`, chép MP4/SRT và `index.html` từ gốc ZIP vào `output`, chạy `python production/serve.py` rồi mở http://127.0.0.1:8833/.

Tái dựng trong môi trường Video Shotcraft: Python với NumPy/Pillow, Node.js với @napi-rs/canvas, FFmpeg. Renderer tìm canvas tại `/workspace/video-shotcraft/workbench/package.json`; đổi đường dẫn nếu môi trường khác. Giữ các thư mục audio/assets/manifests/production/qa/logs/output cạnh nhau. Metadata TTS gốc đã kèm nên không cần chạy lại model.

```bash
mkdir -p output qa logs
python production/prepare.py
python production/audio.py
node production/film.mjs --preflight
node production/film.mjs --full
python production/finish.py
python production/report.py
```

File WAV gốc được bảo toàn. Xem CREDITS.md và Production_Report.md.
''',encoding='utf-8')
(O/'CREDITS.md').write_text(f'''# Nguồn và giấy phép

- Kịch bản: toàn bộ lời kể tiếng Việt người dùng cung cấp; không thêm/đổi lời.
- Nhân vật gốc, tay cận cảnh, điện thoại, môi trường và sơ đồ: vẽ bằng mã của dự án. Nhân vật áo cam tiếp nối thiết kế của video ATM trước; toàn bộ nội dung cảm ứng là mới.
- Không lấy hình/cảnh/âm thanh từ video tham khảo; chỉ dùng chuẩn nhịp kể đã thống nhất.
- Nhạc nền128BPM, âm môi trường và {len(snd['events'])} cue SFX: tự tổng hợp tại máy bằng oscillator và noise trong production/audio.py. Không có bản ghi bên thứ ba. Các âm tín hiệu điện cực là thiết kế âm thanh minh họa.
- Nunito: SIL Open Font License1.1, font và giấy phép kèm assets/.
- VieNeu-TTS v3 Turbo: https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Turbo — model Apache-2.0, ONNX CPU offline. Preset thực tế Hải Đăng, alias adapter Minh Quân. Không clone giọng cá nhân mới.
- Công cụ: FFmpeg, @napi-rs/canvas, NumPy, Pillow, Chromium/Remotion để kiểm tra kỹ thuật.
- Không dùng API, GPU hoặc thuê bao trả phí. Không phân phối model weights/secrets/video tham khảo.
''',encoding='utf-8')
(O/'Production_Report.md').write_text(f'''# Báo cáo thực tế — Màn hình cảm ứng

## Thành phẩm

`{p.name}` đã render: **{q['duration']} giây, {q['frames']} khung hình, 1080×1920, 30fps, H.264 yuv420p, AAC stereo48kHz**, {q['bytes']:,}byte.

SHA-256: `{q['sha256']}`.

17 đoạn lời kể theo thứ tự nguyên bản; có ẩn/hiện lớp kính và lưới điện cực, đầu ngón tay tiếp xúc, điện trường minh họa, bộ điều khiển quét tín hiệu, tọa độ bám điểm chạm, kéo ảnh/cuộn/phóng to hai điểm, ví dụ găng tay không nhận. Nhân vật và tay có chuyển động; không dùng slideshow ảnh.

## Giọng và nhịp

Giữ nguyên221tiếng theo cách đếm khoảng trắng. TTS gốc **{vm['native_duration']}giây** được bảo toàn. Rút khoảng im lặng đầu/cuối câu, nối45ms rồi dùng atempo **{vm['pitch_preserving_tempo']:.6f}** giữ cao độ. WAV sau chỉnh **{vm['vo_duration']:.6f}giây**; video44,2giây≈5,00tiếng/giây. Nhịp tham khảo riêng từ video191tiếng/38,220045giây; không xem đây là quy tắc YouTube chung.

Model thực sự tạo WAV: **{q['voice']['model']}**, backend **{q['voice']['backend']}**, CPU ngoại tuyến. Tên yêu cầu **Minh Quân** là alias preset **Hải Đăng** (nam Bắc tự nhiên), không thay model. Có WAV gốc/chỉnh nhịp và metadata đã loại đường dẫn nội bộ không cần thiết.

Phụ đề một dòng chia cụm nghĩa, theo các khoảng câu đã đo từ audio. Nối phụ đề khớp kịch bản. Không có forced alignment từng từ; không tuyên bố chính xác từng âm tiết.

## Kiểm tra thực tế

- FFprobe xác nhận đầy đủ kích thước/codec/tốc độ/{q['frames']}khung hình.
- FFmpeg giải mã toàn bộ tệp: qua.
- Độ lớn đo từ MP4: **{q['lufs']}LUFS**, true peak **{q['true_peak_dbfs']}dBFS**.
- Khoảng yên voice lớn nhất theo RMS0,003/cửa sổ10ms: **{q['narration_max_quiet_seconds']}giây**. Chỉ là chỉ báo năng lượng, không phân tích âm vị.
- Giải khớp hai tay/hai chân ở các khung có nhân vật: {q['rig']['samples']}phép giải, {q['rig']['unreachable']}mục tiêu ngoài tầm, sai số chiều dài xương tối đa {q['rig']['maxBoneError']:.3g}.
- Đã sửa vị trí chân đứng trên sàn và tránh chữ chồng ở giả thuyết nút bấm trước bản xuất cuối. Bỏ ký tự mũi tên không có trong font; giữ dấu tiếng Việt và Delta có trong font. Chỉnh vùng di chuyển tay ở mặt cắt để không che tiêu đề.
- Cắt vùng ảnh từ **MP4 thực** để đo: ảnh vùng màn hình sau găng tay chạm chênh lệch RGB trung bình **{unchanged:.4f}/255** (ngưỡng2,5); mở ảnh bằng tay trần **{opened:.4f}**, kéo ảnh **{drag:.4f}**, phóng to **{zoomdiff:.4f}**. Các kiểm tra vùng ảnh xác nhận phản hồi/không phản hồi đã chọn, không tự chứng minh toàn bộ chất lượng mỹ thuật.
- Ví dụ nội suy nhiều điện cực có sai lệch tâm trọng số tối đa **{err:.6f}** theo tọa độ chuẩn hóa. Khoảng cách hai điểm minh họa tăng70→{np.hypot(160,44):.2f}px cùng ảnh tăng tỷ lệ1→1,65.
- Có contact sheet lấy từ MP4 mã hóa, kiểm tra phụ đề/rig và báo cáo Chromium phát1× đến cuối. Kiểm tra trình duyệt tự động tắt tiếng; không có thẩm âm bởi người và không tuyên bố người dùng đã duyệt.

## Phạm vi khoa học và giới hạn

Phim mô tả **cảm ứng điện dung phổ biến** bằng sơ đồ giản lược; không áp dụng khẳng định không đo lực cho mọi điện thoại/công nghệ màn hình. Một số thiết bị có phần cứng đo lực riêng; cảm ứng điện trở ngoài phạm vi phim.

Lưới8×10 chỉ để nhìn rõ cơ chế, không phải số điện cực/độ phân giải thật. Mô hình nội suy là ví dụ, không phải firmware hãng. Điện dung ở các điện cực có thể tăng/giảm tùy kiểu đo; thanh minh họa chỉ thể hiện độ lớn thay đổi, không phải giá trị hay chiều thay đổi phổ quát. Ngưỡng/đường sức minh họa không phải đo đạc vật lý. Găng tay thường có thể không nhận; loại dẫn điện có thể hoạt động. Âm tín hiệu là sonification, không phải tiếng thật của điện trường/cảm biến.

## Bảo toàn và chi phí

Tất cả tệp mới nằm trong dự án touchscreen riêng; không sửa Video Shotcraft, skill hoặc video ATM/dự án cũ. Model weights ở runtime ngoài Git. ZIP không có weights/secrets/video tham khảo. Mọi asset/nhạc/SFX mới tạo tại máy, không gọi API hay thuê bao/GPU trả phí.
''',encoding='utf-8')
print('REPORT',q['sha256'],'pixel checks',unchanged,opened,drag,zoomdiff)
