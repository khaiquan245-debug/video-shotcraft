from pathlib import Path
import json,wave,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000
S=json.loads((B/'manifests/story-times.json').read_text());vm=json.loads((B/'manifests/voice.json').read_text());D=S['end'];N=round(D*R);T=np.arange(N)/R;rng=np.random.default_rng(20261122)
with wave.open(str(B/'audio/narration-final.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float32)/32768;assert w.getframerate()==R
assert hashlib.sha256((B/'audio/narration-native.wav').read_bytes()).hexdigest()==vm['native_sha256']
V=np.zeros(N,np.float32);i=round(vm['offset']*R);V[i:i+len(raw)]=raw
F=np.zeros((N,2),np.float32);events=[]
def fx(kind,d):
 t=np.arange(round(d*R))/R;n=rng.normal(0,1,len(t));env=np.sin(np.pi*t/d)**2
 if kind=='key':a=(np.sin(2*np.pi*880*t)+.2*np.sin(2*np.pi*1320*t))*env
 elif kind=='chip':a=(np.sin(2*np.pi*1760*t)+.3*np.sin(2*np.pi*2350*t))*env
 elif kind=='motor':a=(.4*np.sin(2*np.pi*110*t)+.2*np.sin(2*np.pi*220*t)+.4*np.convolve(n,np.ones(21)/21,'same'))*env
 elif kind=='paper':a=(n-np.convolve(n,np.ones(22)/22,'same'))*.25*env
 elif kind=='click':a=(np.sin(2*np.pi*620*t)+.35*n)*np.exp(-t/.014)
 elif kind=='tray':a=(.7*np.sin(2*np.pi*185*t)+.2*np.sin(2*np.pi*390*t)+.1*n)*np.exp(-t/.04)
 elif kind=='confirm':a=(np.sin(2*np.pi*(659.25+220*(t>d*.45))*t)+.3*np.sin(2*np.pi*1318.5*t))*env
 elif kind=='whoosh':a=np.convolve(n,np.ones(19)/19,'same')*env
 elif kind=='step':a=(np.sin(2*np.pi*120*t)+.2*np.convolve(n,np.ones(9)/9,'same'))*np.exp(-t/.027)
 else:raise ValueError(kind)
 return a.astype(np.float32)
def add(at,kind,gain,d,pan,purpose):
 i=round(at*R);assert 0<=i<N
 x=fx(kind,d)[:N-i]*gain;F[i:i+len(x),0]+=x*np.sqrt((1-pan)/2);F[i:i+len(x),1]+=x*np.sqrt((1+pan)/2)
 events.append({'id':f'sfx-{len(events)+1:03}','time':round(at,6),'duration':d,'kind':kind,'gain_linear':gain,'pan':pan,'purpose':purpose,'source':'Original local oscillator/noise Foley in production/audio.py','rights':'Self-created'})
add(.6,'click',.04,.06,.1,'Bare fingertip reaches the screen in the opening')
add(.66,'confirm',.032,.18,.1,'Image opens following recognized touch')
add(S['mystery'],'whoosh',.045,.18,0,'Cut from phone macro to curious character')
for i in range(8):add(S['buttons']+.08+i*.105,'key',.019,.055,0,'Illustrative tiny-button hypothesis builds; not actual phone internals')
add(S['not_buttons']+.06,'whoosh',.07,.25,0,'Cross removes the false button hypothesis')
for at in [S['grid']+.1,S['grid']+.45,S['grid']+.9]:add(at,'paper',.026,.25,0,'Transparent glass and electrode layers separate in the schematic')
add(S['fields']+.06,'chip',.017,.17,0,'Field-line schematic appears; designed sonification, not audible electric discharge')
add(S['capacitance']+.97,'click',.026,.065,0,'Bare fingertip reaches fixed glass surface')
add(S['capacitance']+1.04,'confirm',.022,.15,0,'Illustrative capacitance-change indicator passes recognition threshold')
for at in np.arange(S['controller']+.08,S['coordinates']-.04,.35):add(float(at),'chip',.013,.055,.2,'Designed sonification of measured electrode signals arriving at controller')
add(S['coordinates']+.12,'confirm',.027,.16,0,'Controller resolves one position from neighboring electrode responses')
add(S['swipe']+.08,'paper',.022,S['gestures']-S['swipe']-.16,.1,'Finger drags image while contact position updates')
caps=json.loads((B/'manifests/captions.json').read_text());cue=lambda text:next(q['start']for q in caps if q['text']==text)
add(S['gestures']+.08,'paper',.022,.52,0,'Image drag follows the same contact trajectory')
add(cue('cuộn trang')+.02,'paper',.03,.35,0,'Page list scrolls upward with fingertip')
add(cue('hay phóng to')+.04,'whoosh',.045,.65,0,'Two contact points move apart and image enlarges')
add(S['teaser']+.18,'paper',.025,.3,.2,'Character introduces ordinary fabric glove')
add(S['glove']+.45,'paper',.035,.12,.2,'Fabric fingertip touches screen without a recognition chime')
for at in [S['no_response']+.08,S['no_response']+.85]:add(at,'paper',.028,.11,.2,'Soft physical fabric contact; phone picture remains unchanged and no UI response sound is added')
add(S['fabric']+.03,'whoosh',.045,.2,0,'Cut to fabric and weakened capacitance-change schematic')
add(S['no_pressure'],'click',.027,.08,.3,'Editorial cross rejects pressure measurement for the illustrated common capacitive sensor')
add(S['ending']+.06,'confirm',.035,.2,0,'Ending reconnects capacitance change with resolved screen coordinates')
# Original light technical score at 128 BPM. No sampled recordings or external music.
M=np.zeros(N,np.float32);scale=[293.665,440,349.228,523.251,391.995,349.228,440,261.626]
for k,at in enumerate(np.arange(.03,D-.25,60/128)):
 i=round(at*R);d=min(.62,(N-i)/R);tt=np.arange(round(d*R))/R;f=scale[k%8]
 z=(np.sin(2*np.pi*f*tt)+.24*np.sin(2*np.pi*f*2*tt)+.07*np.sin(2*np.pi*f*3*tt))*np.exp(-tt/.13)
 M[i:i+len(z)]+=.018*z
 if k%4==0:M[i:i+len(z)]+=.009*np.sin(2*np.pi*f/2*tt)*np.exp(-tt/.2)
noise=rng.normal(0,1,N).astype(np.float32);A=.005*np.convolve(noise,np.ones(37)/37,'same');A*=np.where((T<S['buttons'])|((T>=S['swipe'])&(T<S['gestures']))|((T>=S['teaser'])&(T<S['fabric'])),1,.5)
rms=np.sqrt(np.mean(V.reshape(-1,480)**2,axis=1));gate=np.convolve((rms>.012).astype(float),np.ones(15)/15,'same');M*=np.interp(np.arange(N),np.arange(len(gate))*480,1-.66*gate)
fade=np.minimum(1,np.minimum(T/.035,(D-T)/.24));M*=fade;A*=fade;F*=fade[:,None]
stereo=np.column_stack((V+M+A,V+M+.97*A))+F;pre=min(1.,.98/float(np.max(np.abs(stereo))));stereo*=pre

def save(name,a):
 with wave.open(str(B/'audio'/name),'wb')as w:w.setnchannels(1 if a.ndim==1 else 2);w.setsampwidth(2);w.setframerate(R);w.writeframes((np.clip(a,-.99,.99)*32767).astype('<i2').tobytes())
for name,a in [('voice-timeline.wav',V),('music.wav',M),('ambience.wav',A),('sfx.wav',F),('mix.wav',stereo)]:save(name,a)
caps=json.loads((B/'manifests/captions.json').read_text())
def ts(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
(B/'output/Man_Hinh_Cam_Ung.vi.srt').write_text('\n\n'.join(f'{i+1}\n{ts(q["start"])} --> {ts(q["end"])}\n{q["text"]}'for i,q in enumerate(caps)),encoding='utf-8')
(B/'manifests/sound-events.json').write_text(json.dumps({'events':events,'music':'Original light technical plucked composition,128 BPM','source':'All music, ambience and SFX generated locally with oscillators and noise; signal/field sounds are editorial sonification, not claims that the internal electronics audibly beep','pre_master_gain':pre,'paid_apis':False},ensure_ascii=False,indent=2));print('AUDIO',D,'seconds,',len(events),'original SFX cues; gain',pre)
