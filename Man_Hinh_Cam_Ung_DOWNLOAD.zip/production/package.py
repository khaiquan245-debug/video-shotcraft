from pathlib import Path
import json,hashlib,zipfile,shutil
B=Path(__file__).resolve().parents[1];O=B/'output';q=json.loads((B/'qa/final.json').read_text());p=Path(q['file']);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(p)==q['sha256']
pbf=B/'qa'/p.name.replace('.mp4','-playback.json');pb=json.loads(pbf.read_text());assert pb['sha256']==q['sha256']and pb['rate']==1 and pb['samples'][-1]['ended'];assert not any(s['error']for s in pb['samples'])
assert h(Path('/workspace/outputs/atm-cutaway-20261121/output/Ben_Trong_May_ATM_38_2s_1080x1920.mp4'))=='85cd55814b31295818ebcd5b39fbab15bc9c28f7b0b3463e6f2f423662351f0b'
assert ' '.join(c['text']for c in json.loads((B/'manifests/captions.json').read_text()))==' '.join((B/'audio/script-approved.txt').read_text().split())
m=json.loads((B/'audio/narration-native.json').read_text());assert h(B/'audio/narration-native.wav')==m['wav_sha256']
names=[p.name,'Man_Hinh_Cam_Ung.vi.srt','README.md','CREDITS.md','Production_Report.md','SHORTS_NHIP_KE_NHANH.md','Shot_Timeline.csv','SHA256SUMS.txt','index.html'];files=[(O/n,n)for n in names]
files += [(B/'audio'/n,'audio/'+n)for n in ['script-approved.txt','narration-native.wav','narration-final.wav']]
files += [(B/'assets'/n,'assets/'+n)for n in ['Nunito.ttf','OFL-Nunito.txt']]
files += [(f,'manifests/'+f.name)for f in sorted((B/'manifests').glob('*.json'))]
files += [(f,'production/'+f.name)for f in sorted((B/'production').iterdir())if f.is_file()]
files += [(B/'qa'/n,'qa/'+n)for n in ['final.json','final-rig.json','pacing-comparison.json','asset-origin.json','semantic-checks.json','Encoded_Contact_Sheet.jpg']]
files += [(pbf,'qa/browser-playback.json')]
keys=['engine','package_version','actual_backend','session_providers','inference_offline','model_source','canonical_voice','voice_metadata','preset_sha256','speed_method','language','requested_voice','speed','text','duration','sample_rate','channels','pcm_bits','execution_provider','start_offset','captions','alignment','peak_before_gain','gain','wav_sha256'];public_m={k:m[k]for k in keys if k in m}
zpath=O/'Man_Hinh_Cam_Ung_DOWNLOAD.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for src,name in files:
  assert src.is_file()and src.stat().st_size<100*1024*1024,src
  z.write(src,name)
 z.writestr('audio/narration-native.json',json.dumps(public_m,ensure_ascii=False,indent=2))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None
 assert hashlib.sha256(z.read(p.name)).hexdigest()==q['sha256']
 assert not any(n.endswith(('.onnx','.safetensors','.pt','.pth','.bin'))for n in z.namelist())
repo=Path('/tmp/touchscreen-download');repo.mkdir(exist_ok=False)
for n in [p.name,zpath.name,'README.md','CREDITS.md','Production_Report.md','SHORTS_NHIP_KE_NHANH.md','SHA256SUMS.txt','Man_Hinh_Cam_Ung.vi.srt']:shutil.copy2(O/n,repo/n)
report={'zip':str(zpath),'zip_bytes':zpath.stat().st_size,'zip_sha256':h(zpath),'mp4_sha256':q['sha256'],'mp4_bytes':p.stat().st_size,'entries':len(files)+1,'crc':'passed','model_weights_in_zip':False,'previous_atm_mp4_unchanged':True,'publication_repo':str(repo)};(B/'qa/package.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
