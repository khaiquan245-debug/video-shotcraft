from pathlib import Path
import json,wave,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];R=48000;OFFSET=.04
m=json.loads((B/'audio/narration-native.json').read_text());assert m['inference_offline']
with wave.open(str(B/'audio/narration-native.wav'))as w:raw=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').copy();assert w.getframerate()==R
parts=[];cursor=0;spans=[];trims=[]
for i,q in enumerate(m['captions']):
 x=raw[round(q['start']*R):round(q['end']*R)];k=len(x)//480;v=x[:k*480].astype(float)/32768;energy=np.sqrt(np.mean(v.reshape(-1,480)**2,axis=1));active=np.where(energy>max(.004,float(np.max(np.abs(v)))*.013))[0];assert len(active)
 a=max(0,int(active[0])*480-round(.04*R));z=min(len(x),(int(active[-1])+1)*480+round(.045*R));start=cursor/R;parts.append(x[a:z]);cursor+=z-a;spans.append({'text':q['text'],'start':start,'end':cursor/R});trims.append({'sentence':i,'leading_removed':a/R,'trailing_removed':(len(x)-z)/R})
 if i<len(m['captions'])-1:parts.append(np.zeros(round(.045*R),dtype='<i2'));cursor+=round(.045*R)
compact=np.concatenate(parts);tempo=max(1.,len(compact)/R/43.8)
with wave.open(str(B/'audio/narration-compact.wav'),'wb')as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(R);w.writeframes(compact.tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(B/'audio/narration-compact.wav'),'-af',f'atempo={tempo:.9f}','-ar',str(R),'-ac','1',str(B/'audio/narration-final.wav')],check=True)
with wave.open(str(B/'audio/narration-final.wav'))as w:vo_d=w.getnframes()/R
factor=len(compact)/R/vo_d
for s in spans:s.update(start=OFFSET+s['start']/factor,end=OFFSET+s['end']/factor)
D=math.ceil((OFFSET+vo_d+.35)*10)/10
phrases=[['Bạn chỉ cần','chạm nhẹ vào màn hình,','và điện thoại','lập tức biết','chính xác vị trí','ngón tay.'],['Nhưng làm sao','nó biết được?'],['Có phải bên dưới','màn hình có','hàng triệu nút bấm','tí hon?'],['Thực ra,','không phải vậy.'],['Bên dưới lớp kính','là một mạng lưới','điện cực trong suốt,','được sắp xếp','thành các hàng','và cột.'],['Chúng tạo ra','những điện trường','rất nhỏ.'],['Khi ngón tay bạn','tiến đến gần,','cơ thể bạn','làm thay đổi','điện dung','tại khu vực đó.'],['Bộ điều khiển','cảm ứng liên tục đo','những thay đổi này.'],['Nó so sánh','tín hiệu từ','nhiều điện cực','để tính ra','tọa độ ngón tay.'],['Và khi bạn','vuốt màn hình,','vị trí ấy','được cập nhật','liên tục.'],['Nhờ vậy,','điện thoại biết','bạn đang kéo ảnh,','cuộn trang','hay phóng to','bằng hai ngón tay.'],['Nhưng có','một điều thú vị.'],['Hãy thử dùng','một chiếc găng tay','thông thường.'],['Màn hình có thể','không phản hồi!'],['Bởi vì lớp vải','khiến ngón tay','khó tạo ra','thay đổi điện dung','đủ lớn','để cảm biến nhận biết.'],['Vậy nên,','màn hình không','thực sự cảm nhận','được áp lực ngón tay.'],['Nó đang phát hiện','sự thay đổi','của một điện trường','vô hình!']]
assert len(spans)==len(phrases),(len(spans),len(phrases));caps=[]
for s,ps in zip(spans,phrases):
 assert ' '.join(ps)==s['text'],(ps,s['text'])
 total=sum(len(p.split())for p in ps);a=s['start']
 for j,p in enumerate(ps):
  z=s['end']if j==len(ps)-1 else a+(s['end']-s['start'])*len(p.split())/total
  caps.append({'text':p,'start':a,'end':z,'emphasis':any(k in p for k in ['điện dung','điện trường','không phản hồi','tọa độ','không phải','hai ngón'])});a=z
assert ' '.join(q['text']for q in caps)==' '.join((B/'audio/script-approved.txt').read_text().split())
keys=['touch','mystery','buttons','not_buttons','grid','fields','capacitance','controller','coordinates','swipe','gestures','teaser','glove','no_response','fabric','no_pressure','ending'];S={k:s['start']for k,s in zip(keys,spans)};S['touch']=0.;S['end']=D
(B/'manifests/story-times.json').write_text(json.dumps(S,indent=2));(B/'manifests/captions.json').write_text(json.dumps(caps,ensure_ascii=False,indent=2))
meta={'duration':D,'vo_duration':vo_d,'native_duration':m['duration'],'compacted_duration':len(compact)/R,'offset':OFFSET,'pitch_preserving_tempo':tempo,'native_sha256':m['wav_sha256'],'voice_sha256':hashlib.sha256((B/'audio/narration-final.wav').read_bytes()).hexdigest(),'trim_log':trims,'sentence_spans':spans,'space_units':221,'model':m['engine'],'canonical_voice':m['canonical_voice'],'requested_voice':m['requested_voice'],'offline':True}
(B/'manifests/voice.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(B/'manifests/project.json').write_text(json.dumps({'title':'Màn hình biết ngón tay bạn ở đâu bằng cách nào?','duration':D,'resolution':[1080,1920],'fps':30,'aspect':'9:16','style':'Original2D character and capacitive-touch explainer, continuing previous ATM Short','script':'Exact user narration, no additions','pacing_reference_sha256':'2b47c5289cbed7b4416db2c033b44561b72e4f0230fd7601812a9a944ad36ca4','schematic':'Simplified projected-capacitive touchscreen; not every kind of touchscreen or pressure-sensing hardware','paid_apis':False},ensure_ascii=False,indent=2))
print('VOICE',json.dumps({k:meta[k]for k in ['native_duration','compacted_duration','vo_duration','duration','pitch_preserving_tempo','space_units']}));print('STORY',S)
